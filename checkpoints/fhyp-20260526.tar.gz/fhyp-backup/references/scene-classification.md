# Scene Classification Reference (v4.1)

## Classifier Logic (in priority order)

| Priority | Type | Trigger Keywords | Notes |
|----------|------|-----------------|-------|
| 1 | `outro` | `outro`, `end card`, `subscribe`, `اشترك` | Arabic `اشترك` anywhere in text triggers this |
| 2 | `opener` | `الخلاصة`, `summary`, `opener`, `intro`, `conclusion` | Checked BEFORE comparison — prevents `الخلاصة ولا` from matching comparison |
| 3 | `comparison` | `versus`, `side by side`, `compare`, `against`, `ضد` + regex `\b\w+\s+vs[.\s]\s*\w+\b` + `\b\w+\s+(ولا)\s+\w+\b` (if no الخلاصة) | Arabic ولا/ضد supported. Only 1 word + optional number captured after comparison word |
| 4 | `gameplay` | `gameplay`, `combat`, `battle`, `fight`, `deep dive`, `gaming` (unless price/cost/budget present) | `gaming` triggers unless budget keywords also present |
| 5 | `stats` | `N%` pattern, starts with `$` or digit, or keywords in first 60 chars: `95%`, `percent`, `budget`, `price point`, `entry level`, `high end` | Handles `$1500+` prefix (fixed in v4) |
| 6 | `opener` | (fallback) | Any scene that doesn't match above |

## Presentation Scenes

Not auto-classified. Triggered by the extractor when `## Title` + `- bullets` pattern is detected in input.

## Forcing a Type

```bash
hyperframes-broll --type stats "85% of players failed this level"
hyperframes-broll --type gameplay "PC gaming deep dive — performance comparison"
```

## Pitfalls

- **"game" in "gaming"**: `gaming` contains `game` so `gameplay` check triggers. Use `game` keyword carefully.
- **"ولا" in "الخلاصة"**: The opener check runs BEFORE comparison to prevent الخلاصة PC ولا Console from being classified as comparison.
- **"$1500+" stats**: The `$` prefix wasn't handled before v4 — stats classified as opener. Fixed with `r'^\$?\d+'`.
- **"gamer" vs "gaming"**: `gamer` doesn't contain `gameplay` but triggers via `gaming` check. Use more specific descriptions if classification is wrong.
