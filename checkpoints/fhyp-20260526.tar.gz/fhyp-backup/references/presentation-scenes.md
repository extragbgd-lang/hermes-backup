# Presentation Scenes — Kinetic Typography Reference

## Input Format

Use `## Title` header with `- bullet` lines:

```
## مقارنة بي سي و كونسول
- بي سي أداء أعلى و تخصيص كامل
- كونسول أرخص و أسهل في التشغيل
- الفرق واضح في الألعاب الثقيلة
```

## How the Parser Works

1. Lines starting with `##` or `###` start a new presentation scene
2. Following lines starting with `-` or `*` are bullet points
3. Blank lines separate scenes
4. Regular text (no `##` prefix) is treated as a simple scene

## Auto-Highlighting Rules

The `highlight_arabic_terms()` function wraps known gaming terms in `<span>` tags:

| Term | Class | Color |
|------|-------|-------|
| بي سي, جيمينج, مسمار, أداء, فريمات, رسومات, معالج, كارت, رامات | `hl-red` | #ff0040 neon red |
| كونسول, لابتوب, سعر, تبريد | `hl-blue` | #00d4ff neon blue |
| Any numbers (e.g., 1500, 95%, 3) | `hl-num` | #00d4ff neon blue |

## Animation Timing

| # Bullets | Total Duration | Bullet Start Times |
|-----------|---------------|-------------------|
| 1 | 10.0s | 2.0s |
| 2 | 12.0s | 2.0s, 4.8s |
| 3 | 12.0s | 2.0s, 4.8s, 7.6s |
| 4 | 14.8s | 2.0s, 4.8s, 7.6s, 10.4s |
| 5 | 17.6s | 2.0s, 4.8s, 7.6s, 10.4s, 13.2s |

Formula: `total = max(12, 2.0 + n * 2.8 + 3.0)` seconds

## CSS Structure

- `.presentation-content` — RTL container, positioned at vertical center, 80px left/right padding
- `.pres-title` — 64px Cairo, white with neon-red text-shadow
- `.accent-line` — 180px red line under title
- `.bullet-item` — flex row, marker + content
- `.bullet-marker` — ◆ red diamond with glow
- `.bullet-content` — 38px Rubik body text
- `.hl-red` — neon red for gaming terms
- `.hl-blue` — neon blue for gaming terms  
- `.hl-num` — larger neon blue for numbers

## HTML Generation

The `generate_presentation_html()` function in the pipeline:
1. Takes `desc` (raw multiline scene text)
2. Splits into title (line 1) and bullets (remaining lines)
3. Applies `highlight_arabic_terms()` to each bullet
4. Builds GSAP timeline with sequential `fromTo` animations
5. Each bullet starts at `opacity: 0` and slides from `x: -80` to `x: 0`

## Combining With Section Intros

Presentation and simple scenes can coexist in the same script file:

```
## Presentation Title
- Bullet one
- Bullet two

Simple Comparison Scene Line
Another Simple Scene
اشترك الآن
```
