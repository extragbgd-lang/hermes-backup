# Composition Templates Reference

## Template Structure (All Scene Types)

Every generated composition follows this HyperFrames structure:

```html
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Scene Name</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@700;900&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/gsap@3/dist/gsap.min.js"></script>
  <style>/* GameySins brand CSS */</style>
</head>
<body>
  <div data-composition-id="scene-id" data-width="1920" data-height="1080">
    <!-- Scene-specific layers -->
  </div>
  <script>
    window.__timelines = window.__timelines || {};
    window.__timelines["scene-id"] = gsap.timeline({ paused: true });
    const tl = window.__timelines["scene-id"];
    // fromTo animations only
  </script>
</body>
</html>
```

## Scene Types

### 1. Opener (5s)
Dramatic title card. Uses: `generate_opener_html()`
- Red glow top-right, blue glow bottom-left
- 90px Cairo title with neon-red text-shadow
- 40px Rubik subtitle in neon-blue
- Accent line divider between title and subtitle
- Animations: glows fade in → title slides up → accent line scales in → subtitle fades in → hold to end

### 2. Gameplay (4s)
Action-focused gameplay b-roll. Uses: `generate_gameplay_html()`
- Diagonal gradient background
- Red/blue glows in triangular formation + center pulse
- Gameplay tag badge (top) + 90px Cairo title
- Energetic entrances: tag drops in with back.out ease → title scales from 0.5 with rotation
- Hold to end (no exit animation)

### 3. Comparison (6s)
Side-by-side comparison. Uses: `generate_comparison_html()`
- Red glow left (PC side), blue glow right (Console side)
- Two 50% halves with `comparison-container` flex layout
- 4px neon-red divider between them
- Animated "VS" badge in center (spins in with back.out)
- Animations: glows → left title slides from left → divider grows → right title slides from right → VS spins in → hold

### 4. Stats (5s)
Animated numbers display. Uses: `generate_stats_html()`
- Centered layout with top glow
- 140px Cairo stat number in neon-red
- Accent line + 42px Rubik label below
- Animations: glow → number scales up with back.out → accent line → label fades in → hold

### 5. Outro (5s)
End card with subscribe CTA. Uses: `generate_outro_html()`
- 90px "اشترك الآن" subscribe text
- Accent line + 56px channel name "@GameySins"
- Animations: glows → subscribe text fades in → accent line → channel name → **fade to black** (all elements fade out at end, unlike other scene types)

## GSAP Rules (for template authors)

- Use `fromTo()` always — never `from()`, never `to()` (except outro scene for exit)
- First animation offset: `0.3–0.5s` (not t=0)
- Vary eases across a scene: use at least 3 different eases per scene
- Never `repeat: -1` — calculate exact repeats from duration
- No `Math.random()` or `Date.now()`
- Register timeline on `window.__timelines[compId]`
- Timeline must be `{ paused: true }`
