# Companion Skill: html-broll-diagrams

The `html-broll-diagrams` skill (content-creation category) generates diagram-based b-roll footage from Mermaid SVG diagrams embedded in HyperFrames compositions. Run it before or after `hyperframes-broll` for visual explanations.

## When to use it
- Video has comparisons, stats, evolution timelines → use html-broll-diagrams for diagram b-roll
- Video needs kinetic text scenes → use hyperframes-broll for text animations
- Both → run in parallel

## Workflow
1. Script → html-broll-diagrams (generate SVGs + HTML composition)
2. Script → hyperframes-broll (generate animated text scenes)
3. Combine in editor (diagrams as interstitial b-roll between text scenes)

## Language rule
Both skills produce Arabic content files. Chat with the user stays 100% English.

## Diagrams output location
`/mnt/d/hyperframe/output/diagrams/`

## B-roll composition location
`/mnt/d/hyperframe/output/TOPIC-diagrams/`