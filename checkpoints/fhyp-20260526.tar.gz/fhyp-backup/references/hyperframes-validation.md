# HyperFrames Validation & Rendering Reference

## Required Root Attributes (v0.6.34+)

Every composition's root `<div>` MUST have:

```html
<div data-composition-id="scene_id" data-width="1920" data-height="1080" data-start="0">
```

Missing `data-start="0"` triggers: `root_composition_missing_data_start` warning.
Missing `data-composition-id` triggers: `root_missing_composition_id` error.

## Required Runtime API: `window.__hf` (v0.6.34+)

This is the **most commonly missed requirement**. Without `window.__hf`, HyperFrames cannot discover or control the composition, producing:

```
✗ root_missing_composition_id [bg-layer]: Root composition is missing data-composition-id.
✗ root_missing_dimensions [bg-layer]: Root composition is missing data-width or data-height.
```

**Fix:** Register `window.__hf` in every composition AFTER the GSAP timeline:

```javascript
window.__hf = {
  duration: Math.max(10.0, tl.duration()),  // total seconds
  seek: function(t) {
    tl.seek(t);
  }
};
```

The `duration` field tells HyperFrames the total composition length. The `seek` function lets it scrub the timeline programmatically during frame capture.

**Common pattern (from generators):**

```javascript
window.__timelines = window.__timelines || {};
window.__timelines["comp_id"] = gsap.timeline({ paused: true });
const tl = window.__timelines["comp_id"];
// ... animations ...
tl.to({}, { duration: 8 }, 3);

window.__hf = {
  duration: tl.duration(),
  seek: function(t) { tl.seek(t); }
};
```

## Warnings That Can Be Ignored

HyperFrames v0.6.34 auto-handles these, they're non-blocking:

| Warning | What HyperFrames Does |
|---------|----------------------|
| `google_fonts_import` | Fetches Google Fonts .woff2 files and inlines @font-face rules |
| `font_family_without_font_face` | Adds @font-face declarations automatically |
| `composition_self_attribute_selector` | Minor CSS specificity warning, harmless |
| `root_composition_missing_data_start` | Add `data-start="0"` to root (fixed in v4.1+) |

## Render Failure: WSL FFmpeg

**Symptom:** Render compiles but fails at encoding:
```
[in#0] Error opening input file /mnt/d/.../captured-frames/frame_%06d.jpg
```

**Cause:** HyperFrames calls system FFmpeg to encode frames. If WSL has a Windows FFmpeg binary (gyan.dev) in PATH, it cannot read `/mnt/d/` Linux paths.

**Fix — Option A:** Render from Windows CMD:
```cmd
cd /d D:\hyperframe output
render_all.bat
```

**Fix — Option B:** Install Linux FFmpeg in WSL:
```bash
sudo apt install ffmpeg
```

**Fix — Option C:** Use `--docker` flag (requires Docker):
```bash
npx hyperframes render --docker --dir "D:\..." --output "..."
```

## Checking Validation

To see all warnings without full render:
```bash
npx hyperframes render --dir "D:\hyperframe output\scene_01" --output "D:\hyperframe output\rendered\test.mp4" 2>&1 | grep -E "⚠|✓|✗"
```

The render will continue despite warnings unless `--strict` is passed.

## Output Format

- Resolution: 1920×1080 (16:9)
- Codec: H.264 (via FFmpeg)
- FPS: 30
- GPU: auto-detected (WebGL hardware acceleration)
