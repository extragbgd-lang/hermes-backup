# NotebookLM Browser Automation (Updated May 2026)

## Primary Method: Chrome CDP (No Timeouts)

Use the user's own Chrome with remote debugging. See `quick-facts-pipeline` → `references/chrome-remote-debugging.md` for full setup.

The 5-minute Browserbase free plan timeout is **no longer a limitation** — Chrome CDP has no session limits.

Credentials: `hermossybatooty@gmail.com` / `IamDangerous`

## Email Spelling

`hermossybatooty` (double 's'). Single 's' fails.

## NotebookLM Login via CDP

When using user's Chrome, they're usually already logged into Google. If not:
1. Navigate to `https://notebooklm.google.com`
2. If redirected to Google sign-in, fill email + password (it's a direct form, not OAuth popup)
3. Use `Runtime.evaluate` + `Input.dispatchMouseEvent` for form interactions

## NotebookLM Workflow (CDP)

1. **Navigate** to notebook: `Page.navigate` to `https://notebooklm.google.com/notebook/<ID>`
2. **Click "Sources" tab** to expand the source panel
3. **Add source:** Click "Add source" → "Copied text" → paste script → Insert
4. **Generate Video Overview:** Click "Video Overview" in Studio panel → Customize → Generate
5. **Wait** 60-180s (poll via `Runtime.evaluate` checking for "Generating" text)
6. **Download:** Click `more_vert` on the completed video → "Download"
7. **Retrieve** from `/mnt/c/Users/ammar/Downloads/`

## Notebook IDs

- **GameSins:** `3b421487-9ac0-4d06-bea4-957604998c70`
- **Quick Facts (Sputnik):** `5ccb2287-1917-4a32-a846-0c310ba6b06e`

## Legacy: Browse CLI Method (Deprecated)

The old `browse` CLI approach with Browserbase had 5-min timeouts and Google headless detection. Only use if Chrome CDP is unavailable.

```bash
browse stop 2>/dev/null; sleep 1
browse open https://notebooklm.google.com
browse fill <ref> "hermossybatooty@gmail.com"
browse click <ref>
```

## Download Output

Move from `C:\Users\ammar\Downloads\` to the appropriate D: drive output directory.

Video Overview generation takes 30-180s. Check for completion by evaluating `document.body.innerText.includes('Download')`.
