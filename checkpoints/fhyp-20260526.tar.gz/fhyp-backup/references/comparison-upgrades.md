# Comparison Scene Upgrades — Split-Screen Layouts

When the user says comparisons aren't clear enough (pipeline's sequential bullets), upgrade to these split-screen patterns.

## Pattern 1: Side-by-Side Vertical Split (GPU Price Comparison)

**Structure:** Left half | vertical divider | Right half | bottom banner

**HTML pattern:**
```html
<div class="clip layer" data-start="0" data-duration="12" data-track-index="1">
<div class="comparison-container">
  <div class="comparison-half" style="background:linear-gradient(135deg,rgba(0,0,0,0.9),rgba(0,212,255,0.08));justify-content:center;">
    <div style="font-family:'Cairo',sans-serif;font-size:36px;font-weight:700;color:var(--neon-blue);">CONSOLE</div>
    <div style="font-family:'Cairo',sans-serif;font-size:72px;font-weight:900;color:white;text-shadow:0 0 40px var(--neon-blue);" id="leftLabel">PS5 Pro</div>
    <div style="font-family:'Rubik',sans-serif;font-size:36px;font-weight:500;color:var(--neon-blue);">$899</div>
  </div>
  <div class="comparison-divider" style="height:60%;"></div>
  <div class="comparison-half" style="background:linear-gradient(225deg,rgba(0,0,0,0.9),rgba(255,0,64,0.08));justify-content:center;">
    <div style="font-family:'Cairo',sans-serif;font-size:36px;font-weight:700;color:var(--neon-red);">PC</div>
    <div style="font-family:'Cairo',sans-serif;font-size:72px;font-weight:900;color:white;text-shadow:0 0 40px var(--neon-red);" id="rightLabel">RTX 5070</div>
    <div style="font-family:'Rubik',sans-serif;font-size:36px;font-weight:500;color:var(--neon-red);">$599</div>
  </div>
</div>
</div>
<div class="clip layer" data-start="0" data-duration="12" data-track-index="2">
<div style="position:absolute;bottom:60px;left:0;right:0;text-align:center;">
<div style="display:inline-block;background:rgba(255,255,255,0.1);backdrop-filter:blur(10px);padding:20px 60px;border-radius:16px;border:2px solid var(--neon-red);" id="banner">
<div style="font-family:'Cairo',sans-serif;font-size:48px;font-weight:900;color:#ffd700;">الفرق $300 فقط</div>
</div>
</div>
</div>
```

**GSAP Timeline:**
```javascript
tl.fromTo("#leftLabel",{x:-60,opacity:0,scale:0.9},{x:0,opacity:1,scale:1,duration:0.8,ease:"back.out(2)"},0.5);
tl.fromTo("#rightLabel",{x:60,opacity:0,scale:0.9},{x:0,opacity:1,scale:1,duration:0.8,ease:"back.out(2)"},0.8);
tl.fromTo("#banner",{y:40,opacity:0,scale:0.8},{y:0,opacity:1,scale:1,duration:1,ease:"elastic.out(1,0.3)"},1.5);
tl.to("#banner",{scale:1.05,duration:0.4,ease:"power1.inOut",repeat:2,yoyo:true},5);
tl.to({},{duration:9.5},3);
```

## Pattern 2: Side-by-Side with Game Lists (Xbox vs PS5 Games)

**Structure:** Left (green) | blue divider | Right (blue) — game names listed on each side

**HTML pattern:**
- Left: green theme with `#xTitle` (🎮 Xbox Game Pass) + `#xList` (Halo, Forza, Starfield)
- Right: blue theme with `#pTitle` (⭐ PS5 Exclusives) + `#pList` (Spider-Man 2, God of War, Last of Us)
- Center: `.comparison-divider` with blue glow

```html
<div style="font-family:'Rubik',sans-serif;font-size:30px;font-weight:400;color:rgba(255,255,255,0.85);line-height:2;text-align:center;" id="xList">Halo<br>Forza<br>Starfield</div>
```

**GSAP Timeline:**
```javascript
tl.fromTo("#xTitle",{x:-60,opacity:0,rotation:-5},{x:0,opacity:1,rotation:0,duration:0.9,ease:"power3.out"},0.5);
tl.fromTo("#pTitle",{x:60,opacity:0,rotation:5},{x:0,opacity:1,rotation:0,duration:0.9,ease:"power3.out"},0.8);
tl.fromTo("#xList",{y:30,opacity:0},{y:0,opacity:1,duration:0.8,ease:"power2.out"},1.3);
tl.fromTo("#pList",{y:30,opacity:0},{y:0,opacity:1,duration:0.8,ease:"power2.out"},1.6);
```

## Pattern 3: Top/Bottom Horizontal Split (Switch 2 — Docked vs Handheld)

**Structure:** Top half (docked) | horizontal divider line | Bottom half (handheld)

**HTML pattern:**
- Top 50%: label "DOCKED" + "#dockLabel" (4K) + game subtitle
- Bottom 50%: label "HANDHELD" + "#handheldLabel" (120Hz) + game subtitle
- Center: glowing red dot + horizontal gradient line as divider

**GSAP Timeline:**
```javascript
tl.fromTo("#dockLabel",{y:-40,opacity:0,scale:0.5},{y:0,opacity:1,scale:1,duration:0.8,ease:"back.out(2)"},0.5);
tl.fromTo("#handheldLabel",{y:40,opacity:0,scale:0.5},{y:0,opacity:1,scale:1,duration:0.8,ease:"back.out(2)"},1.0);
```

## Pattern 4: Three-Column Scoreboard (PC vs Console vs Laptop)

**Structure:** 3 columns with animated scores + winner banner

**HTML pattern:**
- Top: trophy emoji "#trophy"
- 3 columns: PC (gold), Console (blue), Laptop (grey) — each with `#scorePc`, `#scoreConsole`, `#scoreLaptop`
- Bottom: "#winner" banner
- Column dividers between each

**GSAP Timeline:**
```javascript
tl.fromTo("#trophy",{y:-40,opacity:0,scale:0,rotation:-30},{y:0,opacity:1,scale:1,rotation:0,duration:1,ease:"elastic.out(1,0.3)"},0.2);
tl.fromTo("#scorePc",{y:40,opacity:0,scale:0.3},{y:0,opacity:1,scale:1,duration:0.8,ease:"back.out(3)"},0.8);
tl.fromTo("#scoreConsole",{y:40,opacity:0,scale:0.3},{y:0,opacity:1,scale:1,duration:0.8,ease:"back.out(3)"},1.1);
tl.fromTo("#scoreLaptop",{y:40,opacity:0,scale:0.3},{y:0,opacity:1,scale:1,duration:0.8,ease:"power2.out"},1.4);
tl.fromTo("#winner",{y:30,opacity:0},{y:0,opacity:1,duration:1,ease:"power3.out"},1.8);
tl.to("#winner",{scale:1.05,duration:0.5,ease:"power1.inOut",repeat:2,yoyo:true},3);
```

## When to Upgrade

- Any scene classified by the pipeline as `comparison` (has "vs" / "versus" / "comparison" in title / "ولا" / "ضد")
- Any scene where the user explicitly wants to compare two or three items side by side
- Three-way splits (Cyberpunk PC/PS5/Laptop) should use Pattern 4 with 3 columns

## Existing CSS Classes Available

Every generated index.html already has these in the `<style>` block:
- `.comparison-container` — flex row, 100% width/height
- `.comparison-half` — flex:1, centered content, padding: 40px 30px
- `.comparison-divider` — 4px wide, 70% height, neon red glow by default
- `.stat-number` — 120px Cairo 900, neon red with glow
- `.stat-label` — 36px Rubik 500, white

Use these to avoid adding new CSS. Override inline via `style=""` for per-half colors.
