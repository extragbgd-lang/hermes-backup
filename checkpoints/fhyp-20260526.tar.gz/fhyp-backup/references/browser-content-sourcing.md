# Browser-Based Content Sourcing (NotebookLM, AI Platforms)

## Overview

Browser automation feeds GameySins video scripts into AI content platforms (NotebookLM) that generate free cloud-rendered video content (Video Overviews, Slide Decks). This runs **in parallel** with the direct CLI pipeline (`hyperframes-broll`) — BOTH output paths fire whenever a script is processed.

## Prerequisites

- **BROWSERBASE_API_KEY** and **BROWSERBASE_PROJECT_ID** in `~/.hermes/.env` (from browserbase.com/settings)
- **Browse CLI** installed: `npm i -g browse`
- **NOTEBOOKLM_EMAIL** and **NOTEBOOKLM_PASSWORD** in `~/.hermes/.env`
- **Browserbase residential proxies** enabled: `BROWSERBASE_PROXIES=true` in `.env` (already set)

## Tooling

- **`browse` CLI** (`npm i -g browse`) — primary tool for Browserbase cloud sessions
- **Hermes `browser_*` tools** — built-in browser tools (use local Chromium unless Browserbase env vars are set)
- **Gemini API** (`GOOGLE_API_KEY` in `.env`) — fallback for text analysis when browser automation isn't needed

## Critical Discovery: Direct Email Login WORKS

**Previous approaches used Session Live View (user logs in via browser link). This is no longer needed.**

Direct `browse fill` of email + password fields works with Browserbase cloud sessions. Google does NOT block the login when:
- `BROWSERBASE_PROXIES=true` (residential proxies enabled)
- The correct email (`hermossybatooty@gmail.com` — double 's') is used
- The password is entered directly via `browse fill`

### Email Spelling Trap

The correct email is **hermossybatooty** (double 's'). `hermosy` (one 's') gives "Couldn't find your Google Account".

## NotebookLM Workflow (Direct Login)

[NotebookLM](https://notebooklm.google.com) processes uploaded documents and generates:

- **Video Overviews** — slide-style videos with AI narration, images, diagrams (main target)
- **Audio Overviews** — podcast-like discussions between AI hosts
- **Slide Deck** — presentation decks from source material
- **Infographics** — visual data representations
- **Data Tables** — structured output from documents

### Step-by-Step

#### 1. Start Browserbase Session

```bash
browse stop 2>/dev/null; sleep 1
browse open https://notebooklm.google.com
browse snapshot
```

#### 2. Login to Google (Direct Fill)

```bash
# Email page
browse fill <email-ref> "hermossybatooty@gmail.com"
browse click <next-ref>
sleep 2

# Password page
browse snapshot  # Get the new refs after Next
browse fill <password-ref> "IamDangerous"
browse click <next-ref>
sleep 3
```

**Element refs shift between sessions.** Always use `browse snapshot` before each action to find the current refs. Typical patterns:

| Page | Field | Typical Refs |
|------|-------|-------------|
| Login (email) | Email field | `4-17`, `4-9` |
| Login (email) | Next button | `4-276`, `4-271` |
| Login (password) | Password field | `4-964`, `4-959` |
| Login (password) | Next button | `4-1029`, `4-1024` |

#### 3. Open Notebook & Upload Script

```bash
# Find the notebook in the snapshot and click it
browse snapshot
browse click <notebook-ref>

# Add source via "Copied text" option
browse click <copied-text-ref>

# Paste the full script
browse fill <paste-ref> "$(cat /path/to/script.txt)"

# Insert the source
browse click <insert-ref>

# Wait for processing (15-30s)
sleep 20
```

**Notebook Info:**
- **Name:** "GameSins - Content Creation Hub"
- **ID:** `3b421487-9ac0-4d06-bea4-957604998c70`
- **Existing sources:** 1 — "The GameSins Brand Manual and Style Guide"
- Brand guide stays as permanent reference; add scripts as additional sources

#### 4. Generate Video Overview

```bash
browse snapshot  # Find the Video Overview button/option
browse click <video-overview-ref>

# Generation takes 30-180s — poll every 15s
sleep 30
browse snapshot  # Check if "Download" button appears
# If not done: sleep 15, repeat snapshot until download button visible
```

#### 5. Download Output

```bash
# Click download button
browse click <download-ref>
sleep 5

# Move downloaded file to D: drive
mkdir -p "/mnt/d/hyperframe output/notebooklm/"
mv ~/Downloads/*.mp4 "/mnt/d/hyperframe output/notebooklm/" 2>/dev/null || \
  mv /tmp/*.mp4 "/mnt/d/hyperframe output/notebooklm/" 2>/dev/null || \
  echo "Check browser download folder for the file"
```

### 5-Minute Session Timeout

Browserbase free plan sessions expire after **5 minutes** (project defaultTimeout: 300s). No keepAlive or timeout override.

**Pattern for long operations:** If the session dies mid-operation:
```bash
browse stop 2>/dev/null; sleep 1
browse open https://notebooklm.google.com
# Re-login and navigate back to where you were
```

### Key Browse CLI Commands

| Command | Purpose |
|---------|---------|
| `browse open <url>` | Navigate + create session |
| `browse snapshot` | Get accessibility tree (find element refs like `7-1277`) |
| `browse click <ref>` | Click element by ref |
| `browse fill <ref> <text>` | Fill input field |
| `browse type <text>` | Type text at current focus |
| `browse upload <ref> <path>` | Upload file into file input |
| `browse screenshot` | Capture screenshot |
| `browse eval <js>` | Execute JavaScript in the page |
| `browse status` | Check session health |
| `browse stop` | Kill daemon + clean up session |

## Parallel Execution Pattern

Whenever b-roll is generated via `hyperframes-broll`:

```
┌─ hyperframes-broll ─────────────────┐
│  Generated: /mnt/d/hyperframe output/│
│  HTML compositions ready for render  │
└──────────────────────────────────────┘

⟷ RUN IN PARALLEL ⟷

┌─ NotebookLM ─────────────────────────┐
│  Generated: /mnt/d/hyperframe output/ │
│             notebooklm/*.mp4          │
│  Cloud-rendered Video Overview ready  │
└──────────────────────────────────────┘
```

## Fallback: Gemini API (No Browser Needed)

If browser automation fails or session expires:

```python
# python3 -c "
import google.generativeai as genai
genai.configure(api_key='YOUR_GOOGLE_API_KEY')
model = genai.GenerativeModel('gemini-2.0-flash')
response = model.generate_content('Analyze this gaming script and provide a scene-by-scene shot list with suggested visuals:\n' + script_text)
print(response.text)
```

Use for: text-based scene breakdowns, shot lists, visual descriptions that feed into HyperFrames.

## Pitfalls

- **Session timeout is 5 minutes** on free Browserbase plan. Work fast or restart the session.
- **Element refs shift between sessions.** Always `browse snapshot` before clicking — never hardcode refs.
- **No public API** — NotebookLM is web-UI only. Browser automation is the sole integration path.
- **Download destination varies.** Check browser download dir — files may go to `~/Downloads/`, `/tmp/`, or browser's temp cache.
- **Don't re-upload brand guide.** Only the first-source setup added it. Brand guide stays; add only new scripts as sources.
