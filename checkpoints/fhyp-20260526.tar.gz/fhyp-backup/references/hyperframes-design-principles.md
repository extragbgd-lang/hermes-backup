# HyperFrames Design Principles for GameSins

## Font Setup (CRITICAL for Windows Render)

- Fonts live at: `/mnt/d/Hermes project/output/assets/fonts/` (Cairo 3 weights + Rubik 3 weights)
- **MUST be COPIED into the composition, NOT symlinked** — WSL symlinks (`ln -sf`) don't resolve when `npx hyperframes render` runs from Windows CMD
- Copy command: `mkdir -p fonts && cp /mnt/d/Hermes\ project/output/assets/fonts/*.ttf fonts/`
- @font-face path in index.html: `url('fonts/Cairo-Regular.ttf') format('truetype')` (relative from index.html)
- Every composition needs its own `fonts/` dir with real files

## Element Sizing (1920×1080 canvas)

Aim for these sizes — they're proven to look clean at rendered output:

| Element | Size | Font | Weight |
|---------|------|------|--------|
| Hero headline | **120px** | Cairo | 900 |
| Secondary title | **72px** | Cairo | 900 |
| Stat number | **120px** | Cairo | 900 |
| Stat price | **48px** | Cairo | 700 |
| Subtitle/tagline | **48px** | Rubik | 500 |
| Body/list point | **36px** | Rubik | 400 |
| Badge/label | **40px** | Cairo | 700 |
| VS badge | **96px** | Cairo | 900 |
| Small print | **20-22px** | Rubik | 400 |

## Spacing & Layout

- **Side padding:** 120-160px minimum. Never less than 80px on any side.
- **Element gap:** 24px between headline and accent line, 16-20px between text elements, 40px+ between distinct sections.
- **Bottom banner:** Position at `bottom: 80px`, padding `24px 80px`, border-radius `20px`.
- **Split-screen halves:** Each half gets `padding: 60px 40px` and `flex:1`.

## Brand Color Application

- **Background:** Midnight blue `#0a0e1a` via `radial-gradient(ellipse at 50% 50%, #0a0e1a 0%, #000 100%)` — not pure black `#000`.
- **Rim lighting glow:** Use `<div class="rim" style="background:#COLOR;width:400px;height:400px;filter:blur(120px);opacity:0.25;">` behind key elements.
- **Particles:** Opener scenes get 12 deterministic-position particles (pre-computed array, no Math.random()).
- **Text:** White headlines get `-webkit-text-stroke:2px rgba(0,0,0,0.5)` + `text-shadow:0 0 40px currentColor,0 4px 8px rgba(0,0,0,0.8)`.
- **Accent lines:** 160px × 6px, brand color, `border-radius:3px`, `margin:24px auto`.

## Avoiding Linter False Positives

### CSS var() in HTML attributes
The linter's JS parser scans the entire file. `style="background:var(--red)"` is read as JavaScript `var` keyword. **Fix:** Define CSS utility classes instead:

```css
.c-red{color:#ff0040}.c-blue{color:#00d4ff}
.bg-red{background:#ff0040}.bg-blue{background:#00d4ff}
.bc-red{border-color:#ff0040}
.glow-red{box-shadow:0 0 30px #ff0040}
```

Then use `<div class="c-red">` instead of `<div style="color:var(--red)">`. Classes are safe — inline style `var()` is not.

### Hex colors in GSAP tweens
Inside `<script>`, unquoted hex `#ff6b00` is parsed as a JavaScript private field. **Fix:** Always quote hex in GSAP:

```javascript
// WRONG — linter error
tl.to("#el", { color: #ff0040, ... });

// RIGHT
tl.to("#el", { color: "#ff0040", ... });
```

### Ban Math.random()
HyperFrames requires deterministic output. **Fix:** Use pre-computed arrays:

```javascript
// WRONG
for(i=0;i<12;i++){ /* Math.random() positions */ }

// RIGHT — array literal with fixed values
var xs = [10,25,40,55,70,85,20,35,50,65,80,15];
var ys = [20,60,30,70,40,80,25,55,35,75,45,90];
```

## Key Animation Patterns

- **Transition overlay:** Every scene change gets a 0.5s crossfade via `#t-overlay` div. Pattern: fade overlay IN at `sceneEnd - 0.5s`, then set next scene opacity=1 and fade overlay OUT at `sceneEnd`.
- **Stagger cascade:** For cards/list items, use `0.2-0.25s` stagger with `back.out(2)` ease.
- **VS badge:** Use `elastic.out(1,0.3)` for dramatic pop, then finite `yoyo:true,repeat:4` pulse.
- **Scoreboard bars:** Animate from `height:0` to target height with `power3.out` or `expo.out` ease.
- **Timeline progress:** Draw the line with `width:0% → width:100%` over 3-4 seconds with `power1.inOut`.

## Professional Pipeline: Storyboard & Diagrams as B-Roll

When the user asks for "varied outputs", ALL three outputs must be HyperFrames compositions — not just the main video:

1. **Main composition** (`index.html`) — the primary 12-scene video
2. **Diagrams b-roll** (`compositions/diagrams-broll/index.html`) — each SVG diagram shown as an animated scene with:
   - Title + subtitle header
   - SVG image framed with border
   - Pulsing overlay dots highlighting key diagram nodes
   - 10-12s per diagram, 3 scenes total
3. **Storyboard b-roll** (`compositions/storyboard-broll/index.html`) — the video flow overview:
   - Scene 1: Overview with big stats (scene count, duration, diagram count)
   - Scene 2: 4×3 card grid showing all scene titles/types/durations, with animated cascade entrance and progress bar

Each sub-composition gets its own `fonts/` directory with copied (not symlinked) .ttf files and its own `data-composition-id`.

## Variable Weight SVG Images Inside Compositions

When embedding SVGs in `<img>` tags inside HyperFrames:
- Use a wrapper div: `<div class="diagram-frame"><img src="assets/name.svg"></div>`
- The frame needs `width:75%` or fixed `max-width:1200px` + `border-radius:16px` + `border:1px solid rgba(255,255,255,0.08)` + `background:rgba(0,0,0,0.3);padding:10px`
- SVG files must be COPIED into the composition directory (or a local `assets/` subdirectory). Do NOT use `../` relative paths.
