# Motion Complexity Patterns — GameySins HyperFrames B-Roll

User explicitly complained basic animations were "not advanced motion graphics."
Every scene type below uses the **upgraded** pattern. Use these when generating or patching compositions.

---

## Pattern 1: Opener — 5-Step Multi-Ease Entrance

```javascript
// Background layers
tl.fromTo("#g1", {scale:0, opacity:0, rotation:45},
                {scale:1.8, opacity:0.5, rotation:0, duration:2, ease:"power2.out"}, 0);
tl.fromTo("#g2", {scale:0, opacity:0, x:-100},
                {scale:1.5, opacity:0.4, x:0, duration:2, ease:"expo.out"}, 0.2);

// Hero title: 3 properties simultaneously + back.out for bounce
tl.fromTo("#t", {scale:0.3, y:80, rotation:-3, opacity:0, filter:"blur(8px)"},
                {scale:1, y:0, rotation:0, opacity:1, filter:"blur(0px)",
                 duration:1.4, ease:"back.out(2)"}, 0.5);

// Accent line with color shift
tl.fromTo("#l", {scaleX:0, opacity:0, backgroundColor:"#00d4ff"},
                {scaleX:1, opacity:1, backgroundColor:"#ff0040",
                 duration:0.8, ease:"power2.out"}, 1.0);

// Subtitle with letter-spacing trick
tl.fromTo("#s", {y:40, opacity:0, letterSpacing:"10px"},
                {y:0, opacity:1, letterSpacing:"0px",
                 duration:1, ease:"expo.out"}, 1.3);

// Hold-phase pulse on hero title (finite repeat)
tl.to("#t", {scale:1.03, duration:0.6, ease:"sine.inOut"}, 3.5);
tl.to("#t", {scale:1, duration:0.6, ease:"sine.inOut"}, 4.1);
tl.to("#t", {scale:1.02, duration:0.5, ease:"sine.inOut"}, 5.5);
tl.to("#t", {scale:1, duration:0.5, ease:"sine.inOut"}, 6.0);
```

## Pattern 2: Gameplay — Energetic Multi-Directional

```javascript
// Glows with skew
tl.fromTo("#g1", {scale:0, opacity:0, skewX:30},
                {scale:2, opacity:0.5, skewX:0, duration:1.5, ease:"back.out(1.5)"}, 0);
tl.fromTo("#g2", {scale:0, opacity:0, skewX:-30},
                {scale:2, opacity:0.4, skewX:0, duration:1.5, ease:"back.out(1.5)"}, 0.2);

// Tag bounces in
tl.fromTo("#tag", {y:-40, opacity:0, rotation:-5},
                  {y:0, opacity:1, rotation:0, duration:0.6, ease:"bounce.out"}, 0.3);

// Title: scale + rotation + y simultaneously
tl.fromTo("#t", {scale:0.4, rotation:-8, y:40, opacity:0},
                {scale:1, rotation:0, y:0, opacity:1,
                 duration:1, ease:"elastic.out(1,0.4)"}, 0.8);

// Center pulse glow after entrance
tl.fromTo("#pulse", {scale:0, opacity:0.6},
                    {scale:3, opacity:0, duration:1.2, ease:"power2.out"}, 1.5);
tl.fromTo("#pulse", {scale:0, opacity:0.5},
                    {scale:2.5, opacity:0, duration:1, ease:"power2.out"}, 3.0);
```

## Pattern 3: Comparison — Dual-Sided Symmetry

```javascript
// Glows
tl.fromTo("#gl", {scale:0, opacity:0},
                 {scale:2, opacity:0.5, duration:1.5, ease:"power2.out"}, 0);
tl.fromTo("#gr", {scale:0, opacity:0},
                 {scale:2, opacity:0.5, duration:1.5, ease:"expo.out"}, 0.3);

// Left title: slides from left with rotation
tl.fromTo("#l", {x:-120, opacity:0, rotation:-5},
                {x:0, opacity:1, rotation:0, duration:0.9, ease:"back.out(1.7)"}, 0.5);

// Divider: grows from center with neon pulse
tl.fromTo("#d", {scaleY:0, opacity:0},
                {scaleY:1, opacity:1, duration:0.5, ease:"power3.out"}, 0.8);

// Right title: slides from right with rotation
tl.fromTo("#r", {x:120, opacity:0, rotation:5},
                {x:0, opacity:1, rotation:0, duration:0.9, ease:"back.out(1.7)"}, 1.1);

// VS badge: dramatic spin-in
tl.fromTo("#vs", {scale:0, opacity:0, rotation:-720},
                 {scale:1, opacity:1, rotation:0, duration:0.8, ease:"back.out(3)"}, 1.3);

// VS pulse (finite)
tl.to("#vs", {scale:1.2, duration:0.4, ease:"sine.inOut"}, 3);
tl.to("#vs", {scale:1, duration:0.4, ease:"sine.inOut"}, 3.4);
tl.to("#vs", {scale:1.1, duration:0.3, ease:"sine.inOut"}, 5);
tl.to("#vs", {scale:1, duration:0.3, ease:"sine.inOut"}, 5.3);
```

## Pattern 4: Presentation — Kinetic Typography with Emphasis

```javascript
// Title entrance
tl.fromTo("#pt", {y:-70, opacity:0, scale:0.9},
                 {y:0, opacity:1, scale:1, duration:0.9, ease:"power3.out"}, 0.5);
// Accent line
tl.fromTo("#al", {scaleX:0, opacity:0},
                 {scaleX:1, opacity:1, duration:0.6, ease:"expo.out"}, 1.0);

// Each bullet: slides from right (RTL) with stagger
// bullet 1
tl.fromTo("#b0", {x:100, opacity:0, scale:0.95},
                 {x:0, opacity:1, scale:1, duration:0.7, ease:"power2.out"}, 2.0);
// bullet 2
tl.fromTo("#b1", {x:80, opacity:0, scale:0.95},
                 {x:0, opacity:1, scale:1, duration:0.7, ease:"power2.out"}, 4.8);
// bullet 3
tl.fromTo("#b2", {x:60, opacity:0},
                 {x:0, opacity:1, duration:0.7, ease:"power2.out"}, 7.6);

// Bullet highlight sweep on entry
// When each bullet appears, its matching highlight term glows
tl.to("#b0 .hl-red", {textShadow:"0 0 30px #ff0040, 0 0 60px #ff0040", duration:0.3}, 2.5);
tl.to("#b0 .hl-red", {textShadow:"0 0 15px #ff0040", duration:0.4}, 2.8);
// Same pattern for b1 at 5.3s, b2 at 8.1s
```

## GSAP Ease Reference

| Ease | Use Case | Energy |
|------|----------|--------|
| `power2.out` | General entrance, glows | Medium |
| `power3.out` | Fast, snappy entrances | High |
| `back.out(1.7)` | Bouncy hero elements | Energetic |
| `back.out(2.5)` | Extra bounce (VS, stats) | Dramatic |
| `expo.out` | Smooth, long slides | Fluid |
| `elastic.out(1,0.3)` | Playful, exaggerated | Bouncy |
| `bounce.out` | Tags, small elements | Playful |
| `sine.inOut` | Pulses, oscillations | Subtle |

**Rule**: Use at least 3 different eases per scene. Never use only `power2.out` across all elements.
