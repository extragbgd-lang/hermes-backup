# PC vs Console 2026 — Pipeline Reference (2026-05-26)

## Outputs Generated
- **HyperFrames composition** (`index.html`): 12 scenes, 166s, midnight blue BG, linear transitions, split-screen comparisons
- **Storyboard** (`storyboard.html`): 654 lines, scene cards + diagram gallery + timeline bar
- **SVG Diagrams**: timeline.svg, flow.svg, stats.svg (Mermaid CLI v11.15.0)

## Workflow
1. Read script → extract scene intents (not just list lines)
2. Expand to full scene-by-scene Arabic breakdown with on-screen text
3. Generate 3 SVG diagrams with `mmdc -w 1600 -H 900 --backgroundColor transparent`
4. Build `storyboard.html` with embedded diagrams + scene cards + timeline bar
5. Build `index.html` (single composition, all scenes, transition overlay)
6. Sub-compositions: `compositions/diagrams-broll/` + `compositions/storyboard-broll/`
7. Each sub-comp has its own `fonts/` dir with COPIED .ttf files
8. Lint (0 errors) + Validate (0 errors) before delivery
9. Render from Windows CMD: `npx hyperframes render --output rendered/output.mp4`

## Critical Linter Rules Learned (2026-05-26)
- NO `var(--color)` in inline HTML `style=""` attributes → use CSS classes or raw hex
- NO `Math.random()` → use deterministic arrays with hardcoded values
- ALL scenes need `class="clip"` on the div
- Hex in GSAP tweens must be quoted strings: `borderColor:"#ff6b00"` not `borderColor:#ff6b00`
- Font paths: `url('fonts/Cairo-Regular.ttf')` from composition dir
- **Font files must be COPIED, not symlinked** — WSL symlinks fail on Windows render

## HyperFrames Setup
- v0.6.45 from `https://github.com/heygen-com/hyperframes` (official HeyGen)
- Installed via `npm install -g hyperframes`
- GSAP v3.14.2 from CDN: `https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js`

## Brand Colors (hex only in inline styles)
- Neon Red: `#ff0040`
- Neon Blue: `#00d4ff`
- Orange: `#ff6b00`
- Yellow: `#ffcc00`
- Purple: `#8833ff`
- Midnight BG: `#0a0e1a`
- White: `#ffffff`
- Dim text: `rgba(255,255,255,0.6)`