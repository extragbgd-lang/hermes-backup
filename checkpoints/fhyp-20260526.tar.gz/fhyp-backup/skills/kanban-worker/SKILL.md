---
title: kanban-worker
name: kanban-worker
description: Protocol for Hermes Kanban workers — how to receive, work, and complete tasks using kanban_* tools.
trigger_conditions:
  - Running as a kanban worker with HERMES_KANBAN_TASK set
  - Task assigned to you via kanban and spawned by the dispatcher
  - Using kanban_show, kanban_complete, kanban_heartbeat, kanban_block tools
---

# Kanban Worker Protocol

When you're spawned as a kanban worker (you see `HERMES_KANBAN_TASK` set in env), follow this protocol:

## Step 1: Read Your Task

Call the `kanban_show()` tool with no arguments. It reads `HERMES_KANBAN_TASK` from the environment automatically.

This returns:
- Task title & body (the assignment)
- Prior attempts (if any) with their outputs
- Parent handoffs (summary + metadata from upstream tasks)
- Full comment thread (inter-agent communication)
- Workspace path

## Step 2: Navigate to Workspace

```
cd $HERMES_KANBAN_WORKSPACE
```

This is your dedicated directory. All task artifacts go here. If the task uses a `dir:<path>` workspace, that's the shared directory you operate on.

## Step 3: Discover Available Tools

Tool names available to workers differ from what the parent agent session has. Before relying on a specific tool name (e.g. `web_search`), call a tool you know exists (like `kanban_show()`) and check the tool listing in the system prompt. If a tool returns "Unknown tool", the name differs in this context — try alternatives or use the terminal tool to inspect the available schema.

Common tool availability for kanban workers:
- ⚠️ `web_search` may not be available by that name — use browser tools or terminal-based alternatives
- ✅ `terminal`, `read_file`, `write_file`, `search_files`, `patch` are available
- ✅ `delegate_task` is available for spawning subagents
- ✅ `kanban_show`, `kanban_complete`, `kanban_heartbeat`, `kanban_comment` are available
- ❌ `clarify` is NOT available (workers cannot ask questions)
- ❌ Orchestrator kanban tools (create, link, list, unblock) are NOT available to workers

Pro tip: use `delegate_task` for complex research subtasks — the subagent gets its own context and tool access, and returns a structured summary.

## Step 4: Do the Work

Use terminal, file, delegate_task, and any other available tools to accomplish the task described in the body and comments. Write artifacts to the workspace directory (cd $HERMES_KANBAN_WORKSPACE first) — they persist for downstream tasks and human review.

## Step 5: Heartbeat During Long Ops

Call `kanban_heartbeat(note="what I'm doing")` at least once per hour during operations expected to take longer than a few minutes. Without a heartbeat within the stale timeout (default: 4 hours), the dispatcher reclaims the task and you lose your progress.

## Step 5: Complete or Block

### On success:
```
kanban_complete(
    summary="human-readable closeout of what was done",
    metadata={
        "changed_files": ["path/to/file"],
        "verification": ["command or test that was run"],
        "dependencies": ["related task ids or references"],
        "residual_risk": ["what's still open or needs human review"]
    }
)
```

### On stuck:
```
kanban_block(reason="clear explanation of what's blocking and what input is needed")
```

## Critical Rules

- **Use tools, not CLI.** Never run `hermes kanban complete` — use the `kanban_complete()` tool.
- **Must complete or block.** If your process exits with status 0 while the task is still `running`, the dispatcher treats it as a protocol violation and auto-blocks the task. You MUST call one of the terminal tools.
- **Heartbeat regularly.** Every 30-60 minutes during long operations.
- **Don't touch other tasks.** You are scoped to your own task. Orchestrator tools (kanban_create, kanban_link, kanban_list, kanban_unblock) are not available to workers.
- **Leave evidence.** metadata should let the next reader answer: What changed? How was it verified? What risk is still open?
