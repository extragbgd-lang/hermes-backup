# Model Router — Routing Algorithm Deep Dive

## Provider Detection Semantics

| Provider | Detection Method | "Available" Signal | Gotchas |
|----------|-----------------|-------------------|---------|
| OpenCode Go | `GET {health_endpoint}` (default: `https://opencode.ai/zen/go/v1/models`) | HTTP 200 **or** 401/403 (auth required but service reachable) | 401/403 means "available" — don't mark as down. Only connection-refused/timeout/unresolved-host = down. |
| LM Studio | `GET {base_url}/models` (e.g. `http://192.168.100.17:1234/v1/models`) | HTTP 200 + non-empty body. Response format: `{"data": [{"id": "model-name", ...}]}` or bare array | Timeout >5s = likely not running. Returns models loaded in LM Studio's current session, not all available. |
| OpenRouter | `GET {base_url}/models` (e.g. `https://openrouter.ai/api/v1/models`) | HTTP 200 | Latency ~100-600ms from WSL. Slower due to internet routing. |

## Rate Limit State Machine

```
IDLE
  │
  ├── successful request ──────────────► IDLE (backoff resets to base)
  │
  └── rate limit hit ──► BACKOFF
                            │
                            ├── backoff expires ──► RETRY
                            │                          │
                            │                          ├── success ──► IDLE
                            │                          └── failure ──► BACKOFF (2x, max 30s)
                            │
                            └── 3rd consecutive failure ──► DEGRADED
                                                                │
                                                                ├── (auto-switch to LM Studio)
                                                                │
                                                                └── 2 successful fallback requests ──► IDLE (recheck primary)
```

**Backoff formula**: `delay = min(base * factor^attempts, max_delay)` with jitter (±20% random offset)

**Degraded mode exit conditions**:
- `recheck_after_successful_requests` (default: 2) successful completions on the fallback provider
- `recheck_interval_seconds` (default: 60) — not currently timer-based, only request-count-based

## Provider Selection Algorithm

```
_input_: task_type, total_tokens, force_provider (optional)

1. If force_provider is set:
   → return that provider unconditionally (mark as "forced_by_user")

2. Build candidate list:
   candidates = ["opencode-go"] + config.fallback_providers.order
   # e.g. ["opencode-go", "lmstudio", "openrouter"]

3. Filter candidates by task_classification[task_type].providers:
   lightweight → ["opencode-go", "lmstudio"]
   medium      → ["opencode-go", "lmstudio", "openrouter"]
   heavy       → ["opencode-go", "openrouter"]
   massive     → ["lmstudio"]

4. For each candidate, in order:
   a. Skip if not in allowed providers for this task_type
   b. Skip if rate_limiter.can_use_provider() == False (backoff active)
   c. Skip if degraded mode AND candidate is opencode-go
   d. Skip if total_tokens > provider's max_context capability
   e. FIRST candidate passing all checks → SELECTED

5. If no candidate selected → default to "lmstudio" (safety net)

6. Mark was_fallback = True if index > 0 in candidate list
```

## Task Classification Engine

```python
Massive triggers (regex):
  - r'(analyze|scan|review|audit|check).{0,20}all\s+files'
  - r'(full|entire|complete).{0,20}(codebase|project|repository)'
    AND r'(analyze|scan|audit|migrat|convert|review)'
  - r'\b(massive|very\s+large|huge)\b'

Heavy triggers:
  - heavy_score >= 2
  - heavy_score >= 1 AND medium_score >= 1

Lightweight triggers:
  - light_score > 0 AND light_score >= medium_score AND heavy_score == 0
  # e.g. "fix the spelling" → light=1, medium=1 ("fix" in MEDIUM) → L >= M → lightweight
  # because the main intent (spelling correction) is clearly lightweight

Medium triggers:
  - medium_score >= 1 (any coding/analysis keyword matched)

Fallback: length-based (no keywords matched):
  - len < 50  → lightweight
  - len < 200 → medium
  - else      → heavy
```

## Token Estimation Fallback Chain

1. **tiktoken** (preferred): `cl100k_base` encoding → exact token count
2. **Char-count heuristic** (fallback when tiktoken missing):
   - ASCII chars: ~4 chars/token
   - Non-ASCII (CJK/Arabic): ~2 chars/token
   - +1 minimum
3. **Message overhead**: +4 tokens per message, +2 for assistant reply
4. **Image cost**: +200 tokens per image_url content part (rough estimate)

## Log Format

```
2026-05-22 17:14:41 | INFO     | routing_decision | task_type=lightweight |
  selected=opencode-go | model=deepseek-v4-flash | was_fallback=False |
  tokens=156 | cost=$0.00000000

2026-05-22 17:14:42 | WARNING  | fallback_triggered | primary=opencode-go |
  selected=lmstudio | chain=opencode-go:rate_limited -> lmstudio:selected_after_1_fallbacks

2026-05-22 17:14:43 | INFO     | rate_limit_backoff | provider=opencode-go |
  delay=2.0s | consecutive=1
```

## Configuration Schema Reference

Key paths in `model_router_config.json`:

| JSON Path | Purpose |
|-----------|---------|
| `primary` | OpenCode Go endpoint, model, rate limits, cost, capabilities |
| `primary.rate_limit` | RPM, TPM, cooldown, max failures before fallback |
| `fallback_providers.order` | Ordered list of fallback provider keys |
| `fallback_providers.lmstudio` | LM Studio endpoint, model, timeout, auto-detect |
| `fallback_providers.openrouter` | OpenRouter endpoint, model, preferred model lists |
| `task_classification.*.providers` | Which providers are allowed per task type |
| `context_compression` | Thresholds, target ratios, strategy settings |
| `rate_limit.retry` | Backoff params (base, max, factor, jitter) |
| `rate_limit.degraded_mode` | When to enter/exit degraded mode |
| `cost_management` | Budget caps and free-tier enforcement |
| `logging` | Log paths, rotation, field selection |

## Testing the Router

```python
from model_router import ModelRouter

r = ModelRouter()

# Get full status
status = r.get_status()

# Preview a routing decision
decision = r.route("format this json")
print(decision["selected_provider"])  # "opencode-go"
print(decision["task_type"])          # "lightweight"

# Force a provider
decision = r.route("complex task", force_provider="lmstudio")

# Simulate rate limit + fallback
r.rate_limiter.record_failure("opencode-go", is_rate_limit=True)
r.rate_limiter.record_failure("opencode-go", is_rate_limit=True)
r.rate_limiter.record_failure("opencode-go", is_rate_limit=True)
decision = r.route("medium complexity task")
print(decision["was_fallback"])       # True
print(decision["selected_provider"])  # "lmstudio"

# Reset state
r.rate_limiter.record_success("opencode-go")
r.rate_limiter.record_success("opencode-go")
```

## Known OpenCode Go Quirks

- Health check returns 403 (not 200) when API key is valid but the models endpoint needs auth — still means "available"
- The base URL is `https://opencode.ai/zen/go/v1` (not a different hostname)
- Model name: `deepseek-v4-flash` (fast inference)
- Rate limits: 30 RPM / 100K TPM assumed (verify in OpenCode Go dashboard if different)
