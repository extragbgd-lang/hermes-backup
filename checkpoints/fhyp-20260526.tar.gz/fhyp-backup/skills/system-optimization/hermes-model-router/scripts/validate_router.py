#!/usr/bin/env python3
"""
Model Router — Re-runnable Validation Script
=============================================
DEPRECATED — This is the OLD v3 validation script that references opencode-go
and the old router architecture. Use `model_router.py` directly instead:

    python3 ~/.hermes/scripts/model_router.py --validate

Invocation: python3 ~/.hermes/skills/system-optimization/hermes-model-router/scripts/validate_router.py
           (kept for reference only — will be removed in next cleanup)

Returns exit code 0 if all checks pass, 1 on failure.
"""
import sys, json, os

# Resolve paths relative to skill directory
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS_DIR = os.path.expanduser("~/.hermes/scripts")
sys.path.insert(0, SCRIPTS_DIR)

from model_router import ModelRouter, TaskClassifier, TokenEstimator

errors = []

def check(name, condition, detail=""):
    if condition:
        print(f"  ✓ {name}")
    else:
        print(f"  ✗ {name} — {detail}")
        errors.append(name)

print("Model Router Validation Suite")
print("=" * 50)

# 1. Config health
print("\n1. Config")
r = ModelRouter()
check("config loaded", bool(r.config), "empty config")
check("primary = opencode-go", r.config.get("primary",{}).get("provider") == "opencode-go")
check("fallback order has entries", len(r.config.get("fallback_providers",{}).get("order",[])) > 0)
check("lmstudio configured", "lmstudio" in r.config.get("fallback_providers",{}))
check("openrouter configured", "openrouter" in r.config.get("fallback_providers",{}))

# 2. Token estimator
print("\n2. Token Estimator")
te = r.estimator
check("estimates text", te.estimate("hello world") > 0)
check("estimates empty", te.estimate("") == 0)
check("estimates messages", te.estimate_messages([{"role":"user","content":"hi"}]) > 0)
check("cost calc", isinstance(te.cost_estimate(100,50,1.0,2.0), float))

# 3. Task classifier
print("\n3. Task Classifier")
tc = r.classifier
check("lightweight", tc.classify("format this json") == "lightweight")
check("medium", tc.classify("write a function") == "medium")
check("heavy", tc.classify("design architecture") == "heavy")
check("massive", tc.classify("analyze all files") == "massive")
check("allowed providers", len(tc.get_allowed_providers("lightweight")) > 0)

# 4. Rate limit state machine
print("\n4. Rate Limits")
rl = r.rate_limiter
check("initial available", rl.can_use_provider("opencode-go"))
rl.record_failure("opencode-go", is_rate_limit=True)
check("records rate limit", rl.state["opencode-go"]["rate_limited"])
check("applies backoff", not rl.can_use_provider("opencode-go"))
rl.record_success("opencode-go")
check("recovers on success", rl.can_use_provider("opencode-go"))

# Degraded mode
rl.record_failure("opencode-go")
rl.record_failure("opencode-go")
rl.record_failure("opencode-go")
check("enters degraded", rl.state["opencode-go"]["degraded"])
for _ in range(3): rl.record_success("opencode-go")
check("exits degraded", not rl.state["opencode-go"]["degraded"])

# 5. Routing decisions
print("\n5. Routing")
d = r.route("format this json")
check("returns dict", isinstance(d, dict))
check("has provider", d["selected_provider"] in ("opencode-go","lmstudio","openrouter"))
check("has task_type", "task_type" in d)
check("has tokens", d["estimated_tokens"] > 0)

# Force fallback
d2 = r.route("medium task", force_provider="lmstudio")
check("forced lmstudio", d2["selected_provider"] == "lmstudio")
check("forced marked fallback", d2["was_fallback"] == True)

# 6. Prompt optimization
print("\n6. Prompt Optimization")
orig = "  please   could you   format   this"
opt = r.optimize_prompt(orig, "lightweight")
check("shorter after opt", len(opt) < len(orig))
check("non-empty", len(opt) > 0)

# 7. Provider detection
print("\n7. Provider Detection")
oc_ok, oc_lat, oc_det = r.detector.check_opencode()
check("opencode detection", isinstance(oc_ok, bool))
lm_ok, lm_lat, lm_det, lm_models = r.detector.check_lmstudio()
check("lmstudio detection", isinstance(lm_ok, bool))

# 8. Init
print("\n8. Initialization")
init = r.initialize()
check("init returns dict", isinstance(init, dict))
check("init has summary", bool(init.get("summary")))

# 9. Status
print("\n9. Status")

print(f"\n{'='*50}")
if errors:
    print(f"\n⚠ {len(errors)} CHECK(S) FAILED:")
    for e in errors:
        print(f"  • {e}")
    sys.exit(1)
else:
    print(f"\n✓ ALL CHECKS PASSED")
    print(f"  Router: {init.get('summary', 'N/A')}")
    sys.exit(0)
