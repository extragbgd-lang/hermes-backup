---
name: hermes-model-router
description: Cost-aware multi-provider model routing — Free APIs first, LM Studio local fallback, OpenCode Go paid subscription last resort.
version: 3.0
dependencies:
  - hermes-agent
skills: []
---

# Hermes Model Router v3 — User's Provider Priority Order

## System Overview & Priority Order
Ammar's explicit preference (set 23-May-2026):
```
Priority 1: Free API providers (Groq, OpenRouter free models, Perplexity free tier — zero cost)
Priority 2: LM Studio local (192.168.100.17:1234, 64K context, free)
Priority 3: OpenCode Go paid subscription (128K — ONLY when free/local is too slow or runs out of context)
```

## Core Files

| File | Purpose |
|------|---------|
| `~/.hermes/model_router_config.json` | Full configuration: endpoints, thresholds, budgets, fallback rules |
| `~/.hermes/scripts/model_router.py` | Core routing engine — classifies, selects, optimizes, logs |
| `~/.hermes/scripts/startup_model_router.py` | Startup initialization — detects providers, benchmarks, builds routing table |
| `~/.hermes/hooks/pre-model-router-check.sh` | Lazy startup hook — runs init on first tool call if state is stale |
| `~/.hermes/model_routing.log` | Structured routing log (provider, tokens, fallbacks, rate limits) |
| `~/.hermes/token_usage.log` | Usage statistics (persisted across sessions) |
| `~/.hermes/model_router_state.json` | Cached state for fast access |
| `references/routing-deep-dive.md` | Algorithm details, state machine, config schema, testing snippets |
| `scripts/validate_router.py` | Re-runnable validation — 32 checks, fast smoke test after config changes |

## Command Interface

Use via the router script:

```bash
# Show routing status and provider health
python3 ~/.hermes/scripts/model_router.py status

# Preview routing decision for a task
python3 ~/.hermes/scripts/model_router.py route "analyze this codebase and find bugs"

# Show usage statistics
python3 ~/.hermes/scripts/model_router.py usage

# Show fallback state and chain
python3 ~/.hermes/scripts/model_router.py fallback

# Reset rate limit counters and degraded mode
python3 ~/.hermes/scripts/model_router.py reset-limits

# List all providers with health
python3 ~/.hermes/scripts/model_router.py providers

# Show active routing configuration
python3 ~/.hermes/scripts/model_router.py config

# Run latency benchmarks
python3 ~/.hermes/scripts/model_router.py benchmark

# Run full initialization
python3 ~/.hermes/scripts/model_router.py initialize
```

## Hermes Agent Slash Commands

When asked to run `/model status`, `/model route <task>`, etc., use:
```python
from hermes_tools import terminal
output = terminal("python3 ~/.hermes/scripts/model_router.py status")
```

## Routing Decision Flow

### Step 1: Task Classification
Classify the task before selecting a model:

| Category | Token Range | Primary Providers | Description |
|----------|------------|-------------------|-------------|
| **Lightweight** | 200–2,000 | OpenCode Go, LM Studio | Formatting, small scripts, summaries |
| **Medium** | 2,000–8,000 | OpenCode Go | Coding, debugging, reasoning |
| **Heavy** | 8,000–32,000 | OpenCode Go, OpenRouter | Large context, multi-file, architecture |
| **Massive** | 32,000–128,000 | LM Studio (chunked) | Context overflow — chunk/summarize |

### Step 2: Context Optimization
Before every request:
1. Estimate token usage with `TokenEstimator`
2. Compress context if over threshold (deduplicate system messages, trim old turns)
3. Remove redundant prompt data
4. Batch small operations when ≥3 tasks exist

### Step 3: Provider Selection
The `_select_provider()` method follows this logic:

1. Check if `force_provider` is set → use it directly
2. Build candidate list: free providers first, then local LM Studio, then paid opencode-go as last resort
3. For each candidate:
   - Skip if not allowed for this task type
   - Skip if rate-limited/backed-off (with logging)
   - Skip if in degraded mode (after 3+ consecutive failures)
   - Skip if context exceeds provider's max_context
   - First viable candidate is selected
4. If no provider found → default to free API provider (never drop tasks)

### Step 4: Rate Limit Protection
- Tracks consecutive failures per provider
- Exponential backoff: base 1s, factor 2x, max 30s (with jitter)
- After 3 consecutive failures → enters **degraded mode**, auto-switches to LM Studio
- Rechecks primary after 2 successful requests on fallback
- Request queuing: max 10 queued, 30s timeout

### Step 5: Logging
Every routing decision logs to `model_routing.log`:
- Task type, selected provider, model
- Token estimates, cost estimate
- Was fallback? → fallback chain
- Compression savings
- Rate limit events

## Cost Optimization Rules

1. **Free APIs are priority #1** — Groq, OpenRouter free models (:free suffix), Perplexity free tier. These cost nothing and should be the default for most tasks.
2. **LM Studio is free fallback** — 192.168.100.17:1234, 64K context, Qwen 3.5 9B. Use when free API is rate-limited or unavailable.
3. **OpenCode Go is LAST RESORT** — Only when free APIs AND local LM Studio are both too slow or run out of context (128K available there).
4. Prompt optimization levels:
   - **Aggressive** (lightweight): strip redundancy, normalize whitespace, remove pleasantries
   - **Moderate** (medium): normalize whitespace only
   - **Minimal** (heavy): no optimization (preserve all context)
3. Context compression: enabled for lightweight + medium tasks when context > 4,000 tokens
4. Batch optimization: combines 3+ small tasks into single prompt requests
5. Never silently switch to a paid provider without logging the switch

## Fallback Rules

Priority chain: Free APIs → LM Studio → OpenCode Go (paid, last resort)

If free API is:
- **Rate limited**: switch to LM Studio
- **Unavailable**: switch to LM Studio
- **Too slow or context too small (64K exhausted)**: switch to OpenCode Go (128K)

If LM Studio is:
- **Down**: try OpenCode Go next

Fallback order:
1. Free API providers (Groq, OpenRouter free, Perplexity free)
2. LM Studio (free, local, 64K)
3. OpenCode Go (paid, 128K)
4. Only ask user if ALL options are exhausted (log why)

The user's explicit rule: "prioritize free LLM providers API, then local, then if it takes too much time or out of context, use the paid opencode subscription." Follow this strictly — never default to paid when free/local works.

Task safety rules:
- Never drop or truncate user tasks during fallback
- Always preserve context when switching providers
- Log every fallback with reason and chain

## Startup Behavior

On first tool call each session (via hook):
1. Detect OpenCode Go connection (GET to health endpoint)
2. List LM Studio available models
3. Check OpenRouter reachability
4. Benchmark provider latency (3 probes each)
5. Build routing priority table
6. Load last usage statistics from `token_usage.log`
State is cached for 5 minutes; recheck after that.

## Safety Rules

- API keys are redacted from all logs (`sk-****`, `gsk-****`)
- Never jump to paid OpenCode Go without checking free APIs and local LM Studio first
- Always preserve task context during fallback transitions
- Never drop or truncate user tasks without recovery attempt
- Log every provider switch with reason

## Pitfalls

- **tiktoken not installed**: TokenEstimator falls back to char-count heuristic (~4 chars/token). Install with `pip install tiktoken` for accuracy.
- **LM Studio down**: If LM Studio isn't running, the fallback chain is broken. The system will try OpenRouter as the next fallback.
- **State file missing**: On first run, the lazy hook spawns a background initialization. It may take a few seconds before state is ready.
- **Both primary and fallback down**: The router warns loudly at startup but continues operating. Tasks will fail at the provider level, not the router level.
- **Config changes**: After editing `model_router_config.json`, run `python3 ~/.hermes/scripts/model_router.py initialize` to reload.
- **OpenCode Go health endpoint**: OpenCode Go may return 401/403 (auth required) but still be reachable. The detector treats this as "available."
- **Companion monitoring**: The `system-monitoring-heartbeat` skill's `references/llm-provider-monitoring.md` has a no_agent cron script that periodically checks all configured providers (OpenCode Go, OpenRouter, Groq, LM Studio, Gemini) and reports live status via the user's home channel. Useful for catching degraded state before the router encounters it.
