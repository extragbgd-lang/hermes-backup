# Google Doc Delivery via Drive API

Google Docs API is NOT enabled on the project. Use Drive API HTML→Doc import instead.

**Script:** `~/.hermes/scripts/pipeline_to_docs.py`

**Functions:**
- `build_pipeline_html(topic, research, script, diagrams, seo)` → returns HTML string
  - `diagrams` is a list of SVG file paths with descriptions
  - Includes 5 sections: RESEARCH BRIEF, VIDEO SCRIPT, VIDEO DIAGRAMS, B-ROLL PROMPTS, YOUTUBE SEO
- `create_doc_from_html(html, title)` → creates Google Doc via Drive API import, returns `{"id", "name", "url"}`

**How it works:**
1. Build HTML with Arabic RTL styling and sectioned content (5 sections)
2. Write HTML to temp file
3. Upload via Drive API `files.create()` with `mimeType: "application/vnd.google-apps.document"` and `media_body: MediaFileUpload(html_file, mimetype="text/html")`
4. Delete temp file

**Section structure in the HTML:**
| Section | Color | Content |
|---------|-------|---------|
| 1. RESEARCH BRIEF | Blue | Trend data, pricing tables, source links |
| 2. VIDEO SCRIPT | Green | YT timestamps + Egyptian Arabic dialogue with speaker labels |
| 3. VIDEO DIAGRAMS | Purple | SVG file paths, diagram descriptions, links to D:/hyperframe output/diagrams/ |
| 4. B-ROLL PROMPTS | Orange | [VISUAL:] blocks from the script, copy-paste ready for b-roll agent |
| 5. YOUTUBE SEO | Red | 5 titles, description, tags, thumbnail prompt |

**Share:** After creating doc, grant edit access via `drive.permissions().create(fileId=doc_id, body={"type": "user", "role": "writer", "emailAddress": "ammar.basher12@gmail.com"})`

## Google Flow Thumbnail Prompt

**URL:** https://labs.google/fx/tools/flow
**Model:** Nano Banana Pro

Before generating, user uploads their reference photo to Flow.

**Prompt template:**
"YouTube thumbnail, 16:9, ultra high quality. Using the reference image of Ammar [compose]. His face shows [EMOTION] — [DESCRIPTION]. He is [scene]. Cinematic lighting, high contrast, [colors]. Bold Arabic text '[TEXT]' in heavy sans-serif, yellow with black outline. Style: cinematic, YouTube CTR optimized."

**Consistency rules:**
- Do NOT describe Ammar's appearance (reference image handles it)
- Color palette: warm orange/yellow highlights + cool blue/teal shadows
- Text: bold Arabic, thick black outline, drop shadow
- Only change per video: emotion, scene, Arabic text
