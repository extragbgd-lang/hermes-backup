# GameSins Thumbnail Prompt Generator — Quick Reference
# For Google Flow (labs.google/fx/tools/flow) → Nano Banana Pro

## MASTER PROMPT TEMPLATE:
YouTube thumbnail, 16:9 aspect ratio, ultra high quality. Using the reference image of Ammar [position/composition]. His face shows [EMOTION] — [EMOTION_DESC]. He is [scene description matching game/topic]. Cinematic lighting, high contrast, [color scheme]. Bold Arabic text '[ARABIC_TEXT]' in heavy sans-serif, yellow with thick black outline and drop shadow. A subtle red accent element draws attention to a key area. Style: cinematic, hyper-detailed, YouTube CTR optimized, mobile-friendly composition with clear focal point. No watermarks, no text other than the specified Arabic text.

## EMOTION GUIDE:
- shock: "extreme shock — mouth open, eyes wide, eyebrows raised, one hand near his face"
- excitement: "wild excitement — huge grin, eyes wide, both hands raised in celebration"
- fear: "genuine fear — wide eyes, gritted teeth, looking over his shoulder"
- focus: "intense competitive focus — determined eyes, slight smirk, gripping a weapon"
- laughter: "uncontrollable laughter — eyes squeezed shut, mouth wide open laughing"
- rage: "competitive rage — clenched jaw, intense eyes, veins visible on forehead"
- disbelief: "shock and disbelief — both hands on head, mouth wide open, eyes popped"
- mystery: "intrigued mystery — one eyebrow raised, slight smile, looking directly at viewer"

## CONTENT TYPE → COMPOSITION MAPPING:
| Type | Layout | Color | Text Examples |
|------|--------|-------|---------------|
| Comparison/Controversy | Split diorama, red lightning bolt, character center | Warm/cool clash | "PC ولا Console؟", "اختار صح!", "مين الأقوى؟" |
| News/Reaction | Split-screen collage, glitch border, arrows | Electric blue + orange | "الخبر الصادم!", "أخيراً!", "ما توقعت!" |
| Funny | Bright oversaturated, comic impact lines, starbursts | Warm yellow/orange | "ما قدرت أتمالك 😂", "لحظة مجنونة!" |
| Tutorial/Guide | Clean, character pointing, infographic style | Blue/orange | "السر اللي ما حد يعرفه!", "نصيحة ذهبية" |
| Challenge/Hardcore | Dark intense, character in danger, red glow | Red accent + shadows | "أصعب تحدي!", "مستحيل!", "تحدي الموت" |
| Review/First Impression | Game elements around character, yellow star | Vibrant, balanced | "يستاهل؟", "أول انطباع!", "تقييمي النهائي" |

## CONSISTENCY RULES (never change):
- Character: Use "Using the reference image of Ammar" — NEVER describe his appearance
- Composition: character left/center third, text right, game scene background
- Text style: bold Arabic (Cairo font), bright yellow + thick black outline + drop shadow
- Colors: warm orange/yellow highlights + cool blue/teal shadows
- Mosmar: mascot sidekick character for comedic punchlines only — NOT the main presenter

## GAME SCENES GUIDE (for PC/console comparison videos):
- PC setup: "RTX 5090 graphics card glowing RGB, mechanical keyboard, ultrawide monitor with 240fps gameplay, RGB-lit gaming chair"
- Console setup: "PS5 Pro and Xbox Series X on TV stand, neon blue/purple glow, game cases, cozy living room"
- Gaming laptop: "RTX 5070 laptop on desk with RGB keyboard, portable setup, cooling pad, glowing fans"
