# Channel-Specific Pipeline Variants

When a second YouTube channel is created (e.g., GameSinsTech alongside GameSins), the GameSins pipeline structure is adapted rather than rewritten. This document captures what varies per channel and what stays the same.

## Shared Infrastructure

These stay the same across all channels:
- Notion integration (API token, workspace structure)
- YouTube API (Google OAuth, upload, metadata)
- HyperFrames B-roll engine
- Kanban task board (separate tenant per channel)
- Discord DM notification for blocked tasks
- **Mermaid diagrams** via `mmdc` CLI (installed globally, config at `~/.config/mermaid/config.json`)
- **Google Doc delivery** with 5-section structure via Drive API HTML import

## Pipeline Structure (all channels)

```
Research → Script → Diagrams → SEO → Google Doc → Thumbnail
```

| Step | Agent | What it produces |
|------|-------|-----------------|
| 1 | Gaming Researcher | Structured research brief (live web data) |
| 2 | Script Writer | Egyptian Arabic video script with timestamps + [VISUAL] blocks |
| 3 | Video Diagrams | SVG flowcharts/mind maps/timelines from script content |
| 4 | YouTube SEO | 5 titles, description, tags, thumbnail prompt |
| 5 | Compiler | Google Doc with 5 color-coded sections |
| 6 | Thumbnail | Google Flow prompt for Nano Banana Pro |

## What Varies Per Channel

| Dimension | GameSins | GameSinsTech |
|-----------|----------|-------------|
| Host persona | "GameSins" character + Mosmar mascot | Ammar as himself |
| Language | Egyptian Arabic only | Egyptian Arabic, MSA for formal parts |
| Topics | Gaming (survival, multiplayer, VR) | AI tools, freelancing, Gulf business |
| Tone | Funny, energetic, meme-heavy | Educational, practical, direct |
| Pipeline skill | `video-pipeline-agent` | `gameysinstech-pipeline` |
| Researcher focus | Gaming trends, Steam, IGN | AI tools, freelancing platforms |
| Script format | [VISUAL] blocks + Mosmar interjections | Plain visual cues, no mascot |
| Diagram style | Gaming-themed (🎮 ⚔️ 🎨 emoji, purple brand) | Clean professional (blue/teal brand) |
| Monetization | YouTube ads, sponsorships | Affiliate, digital products, consulting |

## Creating a New Channel Pipeline

1. Copy an existing pipeline skill's structure as a template
2. Replace: triggers, researcher context, script writer context, SEO voice, diagram style
3. Create a new Notion workspace sub-page for the channel
4. Register a kanban tenant slug for the channel
5. Save as a new skill: `content-creation/<channel-name>-pipeline`

## Related Skills

- `video-pipeline-agent` — Base pipeline (GameSins gaming)
- `gameysinstech-pipeline` — Derived pipeline (Arabic AI / freelancing)
- `video-diagrams-agent` — Diagram generation from script content
- `mermaid-diagrams` — Mermaid CLI tooling and templates
- `script-writer-agent` (GameSins) — Template adapted for non-gaming scripts
- `youtube-seo-agent` (GameSins) — Template adapted for non-gaming SEO
