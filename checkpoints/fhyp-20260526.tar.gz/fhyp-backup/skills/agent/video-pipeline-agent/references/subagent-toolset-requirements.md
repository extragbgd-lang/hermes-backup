# Subagent Toolset Requirements

## Why `browser` > `web` for research

Subagents given `["web"]` toolsets may generate research from their training data and pretend they checked sources. This produces stale or fabricated results.

**Detection:** Check the tool_trace in delegate_task results. If tool calls are empty (0 browser_navigate, 0 curl, 0 terminal), the subagent faked the data.

## Required toolsets by agent type

| Agent | Toolsets | Reasoning |
|-------|----------|-----------|
| Gaming Researcher | `["browser", "terminal"]` | Must browse live gaming news sites, Steam, YouTube. `web` alone lets it fake data. |
| Script Writer | `["browser", "terminal", "file"]` | Needs browser for Steam page details, file for output. But output goes to stdout, not saved files. |
| Video Diagrams | `["terminal", "file"]` | Reads script from stdin/file, writes Mermaid definitions, runs `mmdc` CLI to render SVGs. No browser needed — diagram logic is code-driven. |
| YouTube SEO | `["web", "terminal", "file"]` | SEO is less dependent on live browsing — keyword research is lightweight. |

## How to verify real data

After delegate_task returns, check:
1. tool_trace contains browser_navigate calls with real URLs
2. browser_snapshot or browser_vision was used to read content
3. Summary mentions specific facts (prices, dates, numbers) with source attribution
4. Terminal/curl was used as fallback when browser blocked

If any of these are missing, re-run with stricter instructions and `["browser"]` toolsets only.

## Verifying diagram output

After the diagrams agent returns, verify:
1. SVG files exist at `/mnt/d/hyperframe output/diagrams/` (stat the files)
2. Each SVG has non-trivial content (>5KB)
3. File names match the diagram types intended (mindmap, flowchart, timeline, etc.)
4. Paths are included in the Google Doc delivery
