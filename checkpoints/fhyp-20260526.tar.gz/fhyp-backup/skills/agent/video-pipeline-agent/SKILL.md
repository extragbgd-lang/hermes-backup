---
title: video-pipeline-agent
name: video-pipeline-agent
description: Full GameSins video production pipeline. Automates Research, Script Writing, Video Diagrams, YouTube SEO, Google Docs, and thumbnail prompts. Single command runs the whole flow.
trigger_conditions:
  - User says "run pipeline" or "run the pipeline" or "video pipeline" or "اعمل فيديو" or "إعمل فيديو عن"
  - User wants to go from topic to complete video package
  - User says "run pipeline for [topic]" or "full pipeline on [topic]"
  - Task involves running all 4 agents (researcher + script + diagrams + SEO) sequentially
  - User needs to create a channel-specific pipeline variant (e.g., GameSinsTech)
---

# Video Pipeline Agent

Orchestrates the full GameSins video production pipeline:
**Topic -> Research -> Script -> Diagrams -> SEO -> Google Doc**

## Reference Files

- **`references/subagent-toolset-requirements.md`** — Detailed discovery on why `browser` tools are required over `web` alone, and how to detect faked data from subagents.
- **`references/thumbnail-prompt-template.md`** — Thumbnail prompt template for Google Flow.
- **`references/delivery-workflow.md`** — Delivery workflow details and patterns.
- **`references/channel-specific-pipelines.md`** — How to create channel-specific pipeline variants (e.g., GameSinsTech) by adapting the base GameSins pipeline template. Read this before creating a new channel pipeline.

## How to Run

When the user triggers the pipeline:

1. **Load this skill** - you are now in pipeline orchestrator mode
2. **Get the video topic** from the user (if not already provided)
3. **Run the 4 agents sequentially** via `delegate_task`
4. **Compile results** (research + script + diagrams + SEO) and push to Google Docs
5. **Return the final Doc link** to the user

## Pipeline Steps

### Step 1: Research
Use `delegate_task` with toolsets=`["browser", "terminal"]`

**CRITICAL:** The `web` toolset can let subagents generate from training data instead of browsing live sites. Always use `browser` + explicit "you MUST browse live websites" to force real data.

Goal: "Research gaming trends and information about: [TOPIC]. Return a structured research brief."

Context: "You are a Gaming Content Researcher for GameSins (Arabic gaming channel). 

**CRITICAL — YOU MUST BROWSE LIVE WEBSITES.** Your training data is outdated. Use browser_navigate + browser_snapshot or curl to visit real sites. Do NOT generate findings from memory.

**Content type filter:** Only findings relevant to survival, multiplayer, PC/console, or VR gaming matter. Filter out anything outside these genres.

**Freshness requirement:** Prioritize content from today/this week. Not-yet-released content is most valuable. Content older than 2 weeks needs explicit justification. The goal is to find things the channel can cover FIRST — before other Arabic channels.

Visit these types of sources:
- Steam new releases & coming soon (store.steampowered.com/explore/new)
- Gaming news (IGN, PC Gamer — today's headlines only)
- Steam store pages for specific games to extract real details
- IGN Middle East (me.ign.com/ar) for Arabic gaming coverage

Search both Arabic and English sources. Return findings in the format: KEY TRENDING TOPICS, AUDIENCE INSIGHTS, CONTENT IDEAS, RECENT NEWS, RECOMMENDATIONS, SOURCES. Include the URLs you actually visited. English text in brief, Arabic terms only in content ideas."

### Step 2: Script Writing
Use `delegate_task` with toolsets=`["browser", "terminal"]` — no file tools, output to stdout only.

Goal: "Write a full GameSins video script in Egyptian Arabic about: [TOPIC]. Use these research findings: [paste full research output]"

Context: "You are a Script Writer for GameSins (Arabic gaming channel). GameSins is the main host (Ammar). Mosmar is a mascot character (imaginary friend plush sidekick) who appears for comedic punchlines **5-6 times per video** (not 2-3 — make him appear more). 

**CRITICAL FORMAT REQUIREMENTS:**

1. **YouTube-compatible timestamps** — At the top, include a copy-paste-ready block:
```
0:00 section name in Arabic
X:XX section name
```
No brackets, plain text. YouTube auto-detects.

2. **Pure Arabic script format** — ALL dialogue in Egyptian Arabic. Speaker labels in English (GameSins: / Mosmar:). Separate speakers by blank lines. Mosmar lines are short (1 sentence). Vary his entrance position each time.

3. **HyperFrames B-roll prompts before each section** — Use this format for every [VISUAL:] block:
```
[VISUAL:
SCENE: shot type + subject + action + lighting
DURATION: X seconds
STYLE: vibe description
TEXT OVERLAY: text + font + colors + animation
COLORS: color palette
OUTPUT: 1920x1080, 30fps
]
```

4. **B-roll shot list** — End with a table of ALL shots: description, duration, style.

Duration 8-15 minutes. Use Arabic gaming terms (بي سي, كونسول, جيمينج). Output full text to stdout — do NOT save files.

**Language rule:** Internal thinking in English. Arabic ONLY in dialogue."

> **📦 After Step 2 completes:** Save the script text that the subagent returned to `/tmp/gamesins-last-script.txt`. This cache is required by NotebookLM (parallel step) and serves as a fallback if the Google Doc is later deleted. Write the full script verbatim — do not truncate, summarize, or reformat.

### Parallel Step: NotebookLM Video Overview

### Parallel Step: NotebookLM Video Overview

After the script is written, **launch NotebookLM Video Overview generation in parallel** with Steps 3-5.

**Browser automation method:** Chrome CDP via user's own Chrome (see `chrome-cdp-automation` skill and `quick-facts-pipeline` → `references/chrome-remote-debugging.md`). No Browserbase, no 5-min timeout.

Credentials: `hermossybatooty@gmail.com` / `IamDangerous`
Notebook: "GameSins - Content Creation Hub" (ID: `3b421487-9ac0-4d06-bea4-957604998c70`)

**Execution pattern:** Use `delegate_task` with toolsets=`["terminal"]` — spawn the NotebookLM subagent while diagrams + SEO run. The subagent connects via Python websocket-client to `ws://192.168.100.17:9223/devtools/browser/...`, navigates to notebook, adds script as Copied text source, generates Video Overview, downloads to `/mnt/d/hyperframe output/notebooklm/`.

**Full reference:** `hyperframes-broll` → `references/notebooklm-direct-login.md` (updated for CDP)

### Step 3: Video Diagrams Generation

After the script is written, generate explanatory diagrams. Use `delegate_task` with toolsets=`["terminal", "file"]`. Load the **`mermaid-diagrams`** and **`video-diagrams-agent`** skills for detailed instructions.

**Goal:** "Generate Mermaid diagrams from this video script and render them to SVG."

**Context:** Pass the full script text + these instructions:

```
You are a Mermaid Diagram Generator. You have a video script.
Your task:
1. Analyze the script structure (sections, topics, flow)
2. Choose 2-3 diagram types that best explain the content:
   - Mind map → topic breakdowns, review categories
   - Flowchart → mechanics, comparisons, decision trees
   - Timeline → release history, series evolution
3. Write Mermaid definitions for each diagram
4. Render them to SVG:
   mmdc -i /tmp/NAME.mmd -o "/mnt/d/hyperframe output/diagrams/NAME.svg" -c ~/.config/mermaid/config.json -w 1200
5. Report back with file paths and descriptions

STYLE: GameSins brand (purple #6c5ce7, transparent bg), emoji nodes, concise text.
```

**Output:** SVG files saved to /mnt/d/Hermes project/output/videos/hyperframes/diagrams/ + paths reported back for the Google Doc.

### Step 4: YouTube SEO
Use `delegate_task` with toolsets=`["web", "terminal", "file"]`

Goal: "Generate YouTube SEO package for a GameSins video about: [TOPIC]. Here is the script: [paste full script]"

Context: "You are a YouTube SEO Agent for GameSins (Arabic gaming channel). Generate: 5 title options in Arabic, full optimized description in Arabic with timestamps, comma-separated tags (Arabic + English), thumbnail concept. Prioritize Arabic keywords and Egyptian dialect terms.

**Language rule:** Internal thinking in English. Output text (titles, description, tags) in Arabic where it belongs. Output to stdout — do NOT save files."

### Step 5: Compile and Upload to Google Docs

After all 4 agents return their results, build an HTML document with 5 color-coded sections and upload via Drive API:

```
┌─ section-blue   ───────────────────┐
│  1. RESEARCH BRIEF                 │
│     All pricing data, trends,      │
│     sales figures clean table      │
└────────────────────────────────────┘
┌─ section-green  ───────────────────┐
│  2. VIDEO SCRIPT (Egyptian Arabic) │
│     YT timestamp block at top      │
│     Pure Arabic dialogue           │
│     Speaker labels: GameSins: /    │
│     Mosmar:                        │
└────────────────────────────────────┘
┌─ section-purple ───────────────────┐
│  3. VIDEO DIAGRAMS                 │
│     SVG file paths with preview    │
│     descriptions of each diagram   │
│     Links to /mnt/d/Hermes project/output/videos/hyperframes     │
│     output/diagrams/               │
└────────────────────────────────────┘
┌─ section-orange ───────────────────┐
│  4. HYPERFRAMES B-ROLL PROMPTS     │
│     Each prompt is self-contained: │
│     SCENE / DURATION / STYLE /     │
│     TEXT OVERLAY / COLORS / OUTPUT │
│     Copy-paste ready for B-roll    │
│     agent                          │
└────────────────────────────────────┘
┌─ section-red    ───────────────────┐
│  5. YOUTUBE SEO                    │
│     5 titles, description, tags,   │
│     thumbnail prompt               │
└────────────────────────────────────┘
```

Build the HTML with proper RTL styling, colored section borders, and pre-formatted code blocks for the script and prompts. Use the Drive API HTML import to create the Google Doc.

After creating the doc, grant edit access to: **ammar.basher12@gmail.com**

Clean up: delete any temp files after upload. The user wants NO local files — everything goes to the Google Doc.

### Step 6: Generate Thumbnail Prompt for Google Flow

After the doc is uploaded, generate a complete paste-ready thumbnail prompt for Google Flow (Nano Banana Pro model). The prompt MUST have ALL variables filled in — no templates, no blanks. Output the prompt to stdout — no files.

Use the content type to determine thumbnail composition style:
- **Comparison/Controversy** (PC vs console, etc.) → split diorama, red lightning bolt
- **News/Reaction** (breaking news) → split-screen collage, glitch border
- **Funny Moments** → bright oversaturated, comic effects
- **Tutorial/Guide** → clean pointing, infographic style
- **Challenge/Hardcore** → dark intense, red glow
- **Review/First Impression** → game elements around character, yellow star

**CRITICAL:** Do NOT describe Ammar's or Mosmar's appearance in prompts. Use "Using reference image of Ammar" and "Using reference image of Mosmar" instead. User uploads both photos to Flow.

Tell the user:
1. Go to https://labs.google/fx/tools/flow
2. Select Nano Banana Pro model
3. Upload their reference photo
4. Paste the prompt
5. Generate

The prompt format:
"YouTube thumbnail, 16:9 aspect ratio, ultra high quality. Using the reference image of Ammar [position/composition]. His face shows [EMOTION] — [EMOTION_DESC]. He is [scene description matching game/topic]. Cinematic lighting, high contrast, [color scheme]. Bold Arabic text '[ARABIC_TEXT]' in heavy sans-serif, yellow with black outline and drop shadow. Style: cinematic, hyper-detailed, YouTube CTR optimized, mobile-friendly."

Color palette: warm orange/yellow highlights + cool blue/teal shadows (consistent).

## Pitfalls

- **`web` toolset allows subagents to fake data from training.** Subagents given `["web"]` toolsets may generate research from their training data and pretend they checked sources (0 browser API calls, 0 tool calls in trace = they faked it). Always use `["browser", "terminal"]` for the researcher and include "CRITICAL: You MUST browse live websites" in the context. Verify the tool_trace in delegate_task results — if tool calls are empty, the subagent faked the data.
- **Research returns stale content by default.** Subagents default to "what's popular" which yields weeks/months-old data. The goal is NOT-YET-RELEASED content or THIS-WEEK news. Always include freshness constraints in the research goal: "today/this week only, not-yet-released preferred."
- **Script writer needs real game data.** Without explicit Steam page browsing instructions, the script writer fills details from training data (made-up features, wrong specs). Always include "Navigate to Steam page and extract REAL details" in the script writer context.
- **Research timeout on broad scope.** The researcher subagent has 600s max. A vague research goal like "find gaming trends" causes it to visit too many sites and hit timeout. Narrow to specific sources (3-4 max) and a specific question. Time-box explicitly ("5 min max").
- **Pass full output between steps.** Do not truncate or summarize when passing research → script or script → SEO.
- **Google Docs API may not be enabled** on the Cloud project. pipeline_to_docs.py falls back to Drive API HTML→Doc import which works without the Docs API being enabled.
- **All communication with the user is in English only.** Arabic ONLY appears inside content outputs (script text, titles, descriptions). Step update messages, confirmations, questions — all English.
- **Local files for diagrams.** Video diagrams MUST be saved as SVG files to `/mnt/d/hyperframe output/diagrams/`. Include diagram file paths in the Google Doc. The script and other pipeline outputs still go only to the Google Doc.
- **Channel-specific variants.** When creating a pipeline for a different channel (e.g., GameSinsTech), do NOT modify this base skill. Create a new pipeline variant. See `references/channel-specific-pipelines.md` for the pattern.
- **NotebookLM session timeout.** Browserbase free plan sessions expire in 5 minutes. The NotebookLM subagent must login fresh each time. Use `browse stop; sleep 1; browse open <url>` to restart dead sessions.
- **NotebookLM runs in the background.** Don't block the main pipeline waiting for NotebookLM output. Spawn it as a parallel `delegate_task` and collect results at the end. If it's still generating when the pipeline finishes, note it in the final report.
- **NotebookLM uses Chrome CDP now, not Browse CLI.** See `chrome-cdp-automation` skill. Connect via `websocket-client` Python lib to `ws://192.168.100.17:9223/devtools/browser/...`. No 5-min timeouts.
- **NotebookLM credentials are in `.env`.** Email: `hermossybatooty@gmail.com`, Password: `IamDangerous`. Notebook ID: `3b421487-9ac0-4d06-bea4-957604998c70`. Never prompt the user for these.
- **NotebookLM needs the raw script text locally.** The script is cached at `/tmp/gamesins-last-script.txt` during pipeline execution. If running NotebookLM post-hoc (after the pipeline finished), check this file first. If it's empty or gone, the user must provide the script text — the Google Doc may have been deleted or may require different login credentials. Do NOT try to read the script from the Google Doc via browser as a fallback; ask the user to paste it.

## Example Conversation

User: "run pipeline for Where Winds Meet PS5"

You respond with progress updates (English only):
1. "🎬 Pipeline started for: Where Winds Meet PS5"
2. "🔬 Step 1/6: Researching gaming trends..." (spawn researcher)
3. "✍️ Step 2/6: Writing Egyptian Arabic script..." (spawn script writer with research)
4. "📊 Step 3/6: Generating video diagrams + NotebookLM Video Overview running in parallel..." (spawn diagrams + NotebookLM in parallel)
5. "🔍 Step 4/6: Generating SEO package..." (spawn SEO with script)
6. "📤 Step 5/6: Uploading to Google Docs..." (compile and upload)
7. "🖼️ Step 6/6: Generating thumbnail prompt for Google Flow..."
8. "✅ Pipeline complete! Google Doc: [link] + diagrams at: /mnt/d/Hermes project/output/videos/hyperframes/diagrams/
NotebookLM Video Overview: /mnt/d/Hermes project/output/videos/hyperframes/notebooklm/
thumbnail prompt ready"
