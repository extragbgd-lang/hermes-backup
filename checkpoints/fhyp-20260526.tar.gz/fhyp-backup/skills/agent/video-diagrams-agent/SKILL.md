---
name: video-diagrams-agent
title: Video Diagrams Agent
description: Agent that generates professional explanatory diagrams from video scripts using Mermaid CLI. Analyzes script structure and produces SVG flowcharts, mind maps, timelines, and comparison charts.
category: agent
trigger_conditions:
  - User says "generate diagrams for script" or "diagrams for video"
  - User provides a video script and wants it visualized
  - Task involves creating explanatory visuals from content
  - User says "رسم" or "دايجرام" in context of video production
  - Pipeline step 3 runs automatically between script writing and SEO
  - Any pipeline run that produces a script
---

# Video Diagrams Agent

Generates professional SVG diagrams from video scripts. Part of the GameSins content pipeline — takes a finished script and produces visual explainers for use in HyperFrames compositions.

## Prerequisites

- `mmdc` installed: `npm install -g @mermaid-js/mermaid-cli`
- Mermaid config: `~/.config/mermaid/config.json`
- Output dir: `/mnt/d/hyperframe output/diagrams/`

## How to Run

When the user provides a video script (or asks to generate diagrams from an existing one):

1. **Load this skill** + `mermaid-diagrams` skill  
2. **Get the script** from user or find it by searching for related files
3. **Analyze** the script structure
4. **Generate diagrams** via `delegate_task`
5. **Return file paths** to the user

## Workflow

### Step 1: Analyze the Script

Parse the script and identify:
- **Number of sections / topics**
- **Key entities** (games, features, comparisons, scores)
- **Flow structure** (sequential process, comparison, review, tutorial, etc.)
- **Data points** (ratings, scores, stats, generation comparisons)

### Step 2: Decide Diagram Types

Based on script structure:

| Script Type | Recommended Diagrams |
|-------------|---------------------|
| **Game Review** | Mind map (features → pros/cons) + Score gauge/funnel |
| **Tutorial / How-To** | Flowchart (steps sequence) + Timeline |
| **Comparison / vs** | Side-by-side flowchart + Quadrant chart |
| **News / Update** | Timeline (evolution) + Block diagram |
| **Multi-game roundup** | Mind map per game + Comparison table |
| **Deep dive / analysis** | Flowchart (game systems) + Sequence diagram |

Generate 1-3 diagrams per script. 2 is the sweet spot.

### Step 3: Generate Diagrams

Use `delegate_task` to spawn a subagent with toolsets=`["terminal", "file"]`

**Goal:** "Generate Mermaid diagrams from this video script and render them to SVG."

**Context:** Include the full script text + these instructions:

```
You are a Mermaid Diagram Generator. You have a video script.
Your task:
1. Analyze the script structure (sections, topics, flow)
2. Choose 2-3 diagram types that best explain the content
3. Write Mermaid definitions for each diagram
4. Render them to SVG using:
   mmdc -i /tmp/diagram_name.mmd -o /mnt/d/hyperframe output/diagrams/diagram_name.svg -c ~/.config/mermaid/config.json -w 1200
5. Report back with file paths and what each diagram shows

DIAGRAM TYPE REFERENCE:
- flowchart TD/LR — processes, comparisons, decision trees
- mindmap — topic breakdowns, review categories
- timeline — chronological events, evolution
- sequenceDiagram — interaction flows, quest lines
- pie — percentage breakdowns, score splits
- quadrantChart — feature comparison matrix
- block — system architecture, component relationships

STYLE RULES:
- Use %%{init: ...}%% header with GameSins brand colors:
  primaryColor: '#6c5ce7', primaryTextColor: '#ffffff', lineColor: '#636e72'
- Emoji in node labels (🎮 ⭐ 🎬 🔥 📊 🆚)
- Keep text concise (max 3-5 words per node)
- Use subgraphs for grouping in flowcharts
- Mind map indent must be exactly 2 spaces per level
- Output width: 1200px minimum for 16:9 video
- Transparent background for video overlay use

OUTPUT FORMAT:
[D1] flowchart-name.svg — Shows: [brief description of what it visualizes]
[D2] mindmap-name.svg — Shows: [brief description]
```

### Step 4: Return Results

Present the results to the user:

```
✅ Diagrams generated for: [Script Title]

📊 [D1] review-flowchart.svg — Game mechanics breakdown from introduction to conclusion
📊 [D2] topic-mindmap.svg — Topic structure showing all key points

📍 Output: /mnt/d/hyperframe output/diagrams/

💡 Next: Embed these SVGs in your HyperFrames composition:
   <img src="../diagrams/filename.svg" style="width:100%;">
```

## Integration with Pipeline

This agent is **Step 3 of the GameSins video pipeline** (installed between Script Writing and YouTube SEO):

```
Step 1: Research → Step 2: Script → Step 3: Diagrams → Step 4: SEO → Step 5: Google Doc
```

When running the full pipeline (`video-pipeline-agent`), this step runs automatically. The generated SVG files are:
- Listed in the Google Doc under the **VIDEO DIAGRAMS** section
- Accessible at `/mnt/d/hyperframe output/diagrams/` for b-roll and HyperFrames use

The generated SVGs can be:
- Used as animated overlays in HyperFrames (scale-in, slide-in)
- Static infographics between sections
- Visual transitions between topics
- Thumbnail elements

## Pitfalls
- Mind map indent must be EXACTLY 2 spaces per level — tabs break it
- Long node text wraps oddly — keep to 3-5 words
- Always use the config file for consistent GameSins branding
- Do NOT generate more than 3 diagrams per script (overwhelming)
- Flowchart node IDs must be unique — use capital letters (A, B, C...)
- SVGs with transparent bg render white in some viewers — open in browser to verify
- If the script is in Arabic, node labels should be in Arabic too with Cairo font
- Always add `--transparent` equivalent via config (`backgroundColor: "transparent"`)
