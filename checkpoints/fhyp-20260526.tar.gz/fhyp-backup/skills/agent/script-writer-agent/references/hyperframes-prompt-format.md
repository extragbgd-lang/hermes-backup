# HyperFrames B-Roll Prompt Format
## Reference for script-writer-agent [VISUAL:] blocks

Every [VISUAL:] block in a GameSins script is a self-contained prompt that feeds into a HyperFrames B-Roll generation agent. The B-Roll agent reads the block and generates an HTML+GSAP composition.

---

## Required Fields

```
[VISUAL:
SCENE: Camera shot type + subject + action + setting + lighting
DURATION: X seconds
STYLE: vibe description
TEXT OVERLAY: text content + font + colors + animation + position
COLORS: dominant and accent colors
OUTPUT: 1920x1080, 30fps
]
```

---

## Field Details

### SCENE
Describe what the viewer sees. Include:
- **Camera position**: CUT TO, WIDE, CLOSE UP, SPLIT SCREEN, POV, TRACKING, LOW ANGLE, TOP DOWN, MACRO, B-ROLL, SLOW MOTION, TIMELAPSE
- **Subject**: What's in frame (character, console, PC, text, etc.)
- **Action**: What happens (boots up, zooms in, fades, cuts)
- **Setting**: Where (desk, shelf, living room, shop, on-screen)
- **Lighting**: neon, natural, dramatic, warm, cold, dim, spotlight, RGB

Example:
> SCENE: Close up on PS5 Pro console booting up. White LED strip illuminates. Dark background with blue rim light. SSD splash screen appears fast on connected monitor.

### DURATION
In seconds. Short shots 2-3s for fast pacing, longer 4-6s for emphasis, 6s+ for comparison sequences or emotional moments.

### STYLE
The intended feel. Common values:
- **cinematic** — slow, dramatic lighting, smooth transitions
- **fast-paced** — quick cuts, energetic, urgent
- **informational** — clean, data-focused, educational
- **comic** — fun, impact lines, bright colors, shake effects
- **tragic** — sad music, slow zoom, dim lighting
- **horrifying** — red low light, thermal camera, uncomfortable close-up
- **satisfying** — clean motion, ASMR-like, smooth
- **documentary** — handheld, natural, real
- **premium** — slow motion, smooth camera movement, luxury feel

### TEXT OVERLAY
Only include if text appears on screen during this shot. Specify:
- **Text content**: Exact Arabic text
- **Font**: Cairo for Arabic (bold, thick), Rubik for English
- **Size**: large (100-110px for main titles), medium (44-48px for Arabic subtitles), small (28-36px for body)
- **Color**: yellow or white for text, black or red for accents
- **Animation**: fade in, slide in from bottom/right, glitch effect, scale up, pulse
- **Position**: center, bottom third, top right, left aligned
- **Duration on screen**: how long text stays visible

Examples:
> TEXT OVERLAY: "PS5 Pro — $899" — Cairo Bold, white with blue glow, fades in from bottom at 1s mark, stays until end
>
> TEXT OVERLAY: None — pure visual montage, no text
>
> TEXT OVERLAY: Bottom banner — "الفرق قل" in Arabic Cairo Bold, yellow with black stroke, slides in from right at 2s

### COLORS
Dominant colors and accents. Describe the color mood:
> COLORS: Neon blue + red alternating per cut, dark background
> COLORS: Warm natural lighting, wooden desk, green motherboard, RBG at end
> COLORS: Dim interior, thermal palette (blue→green→yellow→red with heat)

### OUTPUT
Always: `1920x1080, 30fps`

---

## Complete Examples

### Simple B-Roll (single subject)
```
[VISUAL:
SCENE: Close up on PlayStation 5 Pro — camera slowly circles around the console showing its size, vents, and glossy panels. Blue LED strip reflects off the dark surface beneath. Minimal, studio lighting.
DURATION: 3 seconds
STYLE: Cinematic, premium, futuristic
TEXT OVERLAY: "PS5 Pro — $899" — Cairo Bold, white with blue glow, fades in from bottom at 1.5s mark
COLORS: Dark background, blue LED reflections, white text, black console body
OUTPUT: 1920x1080, 30fps
]
```

### Comparison (multi-subject)
```
[VISUAL:
SCENE: Three-way split screen — same Cyberpunk 2077 neon street scene running on (left) PC RT Overdrive, (center) PS5 Pro high settings, (right) Gaming Laptop medium-high. Frame rate counter in top corner of each segment. Camera zooms in slightly on each segment in sequence.
DURATION: 6 seconds
STYLE: Technical comparison, data-driven
TEXT OVERLAY: "PC — RT Overdrive" / "PS5 Pro — High" / "Laptop — Medium-High" — Cairo Bold, white with colored underline matching each platform. Appears at 0.5s with fade-in.
COLORS: Cyberpunk neon pink/blue/yellow, black dividers between segments
OUTPUT: 1920x1080, 30fps
]
```

### Fast montage
```
[VISUAL:
SCENE: Fast montage of 10 quick cuts (0.3s each): PS5 Pro box, RTX 5090 glowing, gaming laptop on desk, cash register, credit card swipe, Steam logo, Xbox controller, Switch 2 handheld, monitor with game, GameSins logo. Each cut has a zoom transition.
DURATION: 3 seconds total (10 cuts)
STYLE: Dramatic, urgent, high energy
TEXT OVERLAY: None — pure visual montage
COLORS: Alternating neon blue / red / green per cut
OUTPUT: 1920x1080, 30fps
]
```

### Text overlay + background
```
[VISUAL:
SCENE: Animated line graph — X-axis shows years 2016-2026, Y-axis shows price $0-$2000. Two lines converge over time: blue (console avg) and red (PC mid-range). Arrow at 2026 highlighting convergence.
DURATION: 4 seconds
STYLE: Infographic, clean, animated
TEXT OVERLAY: "الفرق قل" — Arabic Cairo Bold, yellow with black stroke, pulses at end. "2016" and "2026" labels on X-axis in white small text.
COLORS: Dark background, blue line (console), red line (PC), yellow highlight
OUTPUT: 1920x1080, 30fps
]
```

---

## Color Palette Reference for GameSins B-Roll

HyperFrames compositions use a strict color palette:
- **Primary**: Neon red `#ff0040`, Neon blue `#00d4ff`
- **Dark**: Black `#050508`
- **Accent**: White `#ffffff`

For YouTube thumbnails (Google Flow):
- **Warm accent**: Orange/yellow highlights
- **Cool accent**: Blue/teal shadows
- **Text**: Bright yellow with black outline, drop shadow

---

## Font Reference

- **Arabic**: Cairo (900 weight for titles, 700 for subtitles)
- **English**: Rubik
- **Banned**: Orbitron, Rajdhani, Chakra Petch
- **Sizes**: Main titles 100-110px, Arabic subtitles 44-48px, body 28-36px

---

## Shot List Table Format

At the end of a script, the B-roll shot list summary table:

```
| # | Description | Duration | Style |
|---|-------------|----------|-------|
| 1 | [clip description] | [X sec] | [vibe] |
| 2 | [clip description] | [X sec] | [vibe] |
```
