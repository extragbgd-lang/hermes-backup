---
title: kanban
name: kanban-task-board
description: Hermes Kanban multi-agent task board — content pipeline, personal ops, and task management for GameySins and daily workflows.
trigger_conditions:
  - User asks about setting up, using, or managing the Kanban task board
  - Creating, assigning, or tracking tasks across boards
  - Decomposing a goal into linked subtasks for different assignees
  - Setting up content pipelines or workflow boards
  - Inspecting board stats, watching activity, or diagnosing stuck tasks
  - Working with the dispatcher, worker lifecycle, or task status transitions
---

# Hermes Kanban — Internal Task Board

Kanban is a durable task board shared across Hermes profiles. Every task is a row in `~/.hermes/kanban.db`; every handoff is durable; every worker is a full OS process with its own identity.

## Architecture

- **Board** — a queue of tasks with its own SQLite DB and workspace directory. Default board at `~/.hermes/kanban.db`. Use multi-board for separate work streams.
- **Task** — row with title, body, assignee (profile name), status (`triage|todo|ready|running|blocked|done|archived`), optional tenant, idempotency key.
- **Dispatcher** — long-lived loop inside the gateway (every 60s). Reclaims stale/crashed tasks, promotes ready tasks, spawns workers. Enabled by default in `config.yaml`.
- **Worker** — spawned profile with `HERMES_KANBAN_TASK` env var set. Uses `kanban_*` tool calls, NOT the CLI, to interact with the board.
- **Dashboard** — GUI at `hermes dashboard` → Kanban tab.

## Status Lifecycle

```
triage → todo → ready → running → blocked → done/archived
                 ↑          ↓
                 └── ready ←──┘ (unblock)
```

Parents → child: dispatcher promotes `todo` → `ready` when all parent tasks are complete.

## CLI Commands

### Board Management
```
hermes kanban boards list                  # List all boards
hermes kanban boards create <slug> \       # Create new board
    --name "Display Name" \
    --description "..." \
    --icon 🎬 \
    --switch                                # Optional: make active
hermes kanban boards switch <slug>         # Switch active board
hermes kanban boards show                  # Show current board
hermes kanban boards rename <slug> "New"   # Rename display name
hermes kanban boards rm <slug>             # Archive (recoverable)
hermes kanban boards rm <slug> --delete    # Hard delete
```

### Task CRUD
```
# Create
hermes kanban create "task title" \
    --assignee profile_name \
    --body "details" \
    --parent t_abc t_def \
    --tenant gameysins \

# Idempotent create (for automation/cron)
hermes kanban create "nightly ops" \
    --assignee default \
    --idempotency-key "nightly-$(date -u +%Y-%m-%d)" \
    --json

# Query
hermes kanban list                         # All active
hermes kanban list --status done           # Filter
hermes kanban list --assignee default      # By person
hermes kanban list --tenant gameysins      # By namespace
hermes kanban show t_abcd                  # Single task detail
hermes kanban stats                        # Board stats
hermes kanban watch                        # Live activity feed

# Lifecycle (batch supported: t_abc t_def t_hij)
hermes kanban complete t_abc --result "done"                              # Simple result
hermes kanban complete t_abc --summary "..." --metadata '{"key":"val"}'   # Structured handoff
hermes kanban block t_abc "need input"
hermes kanban unblock t_abc
hermes kanban archive t_abc
hermes kanban comment t_abc "note text"
hermes kanban link t_parent t_child   # Positional args: parent child
```

## Worker Interaction (Model-side)

When you're working a task (assigned to you via profile), use `kanban_*` tools, NOT the CLI:

1. **kanban_show()** — read task (title, body, comments, prior attempts, parent handoffs)
2. **cd $HERMES_KANBAN_WORKSPACE** — navigate to workspace dir
3. **kanban_heartbeat(note="...")** — every 30-60 min during long ops
4. **kanban_complete(summary="...", metadata={...})** — finish with handoff
5. **kanban_block(reason="...")** — escalate for human input

### Metadata convention for handoffs:
```json
{
  "changed_files": ["path/to/file"],
  "verification": ["command that was run"],
  "dependencies": ["parent task or external ref"],
  "residual_risk": ["what's still open"]
}
```

## Orchestrator Pattern

When decomposing a goal into subtasks:
1. Call `kanban_show()` to read the goal
2. `kanban_create()` multiple child tasks with assignees
3. `kanban_link()` to add cross-cutting deps
4. `kanban_complete()` your orchestrator task

## Ammar's Setup

- **Default board** — general personal ops
- **Boards created**: GameySins (content pipeline)
- **Active profile**: `default` (google/gemma-4-e2b via LM Studio)
- **Gateway**: must be running for dispatcher to pick up tasks (`hermes gateway start`)
- **Tasks on default board**: daily/weekly personal ops tasks
- **Tasks on gameysins board**: video pipeline, shorts, publishing workflow

## Quick Start (new board)

```
# Initialize
hermes kanban init
hermes gateway start                # dispatcher lives here

# Create and watch
hermes kanban create "task" --assignee default
hermes kanban watch
hermes kanban list
```

## Reference Files

- **`references/cli-quirks.md`** — CLI command quirks discovered during setup (link positional args, board switching behavior, dispatcher spawning, zombie worker handling, task lifecycle edge cases).
- **`references/dispatcher-behavior.md`** — detailed testing observations and artifact handoff patterns.
- **`references/blocked-task-monitor.md`** — cron job pattern for detecting blocked tasks and DMing the user; manual notification workflow for worker agents.
## DM Notification on Blocked Tasks

When you need human input during a kanban task:
1. Call `kanban_block(reason="...")` to mark the task blocked
2. **Immediately DM Ammar** using `send_message(target='discord', message='<@525784408930910218> ⚠️ Task blocked: [title] — [reason]')`
3. The home channel (`discord`) routes directly to his DMs (channel ID 1506939046843125811)

This applies whether you're working as a worker, orchestrator, or reviewing tasks.

## Pitfalls

- Dispatcher runs inside the **gateway**. If gateway is stopped, ready tasks stay pending.
- Workers use `kanban_*` **tools**, NOT CLI commands (`hermes kanban complete`).
- If worker exits with status 0 while task is still `running`, dispatcher auto-blocks the task (protocol violation).
- Call `kanban_heartbeat()` at least once per hour on long tasks, or the dispatcher reclaims the task after 4h.
- Skills pinned to tasks via `--skill <name>` must exist on the assignee's profile.
- **Tool names differ in worker context.** Workers may not have `web_search` by that name. The kanban-worker skill covers tool discovery.
- **Batch create then link.** Create all tasks first, verify them with `list`, THEN link dependencies. The dispatcher ticks every 60s and may claim tasks before links are set.
- **Scoping commands to a board (⚠ BROKEN):** `--board <slug>` is NOT supported on `hermes kanban list` or most subcommands — do not use it. Instead, run `hermes kanban boards switch <slug>` before listing or creating tasks on a non-default board. The switch persists for the remainder of the shell session (but not across sessions).
- **Single-profile = sequential.** With only one profile, tasks queue. Use parent-child links to enforce order.

See `references/dispatcher-behavior.md` for detailed testing observations and artifact handoff patterns.
