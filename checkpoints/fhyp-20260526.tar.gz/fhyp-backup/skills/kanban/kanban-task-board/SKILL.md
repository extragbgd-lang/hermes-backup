---
title: kanban-task-board
name: kanban-task-board
description: Hermes Kanban multi-agent task board — board lifecycle, pipeline architecture, and file-system anatomy for GameSins and daily workflows.
trigger_conditions:
  - User asks about kanban setup, board structure, or architecture
  - User wants to know what boards exist and how they're organized
  - User wants to init, reset, wipe, or recover kanban boards
  - User asks about the default vs gameysins board split
  - User wants to understand how tasks flow through the system
---

# Kanban Task Board

System-level view of the Hermes Kanban setup for GameSins. This skill covers **board structure and lifecycle**; for **task creation and decomposition** see `kanban-orchestrator`, for **worker execution** see `kanban-worker`.

## Board Architecture

This machine runs **two boards**:

| Board | Slug | Purpose | Active? |
|-------|------|---------|---------|
| **Default** | `default` | Ops, experiments, system maintenance, non-gaming work | Usually main |
| **GameSins** | `gameysins` | Gaming content — scripts, production, shorts, publishing | Switched manually |

### When to Use Which

- **Gaming content** → always use `gameysins` board. Switch with `hermes kanban boards switch gameysins`.
- **Tech/ops experiments** → use `default` board. Keeps gaming pipeline clean.
- **System maintenance** → use `default` board.
- If unsure, use `default` — content-specific boards are opt-in.

## Filesystem Anatomy

```
~/.hermes/
├── kanban.db                    ← Default board (SQLite)
├── kanban/
│   ├── current                  ← Active board slug
│   ├── logs/                    ← Task run logs for default board
│   ├── workspaces/              ← Task workspaces for default board
│   └── boards/
│       └── gameysins/
│           ├── board.json       ← Board metadata (slug, name, description)
│           ├── kanban.db        ← GameSins board (SQLite)
│           ├── logs/            ← Task run logs
│           └── workspaces/      ← Task workspaces
```

## Profiles & Dispatchers

```bash
# View available profiles
hermes profile list
```

Available: `default`, `night-shift`. Paperclip agents (Research t_d5e97d81, Script t_d0230ea6, Video t_4c557f3e, SEO t_e8a7ce19, QA t_c44b84d7) can also be task assignees.

**The gateway must be running** for the dispatcher to claim tasks:
```bash
systemctl --user status hermes-gateway.service
```

The dispatcher ticks every **60 seconds** (configurable via `kanban.dispatch_interval_seconds`).

## Board Lifecycle

### First-Time Setup
```bash
# Default board (auto-created by init)
hermes kanban init

# Named boards
hermes kanban boards create gameysins --name "GameSins" --description "Gaming content pipeline"

# Verify
hermes kanban boards list
hermes gateway status
```

### Wipe & Fresh Start
Used when the user says "scrap the current setup and start fresh":

```bash
# 1. Delete DBs
rm ~/.hermes/kanban.db
rm ~/.hermes/kanban/boards/gameysins/kanban.db

# 2. Clean workspaces & logs
rm -rf ~/.hermes/kanban/logs ~/.hermes/kanban/workspaces
rm -rf ~/.hermes/kanban/boards/gameysins/logs ~/.hermes/kanban/boards/gameysins/workspaces

# 3. Remove board
hermes kanban boards rm gameysins

# 4. Re-init
hermes kanban init
hermes kanban boards create gameysins --name "GameSins" --description "Gaming content pipeline"

# 5. Verify gateway
hermes gateway status
```

## Pipeline Patterns

### Video Pipeline (GameSins)
Preferred: **short chains (2-3 tasks), parallel research.**

```
❌ Bad:  Long serial chain (7 tasks — one stuck kills the week)
✅ Good: Mini-pipelines per video
         [Research Vid A] ──→ [Script A] → [Produce A] → [Publish A]
         [Research Vid B] ──→ [Script B] → [Produce B] → [Publish B]
```

When a pipeline is blocked >24h: **propose scrapping** rather than debugging. User prefers fresh starts over unblocking stalemates.

### Tenant Namespacing
Use `--tenant` to group tasks within a board:
```bash
hermes kanban create --title "..." --assignee default --tenant video-pipeline --body "..."
hermes kanban create --title "..." --assignee default --tenant ops --body "..."
```

## Related Skills

- **kanban-orchestrator** — How to decompose goals, create tasks, set dependencies, inspect board state
- **kanban-worker** — How workers receive, execute, and complete tasks (has `kanban_show()`/`kanban_complete()` MCP tools)
- **kanban-orchestrator/references/board-management.md** — Complete board command reference
- **kanban-orchestrator/references/blocked-task-diagnostics.md** — SQLite queries for stuck tasks

## Pitfalls

- **Default board DB is at `~/.hermes/kanban.db`, NOT inside `~/.hermes/kanban/`.** Easy to miss during cleanup.
- **`--board <slug>` is NOT supported on `kanban list`.** Switch board first.
- **After wipe, verify gateway.** Tasks stay `ready` forever without it.
- **Blocked tasks don't auto-recover.** A pipeline blocked >24h is usually better scrapped than saved.
- **kanban-task-board SKILL.md was missing from disk** (registered but not found). If this happens again, recreate it with this content.