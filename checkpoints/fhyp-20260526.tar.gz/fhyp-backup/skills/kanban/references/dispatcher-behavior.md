# Kanban Dispatcher Behavior — Observed Patterns

Tested on Hermes v0.14.0 with single profile (`default`). Dispatcher runs inside gateway (systemd user service) every 60s.

## Spawn Behavior

- When multiple tasks are created at once, the dispatcher may claim ALL of them simultaneously in a single tick, spawning multiple workers. Each worker is an independent Hermes session.
- Worker processes show as `[hermes] <defunct>` (zombie) after exiting. Systemd reaps them.
- Workers get `HERMES_KANBAN_TASK` and `HERMES_KANBAN_WORKSPACE` env vars set.

## Worker Lifecycle Observations

| Task Type | Duration | Tools Used | Outcome |
|-----------|----------|------------|---------|
| Smoke test (read+complete) | 15s | kanban_show, kanban_complete | ✅ |
| YouTube API analytics | 157s | terminal, file, read_file, write_file, execute_code | ✅ Produced analytics.md |
| Web research + compilation | 214s | terminal, delegate_task, read_file, write_file | ✅ Produced research.md |
| Freelance tools research | 161s | terminal, delegate_task, read_file, write_file, find | ✅ Produced freelance-tools.md |

## Known Pitfalls

1. **Tool name mismatch**: Workers may not have `web_search` by that exact name. The model self-corrects (up to 3 retries) when it gets "Unknown tool" errors.
2. **Batch create + link race**: Creating many tasks then immediately linking them can cause the dispatcher to claim tasks before links are established. Create tasks first, verify via `list`, THEN link.
3. **Worker crashes on missing skill**: If the dispatcher passes `--skills kanban-worker` and the skill doesn't exist on disk, the worker session exits immediately with "Unknown skill(s)". Error logged to `~/.hermes/kanban/logs/<task_id>.log`.
4. **All tasks stuck "running"**: When workers crash without calling `kanban_complete()` or `kanban_block()`, tasks stay `running` until the stale timeout (4h default). Use `hermes kanban complete <task_id>` manually to unstick.
5. **Single-profile sequential execution**: With only one profile, tasks cannot run in parallel. Use parent-child dependencies to create a pipeline that flows sequentially.

## Board Storage

| Component | Path |
|-----------|------|
| Default board DB | ~/.hermes/kanban.db |
| Named board DB | ~/.hermes/kanban/boards/<slug>/kanban.db |
| Worker logs | ~/.hermes/kanban/logs/<task_id>.log (or boards/<slug>/logs/) |
| Worker workspaces | ~/.hermes/kanban/workspaces/<task_id>/ (or boards/<slug>/workspaces/) |

## Artifact Handoff Pattern

Workers write output files to their workspace directory. Downstream tasks in the pipeline can find these at `$HERMES_KANBAN_WORKSPACE/../<parent-task-id>/<filename>`. Best practice: in the task body, specify the exact filename the worker should produce and the downstream task should look for.
