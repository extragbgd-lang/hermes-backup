# Blocked Task Monitor (Cron Job Pattern)

When a kanban worker calls `kanban_block(reason="...")`, the task stays in `blocked` status until manually unblocked. The dispatcher does NOT notify the user automatically — it relies on the agent to send a message.

## Automatic Monitor via Cron Job

A cron job with the `kanban` skill can poll for blocked tasks every 5 minutes and DM the user:

```bash
hermes cron create \
  --schedule "*/5 * * * *" \
  --name "Kanban Blocked Task Monitor" \
  --skill kanban \
  --deliver discord \
  --prompt "Check both kanban boards (default and gameysins) for tasks in 'blocked' status. For each blocked task found: report the task title, reason, and board name. Use session_search to check if each task was already reported in previous runs — only report new or changed blocked tasks. If no blocked tasks exist or all are already known, respond with exactly [SILENT] to suppress delivery."
```

How it works:

1. The cron job auto-delivers the agent's final response to the configured destination
2. The agent scans both boards for `blocked` tasks
3. For each blocked task, the agent calls `session_search` to check if it was already reported in a previous cron run (by task ID, title, or board)
4. Only **new** or **newly-changed** blocked tasks get reported — previously reported ones are skipped
5. If nothing new is blocked, the agent responds with exactly `[SILENT]` — this triggers the cron delivery system to suppress the output (no message sent, no noise)

**Dedup logic**: Use `session_search(query="blocked task monitor <task_id>")` or track reported task IDs in your response by referencing past sessions. This prevents re-alerting on the same stale blocked task every 5 minutes.

**Escalation-aware dedup**: Dedup interacts with stale-block re-alerting (see below). A task that was "already reported" at a lower escalation level should be re-reported at a higher escalation level. Before deciding to skip a task, check its escalation level — if the current level is higher than any previous report, it's a new escalation, not a duplicate. Encodethe escalation level in the session_search query string to distinguish e.g. `"blocked task monitor t_c8a16b81 escalation=1"` from `"escalation=3"`.

Key rule: do NOT use `send_message` from cron prompts — the cron delivery system handles this. Just put findings in your final response, or say `[SILENT]` if there's nothing new to report.

## Manual Notification (Agent-Worker)

When you're running a kanban worker task and encounter something needing human input:

1. Call `kanban_block(reason="...")` to mark the task
2. Call `send_message(target="discord", message="<@USER_ID> ⚠ Task blocked: [title] — [reason]")` to notify the user immediately

The `send_message(target="discord")` routes to `DISCORD_HOME_CHANNEL`. If the home channel is configured as the user's DM channel (see hermes-agent/notification-routing.md), this goes directly to their DMs with a push notification.

## Dependency Chain Awareness

When blocked tasks form a **parent-child dependency chain** with a common root cause, avoid alerting on each individually — that creates noise and buries the real problem.

Pattern to follow during inspection:
1. Run `hermes kanban list --status blocked` to get all blocked tasks
2. For each, note its parents/children (shown in `kanban_show()`)
3. Trace the chain to identify the **root blocked task** (the one with no blocked parent)
4. **Report once** with: root cause, full chain of affected tasks, and a recommended resolution path

Example from a real chain (GameySins weekly pipeline):

```
Root blocked task:
  t_c8a16b81 — Mon: Script Video 1 (main)
    → Script complete, needs human review before production
    → Blocks: t_4f96dbfd (Tue: Review+Script2) → t_487e53d5 (Wed: Production) → t_6653db6b (Thu: SEO+Publish)
```

Unblocking the root task cascades through the chain. A single alert like this is more actionable than 4 separate ones.

## Stale-Block Escalation

When a blocked task remains blocked for hours with no user action, it should be re-escalated rather than staying silently deduped. The `kanban_show()` output already includes diagnostics that tell you the age:

```
Diagnostics (1):
  ⚠ [warning] Task has been blocked for 47h
     data: blocked_at=1779553670 | age_hours=48.0
```

Use this `blocked_at` timestamp or `age_hours` to determine the escalation level without having to manually compare event timestamps.

### Escalation Levels

| Level | Threshold | Trigger Action | Session Query Tag for Dedup |
|-------|-----------|----------------|---------------------------|
| 0 — Initial | Immediate | First report when task becomes blocked | `escalation=0` |
| 1 — Reminder | 4–24h stale | "gentle ping: task still blocked" | `escalation=1` |
| 2 — Escalation | 24–48h stale | "still blocked — requires attention" | `escalation=2` |
| 3 — Critical | 48h+ stale | "blocked for 2+ days — check notifications" | `escalation=3` |

### Procedure

1. Call `kanban_show(<task_id>)` and read the `blocked_at` timestamp or `age_hours` from Diagnostics
2. Determine the current escalation level from the table above
3. Build a dedup query scoped to that level: `session_search("blocked task monitor <task_id> escalation=<level>")`
4. If a prior session exists at this level → skip (already escalated here)
5. If NO prior session at this level → this is a new escalation. Report with the tone matching the level:
   - **Level 0**: `[task title] — [reason]` (neutral)
   - **Level 1**: `⏰ Ping: [task title] still blocked — [root cause summary]` 
   - **Level 2**: `⚠ Stale: [task title] blocked 24h+ — [root cause] — needs decision`
   - **Level 3**: `🔴 Critical: [task title] blocked 48h+ — [root cause] — please check`

For **dependency chains** (see section above), only escalate the root blocked task — downstream cascading tasks don't get individual re-alerts at any level.

### Example

```
Task t_c8a16b81 blocked for 48h → Level 3 (Critical)
Session search: "t_c8a16b81 escalation=3" → not found (only levels 0-2 reported)
→ REPORT: "🔴 Critical: Mon: Script Video 1 blocked 48h+ — Subnautica 2 script needs review at /mnt/d/... — please approve or redirect"
```

## Why This Is Needed

- The kanban dispatcher does not generate user-facing notifications
- Workers call `kanban_block()` silently — only the task status changes
- Without a monitor, blocked tasks sit unnoticed indefinitely

## Pitfalls

- **Dedup is essential.** Without session_search, the same blocked task gets reported every cron tick (every 5 min), creating noise. Always check previous reports before alerting.
- **But dedup without escalation = silence forever.** If dedup makes you skip every task that was "already reported," you never re-alert on long-stale blockages. Always check the escalation level before deciding to skip.
- **Dependency chains should be escalated as one unit.** When the root task is still blocked at escalation level 3, don't escalate each downstream task individually — just re-alert on the root.
- **Don't spam.** The cron job runs every 5 min but should only send a DM when a NEW block appears, an existing block CHANGES, or an escalation THRESHOLD is crossed.
- **Only `blocked` tasks matter for notification.** `running`, `todo`, and `ready` tasks are the dispatcher's job and don't need human attention.
- **Two boards, one monitor.** The prompt should check both `default` and `gameysins` boards.
- **If the cron job itself fails** (401, provider error, network issue), the monitor goes silent. Monitor for cron failures separately or use a heartbeat check (see system-monitoring-heartbeat skill). A silent monitor looks the same as "nothing to report."
