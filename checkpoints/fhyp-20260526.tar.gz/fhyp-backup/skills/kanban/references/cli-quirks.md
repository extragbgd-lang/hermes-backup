# Kanban CLI Quirks & Discovered Behavior

## Link Command

`link` uses **positional args**, not `--parent`/`--child` flags:

```
hermes kanban link t_parent_id t_child_id
```

Do NOT use:
```
hermes kanban link --parent t_abc --child t_def   # ERROR
```

## Board Switching

```
hermes kanban boards switch gameysins
```

After switching, subsequent `list`, `create`, etc. operate on the switched board for the remainder of the shell session. The switch does NOT persist across new shell sessions or cron invocations.

### Pseudo-flag `--board` does NOT work

The `hermes kanban --board <slug>` flag is **not supported** — tested on `list` and `create` commands. It produces:

```
hermes: error: unrecognized arguments: --board <slug>
```

**Correct workaround**: always run `boards switch` as a separate command before operating on a non-default board:

```
hermes kanban boards switch gameysins
hermes kanban list --status blocked
hermes kanban create "task title" --assignee default
```

If you need to check multiple boards in a single session, switch between them explicitly:

```
hermes kanban boards switch default && hermes kanban list
hermes kanban boards switch gameysins && hermes kanban list
```

## Dispatcher Behavior

- The dispatcher runs **inside the gateway process** (`hermes gateway start`).
- When a task is created with status `ready`, the dispatcher picks it up on the **next tick** (every 60s by default, configurable via `kanban.dispatch_interval_seconds`).
- It spawns the assigned profile as a child OS process with `HERMES_KANBAN_TASK` set.
- **Only one profile exists** (`default`), so the dispatcher spawns the same profile that's running the current chat session. This can create duplicate sessions or zombie processes.

### Zombie Worker Processes

If a worker process exits without calling `kanban_complete()` or `kanban_block()`, the task stays in `running` status and the process becomes a zombie (defunct). The dispatcher reclaims it after the stale timeout (default: 4h with no heartbeat in the last hour).

**To manually fix stuck tasks:**
```
hermes kanban complete t_abc --result "cleaned up"
hermes kanban archive t_abc
```

### All Tasks Become "running" at Once

When linking parents/children after creation, the dispatcher may claim all linked tasks simultaneously even though some have pending parents. This is because they were created as `ready` before links were added. **Best practice**: create tasks, link them immediately, then let the dispatcher handle them naturally.

## Task Creation with Parents

```
hermes kanban create "child task" --assignee default --parent t_parent_id
```

The `--parent` flag accepts multiple IDs: `--parent t_abc t_def`. The task starts in `todo` status and is promoted to `ready` when ALL parents complete.

## Complete Command

Three output modes:
```
hermes kanban complete t_abc --result "simple summary"                   # Simple
hermes kanban complete t_abc --summary "brief"                           # Summary (for downstream)
hermes kanban complete t_abc --summary "structured" --metadata '{"k":"v"}' # Full handoff
```

- `--result`: simple text result (applied to all task_ids in batch)
- `--summary`: structured handoff note for downstream tasks. Falls back to `--result` if omitted.
- `--metadata`: JSON dict of machine-readable handoff facts

## Workspace Types

Three kinds:
1. `scratch` (default) — fresh tmp dir under `~/.hermes/kanban/workspaces/<id>/`
2. `dir:<path>` — existing shared directory (absolute path only, no relative paths)
3. `worktree:<path>` — git worktree for coding tasks

## Board Resolution Order

1. `--board <slug>` on the CLI call (highest)
2. `HERMES_KANBAN_BOARD` env var (set by dispatcher for workers)
3. `~/.hermes/kanban/current` — persisted by `boards switch`
4. `default` (fallback)

## Idempotent Create

For cron/automation, use `--idempotency-key` to avoid duplicates:
```
hermes kanban create "nightly review" \
    --assignee default \
    --idempotency-key "review-$(date -u +%Y-%m-%d)" \
    --json
```
Returns the existing task_id on subsequent identical-key calls instead of creating duplicates.

## Protocol Violation

If a worker process exits with **exit code 0** while the task is still `running`, the dispatcher treats this as a protocol violation, emits a `protocol_violation` event, and **auto-blocks** the task on the next tick. It does NOT respawn it into the same loop. This usually means the model wrote a plain-text answer and exited without using `kanban_complete()`.
