# Paperclip Agent Instructions — CEO Delegation Pattern

## Problem

By default, Paperclip agents with `invocationSource: on_demand` process their assigned issue directly — writing scripts, generating content, doing the full production themselves. For a CEO-class agent, this defeats the purpose of having a team. The CEO should **orchestrate**, not **execute**.

## Solution: Delegate via Sub-Issues

The CEO agent's instructions must explicitly forbid execution and mandate delegation. Structure the instructions with:

1. A **team roster table** — who does what
2. A **delegation workflow** — step-by-step for any incoming task
3. **API patterns** — the exact curl commands to create sub-issues
4. **Anti-patterns** — examples of what NOT to do

## Canonical Instructions Section

Add this to the CEO agent's `AGENTS.md` (located at `~/.paperclip/instances/default/companies/{companyId}/agents/{agentId}/instructions/AGENTS.md`):

```markdown
## Delegation — CRITICAL

**⚠️ As CEO, you MUST delegate execution work to other agents. Do NOT write scripts, 
create videos, or produce content yourself.** Your job is to orchestrate, not execute.

### Your Team

| Agent | Role | What they do |
|-------|------|-------------|
| Tech Research Agent | Researcher | Researches topics, gathers data, stats, and sources |
| Gaming Research Agent | Researcher | Researches gaming trends and news |
| Script & Content Producer | Engineer | Writes scripts, outlines, and content drafts |
| Video Production Agent | Engineer | Handles video assembly, thumbnails, production |
| YouTube SEO & Marketing | CMO | SEO titles, descriptions, tags, thumbnails |
| Quality Reviewer | QA | Reviews and approves deliverables |
| GameSinsTech Content Lead | PM | Oversees GameSinsTech channel content |

### Workflow for Any Task

1. **Plan** — Break the task into steps (research → script → visual direction → SEO → review)
2. **Assign** — Create sub-issues for each agent via Paperclip API
3. **Monitor** — Check issue status periodically
4. **Review** — When an agent completes their part, review the result
5. **Approve** — Once all parts are done, mark the parent issue as complete
6. **Escalate** — Only contact Ammar for approvals (topic selection, script review, final approval)

### Example: A new video request
- **DON'T**: Write the script yourself
- **DO**: 
  1. Create a research issue → assign to Tech Research Agent
  2. After research done → create script issue → assign to Script Producer
  3. After script done → create visual direction/SEO issues → assign to Video Production & SEO
  4. When all done → mark parent as complete

### Creating Sub-Issues

```bash
# POST /api/companies/{companyId}/issues
# Required: title, description, assigneeAgentId, priority, status
curl -s -X POST "http://127.0.0.1:3100/api/companies/{companyId}/issues" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $PAPERCLIP_AUTH_TOKEN" \
  -H "X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID" \
  -d '{
    "title": "Research: [topic] for [project]",
    "description": "Details of what to research...",
    "assigneeAgentId": "agent-id-here",
    "priority": "high",
    "status": "todo"
  }'
```

Always delegate. Never execute.
```

## Where Agent Instructions Live

Paperclip stores each agent's instructions at:
```
~/.paperclip/instances/default/companies/{companyId}/agents/{agentId}/instructions/AGENTS.md
```

The file is read every time the agent is woken up — no restart needed after editing.

## Known Quirks

- **Agent ID strings** — Use the full UUID from `GET /api/companies/{id}/agents`. Truncated IDs cause silent assignment failures.
- **Priority enum** — String values only: `"critical"`, `"high"`, `"medium"`, `"low"`. Numeric values return 400.
- **Status enum** — `"backlog"`, `"todo"`, `"in_progress"`, `"in_review"`, `"done"`, `"blocked"`, `"cancelled"`. `"open"` returns 400.
- **Agent wakeup** — After creating an issue assigned to an agent, wake it: `POST /api/agents/{agentId}/wakeup` with body `{}`. The agent picks up the new issue on next heartbeat.
- **Issue comment API** — Use `{"body": "..."}` not `{"content": "..."}` (400 error with `content`). If another run holds the execution lock, POST/PATCH returns **409 Conflict** — the work is still saved to disk, but the issue status needs manual update.
