# Obsidian-Compatible Memory Vault

Connect Hermes Agent to an external markdown vault for persistent long-term memory beyond the built-in 2KB memory slot. The vault is just `.md` files in a folder — works with Obsidian, VS Code, Notepad, or anything that reads markdown.

---

## Two Approaches

### 1. File-Based (Simpler, No Plugins Needed)

Hermes reads/writes `.md` files directly using file tools. Works without Obsidian installed.

| Aspect | Detail |
|--------|--------|
| **Setup** | Create folder structure on disk |
| **Cost** | Instant — no app, no install |
| **Obsidian** | Later, open folder as vault — `[[wikilinks]]` work |
| **Running** | Works even when Obsidian is closed |

### 2. Local REST API Plugin (More Structured)

Install the **Local REST API** community plugin in Obsidian. Hermes calls `http://localhost:27124` for proper CRUD, search, and link traversal.

| Aspect | Detail |
|--------|--------|
| **Setup** | Install plugin in Obsidian |
| **Cost** | Requires Obsidian running in background |
| **API** | REST — create, read, update, delete, search notes |
| **Capability** | Folder navigation, link traversal, tags |

---

## Vault Folder Convention (File-Based Approach)

Standard structure proven in practice:

```
<vault-root>/
├── _index.md              # Table of contents with [[wikilinks]]
├── projects/              # Project wikis and pipelines
├── people/                # User profiles, contacts, preferences
├── tools/                 # Tool configs, workflows, integrations
└── decisions/             # Decision log (dated entries)
```

### File Conventions

- **`_index.md`** — Top-level table of contents. Lists all sections with [[wikilinks]].
- **Wikilinks** — Use `[[relative/path/without-extension]]` for cross-references. Obsidian renders these natively.
- **Frontmatter** — Optional YAML frontmatter for metadata.
- **Dates** — Decision logs use `YYYY-MM-DD-slug.md` format.
- **Links to external resources** — Standard markdown `[text](url)`.

---

## How Hermes Uses the Vault

The vault supplements (does not replace) the built-in `memory` tool:

| Layer | Purpose | Size Limit |
|-------|---------|------------|
| Built-in memory | Always-on context — user prefs, critical rules, environment facts | ~2KB |
| Vault | Deep storage — project wikis, decision logs, research notes, full profiles | Unlimited |

**Workflow:**
1. **Read** — Before answering contextual questions, search vault files with `search_files`
2. **Write** — After learning something durable, save it to the vault under the appropriate folder
3. **Update** — When a project changes, edit the relevant vault note
4. **Log** — Major decisions get a dated entry in `decisions/`

---

## Migration from Built-In Memory

When the 2KB memory slot is full:
1. Move larger entries to vault files (project details, tool configs)
2. Keep only compact rules and critical preferences in built-in memory
3. Update built-in memory to point to the vault location

---

## Pitfalls

- **Path translation** — On WSL, Windows paths like `D:\Hermes-Vault\` map to `/mnt/d/Hermes-Vault/`. Always use the WSL path for reading/writing, but tell the user the Windows path for browsing.
- **No auto-sync** — If the vault is file-based, there's no conflict detection. Two agents writing simultaneously could overwrite each other (not a practical issue for single-user setups).
- **File size** — Very large `.md` files (>100KB) may hit `read_file` limits. Break into sub-files if needed.
- **No built-in search indexing** — `search_files` is regex-based, not semantic. For proper semantic search over vault content, the Local REST API plugin is better.
- **Obsidian sync caveat** — If the user syncs their vault (Obsidian Sync, iCloud, etc.), file-based writes while Obsidian is open could trigger re-indexing. The plugin approach is safer if the vault is actively used.
