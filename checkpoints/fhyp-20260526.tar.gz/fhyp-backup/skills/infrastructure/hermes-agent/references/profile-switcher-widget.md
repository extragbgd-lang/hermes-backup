# Hermes Profile Switcher — Windows Desktop Widget

A PowerShell WinForms GUI that sits on the Windows desktop and lets the user switch Hermes Agent profiles with one click. Communicates with Hermes over WSL via `wsl.exe`.

## Simpler Alternative: Batch Menu (.bat)

If the user says "simpler" or a GUI is overkill, replace the PowerShell widget with a single `.bat` file that shows a numbered menu:

```
@echo off
title Hermes Profile Switcher
cls
echo ===============================================
echo        HERMES PROFILE SWITCHER
echo ===============================================
echo.
echo  Current profile:
wsl /home/ammar/.local/bin/hermes profile list 2>&1 | findstr "◆"
echo.
echo ===============================================
echo  1  DeepSeek V4 (Online)   - default
echo  2  LM Studio (Local)      - paperclip-agent
echo  3  Local Qwen             - assistant-local
echo  4  Gemma 4 Free           - ceo-free
echo  5  Gemma 4 LM             - lmstudio
echo ===============================================
echo.
set /p choice="Pick a profile (1-5) or 0 to exit: "

if "%choice%"=="1" wsl /home/ammar/.local/bin/hermes profile use default
if "%choice%"=="2" wsl /home/ammar/.local/bin/hermes profile use paperclip-agent
if "%choice%"=="3" wsl /home/ammar/.local/bin/hermes profile use assistant-local
if "%choice%"=="4" wsl /home/ammar/.local/bin/hermes profile use ceo-free
if "%choice%"=="5" wsl /home/ammar/.local/bin/hermes profile use lmstudio
if "%choice%"=="0" exit /b

echo.
echo Done!
pause >nul
cls
echo Current profile:
wsl /home/ammar/.local/bin/hermes profile list 2>&1 | findstr "◆"
pause >nul
```

**When to use which:** Always offer the .bat menu first. Only build the PowerShell GUI if the user wants a persistent floating widget.

## Architecture

```
┌────────────────────────────┐     ┌──────────────────────┐
│  Windows Desktop Widget     │     │  WSL (Ubuntu)         │
│  (PowerShell WinForms .ps1) │────►│  wsl.exe -d Ubuntu …  │
│                              │◄────│  hermes profile use   │
│  Shows: current profile     │     │  hermes profile list  │
│  Click: switch & refresh    │     └──────────────────────┘
└────────────────────────────┘
```

## How It Works

- Each button maps to a Hermes profile
- On click: runs `wsl.exe -d <distro> -- hermes profile use <name>`
- On load & every 30s: runs `wsl.exe -d <distro> -- hermes profile list` to detect active profile (looks for ◆ marker)
- Active profile button is bright + bold; inactive dimmed
- Small floating window with dark theme, always-on-top option

## Profiles Configuration

The widget defines profiles as an array of hashtables:

```
$profiles = @(
    @{ Name = "default";         Label = "DeepSeek V4 (Online)";  Color = "#1a73e8" }
    @{ Name = "paperclip-agent"; Label = "LM Studio (Local)";     Color = "#34a853" }
    @{ Name = "assistant-local"; Label = "Local Qwen";            Color = "#ea8600" }
    @{ Name = "ceo-free";        Label = "Gemma 4 Free";          Color = "#9334e6" }
    @{ Name = "lmstudio";        Label = "Gemma 4 LM";            Color = "#666666" }
)
```

Each entry needs:
- **Name** — matches the Hermes profile name (from `hermes profile list`)
- **Label** — human-readable display text on the button
- **Color** — hex color for the button

## Setup Instructions

### 1. Place the Script

Save `HermesProfileSwitcher.ps1` on the Windows Desktop at:
```
C:\Users\<username>\Desktop\HermesProfileSwitcher.ps1
```

### 2. Create a Silent Shortcut

1. Right-click the `.ps1` → **Create Shortcut**
2. Right-click the shortcut → **Properties**
3. In **Target**, replace with:
   ```
   powershell.exe -WindowStyle Hidden -File "C:\Users\<username>\Desktop\HermesProfileSwitcher.ps1"
   ```
4. Optionally: set **Run** to **Minimized** for cleaner launch
5. Double-click the shortcut to launch

### 3. (Optional) Auto-Start with Windows

1. Press `Win+R`, type `shell:startup`, press Enter
2. Move the shortcut into the Startup folder

## Key Implementation Details

### Detecting Active Profile

Parses `hermes profile list` output looking for the ◆ marker:

```
Get-ActiveProfile:
  foreach line in "hermes profile list":
    if line matches "◆\s+(\S+)": return capture group 1
```

### Switching Profile

```powershell
wsl.exe -d Ubuntu-24.04 -- hermes profile use <name> 2>&1
```

Checks output for "Switched to" to confirm success.

### State Polling

A 30-second `System.Windows.Forms.Timer` re-reads the profile list so the widget self-corrects if the profile was changed externally (e.g., by another session or a Paperclip agent).

## Pitfalls

- **WSL distro name mismatch** — The `$wslDistro` variable must match the actual WSL installation name. Verify with `wsl.exe --list` on Windows. Default Ubuntu install is `Ubuntu` or `Ubuntu-24.04`.
- **Hermes CLI not in WSL PATH** — `wsl hermes` runs in a non-interactive shell that doesn't load `~/.local/bin`. Calling `wsl hermes profile list` directly from Windows will fail with `command not found`. **Fix: use the full path** — `wsl /home/ammar/.local/bin/hermes profile list`. All `wsl` calls in the widget must use this full path, not the bare `hermes` command.
- **Gateway must be running** — Switching profiles doesn't restart the gateway. If the target profile's gateway is stopped, the user won't get message delivery. The widget only switches the default profile.
- **PowerShell execution policy** — By default Windows may block `.ps1` scripts. If double-clicking gives an error, run once from an admin PowerShell: `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser`
- **Window stays on top** — `TopMost = true` by default so the widget is always visible. Can be toggled with the "Always on Top" button.
- **No admin rights needed** — The widget runs in user space. No elevation required.

## When to Build This

- User asks for a desktop widget, profile switcher, or quick-switch UI
- User has multiple Hermes profiles (local/online, free/paid) and frequently switches
- User is on Windows + WSL and prefers GUI over CLI commands
