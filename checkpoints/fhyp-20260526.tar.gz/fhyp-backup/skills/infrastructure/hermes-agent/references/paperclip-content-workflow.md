# Paperclip Content Production Workflow

How to route content production through Paperclip agents instead of doing the work directly.

## When to Route Through Paperclip

- User says "run through paperclip", "use the CEO", "ask the team"
- User wants a multi-step content pipeline (research → script → images → b-roll → SEO)
- The task involves delegating to multiple specialized agents

## Workflow

### 1. Create an Issue

```bash
COMPANY_ID="ba4e7d36-e75a-44eb-97c9-5432d71f0c50"
CEO_ID="dba985c6-7ba3-4b7f-8ac2-1a3c538f7889"

curl -s -X POST "http://127.0.0.1:3100/api/companies/$COMPANY_ID/issues" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Issue title here",
    "description": "Full brief here. Include DELEGATION instructions in the description — tell CEO which agents to assign sub-tasks to.",
    "assigneeAgentId": "'$CEO_ID'",
    "priority": "high",
    "status": "todo"
  }'
```

Valid statuses: `backlog`, `todo`, `in_progress`, `in_review`, `done`, `blocked`, `cancelled`
Valid priorities: `critical`, `high`, `medium`, `low`

### 2. Wake the CEO

```bash
curl -s -X POST "http://127.0.0.1:3100/api/agents/$CEO_ID/wakeup" \
  -H "Content-Type: application/json" -d '{}'
```

### 3. Monitor Progress

```bash
# Check issue status
curl -s "http://127.0.0.1:3100/api/issues/ISSUE_ID"

# Check comments (the agent posts results here)
curl -s "http://127.0.0.1:3100/api/issues/ISSUE_ID/comments"

# Check for sub-issues created by CEO
curl -s "http://127.0.0.1:3100/api/companies/$COMPANY_ID/issues?assigneeAgentId=AGENT_ID"
```

## Known Issues

### CEO Delegation Fails on Local Models

The CEO agent claims to delegate but marks issues "done" without creating sub-issues. This happens consistently on gemma-4-e2b and qwen models — they process the delegation instructions but don't execute the curl commands to create sub-issues.

**Symptoms:**
- Issue status changes to "done" but no new sub-issues exist
- Comment says "Delegated all steps" or similar
- The only issue is the parent — no sub-issues for Research, Script, Video, SEO agents

**Direct Assignment Workaround (reliable path):**
Skip the CEO entirely. Create separate issues for each worker agent and wake them individually:

```
# Create worker issues directly
curl -s -X POST "http://127.0.0.1:3100/api/companies/COMPANY_ID/issues" -H "Content-Type: application/json" \
  -d '{"title":"SUB: task name","description":"detail","assigneeAgentId":"WORKER_AGENT_ID","priority":"high","status":"todo"}'

# Wake each worker
curl -s -X POST "http://127.0.0.1:3100/api/agents/WORKER_AGENT_ID/wakeup" -H "Content-Type: application/json" -d '{}'
```

### Agent Gets Stuck in "running" State

The Hermes adapter session exits without Paperclip recording completion. The agent stays "running" permanently — new wakeups get queued but never execute.

**Symptoms:**
- `GET /api/agents/{id}` shows "running" but no Hermes CLI process exists
- Wakeups return "queued" but never change to active
- The agent has an old `lastHeartbeatAt` timestamp

**Recovery sequence:**
1. Kill any stuck Hermes CLI processes: `pkill -f "hermes chat.*CEO"` (check first with ps aux)
2. Reset agent to idle: `PATCH /api/agents/{id}` with `{"status": "idle", "error": null}`
3. Re-wake with fresh session: `POST /api/agents/{id}/wakeup` with `{"forceFreshSession": true}`
4. Verify: `ps aux | grep "hermes chat" | grep -v grep` should show new processes
5. Wait 30s, check `GET /api/issues/{id}` for status change

**Prevention:** The heartbeat script (~/.hermes/scripts/heartbeat_check.sh) does NOT reset stuck agents. If this happens repeatedly, add a cron job that checks for agents stuck "running" with no Hermes process and auto-resets them.

## Tips for Better Results

1. **Include delegation instructions in the issue description** — explicitly tell the CEO which agents should handle which parts
2. **GameSinsTech vs GameySins:** Always clarify the channel. GameSinsTech = tech channel (AI, tools, career). NOT gaming.
3. **Output to Notion:** The CEO may save files locally. Instruct it to save to Notion under the Main Brain page.
4. **Full production package:** For Shorts, the expected output includes: deep script + generated images + b-roll compositions + SEO package. A script alone is considered incomplete.
