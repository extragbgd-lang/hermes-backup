# Cron Job Debugging

How to diagnose and fix cron jobs when the user says they didn't run or didn't notify.

## Quick Diagnostic (Start Here)

```
cronjob action='list'
```

Check these fields for each job:
- `last_status` — `ok`, `error`, or `null` (never run)
- `last_run_at` — if `null`, the job hasn't hit its first schedule window yet
- `last_delivery_error` — any delivery failure message
- `deliver` — where output goes (`discord`, `local`, `discord:guild:channel`, etc.)
- `next_run_at` — when it will fire next

## Silent Delivery: The Most Common "It's Not Working"

Three patterns cause silence even when the job runs successfully:

### 1. `no_agent: true` Script with Empty stdout
Script-based jobs (no_agent: true) that exit with code 0 and no stdout are SILENT by design. This is intentional for health-check scripts — you only hear from them when something is wrong.

Example: The heartbeat script outputs nothing when all checks pass. It only prints to stdout on warnings/failures:
```bash
# Healthy → empty stdout → silent, no delivery
# Warning/failure → stdout has content → delivery fires
```

### 2. Agent Outputs `[SILENT]`
Agent-driven cron jobs that respond with exactly `[SILENT]` (nothing else) have their delivery suppressed. This is for "nothing to report" scenarios.

Example: The Kanban Blocked Task Monitor outputs `[SILENT]` when no tasks are blocked — no delivery.

### 3. `deliver: "local"` Target
Output is saved to the session file but never sent to any messaging platform. The user sees nothing. Change to `discord` or `discord:channel_id` for notifications.

## Reading Cron Session Files

Every cron run produces a session file:
```
~/.hermes/sessions/session_cron_<job_id>_<timestamp>.json
```

Reading the last assistant message:
```python
import json, glob, os
sessions = sorted(glob.glob(f'{os.path.expanduser("~")}/.hermes/sessions/session_cron_JOBID_*'), reverse=True)
with open(sessions[0]) as f:
    data = json.load(f)
msgs = [m for m in data['messages'] if m.get('role') == 'assistant']
if msgs:
    print(msgs[-1]['content'][:500])
```

## Script Path Rules

- Cron `script` values must be **relative to `~/.hermes/scripts/`**
- Example: `script: "heartbeat_check.sh"` resolves to `~/.hermes/scripts/heartbeat_check.sh`
- Absolute paths and `~`-relative paths are **rejected**
- Scripts in `~/scripts/` must be copied to `~/.hermes/scripts/` for cron use
- Symlinks to `~/scripts/` from `~/.hermes/scripts/` are treated as path traversal — copy the file instead

## Common Fixes

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| Never ran (`last_run_at: null`) | Created after schedule time, hasn't hit window yet | Wait for next schedule slot, or `cronjob action='run'` |
| Error status | Script path wrong, missing dependency, permission | Check script exists in `~/.hermes/scripts/`, check session file for error |
| Runs but silent | Empty stdout (no_agent), `[SILENT]` output, or `local` delivery | Add stdout for no_agent scripts, change delivery target |
| Delivers wrong place | Delivery string points to wrong channel | Check `deliver` field, use `discord:guild:channel` for specific targets |
| Wrong time | Timezone mismatch | System timezone is Asia/Dubai (GMT+4), cron schedules are local |

## Timezone
System runs on Asia/Dubai (GMT+4). All cron schedules are interpreted in local time. `0 8 * * *` = 8:00 AM Dubai time.
