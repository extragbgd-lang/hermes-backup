# Discord DM Channel Routing

When `send_message(target='discord:USER_ID')` returns `404 Unknown Channel`, it's because Hermes treats the value as a literal Discord channel ID, not a user ID. On Discord, DM channels have their own unique snowflake IDs separate from user IDs.

## Technique: Finding the DM Channel ID

Use the Discord API to create/retrieve a DM channel between the bot and a user:

```python
import json, urllib.request

token = open('~/.hermes/.env').read().split('DISCORD_BOT_TOKEN=')[1].split('\n')[0].strip()
user_id = 'USER_DISCORD_ID'

req = urllib.request.Request(
    'https://discord.com/api/v10/users/@me/channels',
    data=json.dumps({'recipient_id': user_id}).encode(),
    headers={
        'Authorization': f'Bot {token}',
        'Content-Type': 'application/json',
        'User-Agent': 'HermesAgent/1.0'
    }
)
resp = urllib.request.urlopen(req)
data = json.loads(resp.read())
dm_channel_id = data['id']  # This is the real DM channel ID
```

If a DM channel already exists (user has DMed the bot before), this returns the existing channel. If not, Discord creates one.

## Configuring DMs as the Home Channel

Once you have the DM channel ID, set `DISCORD_HOME_CHANNEL` to it:

```yaml
# ~/.hermes/.env
DISCORD_HOME_CHANNEL=DM_CHANNEL_ID  # Not a user ID — the actual DM channel snowflake
```

Now `send_message(target='discord')` delivers to the DM channel. Cron jobs with `deliver: "discord"` also go there.

**Verification — check that it's really a DM channel:**
```python
req = urllib.request.Request(
    f'https://discord.com/api/v10/channels/{channel_id}',
    headers={'Authorization': f'Bot {token}', 'User-Agent': 'HermesAgent/1.0'}
)
data = json.loads(urllib.request.urlopen(req).read())
# data['type']: 1 = DM, 0 = guild text channel, 5 = guild news, etc.
```

## Cron-Based Notification Monitoring Pattern

For automated notifications (e.g., kanban blocked task alerts), create a cron job that delivers to the home channel (= DMs):

```yaml
schedule: "*/5 * * * *"        # Every 5 minutes
deliver: "discord"              # Routes to home channel = DM
skills: ["kanban"]              # Load kanban skill for board access
```

The agent in the cron job checks for blocked/attention-needed tasks and DMs the user automatically.

## Limitations

- The `send_message` tool in Hermes does NOT auto-create DM channels — it only sends to an existing channel by ID
- User must have "Allow direct messages from server members" enabled in Discord privacy settings
- DM channel IDs persist as long as neither party deletes/leaves the conversation
- Notion API integrations CANNOT create workspace-level pages — always create as child of an existing page
