# YouTube Video Investigation

Two modes depending on what the user wants: **(A) Tool/App Identification** (find a GitHub repo from a video) or **(B) Content Analysis** (extract use cases, plugins, integrations from the video's transcript).

---

## (A) Tool/App Identification

Use this when the user shares a video and asks "what tool is this?" or "get me this app."

1. **Navigate to the YouTube URL** with `browser_navigate`
2. **Read the video title** to identify the tool name — it's usually in the title or description
3. **Reveal the description** by clicking "...more" (`browser_click` on the element)
4. **Check the description** for links (GitHub, Skool, Patreon, website, etc.)
5. **Search GitHub** by navigating to `https://github.com/search?q=<tool+name>&type=repositories&s=stars&o=desc`
6. **Open the top result** that matches (sort by stars)
7. **Read the README via curl** from `raw.githubusercontent.com` — much faster and cleaner than browser snapshots
8. **Verify features match** what was shown in the video before presenting

### Edge Cases

- **Tool not on GitHub.** Some YouTube creators promote paid/community-only tools (e.g., hosted on Skool, Patreon, or a private repo). If GitHub search returns nothing relevant or the user corrects the name, ask for the exact link — don't keep searching blind.
- **User corrects the tool name.** If the user says "that's not it, it's called X", don't argue or insist. Accept the correction immediately and search again with the new name. If still not found, ask for a direct link.

### Example

- Finding `hermes-web-ui` (EKKOLearnAI/hermes-web-ui) from a Julian Goldie SEO video about "Hermes Agent OS"

---

## (B) Content / Use-Case Analysis

Use this when the user shares a video and asks "what plugins/integrations/workflows are in this?" or "tell me what this video covers."

### Workflow

1. **Get the page snapshot** — `browser_navigate` to the YouTube URL. Read the title and description from the returned snapshot.
2. **Download the transcript** — Use `yt-dlp` to fetch auto-generated subtitles:
   ```bash
   yt-dlp --write-auto-subs --sub-lang en --skip-download --convert-subs srt -o "/tmp/video-transcript" "<VIDEO_URL>"
   ```
   Then read the SRT file via `read_file` or `cat`.
3. **Get full description** — Scroll down with `browser_scroll('down')` then take a full `browser_snapshot(full=true)` or click "...more" (`browser_click` on the "...more" element) to reveal the entire description.
4. **Analyze the transcript** — Read through the SRT content to identify:
   - Specific tools, plugins, or apps mentioned by name
   - Workflows and integrations demonstrated
   - Installation steps or setup commands shown
   - Links mentioned (check the description for associated URLs)
5. **Categorize findings** — For each item, determine if it's:
   - **Built-in** (already available in the user's Hermes setup)
   - **Configurable** (can be set up with a prompt/cron/skill)
   - **Installable** (requires a 3rd-party tool via apt/pip/npm)
   - **External** (needs an API key, account, or hardware)
6. **Present findings** grouped by category so the user can choose what to implement.

### When to Use Each Mode

| Mode | User says | Use when |
|------|-----------|----------|
| (A) Tool ID | "what's this app?", "get me this tool", "is this on GitHub?" | Video promo a specific product/app |
| (B) Content Analysis | "tell me what's in this", "check the plugins", "can I use these workflows?" | Tutorial, use-case list, or demo video about a system the user already has |

### Pitfalls

- **video_analyze tool may fail** (brotli decoder errors). Fall back to the yt-dlp transcript workflow — it's more reliable for YouTube content.
- **Transcript quality varies.** Auto-generated subs may garble technical terms, product names, or non-English words (especially code-switching like Arabic/English). Cross-reference with the video description.
- **Browser snapshots truncate long descriptions.** Always scroll down first, then click "...more" before taking a full snapshot.
- **yt-dlp JS runtime warning** is non-fatal. The warning about "No supported JavaScript runtime" can be ignored for subtitle downloads — it still works.
- **Long transcripts (15min+)** may produce 80K+ chars of SRT output. Read in chunks or skip timestamp lines to focus on content.
