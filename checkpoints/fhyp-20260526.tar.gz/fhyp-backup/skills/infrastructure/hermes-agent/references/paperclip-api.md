# Paperclip — AI Agent Company Builder (HenkDz fork)

Paperclip is an open-source orchestration platform that manages a team of AI agents with org charts, budgets, goals, governance, and heartbeats. Think of it as "building an AI company" — define missions, hire agents into roles, and they work autonomously toward goals.

**Reference:** `paperclip-content-workflow.md` — How to produce content through Paperclip (delegation, output to Notion, channel identity rules). Read this before creating any content request.

**GitHub:** https://github.com/paperclipai/paperclip (upstream)  
**Fork in use:** https://github.com/HenkDz/paperclip (Hermes adapter externalized)  
**Stars:** 67.2k+ (upstream)  
**Docs:** https://docs.paperclip.space  
**Tutorial:** https://paperclip.space/tutorials/your-first-paperclip-company

## Quick Install (WSL)

```bash
# Option A: npx (easiest — no clone, no pnpm)
npx paperclipai onboard --yes

# Option B: Cloned repo (needed for adapter plugin support)
cd /home/ammar
git clone https://github.com/HenkDz/paperclip.git
cd paperclip
pnpm install
pnpm dev
```

**NTFS note:** `npx vite build` hangs on NTFS — use `node node_modules/vite/bin/vite.js build`. Server startup from NTFS takes 30–60s.

## Running & Restarting

Port: **3100** (auto-falls to 3101+ if taken). Foreground process.

```bash
# Health check
curl http://localhost:3100/api/health
# → {"status":"ok","version":"2026.517.0","bootstrapStatus":"ready","authReady":true}

# From cloned repo
cd /home/ammar/paperclip && pnpm dev

# From npx (if no clone)
npx paperclipai run

# Full kill
pkill -f "paperclip"; pkill -f "tsx.*index.ts"
```

**⚠️ Gateway restart kills Paperclip:** After `systemctl --user restart hermes-gateway.service`, always check `curl http://localhost:3100/api/health` and restart Paperclip if needed.

## Data Persistence

- Embedded PostgreSQL at `~/.paperclip/instances/default/db`
- Auto-backups every 60m, keep 30 days
- Config: `~/.paperclip/instances/default/config.json`
- Env overrides: `~/.paperclip/instances/default/.env`

## API Reference

All prefixed with `/api`. Board-level auth in `local_trusted` mode — no JWT needed.

### Companies

```bash
GET  /api/companies                         # List
POST /api/companies                         # Create
PATCH /api/companies/{id}                   # Update (budget, name, etc.)
```
Create body: `{name, description?, budgetMonthlyCents?, status?}`

### Agents (Troubleshooting)

**Agent stuck in "running" state (common issue):** The Hermes adapter session exits without updating Paperclip status. The agent shows "running" but no Hermes CLI process exists.

**Fix — force reset:**
```bash
PATCH /api/agents/{id} -H "Content-Type: application/json" -d '{"status": "idle", "error": null}'
# Then re-wake:
POST /api/agents/{id}/wakeup -H "Content-Type: application/json" -d '{"forceFreshSession": true}'
```

Make sure to check `ps aux | grep hermes` first to confirm no Hermes process is actually running. If a process IS running, the agent is legitimately busy.

**CEO delegation limitation:** CEO agents on local models (qwen2.5-coder-7b-instruct, gemma-4-e2b) and even free OpenRouter models consistently fail at multi-step delegation. They read the task, write a comment saying "delegated," but create zero sub-issues. **Direct worker assignment** (create issues directly assigned to specialist agents, skip the CEO) is more reliable.

**Comment API gotcha:** Use `body`, not `content`:
```bash
# CORRECT:
POST /api/issues/{id}/comments -H "Content-Type: application/json" -d '{"body": "text"}'
# WRONG (returns 400):
POST /api/issues/{id}/comments -H "Content-Type: application/json" -d '{"content": "text"}'
```

```bash
GET  /api/companies/{id}/agents             # List
POST /api/companies/{id}/agents             # Create
GET  /api/agents/{id}                       # Get single agent
PATCH /api/agents/{id}                      # Update (adapterType, adapterConfig, etc.)
POST /api/agents/{id}/wakeup               # Wake agent to process on_demand
```

### Issues

```bash
```bash
GET  /api/issues/{id}                       # Get single issue
PATCH /api/issues/{id}                      # Update (assigneeAgentId, status)
GET  /api/issues/{id}/comments              # Get agent comments on issue
POST /api/issues/{id}/comments              # Add comment — use {"body": "text"}, NOT {"content": "text"}
#                                                                          ^^^^       ^^^^^^^
```

### Secret Management

```bash
POST /api/companies/{id}/secrets
{"name": "OpenRouter API Key", "key": "openrouter-default", "value": "sk-or-..."}

GET /api/companies/{id}/secrets            # List secrets
DELETE /api/secrets/{secretId}             # Delete a secret
```

### Adapter Management

```bash
GET /api/adapters                     # List all adapters (built-in + external)
POST /api/adapters/install            # Install external adapter from npm
  {"packageName": "@henkey/hermes-paperclip-adapter", "version": "0.4.3"}
DELETE /api/adapters/{type}           # Uninstall external adapter
GET /api/adapters/{type}/config-schema  # Get adapter config schema
```

### Activity Log

```bash
GET /api/companies/{id}/activity?limit=5
```
Key event types: `heartbeat.invoked`, `environment.lease_acquired`, `environment.lease_released` (check `details.status`: "released"=ok, "failed"=error), `issue.updated`, `issue.comment_added`.

## Built-in Adapters

| Adapter | Models | Notes |
|---------|--------|-------|
| claude_local | 6 | Requires logged-in Claude CLI |
| codex_local | 10 | OpenAI Codex CLI |
| cursor | 39 | Local Cursor |
| gemini_local | 6 | Google Gemini CLI |
| opencode_local | 5 | OpenAI Codex |
| hermes_local | 0* | *Built-in stub — needs external plugin |

### Hermes Adapter Install

The `@henkey/hermes-paperclip-adapter` v0.4.3 npm package provides a Hermes adapter.

**Problem:** `hermes_local` is a built-in type — `POST /api/adapters/install` returns 409.

**Fix (source-based):** Edit `server/src/adapters/builtin-adapter-types.ts`, remove `"hermes_local"`, rebuild.

**Fix (npx cache — no rebuild needed):** Edit `~/.npm/_npx/<hash>/node_modules/@paperclipai/server/dist/adapters/builtin-adapter-types.js` and remove `"hermes_local"` from the array. Will be overwritten on upgrade.

### Hermes Adapter Config Schema

| Field | Options | Default | Notes |
|-------|---------|---------|-------|
| profile | default, paperclip-agent | default | Hermes profile for model/provider |
| provider | auto, openrouter, nous, anthropic, etc. | auto | Optional LLM provider override |
| memoryScope | session, persistent, ephemeral | session | Agent memory behavior |
| deliveryTarget | none, telegram, discord, slack | none | Run summary destination |

## Context Window Constraints (CRITICAL for local models)

Paperclip agent prompts consistently exceed 64K tokens. Local models with 64K context may hit limits.

**Recommended profile setup (23-May-2026):**

| Agent Role | Profile | Provider | Model | Cost |
|-----------|---------|----------|-------|------|
| CEO/Orchestrator | `ceo-free` | OpenRouter (free) | gemma-4-31b-it:free | **$0** |
| Worker agents | `paperclip-agent` | LM Studio (local) | qwen2.5-coder-7b-instruct | **$0** |
| Assistant (me) | `assistant-local` | LM Studio (local) | qwen2.5-coder-7b-instruct | **$0** |
| Last resort | `default` | LM Studio (local) | gemma-4-e2b | **$0** |

**⚠️ CEO delegation on local/free models is unreliable.** The CEO consistently marks tasks done without creating sub-issues or waking workers. **Direct worker assignment** produces better results.

**Creating profiles:**
```bash
hermes profile create <name> --clone-from <source>
# Then edit ~/.hermes/profiles/<name>/config.yaml
# Set profile on an agent:
PATCH /api/agents/{id} → {"adapterConfig": {"profile": "<name>"}}
```

## Ammar's GameySins Company (set up 2026-05-23)

**Company ID:** `ba4e7d36-e75a-44eb-97c9-5432d71f0c50`  
**Budget:** $500/mo | **Dashboard:** http://localhost:3100

**Agents (all on qwen2.5-coder-7b-instruct / LM Studio free):**
| Name | Role | Profile | Agent ID |
|------|------|---------|----------|
| Chief GameSins Officer | CEO | ceo-free (OpenRouter free) | dba985c6 |
| Tech Research Agent | Researcher | paperclip-agent (local) | d5e97d81 |
| Gaming Research Agent | Researcher | paperclip-agent (local) | e2265b2c |
| Script & Content Producer | Engineer | paperclip-agent (local) | d0230ea6 |
| Video Production Agent | Engineer | paperclip-agent (local) | 4c557f3e |
| YouTube SEO & Marketing | CMO | paperclip-agent (local) | e8a7ce19 |
| Quality Reviewer | QA | paperclip-agent (local) | c44b84d7 |
| GameSinsTech Content Lead | PM | paperclip-agent (local) | 51094a17 |
| Quick Facts Producer | Engineer | paperclip-agent (local) | 6b2aa917 |

**Goals:** GAM-1 (weekly schedule) → COMPLETED ✅ | GAM-2 (Quick Facts) → backlog

**Execution Flow:** Assign issue → wake agent → Paperclip heartbeat picks up → Hermes adapter boots via configured profile → agent processes → updates issue + leaves comment
