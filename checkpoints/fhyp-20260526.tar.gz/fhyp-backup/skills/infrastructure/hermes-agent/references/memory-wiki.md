# Memory Wiki — Static HTML Site

A **Memory Wiki** is a browsable static HTML site that organizes all agent-user interactions: subjects discussed, session timeline, active projects, and kanban status. It's a front-end UI on top of session memory — different from an Obsidian markdown vault (which is for raw knowledge storage).

---

## When to Build a Memory Wiki

| Scenario | Use Memory Wiki | Use Obsidian Vault |
|----------|-----------------|-------------------|
| User wants a browsable dashboard of all work done | ✅ | ❌ |
| User wants persistent deep knowledge storage (projects, people, decisions) | ❌ | ✅ |
| User asks "what have we worked on?" or "show me everything" | ✅ | ❌ |
| User asks for a daily work log / diary | ✅ | ~ |
| User wants to search across all session topics | ✅ (searchable via JS) | ~ |

---

## Architecture

```
Memory Wiki
├── index.html           # Self-contained single-page app (no server needed)
├── JS data embedded     # subjects[], timeline[], projects[] as JS arrays
└── Cron updater         # Python script regenerates HTML with fresh data
```

### Data Sections

| Section | Source | Update Frequency |
|---------|--------|-----------------|
| **Subjects** | Hardcoded topics covering all areas of work | Manual (agent adds new subjects) |
| **Timeline** | Static entries + dynamic session log data | Per cron run |
| **Projects** | Hardcoded project definitions with status | Manual (agent updates on status changes) |
| **Kanban Status** | `hermes kanban list --status active/blocked` | Per cron run |
| **Stats** | Session count, skill count, project count | Per cron run |

### Dual Deployment

The wiki lives in two places simultaneously:
1. **WSL path**: `~/memory-wiki/index.html` — accessible from terminal/wslview
2. **Windows Desktop**: `C:\Users\<username>\Desktop\Memory Wiki.html` — double-click from Windows

On WSL, copy via:
```bash
cp ~/memory-wiki/index.html "/mnt/c/Users/<username>/Desktop/Memory Wiki.html"
```

---

## Auto-Update via Cron

Use a `no_agent=True` cron job with a Python script that regenerates the HTML:

```yaml
# Cron job config (created via cronjob tool):
schedule: "0 */6 * * *"    # Every 6 hours
no_agent: true
script: scripts/update-memory-wiki.py
deliver: local              # Silent — don't notify on every update
```

### Python Script Pattern

The script:
1. **Imports**: `json, os, subprocess, datetime, pathlib.Path, html` (as `html_mod` to avoid name collision with the `html` variable)
2. **Builds data**: Hardcoded subjects, timeline entries, and project definitions (these are stable and get extended manually when significant new work happens)
3. **Gets dynamic data**: Runs `hermes kanban list --status active` and `--status blocked` to get real-time kanban status; counts skills directories from `~/.hermes/skills/`
4. **Generates HTML**: A large f-string with the full HTML template, injecting JSON data and dynamic strings
5. **Writes**: To both `~/memory-wiki/index.html` and Windows Desktop path
6. **Returns**: Path and byte count — cron captures any errors

### Important Implementation Details

- **Use `import html as html_mod`** — the local variable `html` (the f-string result) shadows the module if imported as `html`. Rename the import to avoid `UnboundLocalError`.
- **JSON encoding**: Use `json.dumps(data, ensure_ascii=False)` for the JS data arrays. Handle Unicode for Arabic content.
- **File encoding**: Open with `encoding='utf-8'` when writing. Without it, non-ASCII characters cause `UnicodeEncodeError`.
- **JS escaping**: JavaScript template literals (backtick strings) inside Python f-strings need careful escaping. Use single-quoted JS strings and concatenation (`+`) instead of template literals when possible to avoid escaping conflicts.
- **Kanban CLI output**: `hermes kanban list` may return empty or error output. Default to a fallback string like "No data" if the command fails.
- **Skills count**: `len([p for p in Path(skills_dir).iterdir() if p.is_dir()])` — counts skill directories, not individual files.

---

## Manual Update

When significant new work happens during a session, update the wiki immediately:

```bash
/usr/bin/python3 ~/scripts/update-memory-wiki.py
```

Also update the subject/project/timeline data in the script if new categories of work emerged.

---

## Pitfalls

- **Memory Overwrite Risk**: The cron script replaces the HTML file entirely. If two cron runs overlap (shouldn't happen with 6h interval but could with a forced manual + cron at the same time), the last write wins. No merge logic needed for single-user.
- **Windows path may not exist**: If the Windows Desktop is inaccessible (WSL not mounted, path changed), the script should catch the `Exception` and continue rather than failing.
- **Large session data**: If session search tools return very large outputs, the script doesn't auto-include them — the data is curated manually. The cron refresh mainly updates kanban counts and the "last updated" timestamp.
- **Arabic/Unicode**: JSON data with Arabic text (project names, descriptions) must use `ensure_ascii=False` in `json.dumps()`. The HTML file's `<meta charset="UTF-8">` handles rendering.
- **CSS changes**: The entire CSS is embedded in the f-string. Any style updates require editing the Python script, not just the output HTML. Keep the CSS in a single block at the top of the f-string for easy editing.
