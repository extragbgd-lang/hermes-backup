# Notification Routing: CLI → Discord for Clarify & Approvals

## The Problem

When using Hermes from CLI, the `clarify` tool and `approvals` prompts only appear in the terminal. The user wanted these notifications routed to Discord so they don't have to watch the terminal constantly.

## There Is No Built-In Auto-Route

After investigating the full Hermes documentation, there is **no config option** (no `ask_channel`, `deliver_ask_to`, `notify_on_clarify`, etc.) that auto-mirrors clarify or approval prompts from CLI to a messaging platform. The `deliver` config and `DISCORD_HOME_CHANNEL` only control cron output, reminders, and background process notifications — not interactive agent prompts.

## The Solution: Hybrid Approach

### 1. Approvals: Smart Mode

Set `approvals.mode: smart` instead of the default `manual`. The auxiliary LLM assesses flagged commands and auto-approves low-risk ones. Genuinely dangerous commands still escalate to the user, but routine operations (standard file reads, builds, etc.) pass without asking.

```yaml
approvals:
  mode: smart
  timeout: 60
  cron_mode: deny
```

### 2. Discord Home Channel as Free-Response

Set the `DISCORD_HOME_CHANNEL` as a `free_response_channel` so the bot can proactively send messages there without requiring a prior @mention in a conversation thread.

```yaml
discord:
  require_mention: true
  free_response_channels: "1506939046843125811"  # Home channel — allows proactive sends
```

Or via env:
```bash
DISCORD_FREE_RESPONSE_CHANNELS=1506939046843125811
```

### 3. Agent Notifies Discord Proactively

When the agent needs user input during a CLI session, it must explicitly use `send_message` to deliver a notification to the user's Discord home channel, mentioning the user's Discord ID so they get a push notification:

```python
send_message(
    target="discord",
    message="<@525784408930910218> I need your input on something..."
)
```

The @mention (`<@USER_ID>`) triggers Discord's native push notification system, which is the most reliable way to get the user's attention.

### 4. Fallback: Session Handoff

If the task needs extended back-and-forth with the user, use `/handoff discord` from the CLI session to transfer the entire conversation to Discord. The agent picks up exactly where it left off with full context.

## Discord DM Channel Routing

### Send to DMs (not just channel)

The target format `send_message(target='discord:USER_ID')` **does not work** — it returns:
```
Discord API error (404): {"message": "Unknown Channel", "code": 10003}
```

**Why:** Hermes' `send_message` treats the value after `discord:` as a literal channel ID. A Discord user ID is NOT a channel ID. To DM a user, you need the **DM channel snowflake** — a unique ID that differs from both the user ID and any server channel.

### How to Find the DM Channel ID

Use Discord's API to create/find the DM channel:

```python
import json, urllib.request
token = open('/home/ammar/.hermes/.env').read().split('DISCORD_BOT_TOKEN=')[1].split('\n')[0].strip()
user_id = '525784408930910218'
req = urllib.request.Request(
    'https://discord.com/api/v10/users/@me/channels',
    data=json.dumps({'recipient_id': user_id}).encode(),
    headers={'Authorization': f'Bot {token}', 'Content-Type': 'application/json', 'User-Agent': 'HermesAgent/1.0'}
)
data = json.loads(urllib.request.urlopen(req).read())
dm_channel_id = data['id']        # this snowflake goes into send_message target
is_dm = data['type'] == 1         # 1 = DM, 0 = guild text channel
```

If the user has DMed the bot before, this returns the **existing** DM channel (no duplicate created).

### Strategy: Home Channel = DM Channel

The cleanest approach: set `DISCORD_HOME_CHANNEL` to the DM channel ID. Then `send_message(target='discord')` automatically routes to DMs:

```bash
# ~/.hermes/.env
DISCORD_HOME_CHANNEL=1506939046843125811  # DM channel snowflake, NOT user ID
```

With this set:
- `deliver: "discord"` in cron jobs goes to DMs
- `send_message(target='discord')` goes to DMs
- Cron output from `no_agent: true` scripts also routes here (but ONLY when script produces stdout)

### Verify a Channel Is a DM

```python
req = urllib.request.Request(
    f'https://discord.com/api/v10/channels/{channel_id}',
    headers={'Authorization': f'Bot {token}', 'User-Agent': 'HermesAgent/1.0'}
)
data = json.loads(urllib.request.urlopen(req).read())
# type 1 = DM channel, type 0 = guild text channel
```

### Pitfalls

- **Never pass the user ID as the target** — always 404. Use the DM channel ID or just `"discord"` (home channel).
- **DM must already exist or be creatable** — the user must have DMed the bot before, OR you call Create DM endpoint first from code.
- **Discord privacy blocks DMs** — if user has "Allow DMs from server members" off, the Create DM endpoint also fails.
- **DMs have no threads** — you cannot append `:thread_id` to a DM channel target.
- **Silent watchdog heartbeats** — `no_agent: true` scripts run silently when healthy (zero stdout). No output = nothing delivered even if delivery target is DMs. Users may expect a "still alive" ping but the watchdog pattern intentionally stays quiet.

## Notification Behavior by Platform

| Platform | Push Notification Mechanism |
|----------|---------------------------|
| Telegram | `display.platforms.telegram.notifications: important` (default) — approval prompts and final responses ring. |
| Discord | No equivalent setting. Must @mention user ID (`<@ID>`) or use DM channel to trigger push. |
| Slack | Uses Slack's native notification behavior. No Hermes-level override. |

## Key Files That Control This

| File | What it controls |
|------|-----------------|
| `~/.hermes/config.yaml` | `approvals.mode`, `discord.*`, `display.platforms.*` |
| `~/.hermes/.env` | `DISCORD_HOME_CHANNEL`, `DISCORD_ALLOWED_USERS`, `DISCORD_FREE_RESPONSE_CHANNELS` |
| `~/.hermes/skills/infrastructure/hermes-agent/references/discord-dm-setup.md` | Full technique: finding DM channel ID, home channel = DM configuration, cron monitoring setup |

## Monitoring

The gateway status shows the home channel:
```bash
hermes status | grep discord
# → Discord: configured (home: 1506939046843125811)
```
