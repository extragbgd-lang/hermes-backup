# Zapier MCP — Built-in Integration

## Overview

Zapier MCP connects Hermes to **8,000+ apps** via OAuth (Gmail, Google Sheets, Docs, Drive, Notion, YouTube, Slack, Jira, etc.). It uses a **top-level `zapier:` config key**, NOT a `mcp_servers:` entry — it is a built-in Hermes integration, not a standard stdio/HTTP/SSE MCP server.

## Configuration

### Config format (`~/.hermes/config.yaml`)

```yaml
zapier:
  url: "https://mcp.zapier.com/api/v1/connect?token=ZAPIER_TOKEN"
```

The token is a base64-encoded credential from your Zapier MCP connection page. No env vars needed — embedding the token directly in the URL is the intended format.

### DO NOT add under mcp_servers:

```yaml
# ❌ WRONG — this will fail with "Session terminated"
mcp_servers:
  zapier-mcp:
    url: "..."
    transport: sse     # ❌ Hermes' built-in zapier integration uses a different internal transport
```

The top-level `zapier:` key is the ONLY correct way. Adding it to `mcp_servers:` causes duplicate connection attempts and `CancelledError` / `Session terminated` failures.

### Where to get the token

1. Open **https://zapier.com/app/connections/mcp**
2. Create or copy your MCP connection token
3. Paste the full URL into `zapier.url` in config.yaml

### Current Status (26-May-2026)

The `zapier:` config exists in Hermes with `token=***` — a placeholder. Tokens expire after 7 days. To use Zapier, the user needs to visit https://zapier.com/app/connections/mcp, get a fresh connection URL, and paste it into the config. Canva is available through Zapier — confirmed by the user on 26-May-2026 after a lengthy Composio MCP OAuth attempt.

### Smoke test with curl

```bash
# List available tools
curl -s --max-time 15 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"tools/list","id":1}' \
  "$ZAPIER_URL"

# List connected apps
curl -s --max-time 15 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"tools/call","id":2,"params":{"name":"list_enabled_zapier_actions","arguments":{}}}' \
  "$ZAPIER_URL"
```

**Critical headers:** Must send BOTH `Content-Type: application/json` AND `Accept: application/json, text/event-stream`. Omitting either returns `Not Acceptable`.

### Gateway must be running

The built-in Zapier integration connects through the gateway. After adding the token to config:
```bash
systemctl --user restart hermes-gateway.service
# ⚠️ This foreground command kills the running session.
# Use background mode instead:
#   terminal(background=true, command="systemctl --user restart hermes-gateway.service")
# Then wait a few seconds and verify with:
#   journalctl --user -u hermes-gateway --since "1 min ago" --no-pager | grep -i "zapier"
```

If connected, the gateway logs show NO errors for zapier. If the token is wrong, logs show `401 Unauthorized`.

### User-connected apps management

Users manage OAuth connections at: **https://zapier.com/app/connections/mcp**

## Available Tools (13 tools)

| Tool | Purpose |
|------|---------|
| `discover_zapier_actions` | Search 8,000+ apps by name |
| `enable_zapier_action` | Enable an app's actions (returns auth URL if needed) |
| `disable_zapier_action` | Remove an app's actions |
| `list_enabled_zapier_actions` | List connected apps + their action keys |
| `execute_zapier_read_action` | Execute a search/read action (GET) |
| `execute_zapier_write_action` | Execute a write/create action (POST) |
| `auto_provision_mcp` | Auto-setup based on existing connected accounts |
| `list_zapier_skills` | List saved reusable skills |
| `get_zapier_skill` | Load a saved skill's content |
| `create_zapier_skill` | Save a workflow as a repeatable skill |
| `update_zapier_skill` | Update an existing skill |
| `delete_zapier_skill` | Delete a skill |
| `get_configuration_url` | Get the manage-connections URL |
| `send_feedback` | Send feedback about Zapier MCP |

## Typical Workflow

1. **Discover** — `list_enabled_zapier_actions` to see connected apps
2. **Search** — `discover_zapier_actions(app="slack")` to find new apps
3. **Enable** — `enable_zapier_action(app="slack")` to add app's actions
4. **Check params** — `list_enabled_zapier_actions(app="Notion", action="create_page")` to see required params
5. **Execute** — Call `execute_zapier_read_action` or `execute_zapier_write_action` with the correct params

### Example: Create a Notion Page

```bash
# First, find parent page
curl -s ... -d '{"method":"tools/call","params":{"name":"execute_zapier_read_action","arguments":{
  "app":"Notion","action":"page_by_title",
  "params":{"title":"Parent","exact_match":"no"},
  "output":"page ID and URL"
}}}'

# Then create the page
curl -s ... -d '{"method":"tools/call","params":{"name":"execute_zapier_write_action","arguments":{
  "app":"Notion","action":"create_page",
  "params":{"parent_page":"PAGE_UUID","title":"New Page","content":"# Hello","icon":"📝"},
  "output":"page URL"
}}}'
```

**Important:** The `params` object contains locked parameter values. Do NOT put param values in `instructions` — use `instructions` only for natural-language context. Required params are marked with `"required":true` in the action schema.

## Connected Apps (This User's Setup)

As of 25-May-2026, the user's Zapier account has 6 connected apps:
- **Google Sheets** — 29 actions (read/write/manage spreadsheets)
- **Gmail** — 12 actions (send/read/search/trash emails)
- **Google Docs** — 16 actions (create/edit/get documents)
- **Notion** — 27 actions (pages, databases, blocks, comments)
- **YouTube** — 7 actions (videos, playlists, search)
- **Google Drive** — 22 actions (files, folders, search, permissions)

## Pitfalls

- **`execute_zapier_write_action` may return a `followUpQuestion`** instead of the result. This happens when the action succeeded but the API wants to ask a follow-up (e.g., "add a cover image?"). The `isPreview: false` flag confirms the action actually executed.
- **`get_configuration_url` times out** via direct curl (exit code 28). Use the static URL instead: https://zapier.com/app/connections/mcp
- **Gateway must restart** after changing the token. The built-in integration reads the config at gateway startup.
- **NO `mcp_servers` entry needed** — the built-in integration auto-discovers the top-level `zapier:` key. Adding it to `mcp_servers:` causes conflicts.
- **Token in config.yaml is safe** — Hermes redacts it from display and terminal output via `redact_secrets: true`. The actual file has the raw token.
- **`parent_page` is a SELECT field** in Notion's `create_page` action. Pass the page UUID (NOT the URL) as a string — Zapier resolves it internally.