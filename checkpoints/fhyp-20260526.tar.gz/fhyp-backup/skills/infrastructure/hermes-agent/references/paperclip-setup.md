# Paperclip + Hermes Adapter Setup

Paperclip (`paperclipai/paperclip`) is an open-source AI company builder — 67k stars, very active. It orchestrates teams of AI agents with org charts, budgets, governance, heartbeats, and task management.

## Architecture

```
Paperclip UI (port 3100)
  └─ Paperclip Server (Express + embedded PostgreSQL)
       └─ Hermes Adapter Plugin (@henkey/hermes-paperclip-adapter)
            └─ Hermes CLI (via adapter)
                 └─ LLM Provider (LM Studio local / OpenRouter free / etc.)
```

## Quick Install

```bash
# Fastest — npx (no clone needed)
npx paperclipai onboard --yes
# Access at http://localhost:3100

# From source (for patching)
cd /home/ammar
git clone https://github.com/paperclipai/paperclip.git
cd paperclip
pnpm install
pnpm dev
```

## Key API Endpoints

All at `http://localhost:3100/api`:

| Endpoint | Purpose |
|----------|---------|
| `GET /health` | Health check |
| `GET /companies` | List companies |
| `POST /companies` | Create company |
| `GET /companies/:id/agents` | List agents |
| `PATCH /agents/:id` | Update agent |
| `POST /companies/:id/agents` | Create agent |
| `GET /companies/:id/projects` | List projects |
| `POST /companies/:id/projects` | Create project |
| `GET /companies/:id/routines` | List routines |
| `POST /companies/:id/routines` | Create routine |
| `POST /routines/:id/run` | Trigger routine |
| `POST /routines/:id/triggers` | Add schedule trigger |
| `POST /agents/:id/wakeup` | Wake agent |
| `GET /companies/:id/issues` | List issues |
| `PATCH /issues/:id` | Update issue |
| `POST /issues/:id/checkout` | Checkout issue |
| `POST /api/adapters/install` | Install adapter plugin |
| `GET /api/adapters` | List adapters |
| `POST /companies/:id/secret-provider-configs` | Add provider config |
| `POST /companies/:id/secrets` | Store API key |

## Installing the Hermes Adapter Plugin

The Hermes adapter (`@henkey/hermes-paperclip-adapter` v0.4.3) allows Paperclip to use Hermes as the execution engine for agents.

### Prerequisite: Patch built-in types

Paperclip prevents overriding built-in adapter types. `hermes_local` is built-in. You must remove it:

1. Find the file in the npx cache or cloned repo:
   - npx cache: `~/.npm/_npx/<hash>/node_modules/@paperclipai/server/dist/adapters/builtin-adapter-types.js`
   - Source: `server/src/adapters/builtin-adapter-types.ts`

2. Remove `"hermes_local"` from the `BUILTIN_ADAPTER_TYPES` set.

3. Restart Paperclip.

### Install via API

```bash
curl -X POST http://localhost:3100/api/adapters/install \
  -H "Content-Type: application/json" \
  -d '{"packageName": "@henkey/hermes-paperclip-adapter"}'
```

Expect 201 + `requiresRestart: true` on success. Restart Paperclip after.

### Verify

```bash
curl http://localhost:3100/api/adapters | python3 -m json.tool
# Look for: "type": "hermes_local", "source": "external", "loaded": true
```

## Configuring Agents

### Create agent with Hermes adapter

```json
POST /api/companies/:id/agents
{
  "name": "Agent Name",
  "role": "ceo|researcher|engineer|pm|cmo|qa|...",
  "adapterType": "hermes_local",
  "adapterConfig": {
    "profile": "default",         // Hermes profile to use
    "provider": "auto",           // Provider override or "auto"
    "memoryScope": "session",     // session | persistent | ephemeral
    "deliveryTarget": "none"      // none | telegram | discord | slack
  },
  "budgetMonthlyCents": 10000
}
```

### Update existing agent

```bash
PATCH /api/agents/:id
{
  "adapterType": "hermes_local",
  "adapterConfig": {"profile": "lmstudio"}
}
```

## Profiles

Each Hermes profile is a separate config/environment. Use for provider switching:

```bash
# List profiles
hermes profile list

# Create new profile (clone from existing)
hermes profile create <name> --clone

# Edit profile config
# ~/.hermes/profiles/<name>/config.yaml
```

Recommended profile setup:
- **`default`** — LM Studio local (gemma-4-e2b), planned primary for all agents
- **`paperclip-agent`** or **`lmstudio`** — LM Studio local (64K), no MCPs, compression off, for lighter agents

Switch profiles per agent via `adapterConfig.profile`.

## Agent Instructions

Each agent can have detailed instructions file at:
```
~/.paperclip/instances/default/companies/<company_id>/agents/<agent_id>/instructions/AGENTS.md
```

Write these programmatically for each agent to define:
- Role and responsibilities (in Egyptian Arabic for Arabic channels)
- Workflow steps
- Communication rules (when/how to ping user on Discord)
- Brand asset references

## Routines (Scheduled Automation)

Create routines with schedule triggers for automated agent runs:

```json
POST /api/companies/:id/routines
{
  "title": "Daily Trend Scan",
  "description": "...",
  "assigneeAgentId": "<agent_id>",
  "priority": "high",
  "status": "active"
}

POST /api/routines/:id/triggers
{
  "kind": "schedule",
  "cronExpression": "0 8 * * *",
  "timezone": "Asia/Dubai"
}
```

## Context Window Issues

Paperclip agent prompts include company context + instructions + issue details + Hermes tool list. Total can exceed 64K.

- **Use LM Studio (gemma-4-e2b)** for all agents — local free, primary model
- **Use LM Studio (64K) + minimal profile** for lightweight agents (researchers, reviewers)
- The minimal profile should have: `inherit_mcp_toolsets: false`, `compression.enabled: false`, no extra toolsets
- Without these settings, agents hit `Context length exceeded: max compression attempts (3) reached`

## Pitfalls

- **Port 3100 vs 3101:** The fork may auto-detect port conflicts. Check which port is actually in use.
- **NTFS startup lag:** Server takes 30-60s to start from Windows filesystem. Wait before assuming failure.
- **Embedded PostgreSQL:** Auto-created on first run at `~/.paperclip/instances/default/db/`. Data persists across restarts.
- **Kill all processes:** Before restarting: `pkill -f "paperclip"; pkill -f "tsx.*index.ts"`
- **pnpm not found:** `npm install -g pnpm@9`
- **npx cache path changes:** The hash directory under `~/.npm/_npx/` changes with versions. Find current: `find ~/.npm/_npx -name "builtin-adapter*" 2>/dev/null`
- **Agent status "running" forever:** Agents run through Hermes which has its own timeout (90 turns default). Long-running LM Studio agents may appear stuck. Check Hermes logs or increase `max_turns`.
- **Paperclip crashes when multiple agents run:** Running 3+ Hermes sessions simultaneously can overwhelm WSL/system resources. Space out agent wakeups if crashes persist.
