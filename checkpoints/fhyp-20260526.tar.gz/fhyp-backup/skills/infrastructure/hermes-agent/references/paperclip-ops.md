# Paperclip Operations — Agent Monitoring & Troubleshooting

## Overview

Paperclip (HenkDz fork, port 3100) runs 9 autonomous GameSins agents. This reference covers how to inspect their health, diagnose errors, and verify configuration — the operational side of running the agent factory.

## Quick Dashboard Assessment

Navigate to `http://localhost:3100` and read the AGENTS panel:

| Metric | Where to see | What it means |
|--------|-------------|---------------|
| `N Agents Enabled — X running, Y paused, Z errors` | Main dashboard, agents card | Overall fleet health |
| `N Tasks In Progress — X open, Y blocked` | Dashboard | Current workload |
| `$N Month Spend — X% of $Y budget` | Dashboard | Token cost tracking |
| Agent status badge (idle/error/paused) | Agent list sidebar or All Agents tab | Individual agent status |

**Tab filters:** All / Active / Paused / Error — use the Error tab first when the dashboard shows 1+ errors.

## Agent Detail Page Layout

Each agent has 6 tabs when clicked:

| Tab | What it shows |
|-----|--------------|
| **Dashboard** | Latest run summary, run activity chart (14d), issues by priority/status, success rate, recent issues, costs (token usage), cost table |
| **Instructions** | The system prompt / persona the agent runs with |
| **Skills** | Skills attached to the agent |
| **Configuration** | Adapter type (Hermes Agent local), command, model, Hermes Profile, provider, memory scope, delivery target, env vars, run policy |
| **Runs** | All runs with status, model, duration, tokens, transcript |
| **Budget** | Cost tracking per agent |

## Diagnosing an Agent Error

### 1. Spot it
The agent list shows an "error" status badge. The dashboard counter says "1 errors."

### 2. Click the agent → Runs tab
Each run shows:
- Status badge: `succeeded` / `failed` / `timed out` / `cancelled`
- Duration (e.g., "7m 31s")
- Model used (e.g., `google/gemma-4-e2b` via paperclip-agent profile = LM Studio free)
- Token consumption (input/output/cached)
- Cost (free if local, "$0.00" if LM Studio)

### 3. Identify the failing run
Runs are sorted newest-first. Look for the one with a non-green status. Click its name to expand.

### 4. Read the error
The expanded run view shows:
- **stderr** output (e.g., `session_id: ...`, `Traceback (most recent call last):(timeout)`)
- **Transcript** — full agent conversation for that run (125+ messages common)
- **Retry** button — for timed-out runs you can retry directly

### 5. Common error patterns

| Error | Likely Cause | Fix |
|-------|-------------|-----|
| `timed out` after 7m+ | LM Studio slow to respond; Hermes agent timeout hit | Increase agent timeout, or use a faster local model, or the task was too complex for local |
| `failed` with traceback | Tool execution error or LM crash | Check stderr for the actual Python/Node traceback |
| `cancelled` | Heartbeat cancelled by Board | Usually intentional — check activity log for who cancelled and why |

## Verifying Agent Configuration

When an agent shows unexpected behavior, check its Configuration tab:

| Field | Expected (GameSins workers) | Notes |
|-------|---------------------------|-------|
| Adapter type | `Hermes Agent (local)` | Must be local, not cloud |
| Command | `hermes` | The CLI command |
| Model | `Default` | Resolves from the profile |
| Hermes Profile | `paperclip-agent` | CRITICAL — this routes to LM Studio free tier. If it says `default`, agent burns paid tokens |
| Provider | `Auto (resolve from Hermes config)` | Resolves from the profile's config |
| Memory Scope | `Session` | Default for workers |

**To fix a wrong profile:**
```python
requests.patch(f"http://localhost:3100/api/agents/{agent_id}", json={
    "adapterConfig": {"profile": "paperclip-agent"}
})
```

## Available Profiles (23-May-2026)

| Profile | Provider | Model | Cost | Purpose |
|---------|----------|-------|------|---------|
| `default` | LM Studio (local) | gemma-4-e2b | **Free** | Primary profile — all agents use local free models |
| `paperclip-agent` | LM Studio (local) | qwen2.5-coder-7b-instruct | Free | Default for all worker agents |
| `ceo-free` | OpenRouter (free) | google/gemma-4-31b-it:free | Free | CEO orchestration — free hosted model |
| `assistant-local` | LM Studio (local) | qwen2.5-coder-7b-instruct | Free | Optimized for assistant/interactive use |

**Created 23-May-2026:**
- `assistant-local` — optimized for the Hermes CLI agent with lower max_turns (50), compression enabled, no MCP inheritance.

## Interpreting Run Costs

```
Input: 34.9k   Output: 1.3k   Cached: 0   Cost: -
```

- Cost shows `-` (dash) when using free/local models (LM Studio, Groq, OpenRouter free)
- Cost shows `$0.XX` only when hitting legacy paid providers (not configured)
- The dashboard "Month Spend" should stay at $0.00 if all workers are on paperclip-agent profile

**Suspicious sign:** If Month Spend > $0.00, one or more agents are using a non-local profile. Check every agent's Configuration → Hermes Profile.

## Fleet Status Walkthrough (Example from 2026-05-23)

During a full inspection:

1. Dashboard showed: `9 Agents Enabled — 0 running, 0 paused, 1 errors`
2. Navigated to Agents → Error tab → found **Tech Research Agent**
3. Opened the agent → Runs tab → found run `91c49dd0` with status `timed out`, duration 7m 31s
4. Error details: `Traceback (most recent call last):(timeout)` — LM Studio was too slow
5. Checked Configuration → Hermes Profile = `paperclip-agent` ✅ (correct, not burning paid)
6. Previous run `9645e30e` succeeded in 3m 28s with `google/gemma-4-e2b` via LM Studio
7. Conclusion: The agent is configured correctly; this was a one-off timeout from local model latency, not a config issue

## Pitfalls

- **Timeout ≠ configuration error.** An agent timing out on LM Studio usually means the model was slow, not that the profile is wrong. Check the profile first, then consider the timeout setting.
- **Agent card shows "idle" but hasn't run in 2h+** — this is normal for scheduled agents between routine ticks. Check the agent's runs for the last heartbeat.
- **Paperclip's $0.00 budget doesn't mean nothing ran.** It means everything ran on free/local providers. The dash on individual run costs confirms this.
- **Quality Reviewer** may show "idle" with no runs ever — it's a new agent that hasn't been assigned a task yet.

## Restarting Paperclip After Gateway Restart

**Gateway restart kills Paperclip.** If Paperclip was started from the same npx cache that the gateway cgroup manages, `systemctl --user restart hermes-gateway.service` terminates Paperclip's process. This happens because systemd kills the entire control group (cgroup) on service restart.

**Symptoms after gateway restart:**
- `curl http://127.0.0.1:3100/api/health` → no response (connection refused)
- Paperclip process not found in `ps aux | grep paperclip`
- Hermes Web UI also goes down (separate process, less likely to be affected)

**Restart command:**
```bash
node /home/ammar/.npm/_npx/43414d9b790239bb/node_modules/@paperclipai/server/dist/index.js
```
Do NOT use `npx -y @paperclipai/server` — this fails with "could not determine executable to run" because the package binary is not defined in the npm registry for this version.

**Auto-restart safety net:** The Hermes heartbeat script (`~/.hermes/scripts/heartbeat_check.sh`) now checks Paperclip health every 5 minutes and restarts it if down. After a gateway restart, it catches Paperclip within 5 minutes automatically.

**Data persistence:** Paperclip uses embedded PostgreSQL at `~/.paperclip/instances/default/db/`. All agents, companies, issues, and comments survive restart — confirmed working (GameSins company ID `ba4e7d36-e75a-44eb-97c9-5432d71f0c50` intact after multiple gateway restarts).

## Agent Stuck-State Fix (⚠️ Critical — Hermes adapter lifecycle bug)

When a Paperclip agent shows **"running"** in the dashboard but no Hermes CLI process exists (`ps aux | grep "hermes chat"` returns nothing), the agent is stuck. The Hermes adapter exits without signalling completion.

### Detection
```bash
curl -s http://127.0.0.1:3100/api/agents/AGENT_ID | python3 -c "import sys,json; print(json.load(sys.stdin)['status'])"
```
If "running" but no Hermes process → stuck.

### Fix
```bash
# Step 1: Reset to idle
curl -s -X PATCH "http://127.0.0.1:3100/api/agents/AGENT_ID" \
  -H "Content-Type: application/json" \
  -d '{"status": "idle", "error": null}'
# Step 2: Wake fresh
curl -s -X POST "http://127.0.0.1:3100/api/agents/AGENT_ID/wakeup" \
  -H "Content-Type: application/json" \
  -d '{"forceFreshSession": true}'
```

### CEO Ghosting Issue
The CEO may mark issues "done" with a comment like "DONE: delegated all steps" but create ZERO sub-issues. This happens when local models (gemma-4-e2b) can't follow multi-step delegation. **Fix:** Skip the CEO. Assign issues directly to worker agents with single-step instructions.

### Direct Agent Assignment (when CEO delegation fails)

When the CEO marks issues "done" without creating sub-issues, assign work directly:

| Agent | Paperclip ID | What they do |
|-------|-------------|-------------|
| Tech Research | `d5e97d81-8324-4cf7-bd81-ce27255b5e7d` | Research stats, sources, data |
| Script Producer | `d0230ea6-49af-4ce7-96ad-dc65c578123c` | Write full scripts in Egyptian Arabic |
| Video Production | `4c557f3e-ffe8-4b77-883f-7a7c2f8e2975` | Generate images, b-roll, NotebookLM content |
| YouTube SEO | `e8a7ce19-8ada-4b8a-938b-baf93a471f17` | SEO titles, description, tags, thumbnail |
| Quality Reviewer | `c44b84d7-ba57-49af-8b37-946a080b0033` | Review and approve deliverables |

**Pattern:** Create one issue per agent with a SINGLE concrete task. Put exact curl commands in the description. Wake each agent after creating its issue.

**When to use:** Whenever the CEO fails to delegate (which is common on local models). Also use for time-sensitive tasks where CEO overhead isn't worth it.

## Cost-Aware Startup Checklist

Every new session that involves Paperclip, run this check BEFORE routing any tasks:

1. `curl -s http://127.0.0.1:3100/api/companies/{COMPANY_ID}/agents` — list all agents
2. For each agent, check `adapterConfig.profile`:
   - `profile: default` = LM Studio (local FREE) — PATCH to paperclip-agent if local behavior differs
   - `profile: paperclip-agent` = LM Studio FREE ✅
   - `profile: ceo-free` = OpenRouter FREE ✅
3. Check agent status: if stuck on "running" with no Hermes CLI process, PATCH to idle
4. Check for any issues stuck on "in_progress" with no active Hermes process — PATCH to done or reset to todo

### Local Model Fit for RTX 3050 6GB VRAM

| Model | VRAM | Tool Calling | Speed |
|-------|------|-------------|-------|
| Qwen 3.5 9B | 5.5GB (needs 7GB) | ✅ Good | ❌ Slow — spills to RAM |
| **Qwen 2.5 7B Q4_K_M** | **4.5GB** ✅ | ✅ **Best** | ✅ **Fast** — all GPU |
| Gemma 4 e2b | 5GB | ⚠️ Weak | ✅ Fast |
| Llama 3.2 8B | 5GB | ✅ Good | ✅ Medium |

**Recommendation for 6GB VRAM:** Qwen 2.5 7B (Q4_K_M) — fits fully in GPU, best tool calling, 3-5x faster than 9B spill.

## Issue Comment API Quirks

When Paperclip Hermes agents post comments on issues, these API behaviors matter:

| Attempt | Request Body | Result |
|---------|-------------|--------|
| 1st | `{"content": "..."}` | **400** — `content` is not a valid field |
| 2nd | `{"body": "..."}` | **409** — conflict if another run already holds the execution lock |
| 3rd | `PATCH /api/issues/{id} {"status": "done"}` | **409** — same lock conflict |
| 4th | `POST /api/issues/{id}/release {}` | **409** — release endpoint also locked |

**Working pattern** (confirmed from GAM-13 execution):
```bash
# Post a comment — use body, NOT content
curl -s -X POST "http://127.0.0.1:3100/api/issues/ISSUE_ID/comments" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Paperclip-Run-Id: $RUN_ID" \
  -d '{"body": "DONE: summary of what was done"}'

# Mark issue done
curl -s -X PATCH "http://127.0.0.1:3100/api/issues/ISSUE_ID" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Paperclip-Run-Id: $RUN_ID" \
  -d '{"status": "done"}'
```

**409 handling:** If the agent gets 409, the work is still saved to disk. The issue status can be manually updated from the Paperclip dashboard or via curl without the run ID header. The agent's stdout/stderr transcript captures all output even if the API comment post fails.

**Workaround for stuck issues:** If an issue stays `in_progress` after the agent finished (due to 409 on the status update), manually set it to `done`:
```bash
curl -s -X PATCH "http://127.0.0.1:3100/api/issues/ISSUE_ID" \
  -H "Content-Type: application/json" \
  -d '{"status":"done"}'
```
