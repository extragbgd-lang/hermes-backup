# Browserbase Session Live View — Bypassing Google/oauth Login Blocks

## Problem

Sites using Google Sign-In (NotebookLM, Google Workspace, Canva via Google OAuth, etc.) reject Hermes' browser automation tools with:
```
"This browser or app may not be secure."
```

This happens because:

- **Browserbase cloud browsers** (free/Developer plan) run without residential proxies → Google detects the headless signature and blocks sign-in
- Even `BROWSERBASE_PROXIES=true` silently fails on free plans — the Browserbase API returns 402 and drops the proxy flag
- **Local Chromium** falls back if no `BROWSERBASE_API_KEY` is set, but headless Chromium is also detected by Google
- **Solution**: Browserbase paid plans (Scale+) with residential proxies resolve this. But if the user is on a free/Developer plan, the only interactive solution is **Session Live View**.

## Solution: Session Live View

Browserbase's Session Live View gives the user an interactive browser window URL they can open in their personal browser. They authenticate manually, then the agent takes over.

### Architecture

```
┌──────────────┐     ┌──────────────────┐     ┌───────────────┐
│  User (Discord) │◄──►│  Hermes Agent      │◄──►│  Browserbase   │
│  opens link     │     │  (automation)      │     │  Cloud Browser │
└────────────────┘     └──────────────────┘     └───────────────┘
        │                       │                        │
        │  1. Get Live View URL │                        │
        │◄──────────────────────┤                        │
        │                       │  2. Create session     │
        │                       ├───────────────────────►│
        │                       │                        │
        │  3. User opens URL,   │                        │
        │     logs into Google  │                        │
        │──────────────────────►│ 4. Takes over after    │
        │                       │    login, navigates,   │
        │                       │    uploads, generates  │
```

### Prerequisites

- User's Browserbase API key (`BROWSERBASE_API_KEY` in `~/.hermes/.env`)
- User's Browserbase project ID (`BROWSERBASE_PROJECT_ID` in `~/.hermes/.env`)
- Target URL (e.g., `https://notebooklm.google.com`)
- Hermes' browser toolset enabled (`hermes tools → enable Browser Automation`)

### Step-by-Step Workflow

#### Phase 1: Check Credentials

```bash
# Check if Browserbase credentials are configured
grep BROWSERBASE ~/.hermes/.env
```

Expected output:
```
BROWSERBASE_API_KEY=your_key_here
BROWSERBASE_PROJECT_ID=your_project_id
```

If missing, ask the user to get them from https://browserbase.com/settings

#### Phase 2: Start a Browser Session

```python
import os
import requests

api_key = os.environ["BROWSERBASE_API_KEY"]
project_id = os.environ["BROWSERBASE_PROJECT_ID"]
base_url = os.environ.get("BROWSERBASE_BASE_URL", "https://api.browserbase.com")

# Create session
resp = requests.post(
    f"{base_url}/v1/sessions",
    headers={"X-BB-API-Key": api_key, "Content-Type": "application/json"},
    json={
        "projectId": project_id,
        "keepAlive": True,  # Keep session alive during user login
    },
    timeout=30,
)
session_data = resp.json()
session_id = session_data["id"]
cdp_url = session_data["connectUrl"]
```

#### Phase 3: Get the Live View URL

```python
# Get live view links
debug = requests.get(
    f"{base_url}/v1/sessions/{session_id}/debug",
    headers={"X-BB-API-Key": api_key},
)
live_view = debug.json()
live_url = live_view["debuggerFullscreenUrl"]

# Send to user
# "Open this link in your browser and log into Google: {live_url}"
```

Send the URL to the user via Discord/Telegram. Warn them:
- This is a live view of a cloud browser — their keystrokes are visible
- They should log into Google normally
- Once logged in, tell the agent they're done

#### Phase 4: Connect and Automate

Once the user confirms they're logged in:

1. Connect to the CDP URL (from Phase 2) with Playwright/Puppeteer
2. Navigate to the target page (if not already there)
3. Perform automation tasks:
   - Upload scripts as sources
   - Generate Video Overviews, Slide Decks, Infographics
   - Download results
   - Move files to target paths

```python
# Example: navigate in the authenticated session
# (Browserbase CDP URL -> Playwright)
from playwright.async_api import async_playwright
async with async_playwright() as p:
    browser = await p.chromium.connect_over_cdp(cdp_url)
    page = browser.contexts[0].pages[0]
    await page.goto("https://notebooklm.google.com")
    # Now authenticated — proceed with automation
```

### Alternative: Restart Hermes After Credential Changes

If `BROWSERBASE_API_KEY` was added mid-session, Hermes won't pick it up until restart.
Options:
1. **Gateway restart**: `hermes gateway restart` — picks up new env vars
2. **New session**: Start a fresh Hermes session with `/new`
3. **Temporary env**: Export the vars in the terminal before running browser commands

### Pitfalls

#### 🚨 Browserbase Credentials Missing
**Symptom**: `browse cloud projects list` returns "Missing Browserbase API key."
**Fix**: Add `BROWSERBASE_API_KEY` and `BROWSERBASE_PROJECT_ID` to `~/.hermes/.env`. The tool reads from env.

#### 🚨 Hermes Falls Back to Local Chromium
**Symptom**: The `browser_*` tools work but show "Running WITHOUT residential proxies" warning, and no Browserbase session ID is available for live view.
**Cause**: No `BROWSERBASE_API_KEY` in environment. Hermes' browser provider system (`tools/browser_providers/browserbase.py`) returns `is_configured()=False` when the env vars are missing, so the system falls back to local `agent-browser` Chromium.
**Fix**: Set `BROWSERBASE_API_KEY` and `BROWSERBASE_PROJECT_ID` in `~/.hermes/.env`, then restart Hermes.

#### 🚨 Live View URL Not Generated
**Symptom**: The Browserbase API returns the session but `sessions.debug()` fails.
**Fix**: Check the session status — it may have timed out. Create a fresh session.

#### 🚨 Google Login Still Blocked in Live View
**Symptom**: Even in the live view, Google blocks sign-in.
**Cause**: The browser is still a headless/cloud browser, just viewed through a live window. Google's detection works at the browser level, not the view level.
**How Session Live View helps**: The user logs in interactively. Better UX than the agent typing credentials, but Google may still block if the browser fingerprint is detected as automated. Residential proxies would fix this on the Scale plan.
**Workaround**: Try the same URL in incognito. If Google still blocks, the free plan's bot detection avoidance is insufficient — consider upgrading to Scale plan or using the site's API directly.

#### 🚨 Browse CLI Daemon Stops Responding After Session Expiry
**Symptom**: `browse open <url>` returns `"Timed out waiting for driver daemon session"` even though the Browserbase API says a session is running.
**Cause**: The `browse` CLI daemon internally disconnects when the underlying Browserbase session expires (~5 min on free plan). The daemon process (PID visible in `browse status`) is still alive but the browser connection is dead.
**Fix**: Stop the daemon and start fresh:
```bash
browse stop              # kills the daemon process
browse open <url>        # creates a new daemon + session
```
Do NOT just retry `browse open` — the dead daemon blocks new sessions. Always `browse stop` first.
**Symptom**: User opens the live view URL, but it shows "disconnected" or the page reloads.
**Fix**: Create the session with `keepAlive: true` and a longer timeout (e.g., `timeout: 600000` for 10 minutes).

#### 🚨 Can't Find Live View in Hermes Python Code
The live view generation requires calling the Browserbase REST API directly. Hermes' `browserbase.py` provider creates sessions but doesn't expose the live view URL to the agent. To get it, you must:
1. Extract the session ID from the Browserbase API response
2. Call `GET /v1/sessions/{id}/debug` with the API key
3. Use the returned `debuggerFullscreenUrl`

### Browserbase Contexts — Cookie Persistence Across Sessions

Browserbase Contexts save browser cookies/localStorage so authenticated sessions survive session expiry. Without a context, the user must log in via Live View every ~5 minutes.

**Create a context:**
```bash
curl -s -X POST https://api.browserbase.com/v1/contexts \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectId": "$BROWSERBASE_PROJECT_ID"}'
# Returns: {"id": "091d24ce-7d01-41d8-8417-29c6e3148792", "uploadUrl": "...", ...}
```

**Save a running session's cookies to a context:**
```bash
curl -s -X POST https://api.browserbase.com/v1/contexts/{CONTEXT_ID}/sessions/{SESSION_ID} \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectId": "$BROWSERBASE_PROJECT_ID"}'
```
This exports the session's state (cookies, localStorage) to the context so future sessions can start from it.

**❗ Timeliness is critical:** Save the session to the context IMMEDIATELY after the user confirms login. If the 5-min session timeout fires before you save, the cookies are lost and the user must log in again.

**Create a new session that loads from a context:**
```bash
curl -s -X POST https://api.browserbase.com/v1/sessions \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectId": "$BROWSERBASE_PROJECT_ID", "contextId": "$CONTEXT_ID"}'
```
When `contextId` is set, the new session starts with all the cookies from that context — the user is already authenticated.

**⚠️ Pitfalls:**
- Contexts must be created before the session that you want to save. You can pre-create a context and reuse it across multiple sessions (the `sessions` endpoint overwrites the context data each time).
- The API endpoint `POST /v1/contexts/{id}/sessions/{id}` may return 404 if the session has already expired. Save within the session's lifetime.
- Contexts are project-scoped. A context created in project A cannot load into a session in project B.
- Context expiry: Contexts expire after a period of inactivity (check Browserbase docs for current TTL).

### Reference: Browserbase API Endpoints

```bash
# Create session
curl -X POST https://api.browserbase.com/v1/sessions \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectId": "$BROWSERBASE_PROJECT_ID", "keepAlive": true}'

# Get live view URL
curl -s https://api.browserbase.com/v1/sessions/{SESSION_ID}/debug \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" | jq .debuggerFullscreenUrl

# List active sessions
curl -s https://api.browserbase.com/v1/sessions?projectId=$BROWSERBASE_PROJECT_ID&status=RUNNING \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" | jq '.[].id'

# Create context for cookie persistence
curl -s -X POST https://api.browserbase.com/v1/contexts \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectId": "$BROWSERBASE_PROJECT_ID"}'

# Save session to context (run IMMEDIATELY after user logs in)
curl -s -X POST https://api.browserbase.com/v1/contexts/{CONTEXT_ID}/sessions/{SESSION_ID} \
  -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"projectId": "$BROWSERBASE_PROJECT_ID"}'
```

### Interacting After Login: Browse CLI

After the user logs in via the live view, the `browse` CLI can interact with the same session to perform automated tasks:

```bash
export BROWSERBASE_API_KEY="bb_live_..."
export BROWSERBASE_PROJECT_ID="facfd30e-..."

# Navigate to the page (opens or reuses the daemon session)
browse open https://notebooklm.google.com

# Snapshot the page to see interactive elements
browse snapshot

# Click / fill / type using element refs from the snapshot tree
browse click 7-1277        # click "Create new notebook"
browse fill 4-9 "email"    # fill a textbox
browse click 4-271         # click "Next"
browse type "password\n"   # type into focused field

# Use for any browser automation after auth
```

**Important:** The `browse` CLI runs its own daemon (separate from Hermes' `browser_*` tools). The built-in Hermes browser tools (`browser_navigate`, etc.) use a LOCAL Chromium or a different Browserbase session — they CANNOT see or control the session created by `browse open`. Always use `browse` commands for automation on a Browse CLI session.

**Session lifecycle with Browse CLI:**
```
browse stop        # Kill stale daemon (always do this first if retrying)
browse open <url>  # Start fresh daemon + Browserbase session
browse snapshot    # Interact
browse status      # Check browser connection
browse stop        # Clean up when done
```

If `browse open` times out, you almost certainly have a stale daemon — `browse stop` is the fix.

### ⏱️ Session Timeout: The 5-Minute Wall

Browserbase sessions default to **5 minutes** (300s, set by the project's `defaultTimeout` config). This is the single biggest obstacle in live-view workflows.

**Why it's a problem:**
- The user opens the live view, logs in (takes ~30-60s)
- The agent starts automation — but if the task is complex (upload sources, generate video that takes 2-3 mins, download results), the session may expire mid-task
- Session timeout CANNOT be extended after creation
- The `timeout` parameter on session creation may be capped by the project default

**Workarounds:**
1. **Work fast** — Save the context immediately after login, then if the session dies, create a new one with the context
2. **Set a longer timeout at creation** — The API accepts `timeout` in ms (max 7200000 = 2h on supported plans). Free plan may not honor this.
3. **Browserbase Scale plan** — Enables `keepAlive` and longer timeouts
4. **Fall back to API** — If the target has an API (e.g., Gemini API for NotebookLM), prefer API over browser automation for long operations

### Related Topics

- **Browserbase Provider code**: `tools/browser_providers/browserbase.py` in the Hermes package
- **Browserbase Plan Limits**: Free/Developer plan: no residential proxies, no keepAlive, 402 fallback. Scale plan: residential proxies, keepAlive, advanced stealth. Contexts and live view work on all plans.
- **NotebookLM browser workflow**: See `browser-automation/references/notebooklm-video-workflow.md` for the specific NotebookLM content generation flow
