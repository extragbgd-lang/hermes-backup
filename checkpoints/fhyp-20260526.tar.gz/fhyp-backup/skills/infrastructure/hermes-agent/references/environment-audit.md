# Pre-Task Environment Audit

Before building, creating, or troubleshooting ANYTHING for Ammar, run this audit first.
He gets frustrated when solutions are built from scratch while existing infrastructure sits unused.

## Quick Audit (30 seconds)

```bash
# 1. What MCP servers are configured?
hermes mcp list 2>/dev/null
# Hermes has native MCP integration. Check configured servers before building bridges.
# Also probe known MCP health endpoints:
curl -s http://172.23.240.1:3000/health 2>/dev/null  # NotebookLM MCP

# 2. What cron jobs exist?
# Use cronjob tool: cronjob(action='list')
# For debugging broken/silent crons, see references/cron-debugging.md

# 3. What scripts are in ~/.hermes/scripts/?
ls ~/.hermes/scripts/

# 4. What skills are installed?
# Use skills_list tool (no args = all categories)

# 5. What tools are enabled?
hermes tools list --summary 2>/dev/null  # requires PTY
```

## When to Run

- **ALWAYS** before creating a new script or automation
- Before troubleshooting a cron job — check if it's a path/delivery/config issue first
- Before building a NotebookLM integration — check if the MCP server is already running
- Before creating any file — check if a similar script/template already exists
- When user mentions "MCP", "cron", "automation", "pipeline", "tool"

## Common Pitfalls (Ammar's Setup)

- **NotebookLM MCP server** runs on Windows at `D:\notebooklm-mcp`, accessible from WSL at `172.23.240.1:3000`. It's often already running. Don't build a CDP-based NotebookLM solution without checking if the MCP can handle it first.
- **LM Studio** runs at `http://192.168.100.17:1234` with Qwen 3.5 9B and Gemma 4. Check if it's reachable before suggesting local LLM tasks.
- **Scripts in ~/scripts/** vs **~/.hermes/scripts/** — cron jobs reference the latter. Scripts in ~/scripts/ need to be copied/symlinked to ~/.hermes/scripts/ for cron use.
- **Cron delivery targets:** `discord` = home channel, `local` = no notification, `discord:guild:channel:thread` = specific thread. Check delivery target when user says "I didn't get notified."
- **Model router:** primary is `google/gemma-4-e2b` via LM Studio (local). Fallback is `qwen/qwen3.5-9b` (LM Studio), then OpenRouter (`owl-alpha`). All paid providers removed from chain.
- **Timezone:** Asia/Dubai (GMT+4). Cron schedules are in local time.
- **Browser tools** run on Browserbase cloud browsers. Check BROWSERBASE_API_KEY is set before attempting browser automation.
- **Delegate parallel work.** Use `delegate_task` with `tasks` array (up to 3 concurrent) for independent subtasks. Don't run parallel research/checks sequentially — the user explicitly called this out.
- **Cron debugging:** When a job seems broken or silent, read `references/cron-debugging.md` first. Most "not working" reports are silent-delivery-by-design, not actual failures.
