# Composio + Canva MCP Setup

## Overview

Canva's official MCP server (`https://mcp.canva.com/mcp`) requires **waitlist approval** for custom integrations. For pre-approved tools (Claude, ChatGPT, VS Code, Cursor, Gemini, Codex) the access is already granted. For Hermes or custom agents, the recommended bypass is **Composio** — a pre-approved OAuth bridge with 1000+ app integrations.

## Composio MCP Config

**This is the ONLY working config (26-May-2026, verified empirically):**

```yaml
mcp_servers:
  composio:
    url: "https://connect.composio.dev/mcp"
    auth: oauth
```

No headers. No API keys. The `auth: oauth` setting triggers Dynamic Client Registration (DCR) and a browser-based OAuth flow.

## OAuth Flow

1. Add entry to `~/.hermes/config.yaml` under `mcp_servers:` with `auth: oauth`
2. Run `hermes mcp login composio`
3. **Immediately** give the URL to the user — the listener only stays alive ~40s
4. User opens URL, signs in to Composio, clicks Authorize
5. Token cached at `~/.hermes/mcp-tokens/composio.json`

## WSL OAuth Redirect: 40s Timeout

**✅ WSL2 localhost forwarding WORKS** (verified 26-May-2026 — PowerShell test from WSL succeeded). No netsh needed.

**The real problem: Hard 40-second timeout.** `hermes mcp login composio` kills its callback listener after ~40s regardless of `connect_timeout`/`timeout` settings. Adding these to the MCP config does NOT override it. By the time the user opens the URL and clicks Authorize, the listener is dead.

**Workaround:** Run in background mode and have the user authorize within 30s:
```bash
hermes mcp login composio &
```

If speed doesn't work, a manual OAuth handler can capture the callback on `0.0.0.0:<port>` (script at `~/.hermes/manual_oauth.py`), but Hermes' DCR client_id and PKCE challenge are internal, so manual flow may be rejected.

## ⚠️ Direct Header Auth Does NOT Work

All tested combinations fail. Only `auth: oauth` works.

| Key Type | Headers | Result |
|----------|---------|--------|
| `ak_` API key | `Authorization: Bearer` | 401 |
| `ak_` API key | `x-consumer-api-key` | 401 |
| `ck_` consumer key | `x-consumer-api-key` | 401 `Invalid consumer API key` |

The 401 error message saying "Missing authentication: provide Authorization: Bearer *** x-consumer-api-key header" is **misleading** — no header combination succeeds.

### Key Locations

| Key | Prefix | Location | Purpose |
|-----|--------|----------|---------|
| API Key | `ak_` | Settings → API Keys | REST API |
| Consumer Key | `ck_` | **AI Clients** → select client | OAuth/DCR (NOT headers) |

## Canva After Composio

1. Go to dashboard.composio.dev
2. Find Canva → Connect → authorize
3. Canva tools become available through Composio MCP's 7 meta-tools

## Related Links

- Canva MCP Docs: https://www.canva.dev/docs/mcp/
- Composio for Hermes: https://composio.dev/hermes
- Hermes MCP Guide: https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp/
- **⬅️ CRITICAL SHORTCUT:** Check `references/zapier-shortcut.md` in the api-integrations skill. The user pointed out on 26-May-2026: "You actually can use canva from zapier" after 40+ minutes of Composio MCP fighting. Zapier's built-in Hermes integration (8,000+ apps including Canva) is almost always the faster path.
