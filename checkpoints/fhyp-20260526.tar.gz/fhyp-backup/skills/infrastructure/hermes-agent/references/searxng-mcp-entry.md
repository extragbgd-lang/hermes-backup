# SearXNG — Two Modes on Ammar's Machine

Two separate SearXNG-related MCPs/configs exist:

## 1. pipx MCP Wrapper (Thin Client)

Installed via `pipx install searxng`. This is a THIN MCP wrapper that connects to a SearXNG instance and exposes it as MCP tools.

**Binary:** `/home/ammar/.local/bin/searxng`
**Config entry:**
```yaml
mcp_servers:
  searxng:
    command: /home/ammar/.local/bin/searxng
    args: ["--instance-url", "http://127.0.0.1:8888"]
```

The `--instance-url` points to wherever SearXNG is running — either a public instance or the self-hosted one.

**Public instances (unreliable):** searx.be (403), searx.space (landing page only), all others 429 (rate-limited). Do not depend on these.

## 2. Self-Hosted SearXNG Engine (Full Install)

Running locally from `/home/ammar/searxng/` — cloned from github.com/searxng/searxng and installed in a Python venv.

**Location:** `/home/ammar/searxng/`
**Config:** `/home/ammar/searxng/settings-user.yml`
**Startup script:** `/home/ammar/.hermes/scripts/start-searxng.sh`
**Keepalive cron:** Every 5 minutes, checks port 8888, restarts if down
**Logs:** `/home/ammar/searxng/server.log`

### Manual Restart

```bash
cd /home/ammar/searxng
source venv/bin/activate
export SEARXNG_SETTINGS_PATH="/home/ammar/searxng/settings-user.yml"
nohup python3 -m searx.webapp > server.log 2>&1 &
```

Or use the script: `/home/ammar/.hermes/scripts/start-searxng.sh`

### Verify Running

```bash
curl -s "http://127.0.0.1:8888/search?q=test&format=json" | python3 -c "import json,sys; d=json.load(sys.stdin); print(f'{len(d[\"results\"])} results')"
```

Expect ~25-40 results per query (hits Google + DuckDuckGo).

### Configuration Notes

- `settings-user.yml` uses `use_default_settings: true` with overrides:
  - `server.limiter: false` — disables rate limiting for local use
  - `search.formats: [html, json, csv, rss]` — must include `json` or all API calls return 403
  - `engines:` — google and duckduckgo enabled by default
- The secret_key is auto-generated (run `python3 -c "import secrets; print(secrets.token_hex(32))"` to regenerate if needed)

### Gateway Restart = SearXNG Death

SearXNG is started as a background shell process. It does NOT survive a `systemctl --user restart hermes-gateway.service`. The keepalive cron (every 5 min) will catch this and restart it automatically within 5 minutes.

### Installation Steps (if redoing from scratch)

```bash
# Clone
git clone --depth 1 https://github.com/searxng/searxng.git /home/ammar/searxng
cd /home/ammar/searxng

# Venv + deps
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install msgspec pyyaml flask flask-babel

# Create settings
cat > settings-user.yml << 'EOF'
use_default_settings: true
server:
  secret_key: "YOUR_HEX_SECRET"
  bind_address: "127.0.0.1"
  port: 8888
  limiter: false
search:
  safe_search: 0
  formats: [html, json, csv, rss]
engines:
  - name: google
    engine: google
    shortcut: g
    disabled: false
  - name: duckduckgo
    engine: duckduckgo
    shortcut: ddg
    disabled: false
EOF

# Run
SEARXNG_SETTINGS_PATH="$PWD/settings-user.yml" python3 -m searx.webapp
```

Note: `pip install -e .` (editable/dev mode) FAILS because setup.py imports `searx/__init__.py` during build, which requires `msgspec` that isn't available in the isolated build environment. The fix is `pip install --no-build-isolation -e .` but even that may fail due to setuptools develop mode invoking pip recursively. Running the webapp directly (above) works fine.