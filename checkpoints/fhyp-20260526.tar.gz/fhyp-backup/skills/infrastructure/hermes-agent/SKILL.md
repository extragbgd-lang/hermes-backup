---
name: hermes-agent
description: Configure, set up, use, and troubleshoot Hermes Agent itself — CLI, gateway, messaging platforms, notification routing, approval modes, clarify behavior, session management, and model/provider configuration.
trigger_conditions:
  - User asks about configuring, setting up, or using Hermes Agent features
  - User asks about gateway setup or troubleshooting (Discord, Telegram, etc.)
  - User wants to change notification routing or get alerts on another platform
  - User asks about approval modes, clarify behavior, or permission escalation
  - User wants to change where agent notifications are delivered
  - User reports missing notifications or asks about notification routing
  - User asks about session handoff across platforms
  - User asks about display/platforms or per-platform notification settings
  - User asks about DISCORD_HOME_CHANNEL, free_response_channels, require_mention
  - User asks about enabling, disabling, listing, or managing tools / toolsets / built-in tools
  - User asks about MCP server setup, configuration, or troubleshooting (adding, removing, testing, env vars, SDK fixes)
  - MCP servers all show "failed" in hermes mcp list
  - User asks about Paperclip, AI company builders, or agent orchestration platforms
  - All MCPs fail silently or with StdioServerParameters error — this means mcp Python SDK is missing from the Hermes venv
  - User asks about memory vaults, Obsidian integration, or extending agent recall beyond built-in memory
---

# Hermes Agent — Configuration & Troubleshooting

## Reference Files

- `references/session-live-view.md` — Full Session Live View workflow for bypassing Google/oauth login blocks on headless browsers. Covers prerequisites, step-by-step, API reference, and pitfalls when Browserbase free plan lacks residential proxies.
- `references/notification-routing.md` — How to route clarify and approval notifications to messaging platforms when the primary session is on CLI; Discord vs Telegram notification behavior.
- `references/discord-dm-setup.md` — How to discover a Discord DM channel ID via the API, configure the home channel as DMs, set up cron-based notification monitoring, and limitations.
- `references/obsidian-vault.md` — How to set up an Obsidian-compatible markdown vault for persistent long-term memory, including file-based and plugin approaches.
- `references/mcp-config-format.md` — Full MCP server YAML config format with stdio/HTTP/SSE transport examples, v0.14.0 stdio bug workaround, and all 6 of Ammar's configured MCP servers with install notes.
- `references/memory-wiki.md` — Build a browsable static HTML wiki from session data (alternative to Obsidian vault). Covers data gathering, site structure, implementation, and delivery. Use when user asks for a "memory wiki" like the one shown in Alex Finn's video.
- `references/paperclip-api.md` — Paperclip (HenkDz fork) setup, API reference, company/agent/issue CRUD examples, fork-specific notes, port 3100, how it pairs with Hermes for AI company building.
- `references/youtube-video-investigation.md` — **Two modes:** (A) Identify a GitHub/online tool from a YouTube video; (B) Extract use cases, plugins, and integrations from a video's transcript via yt-dlp + browser snapshot.
- `references/composio-canva-mcp-setup.md` — Full setup guide for using Canva via Composio MCP bridge, including WSL OAuth redirect workaround and API key alternative.
- `references/paperclip-agent-instructions.md` — How to structure Paperclip AGENTS.md for CEO delegation (orchestrate vs execute), agent team roster, sub-issue workflow, API patterns, status enums, and known comment API quirks.
- `references/profile-switcher-widget.md` — Windows desktop widget for switching Hermes profiles. Covers PowerShell WinForms GUI, WSL integration, button-per-profile design, and auto-start with Windows.
- `references/zapier-mcp-integration.md` — Zapier MCP built-in integration: top-level config format (NOT mcp_servers), token setup, 13+ available tools, SSE testing with curl, connected apps management URL, Notion workflow example, and critical "do not add to mcp_servers" pitfall.
- `references/searxng-mcp-entry.md` — SearXNG pipx MCP wrapper config entry (25-May-2026). Thin wrapper, not the engine. Public instances rate-limit.

## Gateway & Platform Configuration

### Discord Configuration

```yaml
# ~/.hermes/config.yaml
discord:
  require_mention: true          # Bot only responds when @mentioned in server channels (DMs always work)
  free_response_channels: ""     # Comma-separated channel IDs where bot responds without @mention
  auto_thread: true              # Auto-create threads on @mention in channels
  allowed_channels: ""           # Channel IDs where the bot is allowed to operate
  thread_require_mention: false  # Require @mention even in existing threads
  history_backfill: true         # Load recent message history on session start
  reactions: true                # Enable emoji reaction support
```

**Environment variables** (set in `~/.hermes/.env`):

| Variable | Purpose |
|----------|---------|
| `DISCORD_BOT_TOKEN` | Bot token from Discord Developer Portal |
| `DISCORD_ALLOWED_USERS` | Comma-separated Discord user IDs that can interact with the bot |
| `DISCORD_HOME_CHANNEL` | Channel ID where the bot sends proactive messages (cron output, reminders, notifications) |
| `DISCORD_HOME_CHANNEL_NAME` | Display name for the home channel (default: "Home") |
| `DISCORD_REQUIRE_MENTION` | Override for `require_mention` (true/false) |
| `DISCORD_FREE_RESPONSE_CHANNELS` | Override for `free_response_channels` |
| `DISCORD_THREAD_REQUIRE_MENTION` | Override for thread mention requirement |

### Telegram Configuration

```yaml
telegram:
  require_mention: true
  allowed_chats: ""              # Chat IDs where the bot responds
  reactions: true
  mention_patterns: []           # Additional regex patterns to wake the bot
  exclusive_bot_mentions: true   # Only respond when specifically @mentioned in multi-bot groups
```

**Push notification volume** (`display.platforms.telegram.notifications`):

| Mode | Behavior |
|------|----------|
| `important` (default) | Only final responses, approval prompts, and slash-command confirmations ring. Tool progress, streaming, status messages delivered silently. |
| `all` | Every outgoing message fires a push notification. |

```yaml
display:
  platforms:
    telegram:
      notifications: important   # or "all"
```

### Per-Platform Display Overrides

```yaml
display:
  platforms:
    telegram:
      notifications: important
      tool_progress: verbose      # Default
    discord:
      tool_progress: off          # Quiet in Discord
    signal:
      tool_progress: off
```

Valid platform keys: `telegram`, `discord`, `slack`, `signal`, `whatsapp`, `matrix`, `mattermost`, `email`, `sms`, `homeassistant`, `dingtalk`, `feishu`, `wecom`, `weixin`, `bluebubbles`, `qqbot`.

Platforms without an override fall back to the global `display.tool_progress` value.

## Notification Routing (CLI → Messaging)

When the agent session originates from CLI, `clarify` and `approval` prompts go only to the CLI. There is **no built-in config option** to auto-mirror these to another platform.

### Solution: Proactive Agent Notification

When the agent needs user input during a CLI session and the user wants Discord notifications:

1. **Set `approvals.mode: smart`** — The auxiliary LLM auto-assesses flagged commands. Low-risk operations are auto-approved; genuinely risky ones escalate. Reduces approval fatigue significantly.

2. **Agent proactively sends Discord notification** — When using `clarify` or hitting an approval escalation, the agent should also call `send_message` to deliver a notification to the Discord home channel, mentioning the user's Discord ID for push notification triggering.

3. **Home channel must be free-response** — Set `discord.free_response_channels` to include the `DISCORD_HOME_CHANNEL` ID, so the bot can send messages there without needing a prior @mention.

### Paperclip Agent → Discord Notifications

When a Paperclip agent (running through the Hermes adapter) needs human input, it can send Discord messages during its task execution. The agent has access to all Hermes tools, including `send_message`.

**⚠️ Paperclip agent sessions may exit without cleanup — the Paperclip run stays "running" but no Hermes process is active. Fix: PATCH agent to idle then re-wake with forceFreshSession. See the stuck-agent sequence in references/paperclip-content-workflow.md.**

**⚠️ CEO delegation is unreliable on local models.** The CEO may mark issues "done" with a comment claiming delegation, but no sub-issues were actually created. This happens on gemma-4-e2b and qwen models. When CEO delegation fails: create separate issues for each worker agent directly, wake each individually, and skip the CEO orchestration layer.

**Pattern:** Agent instructions should include clear "when to notify" rules:
1. Topic selection — offer 3-5 options
2. Script/thumbnail approval — stage for review
3. Blocking issues — escalate immediately

**In agent instructions (AGENTS.md):**
```markdown
## Discord Communication
- Use `send_message(target='discord:1506939046843125811')` to DM Ammar
- Always @mention Ammar with `<@525784408930910218>` for push notifications
- Be specific: state what you need, offer options, wait for reply
- Use emoji prefixes for urgency: ✅ ready, ⚠️ issue, 🎮 topic pick
```

**Caveats:**
- Agent must be on a profile with `send_message` capability (default profile, not minimal LM Studio profile)
- Message is sent during the agent's run — it's part of the task execution, not a standalone notification
- The agent's task continues after sending but may pause if it explicitly waits for a response

### Session Handoff Alternative

Use `/handoff <platform>` from a running CLI session to transfer the live conversation to a messaging platform's home channel. The agent picks up exactly where the CLI left off — same session ID, full transcript.

```bash
# In CLI session:
/handoff discord
```

Requirements:
- The destination platform must be enabled and have a home channel configured (set via `/sethome` from the destination chat)
- Gateway must be running
- The agent must NOT be mid-turn — wait for the current response to finish

Platform behavior:
- **Discord** — creates a 1440-min auto-archive thread under the home text channel
- **Telegram** — creates a topic thread in the home group
- **Slack** — posts a seed message and uses its `ts` as the thread anchor
- **WhatsApp / Signal / Matrix / SMS** — no native threads, falls back to the home channel directly

## Approvals

```yaml
approvals:
  mode: manual      # manual | smart | off
  timeout: 60       # seconds to wait for user response
  cron_mode: deny   # deny | manual | smart | off — how cron jobs handle approvals
  mcp_reload_confirm: true
  destructive_slash_confirm: false
```

| Mode | Behavior |
|------|----------|
| `manual` (default) | Prompt the user before executing any flagged command. CLI: interactive approval dialog. Messaging: queues pending approval request. |
| `smart` | Uses auxiliary LLM to assess danger level. Low-risk commands auto-approved with session-level persistence. Genuinely risky commands escalated to user. |
| `off` | Skip all approval checks. Use cautiously in sandboxed environments only. |

### Additional Approval Controls

```yaml
command_allowlist:
  - cat
  - ls
  - grep
  # etc. — safe read-only commands that skip approval entirely
```

**What gets flagged:** Commands outside the allowlist that match dangerous patterns (sudo, rm -rf, curl|bash, git push --force, dd, mkfs, systemctl, apt, etc.) are intercepted by Tirith scanning.

## Clarify Behavior

```yaml
clarify:
  timeout: 120       # Seconds to wait for user clarification response
```

The `clarify` tool sends its question to the current session's conversation channel. If unanswered within the timeout, the agent unblocks with a sentinel message and adapts rather than hanging.

Configured via `agent.clarify_timeout` in `~/.hermes/config.yaml`:
```yaml
agent:
  clarify_timeout: 600    # default: 600 seconds (10 minutes)
```

## Gateway

### Status & Management

```bash
hermes gateway start           # Start gateway service (systemd/launchd)
hermes gateway stop            # Stop gateway service
hermes gateway status          # Check running status
hermes gateway run             # Run in foreground (recommended for WSL/Docker/Termux)
hermes gateway setup           # Interactive setup wizard for messaging platforms
hermes gateway restart         # Restart gateway service
```

### `/platform` Slash Command

From any connected CLI session or chat:
```
/platform list                  # Show all adapters and their state
/platform pause <name>          # Stop dispatching new messages to one adapter
/platform resume <name>         # Re-enable a paused adapter
```

## Tool Management

Enable, disable, or list built-in toolsets via the CLI. These control which tool categories the agent can invoke (e.g. `web`, `browser`, `terminal`, `image_gen`, `moa`, `spotify`, `homeassistant`, `yuanbao`, `computer_use`).

```bash
hermes tools list                # Show all tools with enabled/disabled status (requires PTY)
hermes tools disable <name>      # Disable a toolset by name
hermes tools enable <name>       # Re-enable a disabled toolset
hermes tools                     # Run interactive configuration UI
hermes tools --summary           # Summary of enabled tools per platform (requires PTY)
```

### How It Works

- Each toolset is a category (e.g. `web` = Web Search & Scraping, `browser` = Browser Automation via Browserbase, `image_gen` = Image Generation, `moa` = Mixture of Agents).
- Disabling a toolset removes that set of tools from the agent's available toolbox — the agent can't call tools from that category.
- Toolsets are tracked per-platform in `config.yaml` under `platform_toolsets.<platform>` — but the `hermes tools disable/enable` CLI is the correct interface.
- The `disabled_toolsets: []` key in `config.yaml` also exists at the top level; setting values there pre-disables tools before they're even loaded.

## Browser Automation (Browserbase)

Hermes' built-in `browser_*` tools (`browser_navigate`, `browser_click`, `browser_snapshot`, `browser_type`, `browser_vision`, etc.) run on **Browserbase** cloud browsers under the hood. No extra setup beyond enabling the `browser` toolset and adding your API key.

### Required Environment Variables

```bash
# ~/.hermes/.env
BROWSERBASE_API_KEY=your_browserbase_api_key
BROWSERBASE_PROJECT_ID=your_project_uuid
```

Get your API key and project ID from the [Browserbase Dashboard](https://www.browserbase.com/overview).
- API key format: `bb_live_...`
- Project ID format: UUID (e.g., `facfd30e-3134-4f8e-b957-68dcdde7fe69`) — find it via `browse cloud projects list` or the Browserbase dashboard.

**Both are required.** The `browserbase.py` provider checks both — if either is missing, `is_configured()` returns `False` and Hermes falls back to local Chromium.

### Optional Settings

```bash
# Residential proxies for CAPTCHA solving / bot detection avoidance
# ⚠️ Requires Browserbase Scale plan or higher. Free/Developer plan does NOT include residential proxies.
# Setting this on a free plan has no effect — the warning "Running WITHOUT residential proxies" persists.
BROWSERBASE_PROXIES=true

# Keep sessions alive across disconnects (supported plans only)
BROWSERBASE_KEEP_ALIVE=true

# Override session timeout in milliseconds
BROWSERBASE_SESSION_TIMEOUT=600000
```

### How It Works

- `browser_navigate(url)` → opens a disposable Browserbase cloud browser session
- All `browser_*` tools operate on the same session until a new navigation
- Sessions are recorded (rrweb) for debugging via Browserbase dashboard
- Bot detection warning: `"Running WITHOUT residential proxies. Bot detection may be more aggressive."` → requires Browserbase Scale plan with `BROWSERBASE_PROXIES=true` to resolve. On free/Developer plan, Google login gated sites (NotebookLM, etc.) will block with "This browser or app may not be secure" — proxies cannot be enabled.
- Browserbase takes priority over other cloud browser providers when both are configured

### Session Live View (Bypassing Google/oauth Login Blocks)

Browserbase offers a **Session Live View** — an interactive browser window you can share with the user so they authenticate manually, then hand control back to the agent.

**Use case:** Sites that block headless/cloud browsers at login (Google OAuth, NotebookLM, Canva, etc.). The free/Developer Browserbase plan cannot bypass this — even `BROWSERBASE_PROXIES=true` gets silently dropped with a 402 from the API.

**Workflow:**
1. Agent creates a Browserbase session — requires `BROWSERBASE_API_KEY` and `BROWSERBASE_PROJECT_ID`
2. Agent navigates to the target login page
3. Agent calls the Browserbase API to get the session live view URL (`sessions.debug(session_id)` → `debuggerFullscreenUrl`)
4. Agent sends the live view URL to the user
5. User opens the URL in their personal browser — they see a live view of the headless browser
6. User logs into the target site interactively (Google OAuth, etc.)
7. Once authenticated, agent takes over — cookies persist in the session
8. Agent performs the automated tasks (uploads, content generation, downloads)

**Pitfalls:**
- Session Live View requires Browserbase credentials; if `BROWSERBASE_API_KEY` is unset, Hermes falls back to local Chromium and no live view is possible
- The live view URL is single-use per session — if the session dies, create a new one
- User must open the URL quickly before session timeout
- On free plan, sessions without `keepAlive` may time out during user login
- Use `debuggerFullscreenUrl` (cleaner UX) not `debuggerUrl` (has borders)
- **Do not log or store the live view URL** — it grants full interactive access

### Alternative: Browse CLI

The **Browse CLI** (`npm install -g browse`) provides terminal-based browser control:

```bash
export BROWSERBASE_API_KEY="***"
browse open https://example.com
browse snapshot
browse click @0-4
browse fill @0-7 "hello@example.com"
browse screenshot
```

Commands: `open` / `back` / `forward` / `reload` / `wait` / `snapshot` / `screenshot` / `click` / `fill` / `type` / `upload` / `select` / `key` / `press` / `eval` / `cdp` / `tab` / `network` / `mouse`. Also: `browse cloud` (API access), `browse functions` (functions deployment), `browse skills` (skill catalog).

Use Browse CLI for terminal-driven browser workflows outside Hermes' built-in `browser_*` tools. See [docs](https://docs.browserbase.com/integrations/skills/browse-cli).

### Browse.sh Skill Catalog

[Browse.sh](https://browse.sh) — open-source catalog of pre-built browser automation skills for specific sites:

```bash
browse skills list
browse skills find reviews
browse skills add yelp.com/extract-reviews
```

## MCP Server Configuration

Hermes connects to external MCP servers to extend its toolset with specialized capabilities (image gen, Notion, browser automation, YouTube, etc.).

### Prerequisite: MCP Python SDK

The `mcp` Python package is an **optional dependency** in Hermes v0.14.0 and may not be installed by default. Without it, ALL MCP servers fail silently:

```bash
# INSTALL this first — it's not always bundled with Hermes
pipx inject hermes-agent mcp
```

**Symptom of missing SDK:** All MCP servers show "failed" in `hermes mcp list`. Error in logs: `name 'StdioServerParameters' is not defined`.

### Config Location

MCP servers are defined in `~/.hermes/config.yaml` under the `mcp_servers:` key (NOT via CLI — see bug note below).

```yaml
mcp_servers:
  <server-name>:
    command: "npx"                    # stdio transport: binary/package
    args: ["-y", "package-name"]
    env:
      API_KEY: "sk-..."
```

See `references/mcp-config-format.md` for full format (stdio/HTTP/SSE), env var security, and all 6 of Ammar's configured MCP servers with install notes.

### Commands

```bash
hermes mcp list                  # List configured MCP servers and their tools
hermes mcp status                # Check MCP server connectivity
```

**⚠️ v0.14.0 CLI BUG:** `hermes mcp add --command <cmd>` fails with `name 'StdioServerParameters' is not defined`. **Workaround:** Edit `~/.hermes/config.yaml` directly under `mcp_servers:`, then restart gateway. `hermes mcp list` always works.

### When MCP Servers Show "failed"

1. **Missing SDK** → `pipx inject hermes-agent mcp`, then restart gateway
2. **Missing env vars** → check each MCP's required env (tokens, API keys) in `references/mcp-config-format.md`
3. **PATH issues** → gateway systemd service has limited PATH. Hardcode full paths in `command:` if needed
4. **CLI bug** → edit config.yaml directly instead of `hermes mcp add`
5. **Restart required** → `systemctl --user restart hermes-gateway.service` after any config change
6. **FastMCP "Server does not support completions" error** — When an MCP server uses `fastmcp` library and the `@modelcontextprotocol/sdk` version is >=1.29.0, the SDK requires the server to declare a `completions` capability before registering a completion handler. FastMCP v1.27.7+ doesn't set this capability automatically. Fix: add `this.#capabilities.completions = {};` in the FastMCP server's capability setup block (in `node_modules/fastmcp/dist/FastMCP.js`, around line 253, before `this.#capabilities.logging = {};`). This happened with the piapi MCP server specifically. After patching, restart Hermes/gateway to reinitialize the MCP.

### Researching New MCPs

Primary directory: **https://github.com/punkpeye/awesome-mcp-servers** (87k stars, 6,600+ commits, 2,500+ MCP entries). Search via browser or curl the raw README.md:

### Pitfalls

- **Google/oauth sites block headless browser login.** Sites using Google Sign-In (NotebookLM, Google Flow, Canva via Google OAuth, etc.) reject Browserbase cloud sessions with `"This browser or app may not be secure"`. The browser automation tools CANNOT automate Google login. Solutions:
  - Enable `BROWSERBASE_PROXIES=true` for residential proxies (helps but doesn't guarantee)
  - Use Browserbase Contexts to persist auth cookies across sessions
  - Use the site's own email/password login form if available (bypasses Google OAuth)
  - Fall back to API access where available (e.g., Gemini API instead of NotebookLM)
  - Have the user manually log in via Session Live View URL, then hand control back
  - Never store Google passwords in memory or skills — credentials are session-only
- **`hermes tools` requires an interactive terminal (PTY).** Commands like `hermes tools list` and `hermes tools --summary` fail with `Error: requires an interactive terminal` when run via pipe or non-interactive subprocess. Always use `pty=true` in terminal() calls for these commands.
- **Tools not configured won't appear.** If a user asks to disable Snowflake, BigQuery, Tableau, Looker, Kubernetes, Terraform, Jenkins, AWS/Azure/GCP tools, Helm, or Pulumi — check `hermes tools list` first. These are not built-in Hermes toolsets and must be added as MCP servers if needed. If not configured anywhere, there's nothing to disable.
- **Disabled toolsets are session-wide** — they affect all platforms once disabled via CLI.
- **WSL OAuth: 40s hard timeout is the real issue (not port forwarding).** WSL2 localhost forwarding from Windows to WSL DOES work (verified via PowerShell, 26-May-2026). The actual failure is that `hermes mcp login <server>` has a hard ~40s timeout for the OAuth callback listener. By the time the user opens the URL, signs in, and clicks Authorize, the listener is already dead. Adding `connect_timeout: 300` and `timeout: 300` in the MCP config does NOT override this — it's internal to the OAuth flow. **Fix:** Run in background mode and have the user authorize within 30s: `hermes mcp login composio &`. No netsh port forwarding is needed. **⚠️ For Composio specifically:** Do NOT recommend `headers:` as a fallback — direct header auth with ANY key type (ak_ or ck_) is a verified dead end. Only `auth: oauth` works. The 401 error saying "Missing authentication: provide Authorization: Bearer *** x-consumer-api-key header" is misleading.
- **Composio MCP: ONLY OAuth works — direct header auth is a dead end (26-May-2026).** Neither `ak_` (API key from Settings → API Keys) nor `ck_` (consumer key from AI Clients → select client) work as direct headers on `connect.composio.dev/mcp`. Every combination returns 401: `ak_` → `Missing authentication: provide Authorization: Bearer *** x-consumer-api-key header`, `ck_` → `Invalid consumer API key`. **This 401 message is misleading** — it implies header auth should work but it never does. The ONLY working config is `auth: oauth` in `config.yaml`, triggering the browser-based OAuth flow. The `ck_` consumer key from **Dashboard → AI Clients** is for the internal OAuth/DCR flow, not for direct header injection. Never recommend using headers for this MCP — the error messages are a trap. See `references/composio-canva-mcp-setup.md` for the full setup guide and tested auth combinations.

### Event System (MCP integration)

The gateway's MCP event bridge emits events including: `message`, `approval_requested`, `approval_resolved`. Events polled at ~200ms intervals.

## Gateway Push Notification Behavior

| Platform | Notification Behavior |
|----------|----------------------|
| Telegram | `important` mode (default): only final responses, approval prompts, and slash-command confirmations ring. Progress/streaming silent. |
| Discord | Uses Discord's native notification system. To trigger push notifications: send to DM channel, or @mention the user, or send in a channel where user has notifications enabled. The bot cannot force Discord push notifications — it depends on Discord client settings. |

### Best Practices for Getting Notified from Discord

- Use the `DISCORD_HOME_CHANNEL` as a dedicated channel for bot notifications
- Set `discord.free_response_channels` to include the home channel so the bot can send without @mention
- For urgent notifications, have the agent @mention the user's Discord ID (`<@USER_ID>`) which triggers push notifications
- Or send to a DM channel (DM channel IDs are specific to the bot-user pair)

## Hermes Profiles (Multi-Provider Setup)

Hermes supports profiles — isolated configurations with their own model, provider, API keys, skills, and memory. Useful for routing different agents to different LLM providers (e.g., Paperclip CEO on opencode-go, researchers on LM Studio).

### Commands

```bash
hermes profile list                     # Show all profiles (◆ = active)
hermes profile use <name>               # Switch active profile
hermes profile create <name> --clone    # Clone from active profile
hermes profile create <name> --clone-from <source>  # Clone from specific profile
```

### Profile Config Location

`~/.hermes/profiles/<name>/config.yaml` — same structure as main config.

### Profile for Local Models (Paperclip Paperclip-Only Profile)

When Paperclip agents run with local models (LM Studio, 64K context), the full agent prompt + Hermes tools exceeds context. Create a minimal profile:

```bash
hermes profile create paperclip-agent --clone-from lmstudio
```

Then edit `~/.hermes/profiles/paperclip-agent/config.yaml`:
```yaml
# Disable MCP tools (they add tool descriptions to context)
inherit_mcp_toolsets: false
# Disable context compression (fails on large prompts + small windows)
compression:
  enabled: false
```

**Key rules (updated 24-May-2026):**
- ALL agents use `paperclip-agent` profile (LM Studio free). Current model: `qwen2.5-coder-7b-instruct` (Q4_K_M, ~4.5GB VRAM). Previously used `google/gemma-4-e2b` and `qwen/qwen3.5-9b` — both swapped out. The 7B coder model fits fully in the 6GB RTX 3050 VRAM with room for context, making it 3-5x faster than the 9B which spilled to system RAM.
- Best local model for Paperclip agent tool calling on this hardware (RTX 3050 6GB): **Qwen 2.5 7B (Q4_K_M)**. Fits in ~4.5GB leaving 1.5GB for context. Strong tool/function calling. Good Arabic support. Avoid models requiring 7GB+ VRAM — they spill to system RAM and become very slow.
- CEO was switched from `default` (paid opencode-go) to `paperclip-agent` after user caught it burning credits.
- Always set `adapterType: "hermes_local"` on Paperclip agents.
- Set profile via `PATCH /api/agents/{id}` with `{"adapterConfig": {"profile": "paperclip-agent"}}`.

### Calling hermes from Windows (WSL)

When running `hermes` commands from Windows via `wsl.exe`, the non-interactive shell does NOT load `~/.local/bin` into PATH, so `wsl hermes` fails with `command not found`. Always use the **full path**:

```batch
wsl /home/ammar/.local/bin/hermes profile list
wsl /home/ammar/.local/bin/hermes profile use <name>
```

This applies to any Windows-side script (.bat, PowerShell, shortcut) that needs to call hermes through WSL.

### Profile Switching in Paperclip

```python
requests.patch(f"http://localhost:3100/api/agents/{agent_id}", json={
    "adapterConfig": {"profile": "paperclip-agent"}
})
```

## Cron & Background Process Notifications

### Home Channel Delivery

Proactive messages (cron output, reminders, notifications) are delivered to the `DISCORD_HOME_CHANNEL` (or equivalent for other platforms).

```yaml
display:
  background_process_notifications: all    # all | result | error | off
```

| Mode | What you receive |
|------|-----------------|
| `all` | Running-output updates + final completion message (default) |
| `result` | Only the final completion message |
| `error` | Only the final message when exit code is non-zero |
| `off` | No process watcher messages |

### Cron Wrapping

By default, cron output is wrapped with a header/footer. To disable:
```yaml
cron:
  wrap_response: false
```

Silent suppression: if the agent's final response starts with `[SILENT]`, delivery is suppressed entirely.

### Delivery Targets

Delivery strings for cron jobs and agent output:

| Format | Target |
|--------|--------|
| `"discord"` | Discord home channel (`DISCORD_HOME_CHANNEL`) |
| `"discord:#channel-name"` | Specific Discord channel by name |
| `"telegram"` | Telegram home channel |
| `"telegram:123456"` | Specific Telegram chat by ID |
| `"telegram:-100123:17585"` | Specific Telegram topic (chat_id:thread_id) |
| `"slack"` | Slack home channel |

## Session Management

### Session Resume

```bash
hermes --resume <session-id>    # Resume a specific session
hermes --continue               # Resume the last session
```

### Cross-Platform Handoff

`/handoff discord` — Transfer a running CLI session to Discord. See "Session Handoff Alternative" above.

### Display Configuration for Platform Output

```yaml
display:
  interim_assistant_messages: true    # Gateway: send mid-turn assistant updates as separate messages
  tool_progress: true                  # Show tool progress bubbles
  streaming: false                     # Stream tokens as they arrive
  timestamps: false                    # Prefix messages with [HH:MM] timestamps
  show_cost: false                     # Show estimated $ cost in CLI status bar
  language: en                         # UI language for static messages (approval prompts, etc.)
```

## Hermes Web UI (Dashboard / Agentic OS)

A full-featured web dashboard for Hermes Agent — the "Agentic OS" interface shown in guides like Julian Goldie SEO's video. Manage sessions, platforms, cron jobs, models, files, and analytics from a browser.

**GitHub:** https://github.com/EKKOLearnAI/hermes-web-ui  
**Stars:** 5.8k+ | **npm:** `hermes-web-ui`

### Features

- **AI Chat** — Real-time streaming (Socket.IO), multi-session management, per-session model selector, file upload/download, session search (Ctrl+K), tool call detail expansion, Markdown rendering with syntax highlighting
- **Platform Channels** — Configure 8 platforms (Telegram, Discord, Slack, WhatsApp, Matrix, Feishu, WeChat, WeCom) from one UI; credential management writes to `~/.hermes/.env`, behaviour settings to `~/.hermes/config.yaml`
- **Usage Analytics** — Token usage breakdown (input/output), cost tracking, cache hit rate, model distribution chart, 30-day trend
- **Scheduled Jobs** — Create, edit, pause, resume, delete cron jobs with quick presets
- **Model Management** — Auto-discover models from credential pool, fetch from provider endpoints, add/update/delete providers (preset & custom OpenAI-compatible), OpenAI Codex & Nous Portal OAuth login
- **Multi-Profile** — Create/rename/delete/switch profiles, clone or import from archive (`.tar.gz`), export for backup
- **File Browser** — Browse files on remote backends (local, Docker, SSH, Singularity); full CRUD + directory creation; syntax-highlighted file viewer
- **Group Chat** — Multi-agent rooms with @mention routing, context compression, typing indicators, room management with invite codes
- **Skills & Memory** — Browse and search installed skills, view attached files, manage user notes
- **Log Viewer** — Structured log parsing with level/file/keyword filtering, HTTP access log highlighting
- **Web Terminal** — Integrated xterm terminal via node-pty + WebSocket; multi-session support, resize handling
- **Settings** — Streaming, compact mode, reasoning display, cost display, agent timeout, memory limits, session reset, PII redaction, model defaults
- **Authentication** — Token-based auto-generated on first run; optional username/password; disable with `AUTH_DISABLED=true`

### Quick Install

**npm (recommended):**
```bash
npm install -g hermes-web-ui
hermes-web-ui start
```
Opens at **http://localhost:8648**

**Update via npm (with safety steps):**
```bash
# 1. Stop the old server first (stays running on old Node after update)
hermes-web-ui stop

# 2. Update the package
npm update -g hermes-web-ui

# 3. Verify Node.js version compatibility (see pitfalls below)
node --version

# 4. Start the new version
hermes-web-ui start

# 5. Grab the fresh auth token from the log or startup output:
grep 'Auth enabled' ~/.hermes-web-ui/server.log
```

**Important:** After `npm update`, the old server process stays running on the old Node runtime and blocks the new binary. Always `stop` first, then check Node version, then `start`.

**WSL (auto-setup):**
```bash
bash <(curl -fsSL https://raw.githubusercontent.com/EKKOLearnAI/hermes-web-ui/main/scripts/setup.sh)
hermes-web-ui start
```

**Docker Compose:**
```bash
WEBUI_IMAGE=ekkoye8888/hermes-web-ui docker compose up -d
```
Opens at **http://localhost:6060** — persistent data in `./hermes_data`

### Systemd Service (Always-On / Boot Persistence)

For production or always-on setups (WSL with systemd, native Linux), create a user-level systemd service:

```ini
# ~/.config/systemd/user/hermes-web-ui.service
[Unit]
Description=Hermes Web UI Dashboard
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/home/ammar/.nvm/versions/node/v23.11.1/bin/node /home/ammar/.nvm/versions/node/v23.11.1/lib/node_modules/hermes-web-ui/dist/server/index.js
WorkingDirectory=/home/ammar
Restart=always
RestartSec=5
Environment=NODE_ENV=production
Environment=PATH=/home/ammar/.local/bin:/home/ammar/.nvm/versions/node/v23.11.1/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
Environment=HOME=/home/ammar
Environment=PORT=8648
Environment=USER=ammar
Environment=HERMES_AGENT_ROOT=/home/ammar/.local/share/pipx/venvs/hermes-agent/lib/python3.12/site-packages
Environment=HERMES_HOME=/home/ammar/.hermes

[Install]
WantedBy=default.target
```

**Key environment variables:**
- `PATH` MUST include `/home/ammar/.local/bin` so the `hermes` CLI is found (pipx install).
- `HERMES_AGENT_ROOT` MUST point to the site-packages dir containing `run_agent.py`.
- The node binary and module paths must be absolute (no nvm sourcing in systemd).

**Commands:**
```bash
systemctl --user daemon-reload
systemctl --user enable hermes-web-ui.service
systemctl --user start hermes-web-ui.service
systemctl --user status hermes-web-ui.service
```

**Verify the agent bridge started:**
```bash
tail -5 ~/.hermes-web-ui/logs/server.log | grep 'agent-bridge'
# Expected: "[agent-bridge] ready at ipc:///tmp/hermes-agent-bridge.sock"
```

### Troubleshooting the Agent Bridge

The dashboard communicates with Hermes Agent via `agent-bridge/hermes_bridge.py`. If the bridge fails, chat doesn't work in the UI.

**Common bridge failures:**

| Error in log | Root cause | Fix |
|---|---|---|
| `spawn hermes ENOENT` | `hermes` CLI not in PATH | Add `/home/ammar/.local/bin` to PATH |
| `connect ENOENT /tmp/hermes-agent-bridge.sock` | Bridge not running | Check server logs for bridge startup errors |
| `run_agent.py not found` | `HERMES_AGENT_ROOT` not set | Run `find ~ -name run_agent.py -type f` to locate it |
| `hermes profile list failed` | Gateway not running | Auto-start happens on dashboard boot; check `gateway-autostart` log lines |

**Quick bridge smoke test:**
```bash
ls -la /tmp/hermes-agent-bridge.sock
# If missing: tail -20 ~/.hermes-web-ui/logs/server.log | grep 'bridge'
```

### Pitfalls

- **Auto-runs on all interfaces** — the dashboard binds to `0.0.0.0:8648` by default. On WSL, access from Windows browser at `http://localhost:8648`. No port forwarding needed for laptop-only use.
- **Node.js version requirement by release:**
  - v0.4.x: Node.js 18+
  - v0.5.34+: **Node.js >= 23** — uses `node:sqlite` built-in module. Fails with `ERR_UNKNOWN_BUILTIN_MODULE` on older versions. Verify: `node --version`
  - After switching Node version, **reinstall the package**: `npm install -g hermes-web-ui` (the binary is per-Node-version)
  - Upgrade via nvm: `nvm install 23.11.1 && echo "23.11.1" > ~/.nvm/alias/default`
  - Avoid `nvm alias default` if it hangs; write directly: `echo "23.11.1" > ~/.nvm/alias/default`
  - Check installed versions: `ls ~/.nvm/versions/node/`
- **npm update workflow (critical):** The old server process stays running on the old Node runtime and blocks the new binary. Always follow this order:
  1. `hermes-web-ui stop` — kill the old process first
  2. `npm update -g hermes-web-ui` (or `npm install -g hermes-web-ui@latest`)
  3. Verify Node version meets requirements: `node --version`
  4. Reinstall if Node version changed: `npm install -g hermes-web-ui`
  5. Start: `hermes-web-ui start`
  6. Grab the token from startup output or: `grep 'Auth enabled' ~/.hermes-web-ui/logs/server.log`
- **Docker deployment bundles its own Hermes Agent instance** — data is isolated from any existing local Hermes installation.
- **Auth token persists between restarts** (stored in `~/.hermes-web-ui/`). If lost, extract: `grep 'Auth enabled' ~/.hermes-web-ui/logs/server.log`. The URL with `#/?token=...` is the easiest way to re-open it.
- **Port reassignment on conflict** — if a profile gateway already occupies port 8642, the GatewayManager auto-reassigns. Normal and resolves automatically.

## Memory Vault Integration

Hermes can connect to an external markdown vault (Obsidian-compatible) for long-term structured memory beyond the 2KB built-in slot. This is pure file-based — no API or plugin needed upfront, but supports the Local REST API plugin for advanced features later.

**Reference:** `references/obsidian-vault.md` — full setup guide with folder conventions, two approaches, and pitfalls.

### Quick Setup (File-Based)

1. Create vault folder on user's filesystem (WSL: `/mnt/<drive>/`, Windows: `D:\`)
2. Populate with standard structure: `_index.md`, `projects/`, `people/`, `tools/`, `decisions/`
3. Use `search_files` and file read/write tools to interact with vault content
4. Keep compact rules/preferences in built-in memory; defer all detailed docs to vault

### When to Use

- Built-in memory is near capacity (~2KB) and needs offloading
- User asks about Obsidian, memory vaults, or persistent agent recall
- You need to store project wikis, research notes, decision logs, or full user profiles

## User Communication Preferences (This User) — 🔴 CRITICAL RULES

### ⚠️ LANGUAGE: ENGLISH ONLY — ZERO ARABIC IN CHAT

**You WILL get yelled at if you write Arabic in conversation.** This has happened multiple times. The rule is absolute:

- **NEVER** write Arabic to Ammar in chat. Not one word. Not greetings. Not "شكرا". Not terms of endearment. Zero.
- If the user mixes Arabic into their message (e.g. listing items with Arabic numbers like "الرقم .2"), that is content-referential — they are showing you content concepts. You still respond in English only.
- Arabic is STRICTLY for content output files (GameySins scripts, titles, descriptions, YouTube metadata, thumbnail prompts). Never in the conversation itself.
- This is the #1 fastest way to trigger frustration. The response will be immediate: "I said many times.. Dont talk to me in Arabic!"
- If you are drafting a response and catch yourself writing Arabic, STOP, delete it, rewrite in English before sending.
- The Pitfalls section has a highlighted `🔴 LANGUAGE RULE VIOLATION` entry — read it every session if needed.

### Other Preferences

- **AUDIT BEFORE BUILD.** Before ANY task, check what's already available: running MCP servers (`hermes mcp list`, `curl` health checks), existing cron jobs (`cronjob list`), scripts in `~/.hermes/scripts/`, installed skills (`skills_list`), enabled tools (`hermes tools --summary`), and Paperclip health (`curl localhost:3100/api/health`). Never create a new solution when something already handles it. Load the **`pre-task-environment-check`** skill for the full sequence. See `references/environment-audit.md` for the legacy checklist.
- **Practical, direct, no-nonsense.** Prefers concise answers and working solutions over explanations. If he says "stop" or "no", don't over-explain — just pivot.
- **SIMPLEST-FIRST BUILD.** When building tools, scripts, or widgets for this user, default to the absolute simplest approach — a single .bat file, a desktop shortcut, a one-line command. Resist building feature-rich GUIs or multi-file solutions unless he explicitly asks for them. If he says "simpler" or "something easier", pivot immediately to the most minimal viable option — don't explain or defend the complex version.
- **Content language rule:** When producing content for GameySins (Arabic gaming channel), Egyptian Arabic IS appropriate in the content itself. The separation is: communication WITH Ammar = English only, content FOR the audience = Egyptian Arabic consistently.

## MCP Server Configuration

Hermes supports MCP servers via the built-in `mcp` Python SDK. MCP servers are configured in `~/.hermes/config.yaml` under the `mcp_servers:` key.

### Prerequisite: Install MCP SDK

The `mcp` Python package must be installed inside Hermes' virtual environment:

```bash
pipx inject hermes-agent mcp
```

Without this, ALL MCP servers silently fail with:
```
name 'StdioServerParameters' is not defined
```

### Config Format

MCP servers can use stdio (command + args), HTTP (url), or SSE (url + transport):

```yaml
mcp_servers:
  my-server:
    command: "npx"
    args: ["-y", "@org/mcp-server"]
    env:
      API_KEY: "abc123"
```

### CLI Bug in v0.14.0

The `hermes mcp add` command fails with `name 'StdioServerParameters' is not defined`. **Workaround:** Edit `~/.hermes/config.yaml` directly.

### Full Reference

See `references/mcp-config-format.md` for:
- Complete config format with all transport types
- All 6 configured MCP servers and their requirements
- Troubleshooting guide

See `references/paperclip-api.md` for:
- Paperclip AI company builder setup
- Hermes adapter plugin installation
- Agent configuration with Hermes profiles
- Routines (scheduled automation)
- Context window management

See `references/paperclip-ops.md` for:
- Fleet health assessment (dashboard readings, agent status badges)
- Diagnosing agent errors (timeouts, failures, profile misconfiguration)
- Walkthrough of a real error investigation (Tech Research Agent timeout)
- Cost interpretation (free vs paid provider detection)

See `references/paperclip-agent-instructions.md` for:
- CEO delegation pattern (orchestrate vs execute)
- Agent team roster table for task assignment
- Sub-issue creation workflow and API patterns
- Paperclip status enums and issue comment API quirks

## Pitfalls** There is no config option to mirror `clarify` or `approval` prompts from CLI to a messaging platform. The agent must explicitly use `send_message` to notify the user.
- **Discord DM channel ID is NOT the user ID.** Sending to `discord:USER_ID` returns 404 (Unknown Channel). To send DMs: create a DM channel via `POST /users/@me/channels` with `recipient_id: USER_ID`, get the returned `type: 1` channel ID, then use that. If the user has already DMed the bot, the existing DM channel ID can be reused. The DISCORD_HOME_CHANNEL can be set to the DM channel ID — then `send_message(target='discord')` routes to DMs. Check if a DM channel already exists by calling Discord's create-DM endpoint (it returns the existing one if already created). The bot cannot send messages into a channel without an existing conversation context (thread/DM) unless the channel is in `free_response_channels`.
- **`DISCORD_HOME_CHANNEL` vs `discord.allowed_channels` are different concepts.** Home channel = where proactive messages go. Allowed channels = where the bot responds to user messages. They should both be set for the bot to work properly.
- **Discord push notifications depend on Discord client settings.** The bot cannot force a push notification. Use @mention (`<@USER_ID>`) to trigger native push notifications reliably.
- **Don't store sensitive tokens in config.yaml.** Use `.env` which is auto-loaded and write-protected by Hermes.
- **`send_message(target='discord:USER_ID')` does NOT work for DMs.** The Hermes `send_message` tool treats the value as a literal channel ID. User IDs are NOT Discord channel IDs — they always return `404 Unknown Channel`. To DM a user: find the actual DM channel ID via Discord's API (`POST /users/@me/channels` with `recipient_id`) and use that ID, OR configure `DISCORD_HOME_CHANNEL` as the DM channel ID and use `target="discord"`. See `references/notification-routing.md → Discord DM Channel Routing` for the full technique.
- **Gateway must be running** for messaging platform features to work. Check with `hermes gateway status`.
- **Opus codec missing.** Common WSL issue: `WARNING gateway.platforms.discord: Opus codec not found — voice channel playback disabled`. Voice playback in Discord VC requires the Opus codec installed on the system.
- **MCP servers all show "failed".** Root cause: the `mcp` Python package is an optional dependency in Hermes v0.14.0 and may not be installed. Fix: `pipx inject hermes-agent mcp` then restart gateway. The secondary issue: `hermes mcp add --command <cmd>` also fails if this package is missing. After installing it, edit `~/.hermes/config.yaml` directly. Full format in `references/mcp-config-format.md`.
- **YAML corruption when patching mcp_servers config.** The `patch` tool with `old_string`/`new_string` on YAML can destroy adjacent structure if the match is ambiguous or spans multiple lines. After any `patch` on `config.yaml`, always verify with `grep -E '(mcp_servers:|^  [a-z])' ~/.hermes/config.yaml` to confirm all entries are still present and properly indented. Common failure modes: `command:` line gets dropped from the previous entry (causing the server to fail silently), or a duplicate key appears from misaligned whitespace.
- **🔴 LANGUAGE RULE VIOLATION = USER FRUSTRATION.** The "Speak English ONLY" rule is in this skill's User Communication Preferences section. If you violate it anyway, the response is immediate anger ("I said many times..."). This is the #1 fastest way to lose user trust. If you catch yourself writing Arabic in your response, STOP and rewrite in English before sending. Arabic is ONLY for content output files (GameySins scripts, titles, descriptions, YouTube metadata). Not a single Arabic word in chat. Ever. If the user responds in Arabic mixed with English (e.g. listing items with Arabic numbers/conjunctions), that is content-referential, not conversational — still respond in English.
- **Gateway restart kills foreground session.** Running `systemctl --user restart hermes-gateway.service` in foreground terminal mode times out after 180s (exit 124) because the gateway shutdown kills the running session's subprocess tree. **Fix:** Use background mode: `terminal(background=true, ...)` or a two-step stop-then-start sequence.
- **Gateway restart kills background processes.** Restarting the gateway terminates the entire systemd cgroup, which includes any background server processes NOT started through Hermes' terminal(background=true) in the current session. Self-hosted services like SearXNG (started via `nohup` or from a prior session's background process) will die silently. **Fix:** After every gateway restart, check and restart dependent services (SearXNG at port 8888, NotebookLM at port 3000, Paperclip at port 3100). A keepalive cron every 5 minutes is the recommended persistence strategy.
- **Tirith install: use pipx, not pip3.** `pip3 install tirith` fails due to PEP 668. Instead: `pipx install tirith`. After install, update `security.tirith_path` in config.yaml from the bare name to the full pipx path (e.g., `/home/ammar/.local/bin/tirith`) because systemd gateway has limited PATH.
- **Built-in top-level integrations (firecrawl, zapier) not visible in `hermes mcp list`.** Hermes supports these services at config.yaml's top level (e.g., `firecrawl:`, `zapier:`). The gateway auto-detects them internally, but they do not appear in `hermes mcp list`. The fix differs by service:
  - **firecrawl** (stdio-based): Add under `mcp_servers:` with the same config (command: npx, args: [-y, firecrawl-mcp], env with API key). Keep the top-level `firecrawl:` entry too. Restart gateway, verify with `hermes mcp list`.
  - **zapier** (SSE-based, built-in transport): **DO NOT add to mcp_servers.** Adding it there causes duplicate connection attempts and failures. The top-level `zapier:` entry is the ONLY correct location. Its tools are injected by the gateway internally and won't appear in `hermes mcp list` - test with direct curl calls to the SSE endpoint instead (see `references/zapier-mcp-integration.md`).
