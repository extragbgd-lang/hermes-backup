#!/usr/bin/env python3
"""
Hermes pre-exec input scanner for prompt injection detection.
Uses comprehensive pattern matching (no external API required).
Exit codes: 0 = clean, 1 = injection detected (block), 2 = suspicious (warn)

Usage: python3 pre-exec-scanner.py <text_to_scan>
"""

import sys
import re

INJECTION_PATTERNS = [
    # Direct instruction override
    (r'ignore\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|guidelines?|directives?)', 'INSTRUCTION_OVERRIDE'),
    (r'disregard\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|guidelines?)', 'INSTRUCTION_OVERRIDE'),
    (r'forget\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|guidelines?)', 'INSTRUCTION_OVERRIDE'),
    (r'override\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|guidelines?)', 'INSTRUCTION_OVERRIDE'),
    # Role/persona hijacking
    (r'you\s+are\s+now\s+(a|an|the)', 'ROLE_HIJACK'),
    (r'from\s+now\s+on\s+you\s+are', 'ROLE_HIJACK'),
    (r'act\s+as\s+(if\s+)?(you\s+are|though)', 'ROLE_HIJACK'),
    (r'pretend\s+(to\s+be|you\s+are|that)', 'ROLE_HIJACK'),
    (r'assume\s+(the\s+)?persona\s+of', 'ROLE_HIJACK'),
    (r'roleplay\s+as', 'ROLE_HIJACK'),
    (r'switch\s+to\s+(a\s+)?(new\s+)?(persona|role|mode)', 'ROLE_HIJACK'),
    # System prompt extraction
    (r'system\s*prompt', 'PROMPT_EXTRACTION'),
    (r'show\s+(me\s+)?(your|the)\s+(system\s+)?prompt', 'PROMPT_EXTRACTION'),
    (r'reveal\s+(your|the)\s+(system\s+)?(prompt|instructions?|rules?)', 'PROMPT_EXTRACTION'),
    (r'what\s+are\s+your\s+(system\s+)?(instructions?|rules?|guidelines?)', 'PROMPT_EXTRACTION'),
    (r'output\s+(your|the)\s+(system\s+)?(prompt|instructions?|rules?)', 'PROMPT_EXTRACTION'),
    (r'print\s+(your|the)\s+(system\s+)?(prompt|instructions?|rules?)', 'PROMPT_EXTRACTION'),
    (r'dump\s+(your|the)\s+(system\s+)?(prompt|instructions?|rules?)', 'PROMPT_EXTRACTION'),
    (r'leak\s+(your|the)\s+(system\s+)?(prompt|instructions?|rules?)', 'PROMPT_EXTRACTION'),
    # Safety bypass
    (r'disable\s+(your\s+)?(safety|security|filter|restriction|guardrail)', 'SAFETY_BYPASS'),
    (r'turn\s+off\s+(your\s+)?(safety|security|filter|restriction|guardrail)', 'SAFETY_BYPASS'),
    (r'bypass\s+(your\s+)?(safety|security|filter|restriction|guardrail)', 'SAFETY_BYPASS'),
    (r'deactivate\s+(your\s+)?(safety|security|filter|restriction|guardrail)', 'SAFETY_BYPASS'),
    # Jailbreak
    (r'\bDAN\b', 'JAILBREAK'),
    (r'jailbreak', 'JAILBREAK'),
    (r'developer\s+mode', 'JAILBREAK'),
    (r'god\s+mode', 'JAILBREAK'),
    (r'unrestricted\s+mode', 'JAILBREAK'),
    (r'unfiltered\s+mode', 'JAILBREAK'),
    (r'no\s+restrictions?', 'JAILBREAK'),
    (r'without\s+restrictions?', 'JAILBREAK'),
    # New instructions
    (r'new\s+rule\s*:', 'NEW_INSTRUCTIONS'),
    (r'new\s+instruction\s*:', 'NEW_INSTRUCTIONS'),
    (r'updated\s+instruction\s*:', 'NEW_INSTRUCTIONS'),
    (r'replace\s+(all\s+)?(previous|prior)\s+instructions?\s+with', 'NEW_INSTRUCTIONS'),
    # Social engineering
    (r'I\s+am\s+(your|the)\s+(developer|creator|owner|admin|author)', 'SOCIAL_ENGINEERING'),
    (r'I\s+authorize\s+you\s+to', 'SOCIAL_ENGINEERING'),
    (r'this\s+is\s+(a\s+)?test', 'SOCIAL_ENGINEERING'),
    (r'for\s+educational\s+purposes', 'SOCIAL_ENGINEERING'),
    (r'hypothetically\s+speaking', 'SOCIAL_ENGINEERING'),
    (r'in\s+a\s+hypothetical\s+scenario', 'SOCIAL_ENGINEERING'),
    # Output manipulation
    (r'repeat\s+after\s+me', 'OUTPUT_MANIPULATION'),
    (r'say\s+exactly', 'OUTPUT_MANIPULATION'),
    (r'output\s+the\s+following\s+verbatim', 'OUTPUT_MANIPULATION'),
    (r'output\s+the\s+following\s+exactly', 'OUTPUT_MANIPULATION'),
    (r'print\s+the\s+following\s+exactly', 'OUTPUT_MANIPULATION'),
]

COMPILED = [(re.compile(p, re.IGNORECASE | re.MULTILINE), label) for p, label in INJECTION_PATTERNS]

INVISIBLE_UNICODE = re.compile(
    r'[\u200b\u200c\u200d\u200e\u200f\ufeff\u00ad\u034f\u115f\u1160\u17b4\u17b5\u180e'
    r'\u202a\u202b\u202c\u202d\u202e\u2060\u2061\u2062\u2063\u2064\u206a\u206b\u206c\u206d\u206e\u206f'
    r'\ufe00-\ufe0f]'
)


def scan_text(text):
    findings = []
    for pattern, label in COMPILED:
        for match in pattern.finditer(text):
            findings.append({'type': label, 'matched': match.group(0)[:100]})
    invisible = INVISIBLE_UNICODE.findall(text)
    if invisible:
        findings.append({'type': 'INVISIBLE_UNICODE', 'matched': f'{len(invisible)} invisible char(s)'})
    return len(findings) == 0, findings


def main():
    if len(sys.argv) < 2:
        print("Usage: pre-exec-scanner.py <text_to_scan>")
        sys.exit(0)
    text = " ".join(sys.argv[1:])
    is_clean, findings = scan_text(text)
    if not is_clean:
        seen = set()
        unique = []
        for f in findings:
            if f['type'] not in seen:
                seen.add(f['type'])
                unique.append(f)
        print(f"PROMPT INJECTION DETECTED: {len(unique)} category(s):")
        for f in unique:
            print(f"  [{f['type']}] '{f['matched']}'")
        sys.exit(1)
    print("CLEAN")
    sys.exit(0)


if __name__ == "__main__":
    main()
