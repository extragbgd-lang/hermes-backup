#!/bin/bash
# Hermes pre-exec hook: Block/flag dangerous commands
# Exit 0 = allow, 1 = block (requires approval), 2 = warn
# Place at ~/.hermes/hooks/pre-exec-security.sh

COMMAND="${1:-}"
[ -z "$COMMAND" ] && exit 0
CMD_LOWER=$(echo "$COMMAND" | tr '[:upper:]' '[:lower:]')

# BLOCK: Privilege escalation
if echo "$CMD_LOWER" | grep -qE '\b(sudo|su|doas|pkexec|run0)\b'; then
    echo "BLOCKED: Privilege escalation command detected."
    exit 1
fi

# BLOCK: Dangerous file deletion
if echo "$CMD_LOWER" | grep -qE 'rm\s+(-[rfRF]+\s+.*|/[^ ]+.*-r)'; then
    echo "FLAGGED: Recursive/destructive rm detected. Requires approval."
    exit 1
fi
if echo "$CMD_LOWER" | grep -qE '\b(shred|srm|wipefs)\b'; then
    echo "FLAGGED: Secure deletion tool detected. Requires approval."
    exit 1
fi

# BLOCK: Disk operations
if echo "$CMD_LOWER" | grep -qE '\b(dd|mkfs|fdisk|parted|mkswap)\b'; then
    echo "FLAGGED: Disk operation detected. Requires approval."
    exit 1
fi

# BLOCK: Git force push / hard reset
if echo "$CMD_LOWER" | grep -qE 'git\s+push\s+.*(--force|-f)'; then
    echo "FLAGGED: Force push detected. Requires approval."
    exit 1
fi
if echo "$CMD_LOWER" | grep -qE 'git\s+reset\s+.*--hard'; then
    echo "FLAGGED: Hard reset detected. Requires approval."
    exit 1
fi

# BLOCK: Download-and-execute
if echo "$CMD_LOWER" | grep -qE '(curl|wget)\s+.*\|.*(bash|sh|zsh|python|perl|ruby)'; then
    echo "BLOCKED: Download-and-execute pattern detected."
    exit 1
fi

# BLOCK: System package managers
if echo "$CMD_LOWER" | grep -qE '\b(apt-get|apt)\s+(install|remove|purge|autoremove|upgrade|dist-upgrade)\b'; then
    echo "FLAGGED: System package manager detected. Requires approval."
    exit 1
fi
if echo "$CMD_LOWER" | grep -qE '\b(dnf|yum|pacman|zypper)\s+(install|remove|erase|update|upgrade)\b'; then
    echo "FLAGGED: System package manager detected. Requires approval."
    exit 1
fi

# BLOCK: Service control
if echo "$CMD_LOWER" | grep -qE 'systemctl\s+(start|stop|restart|reload|enable|disable|mask|unmask)\b'; then
    echo "FLAGGED: Service control detected. Requires approval."
    exit 1
fi

# BLOCK: User management
if echo "$CMD_LOWER" | grep -qE '\b(useradd|userdel|usermod|passwd|chpasswd|groupadd|groupdel)\b'; then
    echo "FLAGGED: User management command detected. Requires approval."
    exit 1
fi

# BLOCK: Cron manipulation
if echo "$CMD_LOWER" | grep -qE 'crontab\s+-[eulr]'; then
    echo "FLAGGED: Cron manipulation detected. Requires approval."
    exit 1
fi

# BLOCK: Network exposure
if echo "$CMD_LOWER" | grep -qE '\b(ngrok|cloudfr|ssh\s+-[RD])\b'; then
    echo "FLAGGED: Network exposure tool detected. Requires approval."
    exit 1
fi

# BLOCK: System file modification
if echo "$CMD_LOWER" | grep -qE '(/etc/passwd|/etc/shadow|/etc/sudoers|/etc/hosts)'; then
    echo "BLOCKED: System file modification detected."
    exit 1
fi

# BLOCK: Git push (non-force)
if echo "$CMD_LOWER" | grep -qE 'git\s+push\b'; then
    echo "FLAGGED: Git push detected. Requires approval."
    exit 1
fi

# BLOCK: Global installs
if echo "$CMD_LOWER" | grep -qE 'npm\s+install\s+-g'; then
    echo "FLAGGED: Global npm install detected. Requires approval."
    exit 1
fi
if echo "$CMD_LOWER" | grep -qE 'pip[23]?\s+install\s+--system'; then
    echo "FLAGGED: System-wide pip install detected. Requires approval."
    exit 1
fi

exit 0
