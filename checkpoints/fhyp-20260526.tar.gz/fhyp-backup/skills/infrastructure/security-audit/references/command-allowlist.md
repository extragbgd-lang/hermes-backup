# Recommended Command Allowlist

Safe read-only commands that don't require approval. Add to `config.yaml` under `command_allowlist:`.

## File & Directory Operations
```
cat, ls, head, tail, less, more, find, grep, wc, sort, uniq, diff, file, stat, du, df, tree, fd, rg, jq
```

## System Information
```
ps, top, htmp, free, uname, date, whoami, id, groups, echo, pwd, which, whereis, env, printenv, history
```

## Safe Script Execution
```
python3 -c, node -e
```

## What NOT to Allow
- `sudo`, `su`, `doas` — privilege escalation, always require approval
- `rm -rf`, `dd`, `mkfs`, `fdisk`, `shred`, `wipefs` — destructive, always require approval
- `apt install`, `pip install`, `npm install -g` — system-wide installs, always require approval
- `iptables`, `ufw`, `setenforce` — security control modification, always require approval
- `curl`, `wget`, `nc`, `ncat` — network tools that could exfiltrate data, require approval
