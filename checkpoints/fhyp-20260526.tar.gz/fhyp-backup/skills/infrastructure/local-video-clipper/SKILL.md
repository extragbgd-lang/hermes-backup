---
name: local-video-clipper
description: Build and maintain a fully local GPU-accelerated video-to-shorts clipper. Downloads from YouTube/X/Facebook, transcribes with faster-whisper GPU, analyzes engagement via local LLM (LM Studio), auto-reframes to 9:16 with subject tracking, and overlays viral word-by-word typography subtitles. Outputs vertical shorts with NVENC hardware encoding. Zero cloud APIs.
trigger_conditions:
  - User wants to build a tool that clips long videos into shorts locally
  - User mentions building a "Nexus-like" or "Opus-like" local alternative
  - User wants to use local LLM + GPU for video clipping with viral captions
  - User asks about auto-reframe, smart cropping, or subject tracking for shorts
  - User asks about word-by-word or TikTok-style typography subtitles
  - User wants to pull from YouTube/X/Facebook and auto-extract engaging moments
tags: [video, shorts, gpu, local-llm, whisper, ffmpeg, typography]
---

# Local GPU-Accelerated Video Clipper

Architecture and implementation guide for building a fully local video-to-shorts clipper that uses local LLM for engagement analysis, GPU for transcription/encoding, and produces vertical 9:16 shorts with viral typography.

## Architecture Overview

```
Video URL (YouTube/X/Facebook)
      │
      ▼
┌─────────────────┐
│ 1. Download      │  yt-dlp → .mp4 + audio.wav
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ 2. Transcribe    │  faster-whisper (GPU) → word-level timestamps
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ 3. Scene Detect  │  PySceneDetect / ffmpeg → cut boundaries
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ 4. Engagement AI │  Qwen/Llama via LM Studio → finds 🔥 moments
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ 5. Smart Reframe │  OpenCV tracking → 9:16 with subject follow
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ 6. Viral Typo    │  Dynamic word-by-word captions + color pops
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ 7. Compose       │  ffmpeg + NVENC → final 9:16 short 🔥
└─────────────────┘
```

## System Requirements Audit

Before building, audit the system for these components:

### GPU Stack
```bash
# Check NVIDIA driver presence (WSL)
ls /usr/lib/wsl/lib/libcuda.so.1

# Check GPU
export LD_LIBRARY_PATH=/usr/lib/wsl/lib:$LD_LIBRARY_PATH
/usr/lib/wsl/lib/nvidia-smi

# Expected: GPU with ≥4GB VRAM, CUDA 12+
```

### Key Dependencies
| Component | Purpose | Install Check |
|-----------|---------|---------------|
| **yt-dlp** | Video download from YouTube/X/Facebook | `which yt-dlp` |
| **ffmpeg** with CUDA | Video processing + NVENC encode | `ffmpeg -hwaccels` shows `cuda` |
| **faster-whisper** | GPU-accelerated transcription | `pip show faster-whisper` |
| **CTranslate2** | Whisper GPU backend | `python3 -c "import ctranslate2; print(ctranslate2.get_cuda_device_count())"` |
| **OpenCV** | Auto-reframe subject tracking | `pip show opencv-python` |
| **PySceneDetect** | Scene change detection | `pip show scenedetect` or `which scenedetect` |
| **Pillow** | Typography subtitle rendering | `pip show pillow` |
| **LM Studio** | Local LLM serving (OpenAI-compat API) | Check API on `http://localhost:1234/v1/models` |

### CUDA Verification (CTranslate2)
```python
import ctranslate2
print("CUDA devices:", ctranslate2.get_cuda_device_count())
print("GPU compute types:", ctranslate2.get_supported_compute_types('cuda'))
# Expected: count > 0, types include float16/int8/bfloat16
```

### ffmpeg CUDA Capabilities
```bash
# Check hardware encoders
ffmpeg -hide_banner -encoders | grep nvenc
# Expected: h264_nvenc, hevc_nvenc

# Check CUDA filters
ffmpeg -hide_banner -filters | grep -E "scale_cuda|overlay_cuda"
# scale_cuda = GPU-accelerated resize
# overlay_cuda = GPU-accelerated overlay compositing
```

### Python Environment
- faster-whisper and CTranslate2 may be installed in user's local site-packages
- The venv Python may not see them — set PYTHONPATH or modify sys.path:
  ```python
  import sys
  sys.path.insert(0, '/home/ammar/.local/lib/python3.12/site-packages')
  ```

---

## Pipeline Stages

### Stage 1: Download

```bash
# Download video + extract audio
yt-dlp -f "bestvideo[height<=1080]+bestaudio/best[height<=1080]" \
  -o "video.mp4" \
  "URL"

# Extract audio separately for transcription
ffmpeg -i video.mp4 -vn -ar 16000 -ac 1 -c:a pcm_s16le audio.wav
```

**Platform notes:**
- **YouTube**: default works, `--cookies` may help with age-restricted
- **X/Twitter**: use `--cookies-from-browser` or manual cookies
- **Facebook**: use `--cookies` file

### Stage 2: Transcription with GPU

```python
from faster_whisper import WhisperModel

model = WhisperModel(
    "base",  # or "medium", "large-v3"
    device="cuda",
    compute_type="float16",  # or "int8_float16" for lower VRAM
)

segments, info = model.transcribe("audio.wav", word_timestamps=True)

# Output format: list of {word, start, end}
for seg in segments:
    for word in seg.words:
        print(f"{word.word} {word.start:.2f} {word.end:.2f}")
```

**Model size guidance (6GB VRAM):**
- `base` / `small` → very fast, low VRAM
- `medium` → good balance, ~2GB VRAM
- `large-v3` → most accurate, ~4GB VRAM, may need `int8_float16`

**Output structure:**
```json
{
  "segments": [
    {
      "start": 0.0,
      "end": 5.2,
      "text": "...",
      "words": [{"word": "...", "start": 0.1, "end": 0.4}, ...]
    }
  ],
  "language": "en"
}
```

### Stage 3: Scene Detection

```bash
# Quick scene detection with ffmpeg
ffmpeg -i video.mp4 -vf "select='gt(scene,0.3)',showinfo" \
  -vsync vfr -f null - 2>&1 | grep "pts_time" | awk '{print $NF}'

# Or use PySceneDetect for more sophisticated detection
scenedetect -i video.mp4 detect-adaptive list-scenes
```

**Threshold tuning:**
- `0.3` → fewer scenes, only hard cuts
- `0.1` → more sensitive, catches transitions
- Adjust based on content type (gaming = fast cuts → lower threshold)

### Stage 4: Engagement Analysis (Local LLM)

Send transcript segments + scene boundaries to LM Studio API:

```python
import requests

LM_API = "http://localhost:1234/v1/chat/completions"
MODEL = "qwen-3.5-9b"  # or whatever is loaded in LM Studio

prompt = f"""You are a viral shorts analyst. Analyze this video transcript and identify the top 3-5 most engaging/viral-worthy moments.

For each moment, return:
1. START_TIME and END_TIME in seconds
2. Why it would go viral (high energy, funny, controversial, surprising, emotional, hook)
3. Suggested clip length (15-60 seconds recommended)

Transcript (with timestamps):
{transcript_with_timestamps}

Scene boundaries (seconds): {scene_boundaries}

Return ONLY a JSON array of moments, no other text."""

response = requests.post(LM_API, json={
    "model": MODEL,
    "messages": [{"role": "user", "content": prompt}],
    "temperature": 0.3,
    "max_tokens": 2000,
})
```

**Prompt engineering tips:**
- Include exact timestamps in transcript so LLM returns accurate ones
- Feed scene boundaries so clips don't cross cuts
- Keep temperature low (0.3) for structured JSON output
- Ask for reasoning per clip to get better quality picks
- For Arabic videos, transcript is already in Arabic — LLM handles it

**LM Studio API setup:**
1. Open LM Studio
2. Load Qwen 3.5 9B (or similar)
3. Go to Server tab → Enable API Server
4. Set port 1234 (default)
5. Start server
6. Verify: `curl http://localhost:1234/v1/models`

### Stage 5: Smart Auto-Reframe (9:16)

```python
import cv2

cap = cv2.VideoCapture("video.mp4")
# Use face cascade or person detection to track subject
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# Track subject position across frames
# Crop 9:16 (1080x1920 or 720x1280) centered on detected subject
# Fall back to center crop + Ken Burns zoom when no subject detected
```

**Approach options (in order of sophistication):**

1. **Basic** (no GPU, always works): Center-crop + smooth Ken Burns zoom. Use ffmpeg `crop` + `zoompan` filters.

2. **Smart** (some CPU, good results): OpenCV face detection + tracking. Follows speaker, falls back to center.

3. **Pro** (uses GPU, best results): Lightweight YOLO person tracking. Expensive on 6GB VRAM.

**ffmpeg center-crop fallback:**
```bash
# 9:16 center crop with smooth Ken Burns zoom
ffmpeg -i video.mp4 \
  -vf "crop=ih*9/16:ih,scale=720:1280,zoompan=z='1+0.001*t'" \
  -c:v h264_nvenc -preset p7 output.mp4
```

### Stage 6: Viral Typography Subtitles

Render TikTok-style word-by-word captions using Pillow:

```python
from PIL import Image, ImageDraw, ImageFont

# For each word in the clip:
# 1. Create transparent RGBA frame (720x1280)
# 2. Render subtitle text at bottom 1/3
# 3. Highlight current word (yellow/white) vs dimmed rest
# 4. Apply stroke + drop shadow for readability
# 5. Save as PNG sequence for ffmpeg overlay
```

**Typography rules:**
- **Font size**: 48-54px for body text
- **Current word**: Bright color (yellow #FFD700, white) with bold weight
- **Rest of text**: Dimmed (semi-transparent gray/white)
- **Stroke**: 2-3px black outline
- **Shadow**: 4px drop shadow for depth
- **Position**: Bottom 1/3 of frame, horizontally centered
- **Max width**: 80% of frame width (wrap if longer)
- **Background**: Optional gradient bar behind text for readability

**For Arabic text:**
- Use Cairo font (supports Arabic glyphs well)
- Right-to-left rendering
- Font size may need adjustment (Arabic script is longer per word)
- Same color/weight rules apply

**ffmpeg overlay:**
```bash
# Overlay subtitle PNG sequence onto cropped video
ffmpeg -i cropped_video.mp4 \
  -framerate 30 -i subtitle_%05d.png \
  -filter_complex "[0:v][1:v]overlay_cuda=0:H-h" \
  -c:v h264_nvenc -preset p7 output.mp4
```

### Stage 7: Final Composition

```bash
# Full pipeline command (GPU-accelerated)
ffmpeg -i cropped_video.mp4 \
  -framerate 30 -i subtitle_%05d.png \
  -filter_complex "
    [0:v]scale_cuda=720:1280[scaled];
    [scaled][1:v]overlay_cuda=0:0[out]
  " \
  -map "[out]" \
  -c:v h264_nvenc -preset p7 -rc vbr -cq 23 -b:v 8M \
  -map 0:a -c:a aac -b:a 128k \
  -movflags +faststart \
  final_short.mp4
```

**NVENC encoding presets:**
| Preset | Quality | Speed | When to use |
|--------|---------|-------|-------------|
| `p1` | Lowest | Fastest | Draft/preview |
| `p4` | Good | Balanced | Default |
| `p7` | Best | Slowest | Final export |

**Audio:** Always AAC at 128kbps minimum. Keep original audio track, optionally duck background music.

---

## Reference Files

- `references/transcript-timestamps-format.md` — Full transcript JSON schema and word-level timestamp extraction patterns
- `references/ffmpeg-cuda-recipes.md` — CUDA-accelerated ffmpeg commands for scaling, overlaying, cropping, and encoding
- `references/lmstudio-api-integration.md` — LM Studio setup, API endpoint usage, and prompt engineering for engagement analysis
- `references/typography-rendering.md` — Pillow-based word-by-word subtitle rendering with viral styling

## Pitfalls

- **Python site-packages mismatch**: faster-whisper/CTranslate2 may be in `~/.local/lib/python3.12/site-packages` but the Python in use may only see its venv. Set `PYTHONPATH=~/.local/lib/python3.12/site-packages` or insert the path in code.
- **PyTorch CPU-only**: The default torch install is CPU-only. For this clipper, PyTorch is optional — faster-whisper uses CTranslate2 (not PyTorch) for GPU, and ffmpeg CUDA filters handle video. Only install torch+CUDA if you need it for some other model.
- **LM Studio not serving**: The LM Studio app needs to be running WITH the API server enabled (Server tab → Enable API Server). The API doesn't start automatically with the app.
- **VRAM contention**: faster-whisper + LM Studio may compete for VRAM. Transcribe first (whisper uses ~2-4GB), save results, stop whisper process, then run engagement analysis via LM Studio.
- **Word timestamps granularity**: faster-whisper word timestamps can drift. Always align them against audio duration before slicing.
- **Auto-reframe fallback**: Not every video has a clear subject to track. Always implement a center-crop+KenBurns fallback so the pipeline doesn't crash on interview clips vs gameplay vs vlogs.
- **NVENC quality vs size**: `-cq 23` is a good default. Lower values (18-21) increase quality and file size. For shorts (under 60s), file size matters less — go with quality.
- **Facebook video URLs**: yt-dlp may need login cookies for Facebook. For public videos, `--cookies-from-browser` usually works on Windows host.

## Quick Start

```bash
# 1. Clone/create project structure
mkdir -p ~/nexclip/{stages,assets/fonts,output/shorts}

# 2. Verify GPU stack
export LD_LIBRARY_PATH=/usr/lib/wsl/lib:$LD_LIBRARY_PATH
/usr/lib/wsl/lib/nvidia-smi

# 3. Install deps
pip install opencv-python scenedetect

# 4. Start LM Studio API server
# Open LM Studio → Load Qwen 3.5 9B → Server tab → Enable API → Port 1234

# 5. Download a test video
yt-dlp -f "bestvideo[height<=1080]+bestaudio" -o "input.mp4" "VIDEO_URL"

# 6. Run the pipeline
python nexclip.py "input.mp4" --count 3 --style viral
```
