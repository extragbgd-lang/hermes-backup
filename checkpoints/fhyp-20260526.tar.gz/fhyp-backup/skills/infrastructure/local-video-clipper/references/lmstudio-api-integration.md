# LM Studio API Integration for Engagement Analysis

## Setup

1. Open LM Studio desktop app
2. Load the model (e.g., Qwen 3.5 9B, Llama 3, DeepSeek)
3. Go to **Server** tab
4. Toggle **Enable API Server**
5. Port: `1234` (default)
6. Verify: `curl http://localhost:1234/v1/models`

## API Endpoint

```
POST http://localhost:1234/v1/chat/completions
Content-Type: application/json
```

## Engagement Analysis Prompt Template

```python
import requests
import json

LM_API = "http://localhost:1234/v1/chat/completions"
MODEL = "qwen-3.5-9b"  # Match loaded model name

def find_engaging_moments(transcript_text, scene_boundaries, min_clips=3, max_clips=5):
    """Send transcript to local LLM and get engaging moments with timestamps."""

    prompt = f"""You are a viral shorts analyst. Your job is to find the MOST engaging moments in a video.

The transcript below has word-level timestamps. Scene boundaries are also provided.

For each moment you identify, return:
1. START_TIME and END_TIME in seconds (must match timestamps in transcript)
2. WHY it would go viral — choose from: high_energy, funny, surprising, controversial, emotional, strong_hook, climax, hot_take
3. Confidence score (0-1)
4. Suggested clip length in seconds (15-60)

RULES:
- Return exactly {min_clips}-{max_clips} moments
- Prioritize variety (don't pick 3 funny moments, spread across categories)
- Clips should be self-contained (make sense on their own)
- Don't cross scene boundaries within a clip
- Longer isn't better — 20-45 seconds is ideal for shorts

TRANSCRIPT:
{transcript_text}

SCENE BOUNDARIES (seconds):
{scene_boundaries}

Return ONLY a valid JSON array, no other text:
[
  {{
    "start_time": 0.0,
    "end_time": 0.0,
    "reason": "why it goes viral",
    "category": "high_energy",
    "confidence": 0.9,
    "suggested_duration": 30
  }}
]"""

    response = requests.post(LM_API, json={
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.3,
        "max_tokens": 2000,
        "response_format": {"type": "json_object"}  # if supported
    })

    if response.status_code == 200:
        content = response.json()["choices"][0]["message"]["content"]
        return json.loads(content)
    else:
        raise Exception(f"LM Studio API error: {response.status_code} {response.text}")
```

## Prompt Engineering Tips

| Parameter | Value | Why |
|-----------|-------|-----|
| `temperature` | 0.3 | Low for structured JSON output |
| `max_tokens` | 2000-4000 | Enough for transcript analysis + JSON |
| `response_format` | `json_object` | If model supports structured output |
| Model | Qwen 3.5 9B | Good balance of quality/speed for 6GB VRAM |

## VRAM Optimization

LM Studio + faster-whisper both use GPU. Avoid contention:

1. **Transcribe first** → whisper uses 2-4GB VRAM
2. **Unload whisper** → release model from memory
3. **Analyze with LLM** → LM Studio uses remaining VRAM

Model quantization levels for 6GB VRAM:
- Qwen 3.5 9B → Q4_K_M (4-bit) → ~5.5GB VRAM
- Llama 3 8B → Q4_K_M → ~5GB VRAM  
- DeepSeek R1 7B → Q4_K_M → ~4.5GB VRAM

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `Connection refused` | LM Studio API server not enabled or wrong port |
| `Model not loaded` | Load the model in LM Studio first, check name in `/v1/models` |
| `Out of memory` | Use a smaller model or higher quantization (Q4 → Q3) |
| `Slow response` | Lower `max_tokens`, use a faster model |
| `JSON parse error` | LLM didn't return clean JSON — set `temperature` lower, add stronger formatting constraints |
