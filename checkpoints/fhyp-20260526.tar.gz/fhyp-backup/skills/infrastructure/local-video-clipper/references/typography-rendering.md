# Viral Typography Rendering with Pillow

TikTok-style word-by-word subtitle rendering for vertical shorts (720×1280).

## Core Concept

Each word of the spoken dialogue is rendered as a separate frame:
- **Current word**: Bright, bold, highlighted (yellow #FFD700 or white)
- **Past words**: Dimmed, semi-transparent gray
- **Future words**: Not yet shown, or dimmed

## Frame Structure (720×1280)

```
┌──────────────────────────────────┐
│                                  │
│       VIDEO CONTENT AREA         │
│        (top ~70% of frame)       │
│                                  │
│                                  │
├──────────────────────────────────┤
│  ┌────────────────────────────┐  │
│  │   SUBTITLE BACKGROUND BAR  │  │  ← Semi-transparent black gradient
│  │                            │  │
│  │  past past PAST CURRENT    │  │  ← Word-by-word highlighting
│  │  future future future      │  │
│  └────────────────────────────┘  │
│     (bottom ~30% of frame)      │
└──────────────────────────────────┘
```

## Pillow Implementation

```python
from PIL import Image, ImageDraw, ImageFont
import numpy as np

class ViralTypography:
    """Generates word-by-word subtitle frames."""

    def __init__(self, width=720, height=1280, font_path="Cairo-Bold.ttf"):
        self.width = width
        self.height = height
        self.font_path = font_path
        self.font_large = ImageFont.truetype(font_path, 52)
        self.font_medium = ImageFont.truetype(font_path, 44)
        self.bg_bar_height = 180  # subtitle area height
        self.bg_bar_y = height - self.bg_bar_height - 60  # 60px padding from bottom

    def render_frame(self, words_before, current_word, words_after, frame_index):
        """Render a single subtitle frame."""
        img = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 1. Draw semi-transparent background bar
        bar = Image.new("RGBA", (self.width - 80, self.bg_bar_height), (0, 0, 0, 180))
        img.paste(bar, (40, self.bg_bar_y), bar)

        # 2. Build the subtitle line
        all_words = words_before + [current_word] + words_after
        x_pos = 60  # left padding
        y_pos = self.bg_bar_y + 30

        for i, word in enumerate(all_words):
            is_current = (i == len(words_before))

            if is_current:
                fill = (255, 215, 0, 255)  # #FFD700 yellow
                font = self.font_large
            elif i < len(words_before):
                fill = (255, 255, 255, 120)  # dimmed past
                font = self.font_medium
            else:
                fill = (255, 255, 255, 60)   # very dim future
                font = self.font_medium

            self._draw_with_stroke(draw, word, x_pos, y_pos, font, fill)
            x_pos += draw.textlength(word + " ", font=font)

        img.save(f"subtitles_{frame_index:05d}.png")

    def _draw_with_stroke(self, draw, text, x, y, font, fill):
        """Draw text with 3px black stroke outline."""
        stroke_color = (0, 0, 0, 255)
        sw = 3
        for dx, dy in [(-sw,-sw),(-sw,0),(-sw,sw),(0,-sw),
                       (0,sw),(sw,-sw),(sw,0),(sw,sw)]:
            draw.text((x+dx, y+dy), text, font=font, fill=stroke_color)
        draw.text((x, y), text, font=font, fill=fill)

    def render_clip(self, words_with_timestamps, fps=30):
        """Render all frames for a clip."""
        total_duration = max(w["end"] for w in words_with_timestamps)
        total_frames = int(total_duration * fps)

        for frame_idx in range(total_frames):
            current_time = frame_idx / fps
            active_idx = -1
            for i, w in enumerate(words_with_timestamps):
                if w["start"] <= current_time <= w["end"]:
                    active_idx = i
                    break

            if active_idx >= 0:
                words_before = [w["word"] for w in words_with_timestamps[:active_idx]]
                current_word = words_with_timestamps[active_idx]["word"]
                words_after = [w["word"] for w in words_with_timestamps[active_idx+1:]]
            else:
                words_before = []
                current_word = ""
                words_after = [w["word"] for w in words_with_timestamps]

            self.render_frame(words_before, current_word, words_after, frame_idx)
```

## Styling Tips

| Element | Style | Why |
|---------|-------|-----|
| Current word | Yellow (#FFD700) + bold | Highest contrast, draws eye |
| Past words | White at 50% opacity | Faded but readable |
| Future words | White at 25% opacity | Minimal distraction |
| Background bar | Black at 70% opacity | Readability on any video |
| Stroke | 3px black | Critical for bright backgrounds |
| Font | Cairo Bold (Arabic) / Inter Bold (English) | Clean, modern |
| Size | 48-54px body, 56-64px highlight | Mobile-readable |
| Position | Bottom 1/3, centered | Doesn't cover face |

## Advanced Effects

1. **Keyword color pops** — highlight nouns/verbs in orange (#FF6B00)
2. **Emoji reactions** — add 🔥 💀 😂 near highlighted words
3. **Pulse animation** — scale current word 1.1x briefly
4. **Speaker labels** — "Person A:" prefix when switching speakers

## Arabic-Specific

- Use **Cairo** font family — excellent Arabic glyph support
- RTL handled by Pillow + Cairo automatically
- Arabic words are visually longer → may need smaller font (42-48px)
- Same highlighting rules apply for bilingual content
