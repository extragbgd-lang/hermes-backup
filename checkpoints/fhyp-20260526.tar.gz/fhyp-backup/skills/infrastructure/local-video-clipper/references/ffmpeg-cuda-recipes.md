# ffmpeg CUDA/NVENC Recipes for Video Clipper

All commands use GPU acceleration via CUDA filters and NVENC encoder.

## Hardware Context
- **GPU**: RTX 3050 (6GB VRAM)
- **CUDA**: 13.2 driver
- **NVENC**: H.264 + HEVC + AV1 encoders
- **Filters**: scale_cuda, overlay_cuda

## 1. Center-Crop to 9:16 with Ken Burns Zoom

```bash
ffmpeg -i input.mp4 \
  -vf "crop=ih*9/16:ih,scale=720:1280,zoompan=z='1+0.001*t'" \
  -c:v h264_nvenc -preset p7 -cq 23 \
  output.mp4
```

**When to use:** Fallback when no subject detected for tracking.
**zoompan formula:** `1+0.001*t` = very slow zoom. Increase multiplier for faster.

## 2. GPU-Accelerated Scale + Overlay

```bash
ffmpeg -i video.mp4 \
  -framerate 30 -i subtitles_%05d.png \
  -filter_complex "
    [0:v]scale_cuda=720:1280[scaled];
    [scaled][1:v]overlay_cuda=0:H-h[out]
  " \
  -map "[out]" -c:v h264_nvenc -preset p7 \
  -map 0:a -c:a aac -b:a 128k \
  output.mp4
```

**Note:** `overlay_cuda` requires both inputs to be on GPU. If subtitle PNGs are CPU-side, use regular `overlay` filter instead (CPU, but lightweight).

## 3. Full Compose Command (Typical Shorts Pipeline)

```bash
ffmpeg -y \
  -i cropped_video.mp4 \
  -framerate 30 -i subtitle_%05d.png \
  -i intro_bumper.mp4 \
  -filter_complex "
    [0:v]scale_cuda=720:1280[main];
    [main][1:v]overlay_cuda=0:0[with_subtitles];
    [2:v]scale_cuda=720:1280[bumper];
    [bumper][with_subtitles]concat=n=2:v=1:a=0[final]
  " \
  -map "[final]" \
  -c:v h264_nvenc -preset p7 -rc vbr -cq 23 -b:v 8M -maxrate 12M \
  -map 0:a -c:a aac -b:a 128k \
  -movflags +faststart \
  final_short.mp4
```

## 4. Scene Detection via ffmpeg

```bash
# Quick scene detection
ffmpeg -i input.mp4 -vf "select='gt(scene,0.3)',showinfo" \
  -vsync vfr -f null - 2>&1 | grep pts_time | awk '{print $NF}'

# Thresholds:
# 0.3 = hard cuts only (gaming, vlogs)
# 0.1 = sensitive (transitions, slow content)
# 0.5 = very selective
```

## 5. Audio Ducking (Background Music)

```bash
# Lower music volume during speech
ffmpeg -i voice_track.wav -i music_track.mp3 \
  -filter_complex "
    [0:a]volume=1.0[voice];
    [1:a]volume=0.15[music];
    [voice][music]amix=inputs=2:duration=first[out]
  " \
  -map [out] output_audio.wav
```

## 6. NVENC Encoding Presets

| Preset | Quality | Speed | Bitrate | Use Case |
|--------|---------|-------|---------|----------|
| `p1` | Low | Fast | Lower | Draft/preview |
| `p4` | Good | Balanced | Medium | Default |
| `p7` | Best | Slow | Higher | Final export |

**Rate control modes:**
- `-rc vbr -cq 23 -b:v 8M` → Variable bitrate, quality-target (recommended)
- `-rc cbr -b:v 6M` → Constant bitrate (live streaming)
- `-rc constqp -qp 23` → Constant quantization (best quality)

## 7. Speed Up / Slow Down

```bash
# Speed up 2x (pitch-corrected)
ffmpeg -i input.mp4 -vf "setpts=0.5*PTS" -af "atempo=2.0" \
  -c:v h264_nvenc output.mp4

# Slow down 0.5x
ffmpeg -i input.mp4 -vf "setpts=2.0*PTS" -af "atempo=0.5" \
  -c:v h264_nvenc output.mp4
```

## 8. Text Overlay (Simple, for testing)

```bash
ffmpeg -i input.mp4 \
  -vf "drawtext=text='Viral Moment':fontfile=/path/to/font.ttf:fontsize=48:fontcolor=yellow:x=(w-text_w)/2:y=h-th-100:shadowcolor=black:shadowx=2:shadowy=2" \
  -c:v h264_nvenc output.mp4
```

**For production typography**, use Pillow-generated PNG sequences instead — `drawtext` is CPU-only and limited for word-by-word animation.

## Verification

```bash
# Check file is valid vertical short
ffprobe -v error -show_entries stream=codec_name,width,height,codec_type \
  -of default=noprint_wrappers=1 final_short.mp4

# Expected:
# codec_name=h264 (or hevc)
# width=720, height=1280
# codec_type=video
# codec_type=audio
```
