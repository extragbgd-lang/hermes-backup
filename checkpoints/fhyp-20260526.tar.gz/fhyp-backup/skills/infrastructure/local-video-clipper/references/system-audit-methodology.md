# System Audit Methodology

Steps to audit a WSL/GPU system before building a local video clipper.

## 1. GPU Detection

```bash
# WSL CUDA library check
ls /usr/lib/wsl/lib/libcuda.so.1
# → exists on WSL with NVIDIA GPU passthrough

# Full nvidia-smi (needs LD_LIBRARY_PATH on WSL)
export LD_LIBRARY_PATH=/usr/lib/wsl/lib:$LD_LIBRARY_PATH
/usr/lib/wsl/lib/nvidia-smi
# Reports: GPU model, VRAM, driver version, CUDA version
```

## 2. ffmpeg CUDA Capabilities

```bash
# Hardware acceleration methods
ffmpeg -hwaccels
# Should show: cuda vaapi dxva2 qsv d3d11va

# Hardware encoders
ffmpeg -hide_banner -encoders | grep nvenc
# Expect: av1_nvenc, h264_nvenc, hevc_nvenc

# CUDA filters
ffmpeg -hide_banner -filters | grep -E "scale_cuda|overlay_cuda|crop_cuda"
# scale_cuda = GPU resize, overlay_cuda = GPU overlay compositing
```

## 3. CTranslate2 CUDA Detection (whisper backend)

```python
import sys
# Add user site-packages if needed
sys.path.insert(0, '/home/ammar/.local/lib/python3.12/site-packages')

import ctranslate2
print("CUDA devices:", ctranslate2.get_cuda_device_count())
print("Supported GPU compute types:", ctranslate2.get_supported_compute_types('cuda'))
# RTX 3050 supports: int8, bfloat16, int8_float16, float16, float32, int8_float32, int8_bfloat16
```

## 4. Python Environment Check

```bash
# The Hermes Agent venv Python may not have user packages
which python3
pip3 list | grep -iE "opencv|torch|whisper|moviepy|scenedetect|pillow|numpy|yt-dlp"

# Check for environment mismatch:
# - faster-whisper often in ~/.local/lib/python3.12/site-packages
# - But Hermes venv is at ~/.local/share/pipx/venvs/hermes-agent/
# - These are separate! User packages are not in the venv by default
# Fix: PYTHONPATH=~/.local/lib/python3.12/site-packages
```

## 5. LM Studio Status

```bash
# Check if running
pgrep -fl lmstudio

# Check API port
curl -s http://localhost:1234/v1/models
# Expected: JSON with loaded model info (if API server enabled)

# Note: LM Studio app can be running without the API server
# Need to manually enable in: Server tab → Enable API Server
```

## Reference Hardware

**Ammar's PC (Lenovo LOQ 83GS0095AX):**
- i5-12450HX, 24GB RAM
- NVIDIA GeForce RTX 3050 (6GB VRAM, laptop)
- CUDA 13.2 driver
- WSL2 with NVIDIA passthrough
- Windows 11 host
