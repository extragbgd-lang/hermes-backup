---
name: api-integrations
description: Set up and manage third-party API integrations for content automation — Google (Drive/Sheets), Notion, Instagram/Meta Graph API, TikTok Content Posting API. Covers OAuth flows, developer portal registration, token management, and the integration hub CLI.
trigger_conditions:
  - User asks to connect a third-party API or platform
  - User wants to set up Google Drive, Sheets, or other Google API services
  - User wants to integrate Notion API (create pages, query databases)
  - User wants to set up Instagram or Meta Graph API for content posting
  - User wants to set up TikTok Content Posting API
  - User says 'set up integrations', 'connect APIs', 'setup an API'
  - User gives you a new automation account to use for API access
  - User asks to create or modify the integrations hub script
related_skills:
  - infrastructure/hermes-agent (for gateway notification platform configuration, not API integrations per se)
---

# API Integrations — Setup & Management

Central integration hub: `~/.hermes/integrations.py`
```bash
python3 ~/.hermes/integrations.py status   # Check all connections
python3 ~/.hermes/integrations.py drive list  # List Drive files
```

## General Pattern for API Setup

**CRITICAL — CHECK ZAPIER FIRST (26-May-2026):**
Before fighting with MCP OAuth (DCR, waitlists, 40s timeouts), check if the service is already available through a simpler integration. The user explicitly corrected this after I wasted 40+ minutes fighting Composio MCP for Canva when Zapier already had it.

1. **Zapier MCP (built-in Hermes):** 8,000+ apps accessed via top-level `zapier:` config. Already live. See `references/zapier-shortcut.md`. **Always check this first.**
2. **Already-configured MCPs:** Check `mcp_servers:` in config.yaml
3. **Direct REST API:** Some services (Notion, GitHub) work with a simple API key
4. **OAuth MCP (Composio, etc.):** Only if none of the above work — and even then, verify the app isn't already in Zapier's catalog first.
   - **Already-configured MCPs:** Check `mcp_servers:` in config.yaml or `hermes mcp list` before setting up a new one.
   - **Direct REST API:** Some services (Notion, GitHub) work fine with a simple API key — no MCP or OAuth needed.
   - ⏱️ **User frustration signal (26-May-2026):** After 40+ minutes fighting Composio MCP OAuth for Canva, the user said "You actually can use canva from zapier." If a direct MCP OAuth path is taking more than a few minutes, stop and check Zapier first — it's already integrated.
2. **Consult official docs** — Follow the documented setup steps before trying alternatives. MCP 401 error messages can be misleading (Composio: says "provide Authorization: Bearer *** x-consumer-api-key header" but neither works — dead end).
3. **Create a dedicated automation account** (e.g., hermossybatooty@gmail.com) — keeps personal accounts separate
4. **Register developer accounts** on each platform's developer portal
5. **Create an app/project** per platform to get API credentials
6. **Authenticate** using OAuth (OOB flow recommended for WSL — see references/google-oauth-wsl.md)
7. **Save tokens** to `~/.hermes/` and update `integrations_config.json`
8. **Test** with `integrations.py status`

## Google APIs (Drive, Sheets, YouTube)

**Prerequisites:**
- Google Cloud project with OAuth 2.0 Desktop credentials (`client_id` + `client_secret`)
- Credentials file at `~/.hermes/youtube_credentials.json`

**OAuth Flow (WSL-compatible):**
- Use **OOB redirect URI** (`urn:ietf:wg:oauth:2.0:oob`) — localhost redirect doesn't work in WSL
- Step 1: Generate URL → user visits in their browser → authorizes → gets code
- Step 2: Exchange code for token and save to `~/.hermes/google_token.json`
- Token includes `refresh_token` for automatic renewal

**Alternative: Chrome Remote Debugging (collaborative browser control)**
If the user wants to share their local Chrome window so you can control it together:

**Prerequisites:**
- User on Windows with Chrome installed
- You in WSL on the same machine

**Setup:**
1. **Add Windows Firewall rule** (one-time):
   ```cmd
   netsh advfirewall firewall add rule name="Chrome Debug" dir=in action=allow protocol=TCP localport=9222
   ```

2. User closes all Chrome windows, then runs from cmd:
   ```cmd
   "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --remote-debugging-address=0.0.0.0 --profile-directory="HermesAgent"
   ```
   - `--remote-debugging-address=0.0.0.0` — lets WSL reach it (default binds to 127.0.0.1 only)
   - Chrome auto-creates the profile as a fresh isolated profile
   - The `--profile-directory` flag keeps sessions separate from the user's personal profile

3. **From WSL**, find the Windows host IP:
   ```bash
   ip route show default | awk '{print $3}'
   # Typically 172.x.x.1
   ```

4. Verify connection:
   ```bash
   curl -s http://<windows-ip>:9222/json/version
   # Should return JSON with Chrome version + webSocketDebuggerUrl
   ```

5. Then use the Hermes browser tool (browser_navigate etc.) — it automatically discovers the remote debugging endpoint.

**Troubleshooting WSL2 connectivity:**
- If curl to `<windows-ip>:9222` times out even with the firewall rule, Chrome may still be refusing non-localhost connections. Try `--remote-debugging-address=0.0.0.0` (already included above).
- If WSL2 still can't reach it, set up Windows port forwarding as a bridge:
  ```cmd
  netsh interface portproxy add v4tov4 listenport=9222 connectport=9222 connectaddress=127.0.0.1
  ```
  Then from WSL, connect via `localhost:9222` or `<wsl-gateway-ip>:9222`.
- On some WSL2 configurations, even this doesn't work due to hypervisor networking isolation. Fall back to: have the user open the auth URL in their own browser and paste back the verification code (OOB flow).

**Use cases:**
- OAuth flows that block headless login (Google, Meta)
- CAPTCHAs
- Interactive form fills where OOB codes are inconvenient
- Visual collaboration — you can both see the same browser window

**Files:**
- `~/.hermes/google_drive_api.py` — Drive + Sheets operations
- `~/.hermes/google_auth_url.py` — step 1 (generate URL)
- `~/.hermes/google_auth_step2.py` — step 2 (exchange code)
- Credentials are shared across YouTube, Drive, and Sheets (same Google Cloud project)

**Common operations:**
```python
python3 google_drive_api.py test-auth        # Verify connection
python3 google_drive_api.py list-files       # List recent Drive files
python3 google_drive_api.py create-sheet     # Create video tracker
```

## Notion

**Prerequisites:**
- Notion account (create at notion.so with automation email)
- Integration token from notion.so/my-integrations (starts with `ntn_`)

**Setup:**
1. Sign up for Notion with the automation account
2. Go to https://www.notion.so/my-integrations
3. Create a new integration → copy the "Internal Integration Secret" (starts with `ntn_`)
4. Save with: `python3 integrations.py notion token ntn_...`

**Important:** After creating the integration, you must share (invite) the integration to specific Notion pages/databases before the API can access them. The integration cannot read pages it hasn't been explicitly shared with.

**Token sourcing — check `mcp_servers` config first:** Before creating a new integration, check `~/.hermes/config.yaml` for the `mcp_servers` section. If a `better-notion` (or similar) MCP is configured, its `NOTION_TOKEN` env var is a working token you can use directly for REST API calls. No need to create a new integration — the token is already connected to the right workspace. Test it with `curl -s "https://api.notion.com/v1/users/me"`. The `better-notion` MCP may not expose tools in your current toolset, but the token works fine for direct curl calls.

**CRITICAL — Verify before using:** A token in a token file (`notion_token.json`) may belong to a different Notion account/workspace than the one the user expects you to use. If you find an existing token, do NOT assume it's the right one. Check with the user first, or test by querying a known page. Creating pages with the wrong token results in content the user cannot access and has to clean up.

**Direct API works fine (not just Zapier):** The Notion REST API with a direct `ntn_` token works reliably for creating pages under a known parent page ID. Zapier is NOT the only option. For batch page creation (e.g., creating a hub + N sub-pages simultaneously), the direct API is faster and more deterministic because you know the parent ID and don't need Zapier's `page_by_title` resolution. Use curl against `https://api.notion.com/v1/pages` with `Notion-Version: 2022-06-28`. See `references/notion-content-creation.md` for block types and `references/notion-direct-api.md` for the batch page-creation pattern with hub + child pages.

**Zapier Notion workflow:**
- `execute_zapier_write_action` with `action="create_page"` creates pages
- **Without `parent_page`**: pages are created as standalone top-level pages (accessible, no nesting)
- **With `parent_page`**: pages are nested under the specified parent, BUT the parent page must be explicitly shared with the Zapier integration in Notion (Share button → invite "Zapier"). If not shared, Zapier returns `"Could not find page with ID: X"`.
- `parent_page` is auto-resolved as "llm-guess" by Zapier — it may pick the wrong parent if multiple pages match. Always verify the resolved parent in the execution response.
- `page_by_title` action: searches pages the integration has access to. Returns empty `results:[]` if the integration hasn't been shared with any pages.
- To move a page under Main Brain after creation: not possible via API. Archive and recreate under the shared parent, or have the user drag it in Notion manually.

### Content Creation via API

You can create rich sub-pages under a shared parent page using the Notion API directly. Supported block types include: headings, paragraphs, bulleted/numbered lists, toggles, callouts, quotes, dividers, and code blocks.

**Key workflow when the user renames/restructures:**
1. Update parent page title with `PATCH /v1/pages/{id}` (supports `properties.title` + `icon`)
2. The API does NOT support changing a page's parent. To regroup: create a new container page, recreate sub-pages under it, archive the old ones
3. Archive via `PATCH /v1/pages/{id}` with `{"archived": true}` — pages go to Notion Trash, can be restored

See `references/notion-content-creation.md` for:
- Full block type reference with correct JSON structures (MUST include both `"type"` and the content key)
- Reusable helper function patterns (h1, h2, bullet, togg, callout, quote, divider)
- Page creation with initial children blocks
- Updating page properties (title, icon, archived)
- Restructuring workflow (archive + recreate since parent can't be changed)
- Pitfalls (100-block limit, table creation, nesting depth, rate limits)

## Instagram (Meta Graph API)

**Prerequisites:**
- Instagram Professional account (Creator or Business) — personal accounts unsupported
- Facebook Page linked to the Instagram account (via Accounts Center)
- Facebook Developer account (developers.facebook.com)

**Key insight — Skip App Review:**
You can post to your own Instagram account **without App Review** by adding the account as a **Tester** in the app's Instagram Tester role. This is the recommended path for single-account automation.

**Setup steps:**
1. Convert Instagram account to Creator/Business (Settings → Account → Switch to Professional)
2. Create a Facebook Page (gaming category) — minimal page, just needed as a container
3. Link IG account to Facebook Page in Accounts Center (Meta's Shared: Linking accounts)
4. Register on developers.facebook.com with the automation email
5. Create App → Add "Instagram Graph API" product → Add IG account as Tester
6. Generate a **Page Access Token** from Graph API Explorer
7. The token grants access to `{ig-user-id}` for content publishing

**Token lifetime:** 60 days (long-lived). Refresh before expiry.
**Scopes needed:** `pages_show_list`, `instagram_basic`, `instagram_content_publish`, `pages_read_engagement`

**API Version:** v21.0 (quarterly migration)
**Hub endpoint:** `python3 integrations.py insta config <fb_page_id> <ig_user_id> <token>`

## Canva

### Zapier MCP (RECOMMENDED — Verified 26-May-2026)
Canva is available through Hermes' built-in Zapier MCP integration with **12 actions** (7 write, 5 search, 0 read). No separate auth, no waitlist, no OAuth flow needed — if Zapier is connected, Canva just works.

**App ID:** `App205891CLIAPI`  
**Auth:** Already enabled in the Zapier MCP connection — `enable_zapier_action("Canva")` was run and stored server-side.  
**Tools:** See `content-creation/canva-zapier` skill for full reference, parameters, and a verification script.

**Key actions available:**
- `create_design` — Create designs (preset or custom dimensions)
- `create_design_export_job` — Export as PNG/JPG/PDF/MP4/GIF/PPTX
- `find_design` — Search existing designs
- `get_design_export_job` — Check export status
- `create_design_autofill_job` — Autofill brand templates (Enterprise)

**End-to-end flow:**
```python
execute_zapier_write_action(app="Canva", action="create_design", params={...})
  → returns design_id + edit URL
execute_zapier_write_action(app="Canva", action="create_design_export_job", params={...})
  → returns job_id
execute_zapier_read_action(app="Canva", action="get_design_export_job", params={...})
  → returns download URL (masked signature still works via urllib)
```

### Direct Canva MCP (waitlist-gated)
Canva provides an official MCP server at `https://mcp.canva.com/mcp` with OAuth (DCR) authentication. Exposes design generation, editing, search, export, and asset management as MCP tools for AI assistants. **Requires Canva waitlist approval for custom integrations — Zapier path is preferred.**

### Via Composio Connect (dead end — do not attempt)
Composio's MCP endpoint at `https://connect.composio.dev/mcp` requires OAuth (DCR). DO NOT try direct header auth — neither `ak_` (API key) nor `ck_` (consumer key) work as `x-consumer-api-key` headers, despite the 401 error message claiming they should. The Composio OAuth flow has three blockers:
1. **DCR registration** fails with `redirect_uris should not be empty` (Zapier avoids this because it uses the built-in `zapier:` config, not mcp_servers)
2. **40s timeout** on `hermes mcp login` — not enough time for user to open URL and authorize
3. **Localhost redirect** — the OAuth callback uses `127.0.0.1:PORT` which times out before the user can complete the flow

Use Zapier instead. Canva is already there.

See `references/canva-mcp.md` for the full verification table (every header combination tested and failed).

## TikTok Content Posting API

**Prerequisites:**
- TikTok Business Account (convert from personal in Settings → Manage Account)
- Developer account on developers.tiktok.com
- Registered App with `video.publish` scope

**Key differences from Instagram:**
- **Video-only** — no photo posting support
- **24-hour token lifetime** — must implement daily refresh flow
- **3-step upload:** Init → Upload chunks → Publish
- Arabic UTF-8 captions supported natively

**Setup steps:**
1. Convert TikTok account to Business
2. Register on developers.tiktok.com
3. Create App → Apply for `video.publish`, `video.upload`, `user.info.basic` scopes
4. Implement OAuth 2.0 to get `access_token` + `refresh_token`
5. Store refresh token securely and call refresh endpoint daily

**API Version:** v2
**Rate limit:** 50 calls/s per app
**Hub endpoint:** `python3 integrations.py tiktok config <access_token> <refresh_token> <open_id>`

## NotebookLM (Browser Automation)

NotebookLM (Google Labs) generates **free cloud-rendered Video Overviews** from video scripts. No API — only browser automation via Browse CLI + Browserbase.

**Setup (done):**
- Notebook: "GameSins - Content Creation Hub" (ID: `3b421487-9ac0-4d06-bea4-957604998c70`)
- Brand guide uploaded as permanent Source 1
- Credentials in `~/.hermes/.env`: `NOTEBOOKLM_EMAIL`, `NOTEBOOKLM_PASSWORD`, `BROWSERBASE_API_KEY`, `BROWSERBASE_PROJECT_ID`
- Direct email login works (no Session Live View needed)

**How it's used:**
- Runs in **parallel** with the b-roll pipeline (hyperframes-broll)
- Spawned via `delegate_task` with toolsets=`["terminal", "browser"]`
- Output goes to `/mnt/d/hyperframe output/notebooklm/`

**Full reference:** `hyperframes-broll` → `references/notebooklm-direct-login.md`

## Integration Hub Architecture

The central `integrations.py` module:
- Uses a JSON config file at `~/.hermes/integrations_config.json`
- Each service has an `enabled` flag and its own credential fields
- `status` command checks all configured services
- Token files stored separately per service under `~/.hermes/`
- All tokens use the same Google Cloud project for Google services

### Adding a new integration

1. Add config schema to `DEFAULT_CONFIG` in the script
2. Create `config_save()` and `config_status()` functions
3. Add a `cmd` handler in the main router
4. Update `status()` to include the new service

## Pitfalls

- **Google blocks headless browser login.** Always use OOB OAuth URL flow and have the user authorize in their own browser. Never try to automate Google sign-in via the browser tool.
- **Notion integrations must be shared with pages.** Creating an integration gives you an API token, but it can't read any pages until you explicitly invite the integration (like inviting a collaborator) to each page/database.
- **Instagram requires a Facebook Page.** Even if you never use the Page, it's a hard requirement in Meta's architecture — the IG user ID is obtained through the Page's access token, not directly.
- **Instagram App Review is avoidable** for single-account use. Use the "Tester" role to skip weeks of review.
- **TikTok tokens expire every 24 hours.** The refresh token must be stored securely and refreshed daily — set up a cron job if auto-posting.
- **Photo posting not possible on TikTok.** The Content Posting API is video-only. For photos, use Instagram instead.
- **Token scope mismatch.** When adding scopes (e.g., adding Drive scope to an existing YouTube token), the user must re-authorize with `prompt=consent` because Google requires re-consent for new scopes.
- **Do NOT store tokens in config.yaml.** Store in separate token files under `~/.hermes/` and reference them from the integration script.
- **Google Cloud APIs must be explicitly enabled per project.** Getting the token is only half the setup. If the API itself (e.g. `drive.googleapis.com`, `sheets.googleapis.com`, `docs.googleapis.com`) hasn't been enabled for the project, calls fail with `HttpError 403: "Google Drive API has not been used in project X"`. The user must visit the API enablement URL (e.g. `https://console.developers.google.com/apis/api/drive.googleapis.com/overview?project=<project-id>`) and click ENABLE. The headless browser can't automate this — the user does it in their own browser.
- **Docs API often disabled by default.** Most Google Cloud projects have `docs.googleapis.com` disabled. If the Docs API call fails with 403, do NOT block on enabling it — use the Drive API HTML-to-Doc import workaround instead (see `references/google-docs-via-drive.md`). Creating a Google Doc with content via Drive API: upload HTML with `mimeType='text/html'` and set target `mimeType='application/vnd.google-apps.document'` in `files.create()`. This works without the Docs API being enabled.
- **OAuth client in "Testing" mode blocks non-testers with 403.** If the Google Cloud OAuth consent screen is in "Testing" state (not "Published"), only accounts added as **Test users** can use it. Everyone else gets `Error 403: access_denied`. Fix: either publish the app (requires verification) or add the automation account as a test user in Cloud Console > APIs & Services > OAuth consent screen > Test users.
- **Sheets API rejects `gridProperties` at sheet creation.** When creating a sheet via `sheets.spreadsheets().create()`, `gridProperties` in the sheet definition is not accepted. Remove it during creation (default grid is applied). Only use `gridProperties` in update requests after the sheet exists.
- **Notion URLs must be bare clickable links on their own line.** The user opens these on mobile and needs to tap directly. Never wrap a Notion URL in descriptive text like `[click here](url)`. Format: `https://www.notion.so/slug-pageid` on its own line, nothing else.
