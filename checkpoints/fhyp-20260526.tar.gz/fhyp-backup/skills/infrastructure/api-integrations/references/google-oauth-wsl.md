# Google OAuth on WSL — OOB Redirect Flow

## Problem

Google's OAuth 2.0 "Desktop" credential type defaults to `http://localhost:8080` for the
redirect URI, which runs a local web server during auth. This **does not work** in WSL
because the host Windows browser can't reach the WSL localhost server reliably, and the
`google_auth_oauthlib` library's `run_local_server()` hangs or times out.

## Solution: OOB (Out-of-Band) Flow

Use `urn:ietf:wg:oauth:2.0:oob` as the redirect URI. The authorization code is displayed
in the browser after the user consents, and they paste it back into the terminal.

## Required: Enable the APIs in Google Cloud Console

Before the OAuth flow will work, the specific Google APIs must be **enabled** for the project.
This is a separate step from getting OAuth credentials.

Enable URLs (project ID in the URL):
```
https://console.developers.google.com/apis/api/drive.googleapis.com/overview?project=<PROJECT_ID>
https://console.developers.google.com/apis/api/sheets.googleapis.com/overview?project=<PROJECT_ID>
https://console.developers.google.com/apis/api/youtube.googleapis.com/overview?project=<PROJECT_ID>
```

The user visits each link, clicks ENABLE. The headless browser **cannot** do this step — Google Cloud Console blocks automated login the same way Google OAuth does.

**Error if not enabled:** `HttpError 403: "Google Drive API has not been used in project X before or it is disabled."`

## Testing Mode — Test User Requirement

If the OAuth consent screen is in **Testing** state (not Published), the OAuth flow will
return `Error 403: access_denied` for any account not added as a test user.

**Fix:** Add the automation account as a test user in:
Google Cloud Console → APIs & Services → OAuth consent screen → Test users → Add Users

## Script Pattern

Step 1 — `google_auth_url.py`:
```python
from google_auth_oauthlib.flow import InstalledAppFlow

flow = InstalledAppFlow.from_client_config(client_config, SCOPES)
flow.redirect_uri = "urn:ietf:wg:oauth:2.0:oob"
auth_url, _ = flow.authorization_url(
    access_type="offline",
    include_granted_scopes="true",
    prompt="consent",        # Force re-consent so we get a refresh_token
)
print(auth_url)
```

Step 2 — `google_auth_step2.py`:
```python
flow.fetch_token(code=user_provided_code)
with open(TOKEN_FILE, "w") as f:
    f.write(flow.credentials.to_json())
```

## Credential Sharing

The same Google Cloud OAuth client ID + secret works across YouTube, Drive, and Sheets.
Instead of creating separate credentials per API:
1. Enable all needed APIs in the same Google Cloud project
2. Request all needed scopes in a single OAuth flow
3. The resulting token works for all enabled APIs

To **add new scopes** to an already-authorized token:
- Include `include_granted_scopes="true"` in the auth URL
- Set `prompt="consent"` to force the consent screen
- The user sees a new consent screen listing both old and new scopes
- Google issues a new token that covers all scopes

## Existing Setup (GameySins)

- Google Cloud project client ID: `512309279577-6mb1m5l7s2anarrgategbimqvm1icb1g.apps.googleusercontent.com`
- Credentials file: `~/.hermes/youtube_credentials.json` (used for all Google APIs)
- YouTube token: `~/.hermes/youtube_token.json` (YouTube scopes only)
- Drive/Sheets token: `~/.hermes/google_token.json` (wider scopes, needs auth)
- Integration hub: `~/.hermes/integrations.py`
