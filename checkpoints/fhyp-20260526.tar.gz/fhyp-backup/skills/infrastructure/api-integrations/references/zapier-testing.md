# Zapier MCP — Testing & Token Update Reference

## Token Update Procedure

When the user provides a new Zapier MCP connection URL:

```bash
# 1. Extract current URL to confirm format
grep "zapier:" -A 2 ~/.hermes/config.yaml

# 2. Replace the URL value (line ~540 in config.yaml)
# Use patch tool with the full line

# 3. Restart the gateway
systemctl --user restart hermes-gateway.service

# 4. Wait 3-4 seconds for restart, then test
sleep 4 && curl -s --max-time 15 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"tools/call","id":1,"params":{"name":"list_enabled_zapier_actions","arguments":{}}}' \
  "$ZAPIER_URL"
```

## SSE Response Format

Zapier MCP uses SSE (Server-Sent Events). Responses look like:
```
event: message
data: {"result":{"content":[{"type":"text","text":"{...JSON...}"}]},"jsonrpc":"2.0","id":1}
```

### Parsing in Python
```python
import json
for line in raw.split('\n'):
    if line.startswith('data: '):
        d = json.loads(line[6:])
        for c in d.get('content', []):
            if isinstance(c, dict) and 'text' in c:
                inner = json.loads(c['text'])
                # inner contains the actual data
```

### Critical Headers
Both are required:
- `Content-Type: application/json`
- `Accept: application/json, text/event-stream`

## Testing Checklist

| Test | Command | Expected |
|------|---------|----------|
| List apps | list_enabled_zapier_actions({}) | 6 apps with action counts |
| List Notion actions | list_enabled_zapier_actions({"app":"Notion"}) | 27 actions listed |
| Create standalone page | create_page without parent | SUCCESS, URL returned |
| Add content | page_content or add_block_to_page | SUCCESS |
| Find page by title | page_by_title({"title":"..."}) | Results array (may be empty if no pages shared) |

## Connected Apps (as of 26-May-2026)

- Google Sheets (29 actions)
- Gmail (12 actions)
- Google Docs (16 actions)
- **Notion (27 actions)** — primary use
- YouTube (7 actions)
- Google Drive (22 actions)