# Instagram (Meta Graph API) — Setup Guide

## Architecture Overview

```
┌──────────────────┐       ┌──────────────────┐       ┌─────────────────┐
│  Facebook App    │──────▶│  Facebook Page   │──────▶│ Instagram Pro   │
│  (dev portal)    │       │  (container)     │       │  (Creator/Biz)  │
└──────────────────┘       └──────────────────┘       └─────────────────┘
        │                         │
        │ Page Access Token       │ Linked via Accounts Center
        ▼                         ▼
┌───────────────────────────────────────────────────────┐
│  Page Access Token → {ig-user-id} → POST /media       │
│                                    → POST /media_publish│
└───────────────────────────────────────────────────────┘
```

## Prerequisites

- **Instagram Professional Account** (Creator or Business)
  - Convert: Settings → Account → Switch to Professional → Creator
  - Required because the content publishing API only works with professional accounts
- **Facebook Page** (any category works, gaming recommended for GameySins)
  - Create: facebook.com/pages/create
  - This is a hard requirement in Meta's architecture
- **Facebook Developer Account**
  - Register at developers.facebook.com
  - No business verification needed for single-account use

## Step-by-Step Setup

### 1. Link Instagram to Facebook Page

Go to **Accounts Center** (meta.com/accountcenter) → **Accounts** → **Add accounts**
→ Link the Instagram account to the Facebook Page.
Or: Settings & privacy → Accounts Center → Sharing and cross-posting → Link accounts.

### 2. Create a Facebook App

1. Go to developers.facebook.com → My Apps → Create App
2. Choose **"Business"** as the app type
3. Name it (e.g., "GameySins Automation")
4. Add **"Instagram Graph API"** product from the dashboard

### 3. Add Instagram Tester (skip App Review)

1. In your App Dashboard → **Roles** → **Instagram Testers**
2. Enter your Instagram account's username or ID
3. Accept the invitation on the Instagram side (Profile → Settings → Apps and websites → Tester invites)
4. Now your app can make API calls on your own account **without App Review**

### 4. Generate a Page Access Token

1. Go to **Graph API Explorer** (developers.facebook.com/tools/explorer)
2. Select your App from the dropdown
3. Select **"Get Token"** → **"Page Access Token"**
4. Select the Facebook Page linked to Instagram
5. Copy the token (it starts with `EAA...`)

Required permissions when generating:
- `pages_show_list`
- `pages_read_engagement`
- `instagram_basic`
- `instagram_content_publish`

### 5. Get Your IG User ID

```bash
curl -X GET \
  "https://graph.facebook.com/v21.0/me/accounts?fields=instagram_business_account&access_token=PAGE_TOKEN"
```

The response includes `{instagram_business_account: {id: "IG_USER_ID"}}`. Save this.

### 6. Post Content

**Post an image:**
```python
import requests
BASE = "https://graph.facebook.com/v21.0"

# Step 1: Create media container
resp = requests.post(f"{BASE}/{IG_USER_ID}/media", params={
    "image_url": "https://example.com/image.jpg",
    "caption": "Your caption here with #hashtags",
    "access_token": PAGE_TOKEN,
})
container_id = resp.json()["id"]

# Step 2: Publish
resp = requests.post(f"{BASE}/{IG_USER_ID}/media_publish", params={
    "creation_id": container_id,
    "access_token": PAGE_TOKEN,
})
print(resp.json())
```

**Post a video:**
```python
requests.post(f"{BASE}/{IG_USER_ID}/media", params={
    "media_type": "VIDEO",
    "video_url": "https://example.com/video.mp4",
    "caption": "Video caption",
    "access_token": PAGE_TOKEN,
})
```

## Token Management

- **Short-lived token** (from Graph Explorer): ~1-2 hours
- **Exchange for long-lived token** (60 days):
  ```bash
  GET https://graph.facebook.com/v21.0/oauth/access_token
    ?grant_type=fb_exchange_token
    &client_id=YOUR_APP_ID
    &client_secret=YOUR_APP_SECRET
    &fb_exchange_token=SHORT_LIVED_TOKEN
  ```
- **Extend long-lived token** (before expiry): Use the same exchange endpoint with the long-lived token. Returns a new 60-day token.
- **Token never expires** if you use Page Access Token from a Business Verifed app (not needed for single-account use).
- Store in `~/.hermes/instagram_config.json`

## Save to Hub

```bash
python3 ~/.hermes/integrations.py insta config <FB_PAGE_ID> <IG_USER_ID> <PAGE_ACCESS_TOKEN>
```

## What You Can Do (Without App Review)

| Action | Supported? |
|--------|-----------|
| Post photos to your own account | ✅ |
| Post videos/reels to your own account | ✅ |
| Post carousels to your own account | ✅ |
| Read your own media | ✅ |
| Read your own insights/analytics | ✅ |
| Read/manage comments | ✅ |
| Post to OTHER accounts | ❌ (needs App Review) |
| Tag users/brands | ❌ (needs App Review) |
