# Canva MCP Server — Setup & Integration

## Quick Facts

- **Direct MCP endpoint:** `https://mcp.canva.com/mcp`
- **Composio bridge endpoint:** `https://connect.composio.dev/mcp`
- **Auth:** OAuth 2.1 (DCR) — ONLY `auth: oauth` works
- **Free tier:** Core features on free Canva plan
- **Waitlist gate:** Direct MCP requires waitlist approval
- **Pre-approved tools:** Claude, ChatGPT, Gemini, Cursor, VS Code, Codex
- **Composio bypass:** Pre-integrated, skips waitlist

## Connecting to Hermes — Only `auth: oauth` Works (26-May-2026)

```yaml
mcp_servers:
  composio:
    url: "https://connect.composio.dev/mcp"
    auth: oauth
```

### Option A — Direct Canva MCP (waitlist required)
```yaml
mcp_servers:
  canva:
    url: "https://mcp.canva.com/mcp"
    auth: oauth
```
1. Apply via Canva MCP waitlist form
2. `hermes mcp login canva` — user authorizes immediately (40s timeout)

### Option B — Via Composio Connect (RECOMMENDED)
1. Add composio to config with `auth: oauth`
2. `hermes mcp login composio` → user opens URL within 30s → authorizes
3. dashboard.composio.dev → find Canva → Connect → authorize Canva

## ⚠️ Critical Auth Rules (26-May-2026)

**No header-based auth works.** All tested:

| Key | Headers | Result |
|-----|---------|--------|
| `ak_` API key | Both `Authorization: Bearer` + `x-consumer-api-key` | 401 |
| `ck_` consumer key | `x-consumer-api-key` | `401 Invalid consumer API key` |

The 401 message that says "Missing authentication: provide Authorization: Bearer *** x-consumer-api-key header" is a **red herring**. No combination succeeds. Only `auth: oauth`.

## WSL OAuth: 40s Timeout

**✅ WSL2 localhost forwarding works** — Windows reaches WSL via `127.0.0.1:<port>` directly (verified via PowerShell on 26-May-2026). No netsh needed.

**Problem:** `hermes mcp login` has a hard 40s timeout on the callback listener. Adding `connect_timeout`/`timeout` in config does NOT extend it. User must open URL and authorize within ~30s.

**Working workaround:** Run `hermes mcp login <server>` in background mode (Hermes background process), IMMEDIATELY send the URL to the user, they open and authorize fast. The 40s window starts from when the command runs — so the user needs to act within ~30s after getting the URL.

**What does NOT work:**
- Running in foreground with user waiting to open the URL (the command blocks waiting)
- Direct headers with any key type (all return 401 — see auth table above)
- Netsh port forwarding (not needed — localhost forwarding already works)

## Tools Available

All plans: Design generation, editing, search, export (PNG/JPG/PDF/PPTX/MP4), comments, asset upload
Canva Pro+: Design resizing
Enterprise: Autofill templates, brand kits

## Post-Setup Test

Ask: "Show me my most recently edited Canva design"

## Use Cases for GameSinsTech

- Title cards (navy #0b276c + orange #ff753a)
- Explainer graphics, comparison cards, step visuals
- Thumbnails → export as PNG

## Related Links

- Canva MCP Docs: https://www.canva.dev/docs/mcp/
- Composio for Hermes: https://composio.dev/hermes
- **Zapier shortcut:** See `references/zapier-shortcut.md` — before fighting MCP OAuth, check if Canva is already available through Zapier's built-in integration (8,000+ apps). Confirmed on 26-May-2026.
