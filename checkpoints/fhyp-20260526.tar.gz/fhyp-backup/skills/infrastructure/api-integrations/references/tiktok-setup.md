# TikTok Content Posting API — Setup Guide

## Key Differences from Instagram

| Factor | Instagram | TikTok |
|--------|-----------|--------|
| Photo posting | ✅ Yes | ❌ No (video only) |
| Token lifetime | 60 days | 24 hours (must refresh daily) |
| App Review for self-posting | Skip via Tester role | Required to go public |
| Upload process | 2 steps (create container → publish) | 3 steps (init → upload → publish) |
| Account type needed | Creator/Business | Business (convert from personal) |

## Prerequisites

- **TikTok Business Account**
  - Convert: Settings → Manage Account → Switch to Business Account
  - Required for API access
- **TikTok Developer Account**
  - Register at developers.tiktok.com with the automation email

## Step-by-Step Setup

### 1. Create a TikTok App

1. Go to developers.tiktok.com → My Apps → Create App
2. Fill in app name, description, and use case
3. Add these scopes:
   - `user.info.basic` — get user profile info
   - `video.publish` — upload and post videos
   - `video.upload` — upload video files

### 2. Implement OAuth 2.0

TikTok uses a standard OAuth 2.0 flow:

**Step A — Generate Auth URL:**
```
https://www.tiktok.com/v2/auth/authorize/
  ?client_key=YOUR_CLIENT_KEY
  &scope=user.info.basic,video.publish,video.upload
  &response_type=code
  &redirect_uri=YOUR_REDIRECT_URI
  &state=custom_state_string
```

**Step B — Exchange code for token:**
```bash
POST https://open.tiktokapis.com/v2/oauth/token/
Content-Type: application/x-www-form-urlencoded

client_key=YOUR_CLIENT_KEY
&client_secret=YOUR_CLIENT_SECRET
&code=AUTHORIZATION_CODE
&grant_type=authorization_code
&redirect_uri=YOUR_REDIRECT_URI
```

Response includes:
```json
{
  "access_token": "clt.example...",
  "expires_in": 86400,
  "refresh_token": "rft.example...",
  "refresh_expires_in": 86400,
  "open_id": "USER_OPEN_ID",
  "token_type": "Bearer"
}
```

### 3. Video Upload (3-Step Process)

**Step 1 — Initialize upload:**
```python
import requests

resp = requests.post(
    "https://open.tiktokapis.com/v2/video/init/",
    headers={"Authorization": f"Bearer {access_token}"},
    json={
        "post_info": {
            "title": "Video title and #hashtags",
            "privacy_level": "PUBLIC",
            "disable_duet": False,
            "disable_comment": False,
            "disable_stitch": False,
            "video_cover_timestamp_ms": 1000,
        },
        "source_info": {
            "source": "FILE_UPLOAD",
            "chunk_size": 5242880,  # 5MB chunks
            "total_size": file_size,
        },
    },
)
upload_url = resp.json()["data"]["upload_url"]
publish_id = resp.json()["data"]["publish_id"]
```

**Step 2 — Upload video chunks:**
```python
with open(video_path, "rb") as f:
    for chunk_start in range(0, file_size, chunk_size):
        chunk = f.read(chunk_size)
        resp = requests.put(
            f"{upload_url}?content-range=bytes={chunk_start}-{min(chunk_start+chunk_size, file_size)}/{file_size}",
            data=chunk,
            headers={
                "Content-Type": "video/mp4",
                "Content-Range": f"bytes {chunk_start}-{min(chunk_start+chunk_size, file_size)}/{file_size}",
            },
        )
```

**Step 3 — Publish:**
```python
resp = requests.post(
    f"https://open.tiktokapis.com/v2/video/publish/{publish_id}/",
    headers={"Authorization": f"Bearer {access_token}"},
)
```

### 4. Token Refresh (Required Daily)

```python
resp = requests.post(
    "https://open.tiktokapis.com/v2/oauth/token/",
    headers={"Content-Type": "application/x-www-form-urlencoded"},
    data={
        "client_key": YOUR_CLIENT_KEY,
        "client_secret": YOUR_CLIENT_SECRET,
        "grant_type": "refresh_token",
        "refresh_token": STORED_REFRESH_TOKEN,
    },
)
```

The response gives you a new `access_token` and `refresh_token`. **Both tokens change** on refresh — store the new refresh token or the old one becomes invalid.

## Save to Hub

```bash
python3 ~/.hermes/integrations.py tiktok config <access_token> <refresh_token> <open_id>
```

## Sandbox vs Production

| Environment | What Works | What's Needed |
|-------------|------------|---------------|
| Sandbox | Test with your own account | App creation + OAuth setup |
| Production | Post to any TikTok account | App Review by TikTok |

For GameySins (single-account automation), sandbox is sufficient for development.
App Review is needed only if the app will be used by other users.

## Limitations

- No photo posting — video content only
- 24-hour token lifetime requires a daily cron job for long-running automations
- Arabic captions are supported (UTF-8), but hashtags in Arabic may have limited discoverability
- Rate limit: ~50 API calls/second per app
- Max video file size: varies by region (typically 1GB or 60 minutes)
