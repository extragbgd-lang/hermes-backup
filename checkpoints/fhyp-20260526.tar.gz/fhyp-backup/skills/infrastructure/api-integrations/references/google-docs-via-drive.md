# Google Docs via Drive API (HTML Import)

## Problem
The Google Docs API (`docs.googleapis.com`) is often not enabled on Cloud projects. Enabling it requires the user to visit the Google Cloud Console and click a button — not automatable.

## Solution
The Drive API can create Google Docs with full content by **importing HTML** and converting it to the Docs format. This works with just the Drive scopes (`drive`, `drive.file`) — no Docs API needed.

## How It Works

```python
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2.credentials import Credentials

creds = Credentials.from_authorized_user_file("google_token.json", SCOPES)
drive = build("drive", "v3", credentials=creds)

# Create HTML content with full formatting
html_content = """<html><body>
<h1>Video Title</h1>
<h2>Section Header</h2>
<p>Paragraph with <b>bold</b> and <i>italic</i> text.</p>
<ul><li>Item 1</li><li>Item 2</li></ul>
</body></html>"""

# Write to temp file
with open("/tmp/doc.html", "w", encoding="utf-8") as f:
    f.write(html_content)

# Upload and convert to Google Doc
media = MediaFileUpload("/tmp/doc.html", mimetype="text/html")
doc = drive.files().create(
    body={
        "name": "My Document Title",
        "mimeType": "application/vnd.google-apps.document"  # target format
    },
    media_body=media,
    fields="id,name,webViewLink"
).execute()

print(f"URL: {doc['webViewLink']}")
```

## HTML Features That Survive Conversion

| HTML Tag | Google Docs Result |
|----------|-------------------|
| `<h1>`-`<h6>` | Heading styles (Title, Heading 1-5) |
| `<p>` | Normal paragraphs |
| `<b>`, `<strong>` | Bold |
| `<i>`, `<em>` | Italic |
| `<ul>`/`<ol>` + `<li>` | Bullet/numbered lists |
| `<a href="...">` | Hyperlinks |
| `<hr>` | Horizontal rule |
| `<style>` block | Inline CSS for fonts, colors (partial support) |
| RTL (`dir="rtl"`) | Right-to-left text direction (Arabic) |
| Arabic/UTF-8 chars | Full Unicode support |

## Limitations

- No support for tables from HTML (they import as plain text)
- Images in HTML do not carry over reliably
- Complex CSS may not render in Docs
- The document is created as a **new** file each time (no update-in-place — use `files.update` for that)

## When to Use This Instead of Docs API

- **Docs API is not enabled** on the Cloud project (403 error)
- **User has only Drive scopes** and re-authing for Docs scope is inconvenient
- **Content is HTML-rich** (headings, lists, links, bold, italic) — converts cleanly
- **You need RTL/Arabic text** — the conversion handles it perfectly

## Full Working Script

See `~/.hermes/scripts/pipeline_to_docs.py` for a production example that:
- Builds formatted HTML from pipeline outputs
- Handles basic markdown-to-HTML conversion
- Creates the Doc and returns the URL
