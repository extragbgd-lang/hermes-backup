# Zapier Shortcut — Your First Stop for App Integrations

## Why Zapier First

Zapier MCP is a **built-in Hermes integration** (top-level `zapier:` config, NOT under `mcp_servers:`). It connects to **8,000+ apps** including Canva, Gmail, Google Sheets, Docs, Drive, Notion, YouTube, Slack, Jira, and more.

**Check Zapier BEFORE fighting MCP OAuth** — the user explicitly corrected this approach on 26-May-2026 after 40+ minutes fighting Composio MCP for Canva. If the app is in Zapier's catalog, the built-in integration is faster, simpler, and doesn't require OAuth setup.

## Status: Connected ✅ (26-May-2026)

Canva token was obtained from https://zapier.com/app/connections/mcp and is live in config.yaml. Canva is enabled with 12 actions — no additional auth needed.

## Tools Available Once Connected

1. `discover_zapier_actions` — Search 8,000+ apps for available actions
2. `enable_zapier_action` — Enable an app's actions on this MCP server
3. `disable_zapier_action` — Remove an app's actions
4. `list_enabled_zapier_actions` — List currently connected apps
5. `execute_zapier_read_action` — Execute a read/search action
6. `execute_zapier_write_action` — Execute a write/create action
7. Plus 7 more (list/create/update/delete skills, etc.)

## Key Lesson (26-May-2026)

**What happened:** Tried to set up Canva via Composio MCP bridge. Spent 40+ minutes fighting:
- OAuth with 40s hard timeout on `hermes mcp login`
- Consumer key (`ck_*`) that returned "Invalid consumer API key"
- API key (`ak_*`) that returned 401 with misleading error message

**User's response:** "You actually can use canva from zapier" — and they were right.

**Takeaway for future sessions:** Before any MCP OAuth deep-dive:
1. Check if the app is in Zapier's catalog first
2. If yes, use Zapier — it's already integrated, just needs the token
3. Only fall back to direct MCP if Zapier doesn't support the use case

## Canva via Zapier — Verified Actions (26-May-2026)

Canva (`App205891CLIAPI`) is enabled with 12 actions. Use `execute_zapier_write_action` / `execute_zapier_read_action`:

### Create Design (`create_design`)

**Custom dimensions (verified working):**
```json
{
  "app": "Canva",
  "action": "create_design",
  "instructions": "Create a blank custom design titled [name]. No asset needed.",
  "params": {
    "title": "GameSins - Test Design",
    "design_type__type": "custom",
    "design_type__width": 1920,
    "design_type__height": 1080
  },
  "output": "design_id, url"
}
```
→ Returns `design_id` (e.g. `DAHKxCeDMsE`) + editable URL. The `"No asset needed"` in instructions bypasses the follow-up question about inserting an asset. `output: "design_id, url"` (comma-separated) is the exact working format.

**Preset template:**
```json
{
  "app": "Canva",
  "action": "create_design",
  "instructions": "Create a presentation titled [name]",
  "params": {
    "title": "Design Name Here",
    "design_type__type": "preset",
    "design_type__preset_design_type": "Presentation"
  },
  "output": "design_id, url"
}
```

**Params:**
| Key | Type | Values |
|-----|------|--------|
| `title` | string | Design name (<256 chars) |
| `design_type__type` | required | `preset` or `custom` |
| `design_type__preset_design_type` | if preset | `Doc`, `Whiteboard`, `Presentation` |
| `design_type__width` | if custom | pixels (e.g. 1920) |
| `design_type__height` | if custom | pixels (e.g. 1080) |
| `asset_id` | optional | Asset to insert (from Uploads folder) |

### Export Design (`create_design_export_job`)
```json
{
  "app": "Canva",
  "action": "create_design_export_job",
  "instructions": "Export design [id] as PNG",
  "params": {
    "design_id": "DAHKw8c3Znw",
    "format__type": "png"
  },
  "output": "The export URL"
}
```
**Format options:** `pdf`, `jpg`, `png`, `pptx`, `gif`, `mp4`
**Optional:** `format__pages` — comma-separated (e.g. `1,2,3`), empty = all pages.

### Find Design (`find_design`)
```json
{
  "app": "Canva",
  "action": "find_design",
  "instructions": "Search for my Canva designs",
  "params": {},
  "output": "List of designs with IDs and URLs"
}
```

### Other Actions
- `create_asset_upload_job` — Upload assets to Canva
- `create_design_autofill_job` — Fill brand template (Enterprise)
- `create_design_import_job` — Import from file (PDF, PSD, AI, DOCX, PPTX)
- `get_design_export_job` — Check export status
- `move_folder_item` — Move items between folders

### Required Fields for ALL execute_zapier_* calls
The tool requires ALL 5 fields: `app`, `action`, `instructions`, `params`, `output`. Omitting any returns `MCP error -32602: Invalid input: expected string, received undefined`.

### Canva Auth Status
No additional auth needed. The Zapier connection is already authenticated. If it prompts for auth, the user needs to re-authenticate Canva in Zapier at https://zapier.com/app/connections/mcp.