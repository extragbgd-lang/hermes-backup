# Integration Hub — API Reference

File: `~/.hermes/integrations.py`
Config: `~/.hermes/integrations_config.json`

## Commands

### Status — Check All Connections
```bash
python3 ~/.hermes/integrations.py status
```
Shows enabled/disabled status for Google Drive, Notion, Instagram, TikTok.

### Google Drive
```bash
# Generate OAuth URL (prints URL for user to visit)
python3 ~/.hermes/integrations.py drive auth

# Exchange OOB code for token
python3 ~/.hermes/integrations.py drive auth-code <CODE>

# List recent files
python3 ~/.hermes/integrations.py drive list
```

### Google Sheets
```bash
# Create content calendar + video tracker spreadsheets
python3 ~/.hermes/integrations.py sheets create
```

### Notion
```bash
# Test connection
python3 ~/.hermes/integrations.py notion auth

# Save API token
python3 ~/.hermes/integrations.py notion token ntn_xxxxxxxxx

# List pages
python3 ~/.hermes/integrations.py notion pages
```

### Instagram
```bash
# Check status
python3 ~/.hermes/integrations.py insta status

# Save configuration
python3 ~/.hermes/integrations.py insta config <fb_page_id> <ig_user_id> <page_token>
```

### TikTok
```bash
# Check status
python3 ~/.hermes/integrations.py tiktok status

# Save configuration
python3 ~/.hermes/integrations.py tiktok config <access_token> <refresh_token> <open_id>
```

## Config File Format (`integrations_config.json`)

```json
{
  "google": {
    "enabled": true,
    "scopes": ["drive", "sheets"]
  },
  "notion": {
    "enabled": true,
    "workspace_name": "GameySins"
  },
  "instagram": {
    "enabled": true,
    "account": "gameysins",
    "fb_page_id": "123456...",
    "ig_user_id": "178414...",
    "page_access_token": "EAA..."
  },
  "tiktok": {
    "enabled": true,
    "account": "@gameysins7",
    "access_token": "clt...",
    "refresh_token": "rft...",
    "open_id": "..."
  }
}
```

## Token Files

| File | Service | Scope |
|------|---------|-------|
| `~/.hermes/youtube_credentials.json` | Google Cloud OAuth creds | Used for all Google APIs |
| `~/.hermes/youtube_token.json` | YouTube API | YouTube scopes only |
| `~/.hermes/google_token.json` | Drive + Sheets | Drive, Drive.file, Sheets |
| `~/.hermes/notion_token.json` | Notion API | Notion internal integration |
| Config embedded in `integrations_config.json` | Instagram, TikTok | Stored inline |

## Adding a New Integration

1. Add config schema block to `DEFAULT_CONFIG` dict
2. Create `service_save_config()` function
3. Create `service_status()` function  
4. Add `elif cmd == "service"` block to the main router
5. Update the `status()` function

Pattern for status function:
```python
def myservice_status():
    cfg = load_config().get("myservice", {})
    if not cfg.get("enabled"):
        print("❌  MyService: NOT CONFIGURED")
        return False
    # Make API call to verify
    if success:
        print("✅  MyService: CONNECTED")
        return True
```
