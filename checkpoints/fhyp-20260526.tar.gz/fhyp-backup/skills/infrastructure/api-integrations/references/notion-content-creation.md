## Critical Rules for This User

## Approach Selection

**Direct API (preferred for batch operations):** When you know the parent page ID and need to create multiple pages (e.g., a hub + N sub-pages), use the direct Notion REST API with the `ntn_` token. This is faster and more deterministic than Zapier because:
- You control the parent page ID directly (no Zapier `page_by_title` resolution)
- You can batch-create pages in parallel with curl
- You can add initial content via `children` in the POST body
- No token expiry or Zapier-specific quirks

**Zapier approach:** Use Zapier's `execute_zapier_write_action` when you DON'T have a parent page ID and need Zapier's page search/resolution. Also use Zapier when the action involves non-Notion apps (Sheets, Gmail, Docs, Drive, YouTube).

**Zapier Notion workflow:**
- `execute_zapier_write_action` with `action="create_page"` creates pages
- **Without `parent_page`**: pages are created as standalone top-level pages (accessible, no nesting)
- **With `parent_page`**: pages are nested under the specified parent, BUT the parent page must be explicitly shared with the Zapier integration in Notion (Share button → invite "Zapier"). If not shared, Zapier returns `"Could not find page with ID: X"`.
- `parent_page` is auto-resolved as "llm-guess" by Zapier — it may pick the wrong parent if multiple pages match. Always verify the resolved parent in the execution response.
- `page_by_title` action: searches pages the integration has access to. Returns empty `results:[]` if the integration hasn't been shared with any pages.
- To move a page under Main Brain after creation: not possible via API. Archive and recreate under the shared parent, or have the user drag it in Notion manually.

**NEVER create empty Notion pages.** After creating a page, always add content using `page_content` or `add_block_to_page` actions. The user opened one empty page this session and it was a frustration.

**Notion URLs must be bare clickable links on their own line.** The user opens these on mobile and needs to tap directly. Never wrap a Notion URL in descriptive text. Format: `https://www.notion.so/slug-pageid` on its own line, nothing else.

**Zapier token update procedure:**
When the user gives you a new Zapier MCP URL:
1. Replace the `url` value under `zapier:` in `~/.hermes/config.yaml` (top-level, NOT under mcp_servers)
2. Restart the gateway: `systemctl --user restart hermes-gateway.service` (background)
3. Test with list_enabled_zapier_actions — should return all connected apps
4. The token is a base64-encoded credential; do not decode or inspect it

## Notion Content Creation

## Correct Block Helper Functions

Notion API v2022-06-28 requires **both** a `"type"` field AND the block content keyed by that same type name:

```python
from typing import Any

def h1(text: str) -> dict:
    return {"type": "heading_1", "heading_1": {"rich_text": [{"type": "text", "text": {"content": text}}]}}

def h2(text: str) -> dict:
    return {"type": "heading_2", "heading_2": {"rich_text": [{"type": "text", "text": {"content": text}}]}}

def h3(text: str) -> dict:
    return {"type": "heading_3", "heading_3": {"rich_text": [{"type": "text", "text": {"content": text}}]}}

def para(text: str, bold: bool = False) -> dict:
    a = {"bold": bold} if bold else {}
    return {"type": "paragraph", "paragraph": {"rich_text": [{"type": "text", "text": {"content": text}, "annotations": a}]}}

def bullet(text: str) -> dict:
    return {"type": "bulleted_list_item", "bulleted_list_item": {"rich_text": [{"type": "text", "text": {"content": text}}]}}

def numbered(text: str) -> dict:
    return {"type": "numbered_list_item", "numbered_list_item": {"rich_text": [{"type": "text", "text": {"content": text}}]}}

def divider() -> dict:
    return {"type": "divider", "divider": {}}

def callout(text: str, emoji: str = "💡") -> dict:
    return {"type": "callout", "callout": {"rich_text": [{"type": "text", "text": {"content": text}}], "icon": {"type": "emoji", "emoji": emoji}}}

def toggle(heading: str, children: list[dict]) -> dict:
    return {"type": "toggle", "toggle": {"rich_text": [{"type": "text", "text": {"content": heading}}], "children": children}}

def quote(text: str) -> dict:
    return {"type": "quote", "quote": {"rich_text": [{"type": "text", "text": {"content": text}}]}}

def code_block(text: str, lang: str = "plain text") -> dict:
    return {"type": "code", "code": {"rich_text": [{"type": "text", "text": {"content": text}}], "language": lang}}
```

## Creating Pages with Rich Content

Create a page **and** its initial content in one POST request:

```python
import requests

headers = {
    "Authorization": f"Bearer {NOTION_TOKEN}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json"
}

def create_page(parent_id: str, title: str, icon: str, children: list[dict] | None = None) -> str | None:
    body = {
        "parent": {"type": "page_id", "page_id": parent_id},
        "properties": {
            "title": {"title": [{"type": "text", "text": {"content": title}}]}
        },
        "icon": {"type": "emoji", "emoji": icon},
        "children": children or []
    }
    resp = requests.post("https://api.notion.com/v1/pages", headers=headers, json=body)
    if resp.status_code == 200:
        return resp.json()["id"]
    else:
        print(f"❌ {resp.status_code}: {resp.json().get('message', '?')}")
        return None
```

**Key constraints:**
- `children` accepts up to 100 blocks per request — for more content, append via `PATCH /v1/blocks/{page_id}/children` in batches of 100
- The parent page must already have the integration shared with it (invited like a collaborator)
- Emoji icons only — custom images not supported in the API for page icons

## Adding More Blocks to an Existing Page

```python
def add_blocks(page_id: str, blocks: list[dict]) -> bool:
    r = requests.patch(
        f"https://api.notion.com/v1/blocks/{page_id}/children",
        headers=headers,
        json={"children": blocks}
    )
    return r.status_code == 200
```
Batch at most 100 blocks at a time. Add `time.sleep(0.2)` between batches for rate-limit safety.

## Updating Page Properties

```python
def update_page(page_id: str, title: str | None = None, icon: str | None = None, archived: bool | None = None) -> bool:
    body = {}
    if title:
        body["properties"] = {"title": {"title": [{"type": "text", "text": {"content": title}}]}}
    if icon:
        body["icon"] = {"type": "emoji", "emoji": icon}
    if archived is not None:
        body["archived"] = archived
    resp = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=body)
    return resp.status_code == 200
```

Usage:
```python
# Rename a page
update_page(page_id, title="New Name", icon="🧠")

# Archive (soft-delete) a page
update_page(page_id, archived=True)
```

## Restructuring Pattern: Moving Pages Between Parents

**The Notion API does NOT support changing a page's parent after creation.** You cannot "move" a child from one parent to another.

The correct workflow when a user wants to restructure:
1. **Create** a new container page under the new parent
2. **Recreate** all sub-pages under the new container (with full content in `children` parameter)
3. **Archive** the old sub-pages with `update_page(old_id, archived=True)`

Example — converting a flat list into a grouped hierarchy:
```python
# 1. Create container
container_id = create_page(main_brain_id, "OVC Marketing", "🏥", [h1("Hub page")])

# 2. Recreate children under container
for each old page:
    new_id = create_page(container_id, title, icon, [all_content_blocks])

# 3. Archive originals
for old_id in old_page_ids:
    update_page(old_id, archived=True)
```

Archived pages can be restored from Notion's Trash if needed, so this is a safe transformation.

## Pitfalls

- **No workspace-level pages via API.** Integration tokens CANNOT create pages with `parent: {"type": "workspace", "workspace": true}`. Always create as a child of an existing shared page.
- **Integration must be invited to the parent page.** If the integration hasn't been shared with (invited to) the parent page, search returns empty and all API calls return 403.
- **Integration search scope.** `POST /v1/search` only returns pages the integration has been explicitly shared with. If search returns 0 results, the integration hasn't been invited to any pages.
- **100-block limit per request.** Cannot append more than 100 blocks in a single POST/PATCH. Split larger content into multiple requests with `time.sleep(0.5)` between.
- **Nesting depth limit.** Max 10 levels of block nesting. Toggles count toward this limit since their `children` are nested blocks.
- **Rate limits.** Notion API has rate limiting — for bulk operations (10+ requests), add delays between calls.
- **No direct table creation.** The Notion API does not support creating database-style tables as blocks. Use full-page databases (separate API endpoint) or numbered/bulleted lists instead.
- **`GET /v1/search` only returns 100 results max per page.** Paginate using `next_cursor` for full workspace search.
- **Block structure gotcha.** Each block MUST have `"type": "<type_name>"` at the top level AND `<type_name>: {...}` as the content key. Omitting either results in a 400 validation error.
