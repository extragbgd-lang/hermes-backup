---
name: notebooklm-mcp-server
description: Set up and operate the roomi-fields/notebooklm-mcp HTTP REST API server for automated NotebookLM video generation, source management, and content download. Trigger when the user needs to generate NotebookLM Video Overviews, add sources, scrape notebooks, or any NotebookLM automation via Playwright.
---

# NotebookLM MCP Server (roomi-fields/notebooklm-mcp)

Uses Playwright (patchright fork) to automate NotebookLM via a REST API.

## Architecture

- **HTTP server must run on Windows native** (not WSL) — Playwright needs Windows Chrome
- **WSL communicates** with the server via `http://172.23.240.1:3000` (Windows host IP)
- **Auth state**: cookies are stored separately from the Chrome profile in a state file (`cookies.json`). The chrome_profile directory is only browser cache/settings. If chrome_profile gets corrupted, you can delete/rename it WITHOUT losing auth — the cookies persist across restarts.
- **Cookie state file** saved at `C:\\Users\\ammar\\AppData\\Local\\notebooklm-mcp\\Data\\cookies.json`
- Source at `D:\notebooklm-mcp` (Windows) and `/tmp/notebooklm-mcp` (WSL copy)

## Setup (one-time)

Run **setup-auth CLI** (at `dist/cli/setup-auth.js`, NOT `dist/setup-auth.js`):

```powershell
cd D:\notebooklm-mcp
node dist/cli/setup-auth.js --show-browser
```

Auth setup opens Chrome — just make sure logged into hermossybatooty@gmail.com, navigate to notebooklm.google.com, Chrome closes automatically when done.

**Note:** `npm run setup-auth` only works from WSL's npm if the project is built and Node is installed. The CLI script path is `dist/cli/setup-auth.js`.

## Start Server

In CMD (not PowerShell — ExecutionPolicy blocks npm):
```cmd
cd /d D:\\notebooklm-mcp
set BROWSER_CHANNEL=chrome
npm run start:http
```

**Alternative: start from WSL** (useful when you discover the server is down mid-session):
```bash
powershell.exe -Command "Start-Process -NoNewWindow -FilePath 'cmd.exe' -ArgumentList '/c cd /d D:\notebooklm-mcp && npm run start:http'"
```
The server output will stream into the terminal. It takes ~5 seconds to see "Listening on 0.0.0.0:3000". The server process keeps running after the WSL command returns.

Server is ready when you see "Listening on 0.0.0.0:3000".

## API Usage (from WSL)

All calls to `http://172.23.240.1:3000`:

### Health check
```bash
curl http://172.23.240.1:3000/health
```

### Add notebook to library
```bash
curl -X POST http://172.23.240.1:3000/notebooks \
  -H "Content-Type: application/json" \
  -d '{"url":"https://notebooklm.google.com/notebook/NOTEBOOK_ID","name":"my-notebook","description":"...","topics":["topic1"]}'
```

### Add text as source
```bash
curl -X POST http://172.23.240.1:3000/content/sources \
  -H "Content-Type: application/json" \
  -d '{"source_type":"text","text":"CONTENT_HERE","title":"My Title","notebook_url":"https://notebooklm.google.com/notebook/NOTEBOOK_ID"}'
```

### Generate video
```bash
curl -X POST http://172.23.240.1:3000/content/generate \
  -H "Content-Type: application/json" \
  -d '{"content_type":"video","video_format":"brief","video_style":"documentary","language":"English","notebook_url":"https://notebooklm.google.com/notebook/NOTEBOOK_ID"}'
```

### Download video
```bash
curl "http://172.23.240.1:3000/content/download?content_type=video&output_path=/mnt/d/path/to/video.mp4&notebook_url=https://notebooklm.google.com/notebook/NOTEBOOK_ID"
```

### Scrape all notebooks
```bash
curl http://172.23.240.1:3000/notebooks/scrape
```

## Pitfalls

### Chrome Browser Crash / Auth Loss

The Playwright Chrome instance can crash (OOM, process kill, etc.), taking the entire server down. Symptoms:
- `/health` returns `authenticated: false`
- `browserType.launchPersistentContext: Target page, context or browser has been closed` on any call
- Sessions show 0/10
- Chrome process immediately closes after launch (`<gracefully close start>` → `<kill>` → `<will force kill>`)

**Recovery procedure:**

1. **Close ALL running Chrome instances** (profile may be locked):
   ```powershell
   Get-Process -Name 'chrome' -ErrorAction SilentlyContinue | Stop-Process -Force
   ```

2. **Kill the old http-wrapper process** on Windows:
   ```powershell
   Get-CimInstance Win32_Process -Filter "CommandLine LIKE '%http-wrapper%'" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
   ```

3. **Fix corrupted Chrome profile** — if the profile at `C:\Users\ammar\AppData\Local\notebooklm-mcp\Data\chrome_profile` is corrupted (common after crashes), rename it so Playwright creates a fresh one:
   ```powershell
   $profileDir = "$env:LOCALAPPDATA\notebooklm-mcp\Data\chrome_profile"
   $backupDir = "$env:LOCALAPPDATA\notebooklm-mcp\Data\chrome_profile_corrupted_$(Get-Date -Format 'yyyyMMddHHmmss')"
   Rename-Item -Path $profileDir -NewName $backupDir
   ```
   **Without this step**, the server fails immediately with "browser has been closed."
   
   **Auth note:** Cookies survive profile reset. After renaming chrome_profile, the server still authenticates on restart — no re-auth needed.

4. **Restart the HTTP server** (cookies persist — most of the time auth still works):\n   ```cmd\n   cd /d D:\notebooklm-mcp\n   set BROWSER_CHANNEL=chrome\n   npm run start:http\n   ```\n\n5. **Verify auth survived:**\n   ```bash\n   curl http://172.23.240.1:3000/health\n   ```\n   Expected: `"authenticated": true`\n\n6. **Only re-auth if authenticated: false** — run CLI setup-auth:\n   ```powershell\n   cd D:\notebooklm-mcp\n   node dist/cli/setup-auth.js --show-browser\n   ```\n   This opens a visible Chrome window for Google login. The user must:\n   - Log into Google (hermossybatooty@gmail.com)\n   - Navigate to notebooklm.google.com\n   - Chrome closes automatically once authenticated\n   - The script waits up to 10 minutes for login\n\n7. **If setup-auth still fails** — check headless config, then retry:\n   ```\n   // In D:\notebooklm-mcp\dist\config.js — change headless: true, → headless: false,\n   ```
   ```


6. **Only re-auth if authenticated: false**
   ```powershell
   $env:BROWSER_CHANNEL = "chrome"
   cd D:\notebooklm-mcp
   Start-Process -WindowStyle Hidden -FilePath "node" -ArgumentList "dist/http-wrapper.js"
   ```

7. **Verify:**
   ```bash
   curl http://172.23.240.1:3000/health
   ```
   Expected: "authenticated": true

### Session Exhaustion
- Max 10 concurrent sessions (hard-coded in config.js `maxSessions: 10`)
- When all slots are full, new requests queue/block
- Stale sessions auto-expire after 900s (15 min) of inactivity
- To check: `curl http://172.23.240.1:3000/sessions`
- To clear: stale sessions expire naturally; no forced-close endpoint
- If agents keep hitting the limit, consider reducing session timeout or increasing max sessions

### MCP Tools vs HTTP Backend Gap

The MCP proxy (`stdio-http-proxy.js`) advertises tools to Hermes agents that the backend HTTP server may NOT fully implement:

| MCP Tool | HTTP Endpoint | Status |
|----------|--------------|--------|
| `ask_question` | POST /ask | ✅ Works (may be slow: 10-30s) |
| `list_notebooks` | GET /notebooks | ✅ Works |
| `get_health` | GET /health | ✅ Works |
| `list_sessions` | GET /sessions | ✅ Works |
| `search_notebooks` | GET /notebooks/search | ✅ Works |
| `notebook_by_name` | GET /notebooks/:name | ❌ 404 — path param not parsed correctly |
| `setup_auth` | POST /setup-auth | ❌ Opens Chrome headless, times out. Use CLI `node dist/cli/setup-auth.js --show-browser` instead. |
| `add_source` | POST /content/sources | ❌ 400 — needs correct payload format |
| `generate_audio` | POST /content/audio | ❌ 404 — endpoint may not exist |
| `generate_content` | POST /content/generate | ❌ 400 — payload format mismatch |
| `add_notebook` | POST /notebooks | ❌ 400 — requires `url` field |
| `select_notebook` | PUT /notebooks/:id/activate | ❌ 404 |

**Impact:** Agents trying to call `generate_audio`, `generate_content`, or `add_source` via the MCP will get errors. The `/ask` endpoint is the most reliable one for agent queries.

### General Pitfalls
- **BROWSER_CHANNEL=chrome must be set in environment** on every run (not .env — the project reads process.env directly, not dotenv)
- **Server must run on Windows** — if you see `/opt/google/chrome/chrome` errors, it's running in WSL
- **PowerShell blocks npm scripts** — use CMD instead (`cd /d D:\\notebooklm-mcp`)
- **Password/login**: credentials `hermossybatooty@gmail.com` / `IamDangerous` — but auth persists for ~399 days
- **Chat tab renamed**: NotebookLM changed "Discussion" tab to "Chat" — selectors patched in content-generator.ts. If video generation fails with "Chat input not found", the selectors may need updating again.
- **Locale**: server defaults to `fr` (French) — may affect UI label selectors
- **Do not modify** the `.env` file expecting it to load — set env vars directly in the CMD session
- **Rebuild after source changes**: edit in WSL at `/tmp/notebooklm-mcp/src/`, run `npm run build`, copy `dist/` to `D:\\notebooklm-mcp\\dist\\`
- **Multiple stdio-http-proxy instances** can conflict. Each Hermes agent session may spawn its own. Check with `ps aux | grep stdio-http-proxy` and kill duplicates.

## Reference Files

- `references/chrome-crash-recovery.md` — detailed Chrome crash detection, recovery procedure, session exhaustion handling, and auth renewal steps with exact commands

## Hermes Native MCP Integration (via stdio-http-proxy)

The NotebookLM server can be registered as a native Hermes MCP server so the agent can call it like any built-in tool. The server itself is a REST API, but the project includes a stdio-to-HTTP proxy bridge.

### Proxy setup

The proxy runs on WSL and translates MCP stdio protocol to HTTP calls against the Windows server.

**Prerequisite:** The `mcp` Python SDK must be installed in Hermes' venv:
```bash
pipx inject hermes-agent mcp
```
Without this, the proxy silently fails with `name 'StdioServerParameters' is not defined`.

Config:

```yaml
# ~/.hermes/config.yaml → mcp_servers:
mcp_servers:
  notebooklm:
    command: "node"
    args: ["/mnt/d/notebooklm-mcp/dist/stdio-http-proxy.js"]
    env:
      MCP_HTTP_URL: "http://172.23.240.1:3000"
```

Key env var: `MCP_HTTP_URL` — defaults to `http://localhost:3000`, must be set to `http://172.23.240.1:3000` when running from WSL to reach the Windows host.

### CLI registration (when CLI is working)

```bash
hermes mcp add notebooklm \
  --command node \
  --args /mnt/d/notebooklm-mcp/dist/stdio-http-proxy.js \
  --env MCP_HTTP_URL=http://172.23.240.1:3000
```

**Note:** Hermes v0.14.0 has a bug where `hermes mcp add --command` fails with `name 'StdioServerParameters' is not defined`. Until fixed, edit `~/.hermes/config.yaml` directly under `mcp_servers:` as shown above. Restart Hermes to pick up the config change.
