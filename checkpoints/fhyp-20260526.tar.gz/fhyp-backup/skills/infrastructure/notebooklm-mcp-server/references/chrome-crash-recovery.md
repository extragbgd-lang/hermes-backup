# Chrome Crash Recovery & Auth Loss

Observed session (2026-05-23): NotebookLM MCP server's Playwright Chrome instance crashed, rendering all agents unable to use NotebookLM.

## Detection

The `/health` endpoint was returning:
```json
{
  "authenticated": false,
  "browser_type": null,
  "active_sessions": 0,
  "max_sessions": 10,
  "headless": false
}
```

Any MCP call returned:
```
browserType.launchPersistentContext: Target page, context or browser has been closed
```

## Root Cause

The http-wrapper.js (running on Windows) had its Chrome child process terminated — likely OOM or Playwright internal crash. The Node server stayed alive but lost all browser context.

**Additional discovery:** After the crash, the Chrome profile at `C:\Users\ammar\AppData\Local\notebooklm-mcp\Data\chrome_profile` becomes corrupted. Any attempt to launch Chrome with that profile (even fresh setup-auth) fails immediately with:
```
browserType.launchPersistentContext: Target page, context or browser has been closed
<launched> pid=26104
[pid=26104] <gracefully close start>
[pid=26104] <kill>
[pid=26104] <will force kill>
```

The fix is to **rename** the corrupted profile directory so Playwright creates a fresh one (see Step 3 below).

Attempting `/setup-auth` via HTTP POST also timed out (>120s) because the dead Chrome profile couldn't be used.

## Recovery Steps

### Step 1: Close ALL Chrome and Kill the orphaned http-wrapper

```powershell
# Close ALL Chrome instances (the profile may be locked)
Get-Process -Name 'chrome' -ErrorAction SilentlyContinue | Stop-Process -Force

# Kill the old http-wrapper
Get-CimInstance Win32_Process -Filter "CommandLine LIKE '%http-wrapper%'" | ForEach-Object {
    Stop-Process -Id $_.ProcessId -Force
}
```

### Step 2: Fix corrupted Chrome profile

If the profile at `C:\Users\ammar\AppData\Local\notebooklm-mcp\Data\chrome_profile` is corrupted, rename it so Playwright creates a fresh one. **This is critical** — without this step, setup-auth will fail immediately with "browser has been closed" because the old profile's lock files prevent launch.

```powershell
$profileDir = "$env:LOCALAPPDATA\notebooklm-mcp\Data\chrome_profile"
$backupDir = "$env:LOCALAPPDATA\notebooklm-mcp\Data\chrome_profile_corrupted_$(Get-Date -Format 'yyyyMMddHHmmss')"
Rename-Item -Path $profileDir -NewName $backupDir
```

### Step 3: Patch headless default to false
In `D:\notebooklm-mcp\dist\config.js`:
```
// Line 32: Change headless: true, → headless: false,
```
The default is baked at module load time. `HEADLESS=false` env var is also read but Start-Process may not inherit it. Patching the source is more reliable.

### Step 3: Restart with BROWSER_CHANNEL=chrome
```powershell
cd D:\notebooklm-mcp
$env:BROWSER_CHANNEL = "chrome"
Start-Process -WindowStyle Hidden -FilePath "node" -ArgumentList "dist/http-wrapper.js"
```

### Step 4: Verify
```bash
curl -s http://172.23.240.1:3000/health | python3 -m json.tool
```
Expected: `"headless": false`, `"authenticated": false`

### Step 5: Authenticate (use CLI, NOT HTTP)

**IMPORTANT:** The CLI script is at `dist/cli/setup-auth.js`, NOT `dist/setup-auth.js`. Running the wrong path gives `MODULE_NOT_FOUND`.

```powershell
cd D:\notebooklm-mcp
node dist/cli/setup-auth.js --show-browser
```

This opens a visible Chrome window for Google login. The script waits up to 10 minutes. User must:
1. Log into Google account (hermossybatooty@gmail.com)
2. Navigate to notebooklm.google.com
3. Chrome closes automatically once authenticated
4. The script then saves auth state to the profile directory

**Note:** The `/setup-auth` HTTP endpoint (`curl -X POST ...`) does NOT work reliably — it opens a headless browser that times out.

### Step 6: Confirm
```bash
curl -s http://172.23.240.1:3000/health | python3 -c "
import sys,json; d=json.load(sys.stdin)['data']
print(f'authenticated={d[\"authenticated\"]} headless={d[\"headless\"]} sessions={d[\"active_sessions\"]}/{d[\"max_sessions\"]}')
"
```

## Session Exhaustion

Before the crash, the server showed 10/10 sessions used. This means agents were connecting and not releasing. Each agent session spawns a Chrome context that stays alive for the session timeout (900s default).

To check current sessions:
```bash
curl http://172.23.240.1:3000/sessions
```

Each session has a `last_activity` timestamp. They auto-expire after `session_timeout` seconds of inactivity. No forced-session-kill endpoint exists.

## MCP Proxy Conflicts

The stdio-http-proxy.js runs as a separate process. Multiple Hermes sessions can each spawn their own proxy, creating conflicts. If NotebookLM calls return inconsistent results:
```bash
ps aux | grep stdio-http-proxy | grep -v grep
# Kill duplicates, keep one
```

## Key Env Vars

| Variable | Value | Purpose |
|----------|-------|---------|
| BROWSER_CHANNEL | chrome | Use installed Chrome, not Playwright Chromium |
| HEADLESS | false | Show browser for auth (default: true) |
| MCP_HTTP_URL | http://172.23.240.1:3000 | WSL→Windows bridge for stdio-http-proxy |
| NOTEBOOK_URL | (unset) | Auto-navigate on launch |
| MAX_SESSIONS | 10 | Hard config limit |
