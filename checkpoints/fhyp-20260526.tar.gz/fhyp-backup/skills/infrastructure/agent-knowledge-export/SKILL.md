---
name: agent-knowledge-export
description: Export all agent knowledge about a user into a portable, structured knowledge base for another AI agent. Use when the user wants to onboard a new agent, copy context to a different system, create an agent backup, or transfer their profile/preferences/projects to another AI.
triggers:
  - "copy all knowledge to another agent"
  - "onboard a new AI agent"
  - "export everything you know about me"
  - "create a knowledge base for [agent name]"
  - "set up [agent name] with my context"
  - "transfer your memory to [agent name]"
  - "knowledge dump for another AI"
  - "package my context for a new agent"
---

# Agent Knowledge Export

Export all accumulated agent knowledge (memory, facts, skills, session history, environment) into a portable, structured markdown knowledge base that another AI agent can ingest.

## Workflow

### 1. Gather All Knowledge Sources

Query all available knowledge stores in parallel:

- **fact_store:** `action='list'` with high limit (100+) to get all facts, then `action='probe'` with the user's name entity
- **skills_list:** all installed skills (filter for user's custom skills in categories like agent, content-creation, video-generation)
- **session_search:** recent sessions and keyword search for user's name / main projects to surface anything not in memory
- **Memory context:** the MEMORY and USER PROFILE blocks injected into every turn (these are already in your context — extract them directly)
- **File system:** check for key config files, .env, agent.md, project directories that define the user's environment

### 2. Deduplicate and Organize

Fact stores accumulate duplicates (same fact saved 3-4 times with slight wording variations). Deduplicate aggressively:

- Group facts by topic (profile, preferences, projects, tools, workflows, pitfalls)
- Keep the most complete/accurate version of each fact
- Discard obviously stale facts (old OAuth states, completed setup steps)
- Organize into logical sections: Profile, Rules, Projects, Environment, Workflows, Pitfalls

### 3. Create the Knowledge Base

Always create 3 files in the target directory:

#### AGENTS.md (System Prompt — ~12-15KB)
This is the primary file the target agent ingests as its system prompt. Structure:

```
# [Agent Name] — Agent System Prompt
# You are an AI agent working for [User]. Read this entire file.

## WHO [USER] IS
- Name, location, job, goals, personality, communication style

## CRITICAL RULES
- Language rules (if any)
- Authentication policy
- Approval workflows
- Financial constraints
- File storage preferences
- Response style preferences

## PROJECTS
- Each project: purpose, audience, output paths, key details

## TECHNICAL ENVIRONMENT
- OS, hardware, key tools, paths, IPs

## CONTENT PIPELINES (if applicable)

## [USER]'S INTERESTS/DOMAIN (if applicable)

## AGENT PERSONA INSTRUCTIONS
- Numbered list of behavioral rules for the target agent
```

MUST end with a pointer to knowledge.md for deeper reference.

#### knowledge.md (Deep Reference — ~20-25KB)
Comprehensive reference with everything organized into numbered sections:
1. Full profile (expanded)
2. Critical rules (with context on WHY each rule exists)
3. Every project in complete detail (pipelines, outputs, gotchas)
4. Technical environment (paths, commands, configs, IP addresses)
5. Step-by-step workflows
6. Quick-reference table mapping "what" → "path"
7. Lessons learned / pitfalls to avoid (numbered list)

This file is for the agent to search/lookup, not load into context every time.

#### README.md (Index — ~1.5KB)
Human-readable index explaining:
- What each file contains
- How to use them (which to load as system prompt, which as reference)
- When it was generated and by whom

### 4. Output Location

Default to D: drive (`/mnt/d/[agent-name]/`) to save C: drive space. The folder name should match the target agent name, lowercased with hyphens.

### 5. Sensitive Data Handling

- Include credentials ONLY if the user explicitly provided them for automation (like a shared NotebookLM account)
- Never create new credential files — reference existing `.env` paths
- If the target agent needs API keys, reference the source paths rather than copying values

## Pitfalls

- **Don't skip deduplication.** Fact stores have heavy duplication. Writing raw facts = bloated, confusing knowledge base.
- **AGENTS.md is NOT a facts dump.** It's a curated system prompt. Deep reference goes in knowledge.md.
- **File sizes matter.** AGENTS.md should be under 15KB so it fits in a system prompt context. knowledge.md can be larger.
- **Don't assume the target agent runs in the same environment.** Use absolute paths but note they may need translation.
- **Include behavioral rules prominently.** The "English only, Arabic for content" type rules are the most important thing the new agent needs — put them at the top of AGENTS.md.
- **Verify the target directory exists** before writing. Use `mkdir -p`.
