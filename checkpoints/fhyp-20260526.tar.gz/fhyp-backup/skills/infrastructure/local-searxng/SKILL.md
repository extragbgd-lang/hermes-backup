---
name: local-searxng
description: Self-hosted SearXNG search instance for Hermes — zero API keys, unlimited web/ Arabic search via MCP.
category: infrastructure
trigger_conditions:
  - Search tools not working (Firecrawl 401, no API keys)
  - Need for free, unlimited web search
  - Arabic search for GameSins content research
  - web_search tool not available
---

# Local SearXNG Instance

## What It Is

A fully self-hosted SearXNG instance running at **http://127.0.0.1:8888** that searches Google + DuckDuckGo directly. No API keys, no rate limits, unlimited queries. Supports Arabic search.

Wired into Hermes as an MCP server via the pipx `searxng` package serving as a bridge.

## Keepalive Cron

A cron job monitors SearXNG every 5 minutes and restarts it if down:
- Job ID: `fa84a0d9e214`
- Script: `/home/ammar/.hermes/scripts/start-searxng.sh`
- Logs: `/home/ammar/searxng/server.log`

## Starting / Restarting

If SearXNG is down (port 8888 unreachable):

```bash
# Method 1: Use the background terminal tool
terminal(background=true, command="/home/ammar/.hermes/scripts/start-searxng.sh")

# Wait ~6 seconds, then verify:
terminal(command="curl -s 'http://127.0.0.1:8888/search?q=test&format=json' --max-time 10")
```

## Verification

```bash
curl -s "http://127.0.0.1:8888/search?q=test&format=json" --max-time 10
# Expect: JSON with "results" array, 25-38 results
```

## Using For Search

SearXNG MCP tool: `mcp_searxng_web_search(query=..., max_results=...)`

Works for English and Arabic queries. Returns results from Google and DuckDuckGo engines.

## Configuration

- **Location:** `/home/am/searxng/`
- **Settings:** `/home/ammar/searxng/settings-user.yml`
- **Startup script:** `/home/ammar/.hermes/scripts/start-searxng.sh`
- **MCP config in Hermes:** Under `mcp_servers.searxng` in `~/.hermes/config.yaml`
- **Web backend:** `web.search_backend: searxng` in config

## Pitfalls

- Gateway restart kills the SearXNG background process (systemd cgroup cleanup). The keepalive cron auto-restarts it within 5 minutes.
- If urgent recovery needed after gateway restart: start manually via background terminal (Method 1 above).
- The server takes ~5 seconds to fully boot before accepting queries.