---
name: hermes-extensions-discovery
trigger_conditions: user_requests_extension_discovery|wants_explore_github_capabilities|asks_install_discovered_tool|queries_hermes_extensions|slash_command/extensions|cli_command/hermes_extensions

description: |
  GitHub-based extension discovery and integration system for Hermes.
  
  Enables automated GitHub search for trusted, production-ready modules, plugins, 
  and complementary services that can enhance Hermes capabilities (UI upgrades, 
  memory systems, browser tools, agent skills, workflow automations).
  
  **Core Features:**
  
  - Automatic GitHub repository search with API integration
  
  - Quality filtering: checks stars, forks, maintenance status, README completeness
  
  - Trustworthy source detection: identifies known frameworks (LangChain, LlamaIndex, etc.)
  
  - Categorization into logical groups:
    • Memory systems (vector DBs, embeddings)
    • UI dashboards (web panels, control centers)
    • Agent skills (task automation modules)
    • Browser automation (web control extensions)
    • Logging/monitoring systems
    • Performance upgrades (queue systems, async runtimes)
  
  - Comprehensive analysis for each discovered tool:
    • Summary of functionality
    • Hermes integration assessment
    • Dependency requirements
    • Risk level (LOW/MEDIUM/HIGH)
    • Maintenance status
    • Compatibility score (0-100)
  
  - Mandatory user approval gate before any installation
  
  - Sandbox testing before full activation
  
  - Security scanning for malicious patterns
  
  - Version control and one-click rollback support
  
  - Registry tracking at ~/.hermes/extensions/registry/installed_extensions.json

trigger_conditions: |
  • User requests extension discovery or GitHub search
  • User wants to explore new capabilities from GitHub
  • User asks to install a discovered tool
  • User queries available Hermes extensions
  • /extensions [search|list|install|rollback|remove|analyze] commands triggered

numbered_steps: |
  step1_search_github: |
    On `/extensions search <query>` or startup:
    1. Query GitHub API with structured search (ai-agent, automation, memory-system tags)
    2. Filter by relevance to agent systems and AI tools
    3. Apply quality thresholds (min stars, recent commits, README exists)
    4. Return top repositories with quality metrics
  
  step2_filter_quality: |
    Before presenting results:
    1. Check repository activity (recent commits < 180 days max)
    2. Verify stars >= threshold (e.g., 10+)
    3. Detect maintenance status (active/slow/deprecated/abandoned)
    4. Evaluate README completeness and license file presence
    5. Identify known frameworks (LangChain, LlamaIndex, AutoGPT-like)
    6. Reject abandoned or low-quality repos (<10 stars, unmaintained)
    7. Only return actively maintained projects with documentation
  
  step3_categorize: |
    Group discovered tools into categories:
    - MEMORY SYSTEMS → Vector DBs, long-term memory, embeddings storage
    - UI DASHBOARDS → Web panels, control centers, observability tools
    - AGENT SKILLS → Task automation modules, tool plugins
    - BROWSER AUTOMATION → Extension hooks, web control tools
    - LOGGING/MONITORING → Observability tools, metrics collectors
    - PERFORMANCE UPGRADES → Queue systems, async runtimes
  
  step4_analyze_each: |
    For each GitHub result, generate:
    1. Summary of what it does (README analysis)
    2. How it integrates with Hermes architecture
    3. Dependencies required (requirements.txt, setup.py parsing)
    4. Risk level (LOW/MEDIUM/HIGH)
    5. Maintenance status
    6. Compatibility score (0-100)
  
  step5_safety_scan: |
    Before any installation approval:
    1. Verify repository contents exist and are readable
    2. Scan for malicious or unsafe patterns:
       - Credential stealing scripts
       - Obfuscated code blocks
       - Unknown binaries
    3. Ensure no destructive install scripts (rm -rf /, etc.)
    4. Validate install commands step-by-step
    5. Detect risky permissions or system access requests
    6. If anything uncertain → classify as "Needs manual review"
  
  step6_request_approval: |
    STRICT RULE - ALWAYS ASK EXPLICITLY:
    "Do you want to install any of these? If yes, specify which ones."
    
    NEVER auto-install. Always wait for user confirmation.
    User response determines next action:
    - YES → proceed with installation after safety verification
    - NO → skip this tool
    - MODIFY → user specifies different options
  
  step7_install_safely: |
    If approved by user:
    1. Clone repository safely (shallow clone first)
    2. Install dependencies in isolated environment (virtualenv)
    3. Never install globally unless explicitly allowed
    4. Create rollback point before installation
    5. Log all changes to registry file
    6. Track version, source URL, install date
  
  step8_sandbox_test: |
    Before full activation:
    1. Run module in sandbox mode (separate directory)
    2. Test basic functionality (import checks, syntax verification)
    3. Verify no crashes or unexpected behavior
    4. Validate integration hooks with Hermes core
    5. If tests pass → proceed to full installation
  
  step9_registry_update: |
    After successful installation:
    1. Update hermes_extensions.json registry file
    2. Include version, source URL, install date
    3. Enable one-click rollback/uninstall support

pitfalls: |
  pitfall_auto_install: |
    ❌ NEVER auto-install any discovered tool (STRICT RULE)
    ✅ ALWAYS request explicit user approval first
    
  pitfall_suspicious_urls: |
    ❌ Never execute remote code without inspection
    ✅ Always verify repository contents before installation
    
  pitfall_binary_downloads: |
    ❌ Never download binaries without verification
    ✅ Always prefer pip packages from trusted PyPI sources
    
  pitfall_deprecated_ai_agents: |
    ❌ Never install deprecated or unmaintained AI agents without approval
    ✅ Check last commit date - reject repos abandoned >180 days

output_format: |
  Each discovered tool must include this exact format:
  
  ```
  NAME: <repository_name>
  GitHub URL: <full_html_url>
  Category: <Memory Systems|UI Dashboards|Agent Skills|Browser Automation|Logging/Monitoring|Performance Upgrades|General>
  Description: <first_150_chars_of_readme>...
  Maintenance Status: ACTIVELY MAINTAINED | SLOWLY UPDATES | DEPRECATED (BUT FUNCTIONAL) | ABANDONED - USE AT OWN RISK
  Stars/Forks: <num_stars>|<num_forks>
  Compatibility Score: <0-100_integer>
  Risk Level: LOW | MEDIUM | HIGH
  Integration Notes: <how_it_integrates_with_hermes>
  Recommended Action: INSTALL | REVIEW | REJECT
  ```

startup_behavior: |
  On Hermes agent startup, extension system automatically:
  
  1. Load installed extensions registry from ~/.hermes/extensions/registry/installed_extensions.json
  
  2. Validate all installed modules (check git repos exist and are valid)
  
  3. Check for available updates (DO NOT auto-update - user must approve)
  
  4. Notify user if upgrades are available
  
  5. Display summary only if action required

commands: |
  /extensions search <query>  
    → Searches GitHub for repositories matching query terms
    Example: `/extensions search "AI agent memory system python"`
  
  /extensions list  
    → Shows all currently installed Hermes extensions
  
  /extensions install <name>  
    → Installs an extension (requires explicit user approval first)
  
  /extensions rollback <name>  
    → Restores extension to previous version from backup point
  
  /extensions remove <name>  
    → Uninstalls and removes extension from Hermes system
  
  /extensions analyze <repo>  
    → Performs detailed analysis on a specific repository

cli_commands: |
  hermes extensions search <query>
  hermes extensions list
  hermes extensions install <name> [--url repo_url]
  hermes extensions rollback <name>
  hermes extensions remove <name>
  hermes extensions analyze <repo>

files_created: |
  - ~/.hermes/extensions/__init__.py           ← Extension system entry point
  - ~/.hermes/extensions/github_search.py      ← GitHub API search engine
  - ~/.hermes/extensions/repository_analyzer.py ← Comprehensive repository analysis
  - ~/.hermes/extensions/categorizer.py         ← Category classification logic
  - ~/.hermes/extensions/registry.py            ← Installation tracking & version control
  - ~/.hermes/extensions/sandbox.py             ← Isolated testing environment
  - ~/.hermes/extensions/installation.py        ← Safe installation with rollback
  - ~/.hermes/extensions/command_handler.py     ← Slash command implementations
  - ~/.hermes/extensions/cli.py                 ← Standalone CLI interface
  - ~/.hermes/extensions/README.md              ← Architecture documentation
  - ~/.hermes/extensions/registry/installed_extensions.json ← Registry file

integration_notes: |
  The extension system integrates with Hermes via:
  
  1. **Slash Commands**: /extensions [search|list|install|rollback|remove|analyze]
  
  2. **CLI Interface**: hermes extensions <subcommand> (via cli.py)
  
  3. **Registry System**: Tracks all installations in JSON format
  
  4. **Sandbox Isolation**: Tests modules before full integration
  
  5. **Safety Gates**: Mandatory user approval and security scanning

safety_rules: |
  - Never execute remote code without inspection
  - Never run install scripts blindly
  - Never download binaries without verification
  - Never install deprecated or unmaintained AI agents without approval
  - Always require user confirmation for installations
  - Always sandbox-test before full activation
  - Always create rollback point before installation
