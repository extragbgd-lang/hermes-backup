# Kanban Board Management Reference

## Quick Command Reference

| Action | Command |
|--------|---------|
| Init default board | `hermes kanban init` |
| List all boards | `hermes kanban boards list` |
| Switch board | `hermes kanban boards switch <slug>` |
| Create board | `hermes kanban boards create <slug> --name "Name" --desc "..."` |
| Remove board | `hermes kanban boards rm <slug>` |
| Rename board | `hermes kanban boards rename <slug> --name "New Name"` |
| Gateway status | `hermes gateway status` |

## DB File Locations

| Board | Path |
|-------|------|
| Default | `~/.hermes/kanban.db` |
| Named board | `~/.hermes/kanban/boards/<slug>/kanban.db` |
| Board config | `~/.hermes/kanban/boards/<slug>/board.json` |

## Cleanup Directories

- Tasks workspaces: `~/.hermes/kanban/workspaces/` (default), `~/.hermes/kanban/boards/<slug>/workspaces/` (named)
- Task logs: `~/.hermes/kanban/logs/` (default), `~/.hermes/kanban/boards/<slug>/logs/` (named)

## Profiles

```bash
hermes profile list
```

Available on this machine: `default`, `night-shift`. All tasks use the `default` profile — Paperclip agents are not in use.

## Gateway Requirement

The dispatcher lives inside the gateway. Without `hermes gateway start` or a running `hermes-gateway.service`, tasks stay `ready` forever. After any init/wipe/restart, verify:

```bash
systemctl --user status hermes-gateway.service
```