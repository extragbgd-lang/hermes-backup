# Blocked Task Diagnostics

## Symptom: `kanban show <id>` returns "no such task" for displayed IDs

IDs shown in `kanban list` (e.g. `t_c8a16b81`) may fail with `kanban show t_c8a16b81` → "no such task". Workaround: query SQLite directly.

## Direct SQLite Queries

Default DB path: `~/.hermes/kanban.db`

### List blocked tasks with full details
```python
import sqlite3, json
conn = sqlite3.connect('~/.hermes/kanban.db')
conn.row_factory = sqlite3.Row
rows = conn.execute("SELECT id, title, body, assignee, tenant, status FROM tasks WHERE status='blocked'").fetchall()
for r in rows:
    print(r['id'], r['title'])
```

### Find block reasons (in task_events table)
Block reasons are NOT stored in the `tasks` table. They live in `task_events` with `kind='blocked'` and the reason in `payload` (JSON).

```python
rows = conn.execute("""
    SELECT task_id, kind, payload, created_at
    FROM task_events
    WHERE task_id IN (<comma-separated-ids>)
          AND kind='blocked'
    ORDER BY task_id, created_at
""").fetchall()
for r in rows:
    reason = json.loads(r['payload']).get('reason', 'no reason given')
    print(r['task_id'], reason)
```

### Find comments on blocked tasks
Comments live in `task_comments` table.

```python
rows = conn.execute("""
    SELECT task_id, author, body
    FROM task_comments
    WHERE task_id IN (<ids>)
""").fetchall()
```

### Check all available tables and schema
```python
tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
for t in tables:
    cols = conn.execute(f"PRAGMA table_info({t[0]})").fetchall()
    print(t[0], [c[1] for c in cols])
```

## Cron Job Monitoring Pattern

For automated blocked-task checks (scheduled cron job):

1. Switch boards with `hermes kanban boards switch <slug>`
2. List with `hermes kanban list --status blocked`
3. If IDs resolve through kanban show, use that. If not, fall back to SQLite queries above.
4. Extract block reasons from `task_events` (kind='blocked').
5. Extract comments from `task_comments`.
6. Report findings via auto-delivered cron response (do NOT use send_message in cron context).

## Table Schema Reference

```
tasks:
  id, title, body, assignee, status, priority, created_by, created_at,
  started_at, completed_at, workspace_kind, workspace_path, claim_lock,
  claim_expires, tenant, result, idempotency_key, consecutive_failures,
  worker_pid, last_failure_error, max_runtime_seconds, last_heartbeat_at,
  current_run_id, workflow_template_id, current_step_key, skills, max_retries

task_events:
  id, task_id, run_id, kind, payload (JSON), created_at

task_comments:
  id, task_id, author, body, created_at

task_links:
  parent_id, child_id

task_runs:
  id, task_id, profile, step_key, status, claim_lock, claim_expires,
  worker_pid, max_runtime_seconds, last_heartbeat_at, started_at,
  ended_at, outcome, summary, metadata, error
```
