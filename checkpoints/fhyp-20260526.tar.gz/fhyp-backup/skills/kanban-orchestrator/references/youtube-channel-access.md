# YouTube Channel Access (No API Key)

## GameSins Channel Details

| Field | Value |
|-------|-------|
| Channel name | GameySins (NOT "Game Sins") |
| Channel ID | `UCONFcmXBuJrx2G3ouEITGpQ` |
| URL | `https://www.youtube.com/@GameySins` |
| RSS Feed | `https://www.youtube.com/feeds/videos.xml?channel_id=UCONFcmXBuJrx2G3ouEITGpQ` |
| Created | 2026-01-13 |

## Method: YouTube RSS Feed (No Auth Required)

YouTube provides an RSS feed for every channel. No API key, no OAuth needed:

```bash
curl -s "https://www.youtube.com/feeds/videos.xml?channel_id=UCONFcmXBuJrx2G3ouEITGpQ" \
  -H "User-Agent: Mozilla/5.0"
```

### What the RSS Feed Contains
- Channel title, link, author name
- All recent video entries with:
  - `yt:videoId` — unique video ID
  - `<title>` — video title (Arabic/English)
  - `<published>` / `<updated>` — timestamps
  - `<link rel="alternate">` — video URL
  - `media:thumbnail` — thumbnail URL (hqdefault.jpg)
  - `media:description` — full description text (Arabic, includes social links, hashtags)
  - `media:statistics` — view count (NOT subscriber count or likes)

### Extracting Specific Fields

**All video IDs + titles + views:**
```bash
curl -s "https://www.youtube.com/feeds/videos.xml?channel_id=UCONFcmXBuJrx2G3ouEITGpQ" \
  -H "User-Agent: Mozilla/5.0" | \
  grep -oP '<yt:videoId>[^<]+</yt:videoId>|<published>[^<]+</published>|<title>[^<]+</title>|<media:statistics[^>]*/>'
```

## Method: Channel Page HTML (Limited)

The channel page at `https://www.youtube.com/@GameySins` returns JavaScript-rendered HTML. The only metadata extractable from raw HTML without a browser:

```bash
curl -s "https://www.youtube.com/@GameySins" -H "User-Agent: Mozilla/5.0" | \
  grep -oP '"externalId":"[^"]*"'
```

This gives the `externalId` (channel ID). All other data (subscriber count, video list, banner) requires JavaScript execution.

## Limitations (No YouTube API)

Without the YouTube Data API (requires OAuth or API key):
- ❌ No subscriber count
- ❌ No like/dislike counts
- ❌ No comment data
- ❌ No analytics (watch time, traffic sources, demographics, CTR)
- ❌ Only last ~15 videos from RSS feed

## Zapier MCP (YouTube OAuth)

The Hermes config has Zapier MCP connected with YouTube OAuth (7 actions available). If Zapier tools work, they can provide:
- Channel statistics (subscribers, total views)
- Video analytics
- Comment moderation
- Playlist management

Test before relying on it — Zapier OAuth tokens expire and may need re-authentication.