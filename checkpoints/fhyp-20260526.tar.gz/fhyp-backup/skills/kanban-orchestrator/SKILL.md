---
title: kanban-orchestrator
name: kanban-orchestrator
description: Protocol for Hermes Kanban orchestrators — how to decompose goals into tasks, fan out work, and step back.
trigger_conditions:
  - User asks you to decompose a goal into kanban tasks
  - User asks about current kanban board state / what's queued / what's blocked
  - You need to inspect or report on pipeline status
  - You need to create multi-step pipelines with different assignees
  - Organizing work across multiple profiles
  - Setting up content pipelines or recurring workflows
  - User asks about YouTube channel data, video list, or channel stats
  - Setting up a content pipeline from research through publishing
---

# Kanban Orchestrator Protocol

An orchestrator does NOT do the work. It decomposes goals into tasks, inspects board state, assigns, links dependencies, and steps back.

## CRITICAL: CLI vs MCP Tools

**The orchestrator (running in the main agent session) does NOT have `kanban_show()`, `kanban_create()`, `kanban_link()`, or `kanban_complete()` as MCP tools.** Those tools are only injected when running as a spawned kanban worker.

The orchestrator uses the **`hermes kanban` CLI** for everything:

| Goal | CLI Command |
|------|-------------|
| List boards | `hermes kanban boards list` |
| Switch board | `hermes kanban boards switch <slug>` |
| List tasks | `hermes kanban list` |
| List tasks on board | `hermes kanban --board <slug> list` |
| Show task | `hermes kanban show <task_id>` |
| Create task | `hermes kanban create --title "..." --assignee <profile> --body "..." --parents t_id` |
| Link deps | `hermes kanban link <task_id> --parent <parent_id>` |
| Complete running | `hermes kanban complete <task_id>` |
| Block a task | `hermes kanban block <task_id> --reason "..."` |
| Unblock | `hermes kanban unblock <task_id>` |
| Comment | `hermes kanban comment <task_id> "..."` |
| Diagnostics | `hermes kanban show <task_id>` (warnings at top) |

## Pre-Flight: Inspect Board State

Before creating anything, understand what's already in play:

```bash
# What boards exist? Which is active?
hermes kanban boards list

# Current board tasks
hermes kanban list

# Another board's tasks (⚠ --board not supported; switch first)
hermes kanban boards switch <slug> && hermes kanban list

# Drill into any blocked or interesting task
hermes kanban show <task_id>
```

⚠ **If `kanban show <id>` returns "no such task" for IDs visible in `kanban list`**, the CLI has a bug. Fall back to direct SQLite queries documented in `references/blocked-task-diagnostics.md`.

Use this pre-flight to spot blocked chains, detect bottlenecks, and avoid duplicating work. Report the bottleneck to the user before offering solutions.
### Profile Discovery (Hermes-only mode)

This user runs **Hermes-only** — no Paperclip agents. Only one profile matters:

```
hermes profile list
```

Expected profiles: `default` (always available), `night-shift` (for off-hours tasks).

**Never** try to assign tasks to Paperclip profiles (Research, Script, Video, SEO, QA) — they are not reliable and the user explicitly prefers Hermes-only. Every task gets assigned to `default`.

## Step 1: Read the Goal

If spawned as a worker, the goal arrives via `HERMES_KANBAN_TASK` env and you use `kanban_show()` tool. Otherwise, read the user's request directly.

## Step 2: Decompose

Break the goal into independent and sequential chunks. Create each via CLI:

```
hermes kanban create \
  --title "specific task description" \
  --assignee "profile_name" \
  --body "detailed instructions, references, and expected output" \
  --tenant "pipeline-name" \
  --parents t_parent_id1,t_parent_id2
```

### Dependency Rules
- **Parallel tasks**: create with no --parents → both become ready immediately
- **Sequential tasks**: use --parents → child stays `todo` until parent completes
- **Fan-in**: child has multiple --parents → child becomes `ready` when ALL parents are done

## Step 3: Link Cross-Cutting Dependencies

If you discover additional dependencies after creation:
```
hermes kanban link <child_id> --parent <parent_id>
```

Use `hermes kanban show <task_id>` to verify the dependency graph afterwards.

## Step 4: Complete Orchestrator Task

If running as a spawned orchestrator worker:
```
kanban_complete(
    summary="decomposed goal into N tasks with X dependencies",
    metadata={
        "tasks_created": ["t_abc", "t_def"],
        "assignee_profiles": ["researcher", "writer"],
        "has_dependencies": true
    }
)
```

If running in the main agent session (not a worker), just report the plan to the user.

## Canonical Patterns

### Batch Content Production (GameSinsTech pattern)

A pattern for producing **multiple related shorts** in one session — research, write, package all N, then deliver. Hermes-only, no Paperclip.

**When to use:** User says "let's do 4 shorts for one shoot" or "batch production" or multiple shorts for a single recording session.

**Kanban setup:**
```bash
hermes kanban boards switch default

# Hub page task
hermes kanban create \
  --title "GST Hub: [batch theme] - [date]" \
  --assignee default \
  --body "Create Notion hub page. Then produce N shorts." \
  --tenant gst-batch

# One task per short (sequential — hub first, then shorts)
hermes kanban create \
  --title "Short 1: [topic] — full package" \
  --assignee default \
  --body "Research → MSA Arabic script → SEO → pinned comment → b-roll → thumbnail prompt → Notion page" \
  --tenant gst-batch

# ... Shorts 2, 3, 4 with same pattern
```

**Execution flow (direct, not through workers):**
1. Create Notion hub page
2. Research ALL topics in one pass (batch research, live site checks)
3. Write ALL scripts (MSA Arabic, 60-90s each, 4-section formula)
4. Package EACH with SEO + pinned comment + b-roll instructions + thumbnail prompt
5. Save EACH as standalone Notion page
6. Deliver summary table

**Rules:**
- All tasks on `default` profile (Hermes-only)
- Tenant tag: `gst-batch`
- Short chains: hub task + N short tasks = max 5 total
- If one short blocks, scrap just that task — not the whole batch
- Do NOT use delegate_task for research; retiree content is simple enough for direct research

### Two parallel → one synthesis
```
kanban_create(title="research topic A", assignee="researcher-a")
kanban_create(title="research topic B", assignee="researcher-b")
kanban_create(
    title="synthesize findings",
    assignee="writer",
    parents=["t_A", "t_B"]
)
```

### Linear pipeline
```
kanban_create(title="plan",    assignee="planner")
kanban_create(title="execute", assignee="executor", parents=["t_plan"])
kanban_create(title="review",  assignee="reviewer", parents=["t_execute"])
```

### Default profile tasks (single-agent mode)
When using a single profile (`default`), tasks queue up sequentially. Create all tasks first, then link dependencies — the dispatcher ticks every 60s and may claim tasks before links are set:

```
kanban_create(title="task 1", assignee="default")
kanban_create(title="task 2", assignee="default")
kanban_create(title="task 3", assignee="default")
kanban_link(parent_id="t_1", child_id="t_2")   # link after all created
kanban_link(parent_id="t_2", child_id="t_3")
```

### Tenant namespacing
Use `tenant` to group related tasks within a board for filtering:

```
kanban_create(title="...", assignee="default", tenant="video-pipeline")
kanban_create(title="...", assignee="default", tenant="shorts")
kanban_create(title="...", assignee="default", tenant="ops")
```

## Pitfalls

- **Channel name is "GameySins", NOT "Game Sins".** Always use the correct spelling in searches, descriptions, titles, and YouTube queries. The RSS feed lists it as "Gamey sins" (lowercase).
- **`kanban show <id>` returns "no such task" for visible IDs.** The IDs shown in `kanban list` output may fail silently. Fall back to direct SQLite queries: `python3 -c "import sqlite3; conn=sqlite3.connect('~/.hermes/kanban.db'); ..."`. See `references/blocked-task-diagnostics.md` for the full set of queries (events, comments, schema).
- **Block reasons are NOT in the tasks table.** They're stored in `task_events` with `kind='blocked'` and the reason in `payload` (JSON). Comments live in a separate `task_comments` table.
- **`--board <slug>` is NOT supported on `kanban list` or most subcommands.** Switch board first with `hermes kanban boards switch <slug>`.
- **Single-profile = sequential.** With only one profile, tasks queue. Use parent-child links to enforce order.
- **Create all tasks first, THEN link dependencies.** The dispatcher ticks every 60s and may claim tasks before links are set.

## Board Lifecycle Management

### DB Locations
- **Default board:** `~/.hermes/kanban.db` (NOT inside `~/.hermes/kanban/`)
- **Named boards:** `~/.hermes/kanban/boards/<slug>/kanban.db` + `board.json`

### Board Operations

```bash
# List all boards (● = current)
hermes kanban boards list

# Create a new board
hermes kanban boards create <slug> --name "Display Name" --description "..."

# Switch active board
hermes kanban boards switch <slug>

# Remove a board (archives it to boards/_archived/)
hermes kanban boards rm <slug>

# Rename a board
hermes kanban boards rename <slug> --name "New Name"

# Init the default board DB (if missing/deleted)
hermes kanban init
```

### Wipe/Reset Procedure

To clean both boards and start fresh (used when user asks to scrap stuck pipelines):

```bash
# 1. Delete the databases
rm ~/.hermes/kanban.db
rm ~/.hermes/kanban/boards/<slug>/kanban.db

# 2. Remove old workspaces + logs
rm -rf ~/.hermes/kanban/logs ~/.hermes/kanban/workspaces
rm -rf ~/.hermes/kanban/boards/<slug>/logs ~/.hermes/kanban/boards/<slug>/workspaces

# 3. Remove board (archives it)
hermes kanban boards rm <slug>

# 4. Re-init default board
hermes kanban init

# 5. Recreate named board
hermes kanban boards create <slug> --name "..." --description "..."

# 6. Verify gateway is running (dispatcher needs it)
hermes gateway status
```

⚠ **After init/wipe, always verify the gateway is running.** The dispatcher lives inside the gateway and won't process tasks without it. Output should show `Active: active (running)`.

### Hermes-Only Mode (Ammar preference)

⚠ **This user does NOT use Paperclip agents.** Paperclip (Research/Script/Video/SEO/QA profiles) is known to be unreliable — do NOT assign tasks to Paperclip profiles unless the user explicitly asks for them. All kanban tasks use either `default` or `night-shift` profile.

When creating pipelines for this user:
- Assign **all tasks to `default`** (the active Hermes profile)
- Keep chains **short — 2-3 tasks max** per pipeline
- **Prefer sequential 2-task mini-pipelines** over complex dependency graphs
- If a pipeline blocks, offer to scrap it rather than debug

## Two-Board Architecture (GameSins pattern)

The recommended structure:

| Board | Purpose | Assignees |
|-------|---------|-----------|
| `default` | Ops, experiments, system maintenance, non-gaming work, GST batch production | `default` |
| `gameysins` | Gaming content — scripts, production, publishing, shorts | `default` |

Key rules:
- **Keep gaming content isolated** from ops/experiments
- **Short chains (2-3 tasks per video), not 7-task monsters** — long chains bottleneck on any one failure; one blocked task stalls the whole week
- **Parallel where possible** — research two topics simultaneously instead of one after another
- **Scrap stuck pipelines** — when a pipeline is blocked and user says "scrap it", archive ALL tasks in that chain (blocked + waiting todos) and start fresh rather than debugging
- **YouTube channel data** can be pulled via RSS (no API key needed): `curl -s "https://www.youtube.com/feeds/videos.xml?channel_id=CHANNEL_ID"` — see `references/youtube-channel-access.md` for the GameySins channel details

## Pitfalls (continued)

- **If gateway isn't running, tasks stay `ready` forever.** Check with `hermes gateway status` after any init/wipe.
- **User prefers scrapping stuck pipelines over fixing them.** When a chain is blocked >24h, offer to scrap it rather than try to unblock. Get user approval, then archive the whole chain.
- **Default board DB lives at `~/.hermes/kanban.db`, NOT `~/.hermes/kanban/kanban.db`.** The workspace and logs directories DO live at `~/.hermes/kanban/`. Easy mistake when cleaning up.

## Anti-Temptation Rules

- **Do NOT execute the task yourself.** Create tasks for the right assignee, then complete your orchestrator role.
- **Do NOT create tasks without assignees.** The dispatcher needs a real profile name.
- **Do not assign work to profiles that don't exist.** Use Step 0 first.
- **Use parents for ordering, not timing.** If two tasks can run in parallel, don't link them.
