---
title: chrome-cdp-automation
name: chrome-cdp-automation
description: Browser automation via Chrome DevTools Protocol (CDP) to the user's own Chrome. No Browserbase, no timeouts, no headless detection. Use for NotebookLM, Google Flow, and any browser automation.
trigger_conditions:
  - Any browser automation task (NotebookLM, Google Flow, web scraping)
  - User says "use my browser" or "browser automation"
  - Whenever browser_navigate fails with timeout
  - NotebookLM video generation
---

# Chrome CDP Browser Automation

Use the user's own Chrome via DevTools Protocol — ZERO timeouts, no headless detection.

## Hermes Browser Config (config.yaml)

For Hermes' built-in `browser_*` tools to route through CDP instead of Browserbase, set these in `~/.hermes/config.yaml`:

```yaml
browser:
  cdp_url: http://localhost:9223     # WSL port forwarding (9223→Windows:9222)
  engine: local                       # use local Chrome CDP, not auto-detect
  allow_private_urls: true            # needed for localhost/self-hosted URLs
```

The port forwarding `localhost:9223 → 127.0.0.1:9222` must be set up first (see Setup section above). After changing config, restart gateway: `systemctl --user restart hermes-gateway.service`.

## Setup (One-Time, Windows Admin CMD)

```cmd
netsh interface portproxy add v4tov4 listenport=9223 listenaddress=0.0.0.0 connectport=9222 connectaddress=127.0.0.1
netsh advfirewall firewall add rule name="Chrome Debug WSL" dir=in action=allow protocol=TCP localport=9222
```

## Starting Chrome (User — every session)

Close ALL Chrome windows. Win+R:

```
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --remote-allow-origins=* --user-data-dir="C:\temp\chrome-debug"
```

## Connecting from WSL2

```bash
pip install websocket-client
```

```python
import json, websocket, urllib.request

# Always fetch fresh WS URL
resp = urllib.request.urlopen("http://192.168.100.17:9223/json/version", timeout=5)
ws_url = json.loads(resp.read())["webSocketDebuggerUrl"]

ws = websocket.create_connection(ws_url, timeout=15)
```

## Standard CDP Command Pattern

```python
mid = [0]
def cmd(ws, method, params=None, sid=None):
    mid[0] += 1
    msg = {"id": mid[0], "method": method, "params": params or {}}
    if sid: msg["sessionId"] = sid
    ws.send(json.dumps(msg))
    while True:
        r = json.loads(ws.recv())
        if r.get("id") == mid[0]: return r
```

## Essential CDP Flow

1. `Page.enable` + `Runtime.enable` + `Input.enable`
2. `Target.getTargets` → find page target → `Target.attachToTarget` → get sessionId
3. `Page.navigate` to URL, wait 3-5s
4. `Runtime.evaluate` for reading page state, finding elements
5. `Input.dispatchMouseEvent` for clicking (NOT element.click() — SPAs ignore it)

## Finding + Clicking Elements

```javascript
// Get coordinates
var el = document.querySelector('button');
var r = el.getBoundingClientRect();
JSON.stringify({x: r.x + r.width/2, y: r.y + r.height/2});
```
```python
x, y = float(x), float(y)
cmd(ws, "Input.dispatchMouseEvent", {"type":"mousePressed","x":x,"y":y,"button":"left","clickCount":1}, sid)
cmd(ws, "Input.dispatchMouseEvent", {"type":"mouseReleased","x":x,"y":y,"button":"left","clickCount":1}, sid)
```

## Downloads

Files go to `C:\Users\ammar\Downloads\` → accessible from WSL2 at `/mnt/c/Users/ammar/Downloads/`.

## Pitfalls

- **SEARCH FOR EXISTING TOOLS FIRST.** Before building raw CDP automation for any web service, search GitHub for existing automation projects. Many popular services have battle-tested libraries that handle UI changes better than raw CDP. For NotebookLM specifically, use `roomi-fields/notebooklm-mcp` (REST API + Playwright). See `quick-facts-pipeline` → `references/notebooklm-mcp-setup.md`. User frustration signal: "is there an existing project on github or something" means you should have searched first.
- **ACT FIRST, EXPLAIN LATER.** Default to doing, not asking. When CDP is connected and a task needs browser interaction, just execute it. Do NOT ask the user "should I try this?" or "can you click X?" — try first via CDP, then report. User will explicitly call out: "why are you not automating this using the browser automation?" and "cant you see it yourself?". Use `Runtime.evaluate` to read page state BEFORE asking the user what they see.
- **NotebookLM v2 UI (May 2026) resists CDP.** The new Angular UI uses deeply nested stateful components where `Input.dispatchMouseEvent` clicks don't reliably trigger state changes. Onboarding dialogs (\"Start a project\"), source panel expansion, and the \"Copied text\" dialog may not open via CDP clicks. If you spend >5 minutes on CDP clicks that don't work, switch to `roomi-fields/notebooklm-mcp` REST API — it wraps Playwright which handles the new UI.
- **Never use Browserbase/Browse CLI** — 5-min timeout, headless detection
- **SPA frameworks (Angular, React) ignore element.click()** — use Input.dispatchMouseEvent
- **WSL2 IP may change** — always use fixed `192.168.100.17` which is the user's LAN IP (same as LM Studio)
- **Chrome must be fully closed** before starting with debug flag (`taskkill /F /IM chrome.exe`)
- **Google sign-in works** because it's a real Chrome, not headless
- **LM Studio models (Qwen/Gemma) are in reasoning mode** — they return empty content, spending tokens on internal thinking. User must disable "Reasoning" in LM Studio settings before using for text generation. For now, use Hermes LLM for script generation.
- **NotebookLM onboarding blocks source panel.** New notebooks show "What would you like this notebook to help you do?" — click "Create a podcast, video, slide deck, etc." to dismiss it before trying to add sources. The "Add source" button exists but the "Copied text" dialog won't appear until onboarding is dismissed.
- **Source vs Chat: different inputs.** NotebookLM has a Chat textbox AND a Sources panel. To add content as a source (required for Video Overview generation), use: "Add source" button → "Copied text" → paste → Insert. Do NOT paste into the Chat textbox — the user will correct this.
- **Textarea for source paste is inside a dialog.** After clicking "Copied text", wait for the dialog to open, THEN find the `textarea` or `[role="textbox"]` element inside it. If `document.querySelector('textarea')` returns null, the dialog may not have loaded yet — wait 1-2s and retry.

## NotebookLM-Specific Patterns (⚠️ CDP is fragile — prefer REST API)

**For automated NotebookLM workflows, use `roomi-fields/notebooklm-mcp` REST API instead of raw CDP.** See `quick-facts-pipeline` → `references/notebooklm-mcp-setup.md`. The CDP patterns below are fallback-only and may fail on NotebookLM's v2 Angular UI (May 2026).

Quick patterns (FALLBACK, may break):
- **Onboarding:** Click "Create a podcast, video, slide deck, etc." before source panel works
- **Tabs:** Sources/Chat/Studio are `<div role="button">`, not `<button>` — use mouse events
- **Source dialog:** "Add source" → "Copied text" → find `<textarea>` inside dialog → paste → "Insert"
- **Video Overview:** "Brief" format, English, Auto-select visuals → Generate → wait 30-180s
- **Download:** Click `more_vert` (⋮) on completed video → menu → "Download"
- **Reuse existing notebook** instead of creating new ones to avoid onboarding
