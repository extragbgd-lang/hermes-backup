---
name: Browser Automation
version: "1.0"
trigger: "browser automation, automate chrome, login website"
description: |
  Complete workflow for automating Chrome via Playwright with persistent profiles, 
  session management, and human-like interaction patterns.
author: Hermes Team
date_created: May-2024
---

## Trigger Conditions
Use this skill for:
- **Local Playwright automation** (primary focus): full visible Chrome with persistent profile
- Automating Chrome/Chromium browser interactions

Use the **hermes-agent skill** (Browserbase section) for:
- **Built-in `browser_*` tools**: Browserbase cloud browsers for non-gated web tasks
- Browse CLI setup and usage
- BROWSERBASE_PROXIES, BROWSERBASE_API_KEY env var configuration

Both stacks apply to:
- Filling forms, logging into websites, downloading files
- Capturing screenshots and extracting page content
- NotebookLM content generation (upload scripts, generate Video Overviews / Slide Decks / Infographics → download results)
- Google-login-gated AI tools where user authenticates first, then agent automates

## Core Requirements

### Primary Engine
- **Playwright** with Chromium (primary)
- **Selenium** only as fallback if Playwright fails
- Never use lightweight/embedded browsers
- Must launch real full browser session

### Profile Isolation
- Separate browser profile from personal browser data
- Isolated cookies, session storage, downloads, cache
- Default profile: `HermesAutomationProfile`

### Session Persistence
- Maintain logins across reboots
- Preserve cookies with auto-recovery
- Detect and reauthenticate on expiration
- Support Google 2FA persistence

### Human-Like Behavior
- Randomized delays (±30% variance)
- Smooth scrolling with pauses
- Realistic typing speed (50-80ms/char)
- Retry failed interactions (3 retries max)

## Auto-Install Required Libraries

On first run, install these system libraries:

```bash
sudo apt-get install -y libnss3 libnss3-dev \
  libnspr4 libnspr4-dev libatk1.0-0 libatk-bridge2.0-0 \
  libcups2-dev libxkbcommon0 libxcomposite1 libxdamage1 \
  libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 \
  libcairo2 libpangoft2-1.0-0 libatspi2.0-0 libasound2t64
```

## Installation Steps

### 1. Create Project Structure
```bash
mkdir -p hermes-browser-automation/core
mkdir -p hermes-browser-automation/automation
mkdir -p hermes-browser-automation/downloads
mkdir -p hermes-browser-automation/outputs/screenshots
cd hermes-browser-automation
python3 -m venv venv
source venv/bin/activate
pip install playwright
python3 -m playwright install chromium
```

### 2. Initialize Chrome Profile
```bash
mkdir -p ~/.config/google-chrome/
mkdir -p /home/ammar/hermes-browser-automation/downloads/
```

### 3. Set Up Login Credentials
Create file: `~/.hermes/browser_credentials.txt`
```
GMAIL_EMAIL=user@gmail.com
GMAIL_PASSWORD=password
```
Secure: `chmod 600 ~/.hermes/browser_credentials.txt`

## Architecture

### Core Components

#### Browser Engine (`core/engine.py`)
- Playwright setup with Chromium
- Full visible browser mode (`headless=False`)
- Persistent profile with isolated storage
- Typing with realistic delays: 50-80ms char + random ±30%
- Smooth scrolling: 0.2s pauses between segments
- Retry logic: 3 attempts, 1500ms base backoff

#### Session Manager (`core/session.py`)
- Cookie storage: `~/.config/google-chrome/Default/Cookies`
- localStorage persistence
- Auto-recovery on crash
- Login expiration detection

#### Automation Controller (`automation/__init__.py`)
- CLI: `/browsers *` commands
- Tab lifecycle management
- Download/upload coordination
- Health monitoring (memory, crashes, timeouts)

#### AI Layer (`ai_layer.py`)
- Selector analysis and fallbacks
- Role/type based element detection
- Screenshot with annotated overlays

## CLI Command Reference

| Command | Description |
|---------|-------------|
| `/browsers init` | Launch browser session |
| `/browsers close` | Close, preserve state |
| `/browsers open <url>` | Navigate to URL |
| `/browsers type <ref> <text>` | Type into element (@e1, @e2, etc.) |
| `/browsers click <ref>` | Click element by ref |
| `/browsers press <key>` | Press key (Enter, Tab) |
| `/browsers tabs` | List open tabs |
| `/browsers screenshot <file.png>` | Save screenshot |
| `/browsers login-status` | Check auth state |
| `/browsers download-status` | Track downloads |
| `/browsers clear-cache` | Clear cookies |
| `/browsers restart` | Reload browser |

## Testing Workflow

### Basic Test
```bash
source venv/bin/activate
cd ~/hermes-browser-automation
python3 automation/run.py
```

### Element Interaction
```bash
/browsers type @e1 TestAutomation123
/browsers click @e2
/browsers screenshot test.png
```

### Multiple Tabs
```bash
/browsers open https://google.com
/browsers open https://python.org
/browsers tabs  # Show both tabs
```

## Pitfalls - Common Failure Modes

### 🚨 Missing System Libraries
**Error**: `libnspr4.so: cannot open shared object file` or `libasound2`  
**Fix**: Run full library install command

### 🚨 Invalid Profile Path  
**Error**: `--user-data-dir` rejection  
**Fix**: Correct path is `~/.config/google-chrome/`

### 🚨 Playwright Version Drift
**Symptom**: Chrome bundled version mismatch  
**Fix**: `python3 -m playwright install --update`

### 🚨 Security: Never Log Credentials
- Never print passwords to stdout
- Use environment variables for sensitive data
- chmod 600 on credential files

### 🚨 Mode Confusion
- `headless=True`: fast, no visuals
- `visible=True` or `headless=False`: required for interactive mode
- Default running: **visible=True for testing**, **headless=False for production**

### 🚨 "Element not found"
**Causes**:
- Page not loaded: Add `wait_for_selector()`
- Dynamic selectors: Use CSS role/name instead of IDs
- Observer hidden: Scroll before clicking

**Pattern**:
1. Wait 1-2 seconds
2. Attempt click/type
3. If fail: Refresh and retry with fallback selector

### 🚨 High Memory (WSL2)
- Monitor: `top -l 30 -m` or task manager
- Restart if >1GB
- Clear cache between major runs

### 🚨 WSL2 Hangs
- Set `LD_LIBRARY_PATH=~/local-libs/lib` before launch
- Test with minimal chrome config first

### 🚨 Captcha Detection
- **DEFAULT**: Stop + notify user, manual intervention required
- **ONLY**: Auto-solve if user explicitly configures external solver
- **NEVER**: Auto-solve by default
### 🚨 Browserbase Cloud Browsers vs Local Playwright — Three Stacks for Different Needs

Hermes has THREE browser automation stacks:

1. **Built-in `browser_*` tools** — run on Browserbase cloud browsers (headless, remote) OR local Chromium via agent-browser CLI (auto-detected from credentials). Configured via hermes-agent skill (env vars: BROWSERBASE_API_KEY, BROWSERBASE_PROXIES). **Google blocks login on cloud mode** — "This browser or app may not be secure" error — unless on Browserbase Scale plan with residential proxies.

2. **Local Playwright** (this skill) — runs Chromium locally with headless=False, persistent profile at ~/.config/google-chrome/. Bypasses cloud browser detection because it's a real visible browser.

3. **`browse` CLI + Browserbase Session Live View** — The working approach for Google-login-gated sites on free Browserbase plans. Start a remote session via `browse open`, get the Session Live View URL from the Browserbase debug API, give the URL to the user to authenticate in their own browser, then control the session via `browse` CLI commands. This is the only approach that reliably works for NotebookLM, Gemini web UI, YouTube Studio, and any other Google-gated tool on free Browserbase plans.

**When to use which:**
- Browserbase cloud browsers / local agent-browser: general web scraping, non-gated sites, quick tasks via Hermes' browser_* tools
- browse CLI + Live View: Google-login-gated tools (NotebookLM, Gemini, YouTube Studio) — user authenticates via live view, then agent automates
- Local Playwright: sites needing persistent auth + human-like appearance, when user is on a machine with a display

### 🚨 Credential Sharing Exception
User's default rule: "never handle passwords." **Exception**: When the user explicitly shares credentials (email + password) in the chat for a specific automation task, the agent may use them directly in browser forms. The user may override the rule for a gated service they want automated. Never save credentials to memory or files — use them once and discard from context.

### 🚨 Gemini API Fallback for Google-Gated Tools
When Browserbase cloud browsers fail to log into a Google service (NotebookLM, Gemini, etc.), the recommended fallback is to use the **Gemini API** directly. The `GOOGLE_API_KEY` is typically already set in `~/.hermes/.env`. Gemini provides the same underlying AI capabilities as NotebookLM without the browser automation headache. You can send script/source content as text and ask for structured breakdowns, scene descriptions, or visual notes — then feed the output into the hyperframes-broll skill for actual video generation.

### 🚨 Don't Assert Tool Limits Without Verification
If the user claims a tool can do something you're unfamiliar with (e.g., "NotebookLM can generate video"), do NOT dismiss it from memory. Verify via live research first — Wikipedia, tool blog, or the tool's actual interface. Tools like NotebookLM, Gemini, and ChatGPT add capabilities frequently. Wrongly asserting limits wastes user time and erodes trust. When in doubt: research first, answer second.

## Best Practices

1. **Always verify Chrome installation** before automation
2. **Test with visible=True** first, then switch to headless
3. **Set realistic timeouts** (2-3s typical page load)
4. **Use stable selectors** (role/name over dynamic IDs)
5. **Clear cache periodically** to avoid cookie bloat
6. **Monitor memory** on WSL2/system environments
7. **Lock credential file permissions** after editing
8. **Save setup commands** to automation scripts

## Files & Locations

- Setup Guide: `/home/ammar/hermes-browser-automation/SETUP_GUIDE.txt`
- Credentials: `~/.hermes/browser_credentials.txt`
- Logs: `~/.hermes/browser_logs/`
- Screenshots: `/home/ammar/hermes-browser-automation/outputs/screenshots/`
- Downloads: `/home/ammar/hermes-browser-automation/downloads/`

## Reference Files

- **`references/notebooklm-video-workflow.md`** — Full workflow for feeding GameySins scripts into NotebookLM via browser automation. Covers: user-first Google authentication, source upload, Video Overview/Slide Deck/Infographic generation, download, and pipeline integration. Use this when the user wants NotebookLM to generate video content from scripts.

## Session Learnings

**Style preferences established**:
- Direct and concise responses
- Commands ready-to-use without excessive explanation
- Code-first approach with minimal preamble

**Technical approach**:
- Playwright primary, Selenium fallback only
- Human-like interaction patterns
- Persistent profile with crash recovery
- Explicit captcha detection requirement
- Save to sessionable output file if multi-step script needed

## Session Reference File
Quick commands reference:
`/home/ammar/.hermes/skills/web/browser-automation/references/quickfix.md`