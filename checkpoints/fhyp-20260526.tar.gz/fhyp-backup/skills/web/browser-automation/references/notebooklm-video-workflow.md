# NotebookLM → GameySins Video Content via Browser Automation

## Overview
Use NotebookLM (notebooklm.google.com) to generate video content from GameySins scripts. NotebookLM can produce:
- **Video Overviews** — slide-style AI-generated videos with narration and visuals (2025 feature)
- **Slide Deck** — presentation format from notebook sources
- **Infographics** — visual summaries powered by Nano Banana Pro
- **Audio Overviews** — podcast-like AI discussions
- **Data Tables** — structured data extraction
- **Study Guides / FAQs / Briefing Docs** — text summaries

NotebookLM runs on Gemini 3. Supports 80+ languages including Arabic.

## ⚠️ Critical: Google Login Block on Browserbase Cloud Browsers

**Browserbase cloud browsers (Hermes' built-in `browser_*` tools) are blocked by Google at login.**  
You get: *"This browser or app may not be secure"* even when typing credentials directly.

**Why:** Browserbase default sessions run without residential proxies. Google detects the headless/cloud browser signature and blocks sign-in regardless of whether the agent or user types the credentials.

**Solutions (in priority order):**

### ✅ Solution A: Browserbase Session Live View (RECOMMENDED — WORKS ON FREE PLAN)
The only approach that reliably works without a paid Browserbase plan. Uses Browserbase's **Session Live View** feature to let the user authenticate in their own browser, then the agent takes over via `browse` CLI.

**Setup:**
```bash
# 1. Install Browse CLI
npm install -g browse

# 2. Add Browserbase credentials to ~/.hermes/.env
BROWSERBASE_API_KEY=bb_live_...
BROWSERBASE_PROJECT_ID=<project-uuid>
```

**Workflow:**
1. Agent runs `browse open https://notebooklm.google.com` (creates a remote Browserbase session)
2. Agent calls the Browserbase debug API to get the Live View URL:
   ```bash
   # Find session ID
   curl -s -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
     "https://api.browserbase.com/v1/sessions?projectId=$PROJECT_ID&limit=1"
   
   # Get live view URL
   curl -s -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
     "https://api.browserbase.com/v1/sessions/$SESSION_ID/debug"
   ```
3. Agent sends the `debuggerFullscreenUrl` to the user
4. User opens the link in their local browser and signs into Google
5. User says "done" — agent runs `browse snapshot` to verify authenticated state
6. Agent controls the session via `browse` CLI commands (`browse click`, `browse fill`, `browse type`, `browse snapshot`, `browse upload`, etc.)

**Session refs:** `browse snapshot` returns accessibility refs like `7-1277` — use them with `browse click 7-1277`. The ref format differs from Hermes' built-in `@e10` format.

**Gotchas:**
- Sessions expire after 5 minutes by default. Extend with `timeout` param when creating the session.
- Keep the env vars exported: `BROWSERBASE_API_KEY` and `BROWSERBASE_PROJECT_ID`
- The `browse` CLI session is independent from Hermes' built-in `browser_*` tools — they use different provider backends

### Solution B: Enable Residential Proxies (Browserbase Scale Plan Required)
1. Set `BROWSERBASE_PROXIES=true` in `~/.hermes/.env`
2. Requires a **Browserbase Scale plan** (or higher) — free/Developer plans don't include residential proxies
3. The env var is loaded at Hermes startup; you may need to restart Hermes for it to take effect
4. If the warning "Running WITHOUT residential proxies" still appears in the browser snapshot header, proxies aren't active

### Solution C: Use Local Playwright (Browser-Automation Skill)
Set up a local Playwright Chromium instance (this skill) with:
- `headless=False` (visible browser)
- Persistent Chrome profile at `~/.config/google-chrome/`
- User authenticates once, cookies persist in the profile

### Solution D: Fall Back to Gemini API
Since NotebookLM runs on Gemini, use the **Gemini API** directly instead of the web UI:
- No Google login required (just an API key in `~/.hermes/.env`: `GOOGLE_API_KEY=...`)
- Same capabilities: document analysis, summarization, structured content generation
- Faster (API calls vs browser automation)
- Can handle Arabic natively
- The output feeds into HyperFrames b-roll generation the same way
- **Limitation:** Gemini API does NOT render video — only text analysis. Use when text breakdown is sufficient.

Use this approach: send the script text/content to Gemini with a prompt asking it to produce the same kind of breakdown/visual notes that NotebookLM Video Overview would generate, then feed those as scene descriptions into the hyperframes-broll skill.

## Prerequisites
- **Browse CLI** installed globally: `npm install -g browse`
- **Browserbase API key** from https://browserbase.com/settings (format: `bb_live_...`)
- **Browserbase project ID** (get from `browse cloud projects list`)
- Environment vars set: `BROWSERBASE_API_KEY`, `BROWSERBASE_PROJECT_ID`
- Google account for NotebookLM web UI (for Video Overviews with actual video rendering)
- **OR** GOOGLE_API_KEY for Gemini API (text-only analysis, no video rendering)
- GameySins script(s) — plain text, PDF, or markdown
- Browser automation tools (Hermes browser stack) — only if using web UI path

## Workflow (Web UI Path)

### Phase 1: Authentication (Session Live View Method)
```
1. Export Browserbase credentials:
   export BROWSERBASE_API_KEY=bb_live_...
   export BROWSERBASE_PROJECT_ID=<uuid>

2. Start a remote browser session:
   browse open https://notebooklm.google.com
   # ^ This also opens a local 'browse' daemon — keep the terminal alive

3. Get the session ID (most recent running session):
   curl -s -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
     "https://api.browserbase.com/v1/sessions?projectId=$BROWSERBASE_PROJECT_ID&limit=1"

4. Get the Live View URL:
   curl -s -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
     "https://api.browserbase.com/v1/sessions/$SESSION_ID/debug"
   # Extract debuggerFullscreenUrl from response

5. Send the Live View URL to the user. They open it in their own browser
   and sign into Google. The session appears to Google as a legitimate browser.

6. User says "done" — verify authenticated state:
   browse snapshot
   # Look for "Google Account: name (email)" in the output

7. Agent takes over browser control via `browse` commands
```

### Phase 2: Create Notebook & Upload Sources
```
1. On NotebookLM home, click "New Notebook"
2. Name it (e.g., "GameSins - [Game Title] Script")
3. Upload script files as sources:
   - Click "Add Source" → "Upload from device"
   - Or paste script text directly
4. Acceptable formats: PDF, .txt, markdown, Google Docs, YouTube URLs, web links
5. Wait for NotebookLM to process the source (takes 30-60s for medium scripts)
```

**Arabic script note:** NotebookLM handles Arabic text fine. Even extracts from Arabic PDFs. But audio overviews may pronounce Arabic text with American-accented Arabic (the known "flattening" criticism).

### Brand Style Guide Setup

For NotebookLM to consistently adhere to the channel brand, upload a Brand Style Guide as a source document before game scripts. This way every generation references the brand rules.

**Create a brand guide file:**
```bash
cat > /tmp/gamesins-brand-guide.md << 'EOF'
# GameSins Brand Style Guide
- Channel: GameSins - Arabic gaming channel (Egyptian dialect)
- Host: Ammar | Mascot: Mosmar (2-3 lines per video max)
- Format: Comedy gaming reviews, fast-paced
- Language: Egyptian Arabic only
- Social links: @Gameysins on YouTube/Twitch/TikTok/Instagram, Discord/facebook
EOF
```

**Upload as a source via Copied text:**
1. Click Add source (e.g., `browse click 7-1591`)
2. Click Copied text button
3. Paste the brand guide content into the textbox
4. Submit - the guide is now a permanent source
5. Every Studio generation will reference this source alongside game scripts

**Important:** Upload the brand guide FIRST, before any game scripts. This gives the notebook the style context from the start.

### Phase 3: Generate Content

#### Video Overview
```
1. Open the notebook containing the script source
2. Click "Create" → "Video Overview" or select from output options
3. NotebookLM generates a slide-style video with AI narration
4. Wait for generation (30-180s depending on source length)
5. Preview the video
6. Download via Save/Export button
```

#### Slide Deck
```
1. In the notebook, click "Create" → "Slide Deck"
2. Select source(s) to base slides on
3. Choose output format - sections, key points, or custom
4. Generate and download as Google Slides or export
```

#### Infographic
```
1. Click "Create" → "Infographic"
2. Powered by Nano Banana Pro
3. Generates visual summary of key concepts
4. Download as image or PDF
```

### Phase 4: Download & Use in Pipeline
```
1. Download generated video/slides/infographic to a local path
2. Path suggestion: ~/scripts/hyperframes-broll/notebooklm-outputs/
3. Use the content:
   - Video Overview → use as-is or extract key frames for HyperFrames b-roll
   - Slide images → use as overlay backgrounds in HyperFrames compositions
   - Slide Deck → reference for shot planning / visual sequence design
4. If generating b-roll HyperFrames compositions from the output, reference the hyperframes-broll skill

### Auto-Download & Pipeline Integration

When generating b-roll with HyperFrames, also trigger NotebookLM content generation on the same script:

**Workflow:**
1. Take the same script being used for HyperFrames b-roll
2. Upload it as a source to the NotebookLM notebook (or use existing)
3. Generate Video Overview / Slide Deck / Infographic in Studio
4. Generation may take 30-180 seconds - poll for completion
5. Download the output file from NotebookLM
6. Save to target directory (e.g., D: drive)

**Download after generation (browser automation):**
```bash
# After generation completes, find the download button
browse snapshot | grep -i "download\|save\|export"
browse click <download-button-ref>

# In Browserbase sessions, downloads go to the cloud storage
# Use the Browserbase API to retrieve:
curl -s -H "X-BB-API-Key: $BROWSERBASE_API_KEY" \
  "https://api.browserbase.com/v1/sessions/$SESSION_ID/downloads"
```

**Target directory on Windows D: drive:**
```
/mnt/d/NotebookLM-Outputs/
```

Ensure the directory exists:
```bash
mkdir -p /mnt/d/NotebookLM-Outputs/
```
```

## Known Limitations
- **Google login blocks headless/cloud browsers** — Hermes' built-in `browser_*` tools and Browserbase cloud sessions both get blocked. **Session Live View + user authentication** is the only workaround that reliably works on free Browserbase plans.
- **Session Live View is manual** — requires the user to open a link and sign in. Not fully autonomous. But it's a one-time cost per session; after authentication, the agent can fully automate everything inside NotebookLM.
- **`browse` CLI is a separate tool** — Hermes' built-in `browser_*` tools and the `browse` CLI use different provider backends. After live-view login, all automation must go through `browse` CLI (not Hermes' browser tools). This means:
  - Commands: `browse open`, `browse click`, `browse snapshot`, `browse fill`, `browse type`, `browse upload`
  - Refs use `browse snapshot` format (e.g. `7-1277`) not `@e10`
- **Arabic in Video Overviews** — text rendering should work but AI narration will be in English default. No Arabic video narration available as of early 2026.
- **Generation time** — long scripts (>5000 words) may take 2-3 minutes for Video Overview.
- **No batch API** — NotebookLM has no public API. Everything is via web UI. That's why browser automation is the only integration path for the web UI.
- **Session timeout** — Browserbase free sessions expire in ~5 minutes. Use `timeout` param or keep-alive if on a paid plan.

## Pitfalls

### 🚨 BROWSERBASE_PROXIES requires Scale plan
Setting `BROWSERBASE_PROXIES=true` in `~/.hermes/.env` does NOT work on the free/Developer Browserbase plan. Residential proxies require the Scale plan or higher. The warning "Running WITHOUT residential proxies" in browser snapshots confirms proxies aren't active. If you set the var mid-session, Hermes may need a full restart to pick it up.

### 🚨 Browse CLI daemon blocks new sessions after timeout
When a Browserbase session expires (~5 min on free plan), the `browse` daemon enters a zombie state. Retrying `browse open <url>` gives `"Timed out waiting for driver daemon session"`.
**Fix:** Always `browse stop` before `browse open` if a daemon was running previously. The stop kills the dead daemon so a fresh one can be spawned.

### 🚨 Modal or popup intercepts
NotebookLM sometimes shows onboarding dialogs or feature announcements. Check for close buttons before proceeding.

### 🚨 Session timeout
If idle too long, Google may invalidate the session. Check login state before starting. If redirected to sign-in, ask user to re-authenticate.

### 🚨 Source processing failure
Arabic PDFs with images may fail OCR. Prefer plain text or markdown for Arabic scripts. If PDF fails, paste text directly.

### 🚨 Browse CLI ref format differs from Hermes browser tools
`browse snapshot` returns accessibility refs in format `7-1277` (not `@e10`). Use `browse click 7-1277` not `browse click @e10`. The snapshot output is JSON with a `tree` string, `urlMap`, and `xpathMap`. Parse the `tree` field for interactive elements.

### 🚨 Session expires quickly on free plan
Browserbase free sessions last ~5 minutes. If the user takes too long to authenticate, the session dies. If this happens, start over with a fresh `browse open` command and new Live View URL.

### 🚨 Download path
Browser downloads in automation go to the browser's configured download dir. After download, move the file explicitly to the target path. Check ~/Downloads/ or the profile's Download directory after generation.

## Related Skills
- **Browser Automation** — parent skill, covers Playwright setup and session management
- **hyperframes-broll** — auto-generate HyperFrames b-roll from script content
- **hyperframes** — create HyperFrames video compositions
- **gameysinstech-pipeline** / **video-pipeline-agent** — GameySins full production pipeline where NotebookLM output feeds in
