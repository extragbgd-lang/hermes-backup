# Heartbeat System — Deployed Architecture Reference

Two architectures coexist. The **active, production system** is the bash+cron approach.
The Python daemon code is archived for reference but **is not the running system.**

---

## ACTIVE: Bash + Cron (Deployed)

### What's Running

- **Script**: `~/.hermes/scripts/heartbeat_check.sh` (also available in this skill at `scripts/heartbeat_check.sh`)
- **Scheduler**: Hermes cron, no_agent mode
- **Schedule**: Every 5 minutes
- **Delivery**: Discord home channel (only on warnings/failures)
- **Log**: `~/.hermes/logs/heartbeat.log`

### Checks Performed

1. **Gateway** — `systemctl --user is-active hermes-gateway.service`
2. **Disk** — `df --output=pcent /home/ammar` (warning >80%, critical >95%)
3. **RAM** — `free -m` (warning >80%, critical >95%)
4. **Hermes process** — `pgrep -f hermes_cli.main`

### Silent-on-Healthy Pattern

The script produces **empty stdout when everything is healthy**. Hermes cron's no_agent mode
delivers script stdout verbatim — empty stdout = silent delivery (nothing sent to Discord).
Non-empty stdout (warnings/failures) triggers a Discord notification.

```bash
# Cron config
cronjob action=create \
    name="System Heartbeat" \
    script="heartbeat_check.sh" \
    schedule="*/5 * * * *" \
    no_agent=true \
    deliver="discord"
```

### Why Bash + Cron Beat the Python Daemon

| Factor | Bash + Cron | Python Daemon (legacy) |
|--------|-------------|----------------------|
| Lines of code | ~50 | 3,218 |
| Token cost | Zero (no_agent) | LLM invocation per cycle |
| Auto-trigger | Guaranteed (cron scheduler) | Needed manual startup |
| Debuggability | Plain bash + log file | Custom async framework |
| Success rate | Fires reliably | Had import bugs, never auto-ran |

---

## LEGACY: Python Async Daemon (Archived)

The original heartbeat system at `~/.hermes/heartbeat/` is a full async Python daemon.
Its Python files remain on disk but it is **not auto-triggered** and was never successfully deployed.

### Architecture (for reference)

```
┌─────────────────────────────┐
│    HeartbeatDaemon          │
│  (Main coordinator)         │
├─────────────────────────────┤
│ StatusTracker → State       │
│ RecoverySystem → Tiers      │
│ DiscordNotifier → Webhook   │
│ LogManager → Rotation       │
└─────────────────────────────┘
```

### Module Dependencies

- **heartbeat_daemon.py**: Entry point, coordinates all subsystems via asyncio.Event
- **status_tracker.py**: Pure Python state machine, no external dependencies
- **recovery_system.py**: Uses subprocess + logging for tiered recovery
- **discord_notifier.py**: aiohttp + discord.py webhook API
- **log_manager.py**: Logging module with 10MB rotation threshold

### Core Patterns (Legacy)

#### Async Non-Blocking Daemon

```python
async def heartbeat_loop():
    while True:
        await check_main_loop_health()
        await check_api_connectivity()
        await check_model_availability()
        await asyncio.sleep(HEARTBEAT_INTERVAL)
```

#### Tiered Recovery

```
Tier 1: Graceful Restart (SIGTERM + timeout)
   ↓ (fails after cooldown)
Tier 2: Aggressive Restart (force kill)
   ↓ (fails after cooldown)
Tier 3: Snapshot Restore (from checkpoint files)
   ↓ (fails after cooldown)
   Notify User → Final fallback to Hermes restart
```

#### Recovery Backoff

Exponential backoff: 10s, 30s, 60s with jitter (-20% to +20%).

#### State Machine

States: idle, processing, waiting_for_input, completed, failed, stalled, disconnected, rate_limited.
Forbidden transitions enforced to prevent race conditions.

### Why It Never Worked

1. **No auto-trigger mechanism** — No cron, systemd, or background process ever started it
2. **Import bugs** — `start_heartbeat.py` referenced `setup_heartbeat_logger()` which didn't exist in `log_manager.py`
3. **Dict vs attribute access** — `args.verbose` used dot notation instead of `args['verbose']`
4. **No startup wiring** — The `__main__.py` created by setup_heartbeat.py was never invoked by anything

### Lesson

> A 3,000-line monitoring system that never auto-triggers is worse than no monitoring at all.
> It creates false confidence. Always verify autonomous execution before trusting a monitoring system.

---

## Migration Checklist (Bash → Python if needed later)

If you ever need the Python daemon's capabilities (process recovery, state tracking, sub-minute intervals):

- [ ] Fix import bugs in `start_heartbeat.py` (dict attribute access, missing log_manager exports)
- [ ] Create a systemd user service (`~/.config/systemd/user/hermes-heartbeat.service`)
- [ ] Enable and start: `systemctl --user enable --now hermes-heartbeat`
- [ ] Remove the bash+cron job via `cronjob action=remove job_id=...`

Until those boxes are checked, the bash+cron approach is the correct running system.

---

## Files Referenced

| Path | Purpose |
|------|---------|
| `~/.hermes/scripts/heartbeat_check.sh` | Active heartbeat script |
| `~/.hermes/logs/heartbeat.log` | Heartbeat log file |
| `~/.hermes/logs/heartbeat_alerts.log` | Failure-only log |
| `~/.hermes/heartbeat/` | Legacy Python daemon files |
| `~/.hermes/archive/` | Archived broken entrypoints |

MIT License (Apache 2.0) © 2025-2026 GameySins / Hermes Team
