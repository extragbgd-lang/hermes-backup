# LLM Provider API Health Monitoring

Monitor LLM API keys + free model availability via a scheduled no_agent cron script.
Delivers status reports to the user's home channel with zero token cost.

## When to Use

- User wants to know which free LLM alternatives are currently working
- User wants automated periodic checks of API key validity + model availability
- User asks for a "heartbeat" or "health check" for LLM providers specifically

## Architecture

```
Script: ~/.hermes/scripts/llm_heartbeat_check.py
Log:    ~/.hermes/logs/llm_heartbeat.log
Cron:   no_agent=true, schedule=0 */4 * * *
```

Zero token cost — the script runs standalone and its stdout is delivered verbatim.

## Setup Steps

### 1. Ensure all API keys are accessible from the script

The script reads keys from `~/.hermes/.env` using env var names:

| Var | Provider | How to get |
|-----|----------|------------|
| `OPENROUTER_API_KEY` | OpenRouter (free models) | Already in .env |

If a key lives only in `config.yaml`, add it to `.env`:
```
echo "OPENROUTER_API_KEY=<key>" >> ~/.hermes/.env
```

### 2. Create the heartbeat script (`~/.hermes/scripts/llm_heartbeat_check.py`)

Template structure:

```python
#!/usr/bin/env python3
"""LLM API Keys & Free Models Heartbeat.

Checks: LM Studio local (primary gemma-4-e2b, fallback qwen3.5-9b),
OpenRouter free (owl-alpha). Reports status to home channel.
"""

import json, os, re, subprocess, time
from datetime import datetime

HOME = os.path.expanduser("~")
ENV_FILE = os.path.join(HOME, ".hermes", ".env")
LOG_FILE = os.path.join(HOME, ".hermes", "logs", "llm_heartbeat.log")

# Helper: read env var from .env
def get_env_val(key: str) -> str | None:
    if not os.path.exists(ENV_FILE): return None
    with open(ENV_FILE) as f:
        for line in f:
            line = line.strip()
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")

# Helper: curl-based HTTP POST (more reliable than urllib for some endpoints)
def curl_post(url, data, bearer=None, timeout=15):
    t0 = time.time()
    cmd = ["curl", "-s", "-w", "\n%{http_code}", "-X", "POST", url,
           "-H", "Content-Type: application/json", "-m", str(timeout)]
    if bearer: cmd += ["-H", f"Authorization: Bearer {bearer}"]
    cmd += ["-d", json.dumps(data)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout+5)
    lat = (time.time() - t0) * 1000
    lines = r.stdout.strip().rsplit("\n", 1)
    code = int(lines[1].strip()) if len(lines) == 2 else 0
    return code, lines[0].strip() if len(lines) == 2 else r.stdout.strip(), lat
```

### 3. Register the cron job

```bash
cronjob action=create \
    name="LLM Heartbeat — Free Provider Check" \
    script="llm_heartbeat_check.py" \
    schedule="0 */4 * * *" \
    no_agent=true \
    deliver=origin
```

## What Gets Checked

| Provider | Check Type | Endpoint |
|----------|-----------|----------|
| **LM Studio (primary)** | Chat completion | `POST http://192.168.100.17:1234/v1/chat/completions` with `google/gemma-4-e2b` |
| **LM Studio (fallback 1)** | Chat completion | `POST http://192.168.100.17:1234/v1/chat/completions` with `qwen/qwen3.5-9b` |
| **OpenRouter (fallback 2)** | Chat completion | `POST https://api.openrouter.ai/v1/chat/completions` with `openrouter/owl-alpha` |

## Output Format

The script prints a Discord/Telegram-friendly Markdown report:

```
📡 **LLM Heartbeat — 2026-05-24 13:01**

  ✅ **LM Studio (local) — gemma-4-e2b** (134ms)
     Primary model loaded and responding
  ✅ **LM Studio (local) — qwen3.5-9b** (150ms)
     Fallback model responding
  ✅ **OpenRouter — owl-alpha** (588ms)
     Free model responding

**✅ All Clear** — 3 providers healthy
```

## Testing

Run manually at any time:
```bash
python3 ~/.hermes/scripts/llm_heartbeat_check.py
```

Check the log:
```bash
tail -20 ~/.hermes/logs/llm_heartbeat.log
```

Verify the cron job:
```bash
cronjob action=list
# Find "LLM Heartbeat" and check next_run_at
```

## Pitfalls

- **LM Studio must be running** — if the local server at 192.168.100.17:1234 is down, all local checks fail. Verify with `curl -s http://192.168.100.17:1234/v1/models`.
- **OpenRouter requires an API key even for free ($0) models** — without `OPENROUTER_API_KEY` set, all requests return 401. This is required for rate limiting/auth even on free models.
- **OpenRouter free model availability rotates** — the specific free model `openrouter/owl-alpha` may change. The script can dynamically list available free models.
- **curl via subprocess** is more reliable than Python's `urllib` for some API endpoints (auth header handling, SSL quirks). Use it as the transport layer.
