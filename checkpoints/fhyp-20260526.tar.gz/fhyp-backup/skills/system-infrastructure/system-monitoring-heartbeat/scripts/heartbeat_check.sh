#!/bin/bash
# ─── Hermes Heartbeat Check ───────────────────────────────────────────────
# Runs every 5 minutes via cron. Checks gateway health, disk, memory, and Paperclip.
# Logs to ~/.hermes/logs/heartbeat.log
# ───────────────────────────────────────────────────────────────────────────

LOG_DIR="$HOME/.hermes/logs"
LOG_FILE="$LOG_DIR/heartbeat.log"
mkdir -p "$LOG_DIR"

log() {
    local level="$1"
    local msg="$2"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $msg" >> "$LOG_FILE"
}

ok=0
warn=0
fail=0

# ── 1. Gateway ────────────────────────────────────────────────────────
if systemctl --user is-active hermes-gateway.service &>/dev/null; then
    log "OK" "Gateway: running"
    ok=$((ok + 1))
else
    log "WARN" "Gateway: NOT running"
    warn=$((warn + 1))
fi

# ── 2. Disk usage ─────────────────────────────────────────────────────
DISK_USAGE=$(df /home/ammar --output=pcent 2>/dev/null | tail -1 | tr -d ' %' || echo "0")
if [ "$DISK_USAGE" -lt 80 ] 2>/dev/null; then
    log "OK" "Disk: ${DISK_USAGE}% used"
    ok=$((ok + 1))
elif [ "$DISK_USAGE" -lt 95 ] 2>/dev/null; then
    log "WARN" "Disk: ${DISK_USAGE}% used — getting full"
    warn=$((warn + 1))
else
    log "FAIL" "Disk: ${DISK_USAGE}% used — CRITICAL"
    fail=$((fail + 1))
fi

# ── 3. Memory ──────────────────────────────────────────────────────────
MEM_TOTAL=$(free -m | awk '/^Mem:/ {print $2}')
MEM_USED=$(free -m | awk '/^Mem:/ {print $3}')
if [ -n "$MEM_TOTAL" ] && [ "$MEM_TOTAL" -gt 0 ] 2>/dev/null; then
    MEM_PCT=$((MEM_USED * 100 / MEM_TOTAL))
    if [ "$MEM_PCT" -lt 80 ]; then
        log "OK" "RAM: ${MEM_PCT}% used (${MEM_USED}M/${MEM_TOTAL}M)"
        ok=$((ok + 1))
    elif [ "$MEM_PCT" -lt 95 ]; then
        log "WARN" "RAM: ${MEM_PCT}% used (${MEM_USED}M/${MEM_TOTAL}M)"
        warn=$((warn + 1))
    else
        log "FAIL" "RAM: ${MEM_PCT}% used — CRITICAL"
        fail=$((fail + 1))
    fi
else
    log "WARN" "RAM: could not determine"
    warn=$((warn + 1))
fi

# ── 4. Hermes process responsiveness ──────────────────────────────────
HERMES_PID=$(pgrep -f "hermes_cli.main" 2>/dev/null || true)
if [ -n "$HERMES_PID" ]; then
    HERMES_CPU=$(ps -p "$HERMES_PID" -o %cpu --no-headers 2>/dev/null || echo "0")
    HERMES_MEM=$(ps -p "$HERMES_PID" -o %mem --no-headers 2>/dev/null || echo "0")
    log "OK" "Hermes: PID $HERMES_PID (CPU: ${HERMES_CPU}%, MEM: ${HERMES_MEM}%)"
    ok=$((ok + 1))
else
    log "WARN" "Hermes: no running process found"
    warn=$((warn + 1))
fi

# ── 5. Paperclip server ──────────────────────────────────────────────
PAPERCLIP_API="http://127.0.0.1:3100/api/health"
PAPERCLIP_DIR="/home/ammar/.npm/_npx/43414d9b790239bb/node_modules/@paperclipai/server"
PAPERCLIP_PID=$(pgrep -f "paperclipai/server/dist/index" 2>/dev/null || true)

if curl -sf --connect-timeout 3 "$PAPERCLIP_API" &>/dev/null; then
    log "OK" "Paperclip: running and responding"
    ok=$((ok + 1))
elif [ -n "$PAPERCLIP_PID" ]; then
    log "WARN" "Paperclip: PID $PAPERCLIP_PID exists but not responding on :3100"
    warn=$((warn + 1))
else
    log "WARN" "Paperclip: NOT running — attempting restart..."
    warn=$((warn + 1))
    if [ -f "$PAPERCLIP_DIR/dist/index.js" ]; then
        nohup node "$PAPERCLIP_DIR/dist/index.js" &>/dev/null &
        log "INFO" "Paperclip: restart initiated (PID $!)"
        sleep 3
        if curl -sf --connect-timeout 3 "$PAPERCLIP_API" &>/dev/null; then
            log "OK" "Paperclip: restart SUCCESSFUL"
        else
            log "FAIL" "Paperclip: restart FAILED — server not responding"
            fail=$((fail + 1))
        fi
    else
        log "FAIL" "Paperclip: cannot restart — server files not found"
        fail=$((fail + 1))
    fi
fi

# ── Summary ──────────────────────────────────────────────────────────
log "INFO" "Heartbeat complete: ${ok} ok, ${warn} warnings, ${fail} failures"

if [ "$fail" -gt 0 ] || [ "$warn" -gt 0 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ${ok} ok, ${warn} w, ${fail} f" >> "$LOG_DIR/heartbeat_alerts.log"
    echo "⚠️ Hermes Heartbeat — ${ok} ok, ${warn} warning(s), ${fail} failure(s)"
    [ "$fail" -gt 0 ] && echo "Check ~/.hermes/logs/heartbeat.log for details"
fi

# Silent exit when healthy — no stdout = no Discord delivery
