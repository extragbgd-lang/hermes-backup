#!/bin/bash
# Hermes Config Backup to GitHub — reference implementation
# Deploy via: cronjob action=create name="..." script="backup_hermes.sh" schedule="0 0 */2 * *" no_agent=true
# Backs up ~/.hermes/*.md to a private GitHub repo using GitHub API (no git CLI needed).
# Uses MD5 change detection — skips if nothing changed. Silent on no-changes (no cron delivery).

set -euo pipefail

BACKUP_DIR="$HOME/.hermes"
TOKEN_FILE="$HOME/.hermes/.github_backup_token"
LOG_FILE="$HOME/.hermes/logs/backup.log"
STATE_FILE="$HOME/.hermes/.backup_state"
REPO="extragbgd-lang/hermes-backup"
BRANCH="main"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

mkdir -p "$HOME/.hermes/logs"

log() {
    local level="$1"
    local msg="$2"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $msg" >> "$LOG_FILE"
}

if [ ! -f "$TOKEN_FILE" ]; then
    log "FAIL" "No token file at $TOKEN_FILE"
    echo "ERROR: No GitHub token. Run setup first."
    exit 1
fi
GITHUB_TOKEN=$(cat "$TOKEN_FILE" | tr -d '\n\r ')

# NOTE: config.yaml is excluded — contains API keys/secrets
# that GitHub secret scanning blocks (and shouldn't be uploaded)
FILES=("SOUL.md" "agent.md" "heartbeat_config.json")

# ── Change detection ────────────────────────────────────────────────
if [ -f "$STATE_FILE" ]; then
    CHANGED=0
    for f in "${FILES[@]}"; do
        if [ -f "$BACKUP_DIR/$f" ]; then
            HASH=$(md5sum "$BACKUP_DIR/$f" | cut -d' ' -f1)
            STORED=$(grep "^$f:" "$STATE_FILE" 2>/dev/null | cut -d: -f2 || echo "")
            [ "$HASH" != "$STORED" ] && CHANGED=1 && log "INFO" "Change: $f"
        fi
    done
    [ "$CHANGED" -eq 0 ] && log "INFO" "No changes. Skipping." && exit 0
fi

log "INFO" "Starting backup..."

# ── Ensure repo exists ──────────────────────────────────────────────
REPO_EXISTS=$(curl -s -o /dev/null -w "%{http_code}" \
    -H "Authorization: Bearer $GITHUB_TOKEN" \
    "https://api.github.com/repos/$REPO" 2>/dev/null || echo "000")

IS_NEW_REPO=false
if [ "$REPO_EXISTS" = "404" ]; then
    log "INFO" "Creating repo $REPO..."
    CREATE_RESP=$(curl -s -X POST \
        -H "Authorization: Bearer $GITHUB_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"name":"hermes-backup","private":true,"auto_init":true}' \
        "https://api.github.com/user/repos" 2>/dev/null)
    log "OK" "Repo created."
    IS_NEW_REPO=true
    DEFAULT_BRANCH=$(echo "$CREATE_RESP" | python3 -c \
        "import sys,json; print(json.load(sys.stdin).get('default_branch','main'))" 2>/dev/null || echo "main")
    BRANCH="$DEFAULT_BRANCH"
fi

# ── Upload each file via GitHub Contents API ────────────────────────
upload_file() {
    local local_path="$1" remote_path="$2"
    [ ! -f "$local_path" ] && log "WARN" "Not found: $local_path" && return 1

    file_content=$(base64 -w0 "$local_path" 2>/dev/null || base64 "$local_path")

    SHA_RESP=$(curl -s -H "Authorization: Bearer $GITHUB_TOKEN" \
        "https://api.github.com/repos/$REPO/contents/$remote_path" 2>/dev/null)
    EXISTING_SHA=$(echo "$SHA_RESP" | python3 -c \
        "import sys,json; d=json.load(sys.stdin); print(d.get('sha',''))" 2>/dev/null || echo "")

    if [ -n "$EXISTING_SHA" ]; then
        PAYLOAD=$(python3 -c "
import json
print(json.dumps({'message':'Backup $remote_path - $TIMESTAMP','content':'$file_content','sha':'$EXISTING_SHA','branch':'$BRANCH'}))")
    else
        PAYLOAD=$(python3 -c "
import json
print(json.dumps({'message':'Initial $remote_path - $TIMESTAMP','content':'$file_content','branch':'$BRANCH'}))")
    fi

    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X PUT \
        -H "Authorization: Bearer $GITHUB_TOKEN" \
        -H "Content-Type: application/json" \
        -d "$PAYLOAD" \
        "https://api.github.com/repos/$REPO/contents/$remote_path" 2>/dev/null)

    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "201" ]; then
        log "OK" "Uploaded $remote_path"; return 0
    else
        log "FAIL" "Upload $remote_path failed (HTTP $HTTP_CODE)"
        return 1
    fi
}

SUCCESS=0; FAIL=0
for f in "${FILES[@]}"; do
    if [ -f "$BACKUP_DIR/$f" ]; then
        upload_file "$BACKUP_DIR/$f" "$f" && SUCCESS=$((SUCCESS+1)) || FAIL=$((FAIL+1))
    fi
done

# ── Save state for next change detection ────────────────────────────
> "$STATE_FILE"
for f in "${FILES[@]}"; do
    if [ -f "$BACKUP_DIR/$f" ]; then
        echo "$f:$(md5sum "$BACKUP_DIR/$f" | cut -d' ' -f1)" >> "$STATE_FILE"
    fi
done

log "INFO" "Backup complete: ${SUCCESS} ok, ${FAIL} failed"
[ "$FAIL" -gt 0 ] && echo "⚠️ Backup: ${SUCCESS} ok, ${FAIL} failed" && exit 1
