---
name: system-monitoring-heartbeat
description: Heartbeat daemon, recovery patterns, Discord webhook notifications for Hermes monitoring subsystems
trigger_conditions:
  - Building persistent background monitoring/watchdog services
  - Implementing fault-tolerant processes with automatic recovery
  - Configuring notification infrastructure (Discord webhooks)
  - Designing non-blocking async daemons
  - Setting up tiered recovery strategies (graceful → aggressive → restore)
  - Debugging why a monitoring/watchdog system isn't actually firing
  - Deciding between a Python daemon vs. cron-based health checks
  - Auditing whether existing monitoring is genuinely functional

---

## Overview

This skill covers the **Heartbeat System** - a persistent watchdog/monitoring subsystem for Hermes that continuously monitors task execution, agent responsiveness, terminal activity, and tool status, providing automatic recovery and Discord notifications.

Based on OpenClaw's monitoring behavior, this system ensures Hermes stays healthy, recovers from failures automatically, and keeps users informed.

## Architecture

### Non-Blocking Async Daemon Pattern

```python
class HeartbeatDaemon:
    """Async heartbeat daemon that runs continuously without blocking main process."""
    
    def __init__(self, config: dict, logger):
        self.config = config  # heartbeat_interval_seconds, stall_timeout_seconds, etc.
        self.logger = logger
        
    async def start(self):
        while True:
            await self.check_health()
            await asyncio.sleep(self.config["heartbeat_interval_seconds"])
```

**Key Principle**: Monitor using async/await to keep main process alive. Only restart Hermes after all recovery attempts fail.

## Subsystems Monitored

| Subsystem | Check Frequency | Health Indicator |
|-----------|-----------------|------------------|
| `main_loop` | Every heartbeat cycle | Active tasks count > 0 |
| `api_client` | Every heartbeat cycle | Connected & response < timeout |
| `model_server` | Every heartbeat cycle | Latency within bounds (e.g., <50ms) |
| `discord_notifier` | On send attempts | Last webhook send < cooldown_timeout |
| `terminal` | Every terminal output | Output within stall_timeout_seconds |

## Status States & Transitions

### States to Track

- **idle**: No active tasks, monitoring continuously
- **processing**: Task actively executing
- **completed**: Task finished successfully  
- **failed**: Task encountered error
- **stalled**: No progress for configurable timeout (default 30s)
- **disconnected**: Model/API disconnected
- **rate_limited**: API rate limit hit

### Allowed Transitions

```python
{
    "idle": [],
    "processing": ["idle"],
    "waiting_for_input": ["processing", "completed", "failed"],
    "completed": ["waiting_for_input"],
    "failed": ["waiting_for_input"],
    "stalled": ["processing", "waiting_for_input"],
    "disconnected": ["model_server"],
    "rate_limited": ["api_client"]
}
```

## Recovery System (CRITICAL PRIORITY ORDER)

### Priority Order for Recovery

1. Preserve task state ← NEVER skip this step
2. Recover subsystem ← Attempt recovery below
3. Notify user ← Discord webhook notification  
4. Restart subsystem ← If recovery 1-2 failed
5. Restart Hermes ← FINAL FALLBACK only

### Tiered Recovery Strategies

#### Graceful (recommended for production)

```python
async def graceful_recovery(subsystem: str):
    """SIGTERM → wait timeout → force kill."""
    
    process = await get_subprocess(subsystem)
    process.send_signal(signal.SIGTERM)
    
    await asyncio.sleep(config["graceful_shutdown_timeout"])  # e.g., 30s
    
    if not process.is_alive():
        return True
    
    process.kill()  # SIGKILL
    return False
```

#### Aggressive (skip grace period)

```python
async def aggressive_recovery(subsystem: str):
    """Immediate force kill without warning."""
    
    process = await get_subprocess(subsystem)
    process.kill()  # Immediate SIGKILL
    
    return True
```

### Recovery Backoff Pattern

```python
async def recover_with_backoff(subsystem: str, max_attempts: int = 3):
    base_delay = 10
    
    for attempt in range(max_attempts):
        logger.info(f"Recovery attempt {attempt + 1}/{max_attempts} for {subsystem}")
        
        result = await try_graceful_recovery(subsystem)
        if success:
            return True
        
        delay = min(base_delay * (2 ** attempt), config["recovery_cooldown_seconds"])
        jitter = random.uniform(-delay * 0.2, delay * 0.2)
        
        await asyncio.sleep(delay + jitter)
    
    return False  # Max attempts exceeded - notify user
```

## Discord Webhook Notifications

### Configuration (`~/.hermes/heartbeat_config.json`)

```json
{
  "enable_notifications": false,
  "discord_webhook_url": "",
  "notification_prefix": "[Hermes Heartbeat]",
  "recovery_cooldown_seconds": 30,
  "max_recovery_attempts": 3
}
```

### Notification Format

```text
[Hermes Heartbeat] Status: <STATUS>
Task: <task_name>
Runtime: <elapsed_time>
Model: <model_endpoint>
System: CPU <cpu>% | RAM <memory>%
Last Output: <latest_terminal_line>

[DETAILS ONLY ON FAILURE/RECOVERY]
Recovery: Attempted graceful restart
Details: Terminal subprocess timed out after 45s idle. Initiating restart...
```

## Logging Structure

| File | Purpose | Rotation |
|------|---------|----------|
| `heartbeat.log` | Main monitoring cycles | 10MB max |
| `tasks.log` | Task execution events | 10MB max |
| `terminal.log` | Terminal/subprocess output | 10MB max |
| `recovery.log` | Recovery attempts (audit) | No rotation |

## CLI Commands

| Command | Purpose | Output Example |
|---------|---------|----------------|
| `/heartbeat status` | Check health, uptime, latency | Status: idle, CPU 5%, latency 8ms |
| `/heartbeat logs` | View structured logs | Last 100 lines of heartbeat.log |
| `/heartbeat restart` | Graceful daemon restart | Restarted in 2.3s |
| `/heartbeat pause` | Pause monitoring (debugging) | Monitoring paused |
| `/heartbeat resume` | Resume paused monitoring | Resumed from idle state |

## Testing

### Import Test

```python
import sys
sys.path.insert(0, '/home/ammar/.hermes/heartbeat')

from heartbeat_daemon import HeartbeatDaemon
from status_tracker import StatusTracker
from recovery_system import RecoveryOrchestrator, RecoveryStrategy

print("✓ All core modules imported successfully")
```

### Configuration Validation

```python
import json
with open('/home/ammar/.hermes/heartbeat_config.json') as f:
    config = json.load(f)
assert "heartbeat_interval_seconds" in config
assert "recovery_strategy" in config
print("✓ Configuration valid")
```

## Practical Lightweight Alternative (Bash + Cron)

For most health-check use cases, a **bash script + Hermes cron in no_agent mode** beats a full Python async daemon:

- **Zero token cost** — no_agent mode delivers script stdout verbatim, no LLM invocation
- **~50 lines** vs. 3,000+ lines of Python — easier to debug, maintain, and audit
- **Guaranteed to fire** — cron scheduler is production-hardened and visible in `cronjob list`
- **Logs to a plain file** — no custom logging framework needed

### Canonical Implementation (`~/.hermes/scripts/heartbeat_check.sh`)

> A reference copy of this script is also available inside this skill at `scripts/heartbeat_check.sh` — ready to copy for fresh deployments.

```bash
#!/bin/bash
# Checks: gateway status, disk usage, RAM, Hermes process, Paperclip health
LOG_FILE="$HOME/.hermes/logs/heartbeat.log"
mkdir -p "$(dirname "$LOG_FILE")"

check_gateway() {
    systemctl --user is-active hermes-gateway.service &>/dev/null
}
check_disk() {
    df /home/ammar --output=pcent | tail -1 | tr -d ' %'
}
check_ram() {
    free -m | awk '/^Mem:/ {printf "%d %d", $3, $2}'
}
check_hermes() {
    pgrep -f "hermes_cli.main" >/dev/null
}
check_paperclip() {
    curl -sf --connect-timeout 3 "http://127.0.0.1:3100/api/health" >/dev/null
}

# Run checks, log results, exit with summary
```

### Scheduling with Hermes Cron

```bash
# Create a no_agent job — script output delivered verbatim, zero LLM cost
cronjob action=create \\
    name="System Heartbeat" \\
    script="heartbeat_check.sh" \\
    schedule="*/5 * * * *" \\
    no_agent=true
```

### LLM Provider API Health Monitoring

For monitoring API keys + free model availability across multiple LLM providers (OpenCode Go, OpenRouter, Groq, LM Studio, Google Gemini), use a **Python + curl script in no_agent cron mode**. Zero token cost, delivered to the user's home channel.

**Reference:** `references/llm-provider-monitoring.md` in this skill.

Key insight: Python beats bash for API work (JSON parsing, error handling, multiple endpoint types), but use `subprocess.run(["curl", ...])` instead of `urllib` — it's more reliable with auth headers and SSL quirks across different API providers.

### When to Use Each Approach

| Use Case | Bash + Cron no_agent | Python + Cron no_agent | Full Python Daemon |
|----------|----------------------|------------------------|-------------------|
| Gateway/disk/RAM health | ✅ Best choice | ⚠️ Overkill | ❌ Overkill |
| LLM API key/model checks | ❌ Bash awkward for JSON APIs | ✅ Best choice | ❌ Overkill |
| Process-level recovery | ❌ Can't send signals | ❌ Can't send signals | ✅ Uses subprocess |
| Complex state machine | ❌ No state tracking | ❌ No state tracking | ✅ StatusTracker class |
| Discord notifications | ❌ Would need separate script | ❌ Would need separate script | ✅ Built-in notifier |
| Sub-5s check intervals | ❌ Cron granularity limit | ❌ Cron granularity limit | ✅ Async loop |
| First-time setup audit | ✅ Always | ✅ Always | ❌ Risk of dead code |

## Related: Automated Config Backup to GitHub

When you need to back up Hermes config files (SOUL.md, agent.md, etc.) to a private GitHub repo, use the same bash + cron no_agent pattern.

**Reference script:** `scripts/backup_hermes.sh` in this skill's directory.

### Setup

1. Create a GitHub personal access token (classic with `repo` scope, or fine-grained with `Contents: Read and write`)
2. Store it: `echo "ghp_..." > ~/.hermes/.github_backup_token && chmod 600 ~/.hermes/.github_backup_token`
3. Create a private repo on GitHub manually (the token typically can't create repos — fix permissions first)
4. Deploy via Hermes cron:
   ```bash
   cronjob action=create name="Hermes Config Backup" script="backup_hermes.sh" schedule="0 0 */2 * *" no_agent=true
   ```

### Important

- **Do NOT back up config.yaml** — it contains API keys/secrets. GitHub secret scanning blocks them and you should not upload credentials anyway.
- **Change detection built in** — md5 hash comparison skips the upload if nothing changed, so no silent cron spam.
- **Silent on no-changes** — empty stdout = no delivery. Only outputs on failures.

---

## Pitfalls & Best Practices

### ⚠️ VERIFY THE MONITORING SYSTEM ACTUALLY FIRES (critical)

This is the #1 failure mode. A monitoring system with 3,000+ lines of code that **never auto-triggers** is worse than no monitoring at all — it creates false confidence.

**Checklist to verify a monitoring system works autonomously:**

1. Is there a cron job / systemd timer / background process that starts it automatically? Check: `cronjob list`, `systemctl --user list-timers`, `ps aux | grep heartbeat`
2. Can you run the check manually right now? Do it: if it errors on manual run, it will never work autonomously.
3. Is the check actually producing output? Check the log file for timestamps.
4. Did the cron job actually execute? Use `cronjob list` and check `last_run_at`.

### ⚠️ Avoid Overengineering Monitoring

A 50-line bash script that reliably runs every 5 minutes is **infinitely more valuable** than a 3,000-line Python daemon that never starts. Start simple. Add complexity only when you have a concrete need for state tracking, recovery automation, or sub-minute intervals.

### ⚠️ NEVER Terminate Main Process Early

Only restart Hermes after all recovery attempts fail. Attempt recovery → Notify user → Final fallback only if truly unrecoverable.

### ⚠️ Configure Discord Before Testing

Always set `discord_webhook_url` before enabling `enable_notifications`.

### ✅ Use Graceful Strategy for Production

```json
{"recovery_strategy": "graceful"}  // Avoid aggressive unless necessary!
```

---

MIT License (Apache 2.0) © 2025-2026 GameySins / Hermes Team