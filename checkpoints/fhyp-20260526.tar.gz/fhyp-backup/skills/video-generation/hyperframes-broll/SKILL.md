---
name: hyperframes-broll
description: Auto-generate HyperFrames b-roll compositions from video scripts — section intros + kinetic presentation scenes. Egyptian Arabic, GameySins brand.
version: 5.0
trigger: hyperframes-broll
aliases:
  - broll
  - b-roll
  - b roll
  - generate-broll
  - broll-generator
  - hyperframes-generator
  - script-to-video
  - broll-pipeline
  - scene-generator
  - video-compositions
  - composition-generator
  - hyperframes-scene
toolsets:
  - terminal
  - file
---

# 🤖 B-Roll Generation Agent — GameySins

## How This Agent Works

When the user mentions B-roll, b-roll, compositions, scenes, or script-to-video, this agent loads **automatically** and follows the workflow below.

**This is a FULLY AUTONOMOUS agent.** You do NOT need to prompt the user step-by-step — just follow the sequence:

**Workflow selector:**
- User says "quick", "fast", "simple", or provides a short script → use the **Quick Pipeline** (Step 2a: CLI generate)
- User says "professional", "varied outputs", "diagrams", "storyboard", "html page with full flow", or provides a long/multi-scene script → use the **Professional Pipeline** (Step 2b: varied multi-output)
- Default behavior: **Professional Pipeline**. The user expects full-quality outputs unless they say otherwise.

1. Get the script → 2. Choose pipeline → 3. Show the plan → 4. Wait for approval → 5. Generate → 6. Fix generated HTML → 7. Lint & validate → 8. Deliver to Notion → 9. Tell them how to render

**CRITICAL — Language Rule:** English only in chat with Ammar. Arabic is exclusively for content output files (scripts, HTML compositions, SVG diagrams, Notion pages). Never use Arabic in chat messages — not even when quoting or explaining Arabic content. A single Arabic word in chat is a bug.

---

## 🚨 CRITICAL: Agent Instructions (MANDATORY)

### Step 0 — Load This Skill
When the user mentions "b roll", "b-roll", "compositions", "scenes", "generate video", "script to video", or anything about GameySins video production:
- **IMMEDIATELY** load this skill
- Use the **CORRECT** pipeline: `/home/ammar/scripts/hyperframes-broll` (v4.1+ Python pipeline, symlinked as `hyperframes-broll`)
- **NEVER** use `/home/ammar/scripts/hyperframes-broll-cli.py` (that generates JSON — BROKEN for HyperFrames)

### Step 1 — Get the Script
If the user hasn't provided a script yet, **ask for it immediately**. Do NOT generate placeholder content.

### Step 2 — Show the Plan
For each line in the script, show:
- Scene number + type (opener/gameplay/comparison/stats/outro/presentation)
- What text will appear on screen (Egyptian Arabic)
- Duration (12-15s per scene)
- Motion/energy description

### Step 3 — Wait for Approval
Do NOT generate until the user says "go", "ok", "proceed", or equivalent.
### Step 2a — Quick Pipeline (CLI Generate)

**Use when:** User says "quick", "fast", "simple", or has a short script (3-5 scenes).

```bash
cat script.txt | hyperframes-broll
hyperframes-broll script.txt
```

### Step 2b — Professional Pipeline (Varied Multi-Output)

**Use when:** User says "professional", "varied outputs", "diagrams", "storyboard", or provides a long/multi-scene script (6+ scenes). This is the DEFAULT.

**Read the script carefully BEFORE anything else.** Extract what each scene actually means — don't just list lines. For each line, ask: "What does this scene communicate? What visual treatment matches it?"

Then generate THREE output types in parallel:

**Output A — SVG Diagrams:** Generate Mermaid CLI diagrams that illustrate the script's key concepts:
- Comparisons → `flowchart TD` decision diagram
- Evolution → `timeline` chart
- Stats → `pie` chart or `quadrantChart`
- Save to `{SCENE_NAME}/diagrams/`

```bash
mmdc -i /tmp/diagram.mmd -o "diagrams/name.svg" -w 1600 -H 900 --backgroundColor transparent
```

**Output B — HTML Storyboard Page:** Create a standalone HTML page (`storyboard.html`) showing the full video flow with:
- Header with title, total duration, scene count
- Embedded diagram previews (image cards showing the SVGs)
- Timeline bar showing each scene segment proportional to duration
- Scene cards for each scene: number, type badge, duration, on-screen Arabic text, description, motion choreography, verb tags
- Local @font-face for Cairo + Rubik
- GameSins brand colors (neon red #ff0040, neon blue #00d4ff, black #050508)

**Output C — HyperFrames Composition:** Create a single `index.html` with all scenes:
- 12-scene max per file (warn the user if exceeding for split consideration)
- Transition overlay crossfade between scenes
- Each scene: background layer + content/midground + accents
- Split-screen layouts for comparison scenes (not sequential bullets)
- 5-6 animation steps per scene, 3+ different eases
- No exit animations except on final scene (outro)
- Proper `data-composition-id`, `data-start`, `data-duration` attributes
- `window.__timelines["id"] = tl` registration

### Step 4b — Professional Pipeline: Generate Sub-Compositions

After creating the main `index.html`, also create:
1. **Diagrams b-roll** — `compositions/diagrams-broll/index.html` with one animated scene per SVG diagram. Each scene: title header + framed SVG + pulsing overlay dots. 10-12s per diagram. Local `fonts/` + `assets/` with copied files.
2. **Storyboard b-roll** — `compositions/storyboard-broll/index.html` showing the full video flow. Scene 1: overview stats. Scene 2: scene card grid (4×3) cascading in with progress bar.

Each sub-composition needs its own `fonts/` directory with COPIED .ttf files (not symlinks) and local `assets/` for SVGs. Font `@font-face` path in these sub-comps: `url('fonts/...ttf')` (no `../` prefix).

### Step 5 — Tell User to Render + Show Exact File Locations

**CRITICAL — Users cannot find files unless you show the exact Windows path.** Always include:
```
📁 All files at: D:\Hermes project\output\videos\hyperframes\SCENE_NAME\
   ├── index.html          ← Main composition
   ├── storyboard.html     ← Storyboard preview
   ├── diagrams/           ← SVG diagrams
   ├── fonts/              ← Font files
   └── rendered/           ← Output mp4s
```

```cmd
From Windows CMD:
  cd /d D:\\\\Hermes project\\\\output\\\\videos\\\\hyperframes
  render_all.bat
```
From Windows CMD:
  cd /d D:\\Hermes project\\output\\videos\\hyperframes
  render_all.bat
```
Or individually: `npx hyperframes render --dir "D:\\Hermes project\\output\\videos\\hyperframes\\SCENE_NAME" --output "D:\\Hermes project\\output\\videos\\hyperframes\\rendered\\SCENE_NAME.mp4"`

---

## 📝 Script Input Formats

The pipeline supports **two input formats** in the same file:

### Format 1: Section Intros (one line = one scene)
```
PC vs Console Dramatic Opening
Gaming 2020 versus Gaming 2026 Evolution
اشترك الآن في قناة GameySins
```
Each line becomes a scene, auto-classified into type.

### Format 2: Presentation Scenes (## header + - bullets)
```
## مقارنة بي سي و كونسول
- بي سي أداء أعلى و تخصيص كامل
- كونسول أرخص و أسهل في التشغيل
- الفرق واضح في الألعاب الثقيلة
```
Each `## Title` with `- bullet` lines becomes a kinetic presentation scene. Bullets animate in sequentially from the left every 2.8 seconds.

---

## 🌐 Egyptian Arabic Mode (Default)

Pipeline defaults to Egyptian Arabic for GameySins. Auto-translates common gaming terms:

| English | Egyptian Arabic |
|---------|----------------|
| PC | بي سي |
| CONSOLE | كونسول |
| LAPTOP | لابتوب |
| DESKTOP | ديسكتوب |
| GAMING | جيمينج |
| LIMITED | محدود |
| FLEXIBLE | مرن |
| CASUAL | كاجوال |
| HARDCORE | هاردكور |
| GAMEPLAY | جيمبلاي |
| MOSMAR | مسمار |
| GAMEYSINS | جيميسينز |
| STATS | إحصائيات |

**Flags:** `--arabic` / `--english`

**Arabic comparison words supported:** `ولا`, `ضد`

---

## 🎬 Scene Types

| Type | Duration | Description |
|------|----------|-------------|
| `opener` | 12s | Dramatic title — 105px Cairo title + 46px Rubik subtitle |
| `gameplay` | 12s | Action b-roll — 28px tag + 105px Cairo title |
| `comparison` | 12s | Side-by-side — 80px labels + VS badge |
| `stats` | 12s | 120px animated number + 36px label |
| `outro` | 12s | 96px اشترك الآن + 48px @GameySins + fade to black |
| `presentation` | 15s+ | 64px title + 40px sequential bullets (2.8s stagger) |

### Classification Order (pipeline logic)
1. `outro` — subscribe/اشترك
2. `opener` — الخلاصة/intro/summary
3. `comparison` — vs/versus/against/ولا/ضد
4. `gameplay` — gameplay/combat/battle/gaming
5. `stats` — starts with digit or contains %
6. `opener` — fallback for everything else

---

## 🎨 GameySins Style Rules

**These are STRICT — do NOT deviate:**

- **Colors**: ONLY `#ff0040` (neon red), `#00d4ff` (neon blue), `#050508` (black)
- **Fonts**: Cairo for Arabic titles, Rubik for body/Latin
- **Language**: Egyptian Arabic for ALL on-screen text
- **Animations**: GSAP `fromTo` only — NO `from()`, NO `repeat: -1`, NO `Math.random()`
- **Format**: 1920×1080 (16:9 landscape)
- **3-layer composition**: background (glows/vignette) + content (text) + accents
- **Minimum 5-6 animation steps per scene** with 3+ different eases

### Font Sizes (Brand-Approved, from PC vs Console 2026 render)
| Element | Size | Font | Weight |
|---------|------|------|--------|
| Hero headline | **120px** | Cairo | 900 |
| Outro subscribe | **110px** | Cairo | 900 |
| Scene title | **72px** | Cairo | 900 |
| VS badge | **96px** | Cairo | 900 |
| Subtitle/tagline | **48px** | Rubik | 500 |
| Channel name (outro) | **52px** | Rubik | 700 |
| Badge/label | **40-56px** | Cairo | 700 |
| Body/list point | **36px** | Rubik | 400 |
| Stat number | **120px** | Cairo | 900 |
| Stat price | **48px** | Cairo | 700 |
| Accent line | 160×6px | — | — |
| Small print | **20-22px** | Rubik | 400 |

### Banned Fonts (user explicitly rejected)
❌ Orbitron — too sci-fi
❌ Rajdhani — too thin
❌ Chakra Petch
❌ Inter, Roboto, Poppins, Montserrat — generic AI defaults

---

## 🖼️ Presentation Scenes — Kinetic Typography

### Input
```
## مقارنة بي سي و كونسول
- بي سي أداء أعلى و تخصيص كامل
- كونسول أرخص و أسهل في التشغيل
- الفرق واضح في الألعاب الثقيلة
```

### Animation Timeline
| Time | Event |
|------|-------|
| 0.0s | Background glows fade in |
| 0.5s | Title slides down from top |
| 1.0s | Accent line grows |
| 2.0s | Bullet 1 ◆ slides in (x:-80 → 0) |
| 4.8s | Bullet 2 ◆ slides in |
| 7.6s | Bullet 3 ◆ slides in |
| 10.4s+ | Hold all visible (fade to end) |

### Auto-Highlighting
- `hl-red` (#ff0040) — بي سي, جيمينج, مسمار, أداء, فريمات, رسومات, معالج, كارت, رامات
- `hl-blue` (#00d4ff) — كونسول, لابتوب, سعر, تبريد
- `hl-num` (#00d4ff, 1.1em) — Any numbers

---

## ⚙️ CLI Reference

```bash
# Generate from file
hyperframes-broll script.txt

# Generate from stdin (pipe)
cat script.txt | hyperframes-broll

# Force language
hyperframes-broll --arabic script.txt
hyperframes-broll --english script.txt

# List existing compositions
hyperframes-broll --list

# Show render commands only
hyperframes-broll --render-only
```

### Pipeline Source
`/home/ammar/scripts/hyperframes-broll` (Python, 579 lines)
Symlinked: `~/.local/bin/hyperframes-broll`

---

## 🚀 Render Commands

### From Windows (RECOMMENDED — avoids WSL FFmpeg bug)
```cmd
cd /d D:\\Hermes project\\output\\videos\\hyperframes
render_all.bat
```

### From WSL
```bash
cd /mnt/d/Hermes\ project/output/videos/hyperframes
bash render_all.sh
```

### Render a single composition
```cmd
npx hyperframes render --dir "D:\\\\Hermes project\\\\output\\\\videos\\\\hyperframes\\\\SCENE_NAME" --output "D:\\\\Hermes project\\\\output\\\\videos\\\\hyperframes\\\\rendered\\\\SCENE_NAME.mp4"
```

### Render sub-compositions (diagrams b-roll, storyboard b-roll)
Sub-compositions live under `compositions/`. Render from their directory:
```cmd
cd /d D:\\\\Hermes project\\\\output\\\\videos\\\\hyperframes\\\\SCENE_NAME\\\\compositions\\\\diagrams-broll
npx hyperframes render --output ..\\\\..\\\\rendered\\\\diagrams-broll.mp4

cd ..\\\\storyboard-broll  
npx hyperframes render --output ..\\\\..\\\\rendered\\\\storyboard-broll.mp4
```

---

## 🔄 Companion Skills

This skill works alongside:
- **`html-broll-diagrams`** — generates diagram-based b-roll (Mermaid SVGs embedded in HyperFrames compositions). Run before or after this skill for visual explanations alongside text scenes.
- **`website-to-hyperframes`** — captures real web pages as b-roll footage.
- **`references/hyperframes-design-principles.md`** — design philosophy: element sizing, spacing, brand color strategy, linter-avoidance patterns, animation patterns, storyboard/diagrams-as-broll patterns. **Read BEFORE writing any composition HTML.**

## GameySins Brand Guidelines (2026-05-26)
These supersede all previous color defaults. Integrated into every composition design.

| Element | Value |
|---------|-------|
| Style | Cinematic, UE5 realism, composited photorealistic + game graphics |
| Tone | Intense, dramatic, humorous exaggeration — Ammar focal point reacting |
| Atmosphere | Particles: sparks, embers, smoke, neon dust, rain |
| Backdrop | Dark/moody/desaturated — charcoal #1a1a1a, midnight blue #0a0e1a, ash grey #2a2a2a |
| Horror/Action | Blazing orange #ff6b00, fiery yellow #ffcc00, blood red #ff0040 |
| Tech/Retro | Neon blue #00d4ff, bright purple #8833ff |
| Subject Light | Cinematic rim lighting (bright edge separating from dark BG) — 400px glow divs with blur(120px) |
| Text Colors | Stark white #ffffff, neon cyan #00d4ff, warning yellow #ffcc00 |
| Arabic Font | Cairo 900 for headlines (120px), Cairo 700 for stat numbers (120px), Cairo 700 for badges (40px) |
| Latin Font | Rubik 500 for subtitles (48px), Rubik 400 for body/lists (36px) |
| Text Treatment | -webkit-text-stroke: 2px black + text-shadow: 0 0 40px currentColor + drop shadow |
| TEXT RULE | NEVER AI-generated in-image. Generate clean image, add text in post-production |
| Contrast | White text on midnight blue passes 4.5:1. Neon text must have stroke + shadow for readability |
| Banned | Flat lighting, pure black (#000) backgrounds, thin fonts (<400 weight), AI text in images |

## ⚠️ Critical Render Rules (2026-05-26 production battle)
Violating any ONE of these causes render failure. Check ALL before delivery.

**Fonts: COPIED .ttf files, NOT symlinks**
- WSL symlinks (`ln -sf`) break on Windows `npx hyperframes render`. Files must be COPIED.
- Source: `/mnt/d/Hermes project/output/assets/fonts/*.ttf` → copy to `./fonts/` in each composition.
- @font-face path: `url('fonts/Cairo-Regular.ttf')` (relative to index.html).

**NO CSS `var()` in inline HTML style attributes**
- The linter's JS parser sees `var(--red)` in `<div style="...">` as JS `var` keyword → parse error.
- Define CSS color classes instead: `.c-red{color:#ff0040}`, then use `<div class="c-red">`.
- For inline styles, use raw hex: `style="color:#ff0040"`.
- CSS `var()` IS allowed inside `<style>` blocks — only inline HTML attributes trigger the bug.

**NO `Math.random()` in scripts**
- HyperFrames requires deterministic renders. Use pre-defined arrays with hardcoded values.
- Example: `['left:'+[15,30,50][i]` not `Math.random()*80`.

**ALL scene divs need `class="clip"`**
- Every `<div>` with `data-start` + `data-duration` MUST have `class="scene clip"`.
- Without `clip`, the scene is visible the entire composition → timing broken.

**Hex colors in JS GSAP tweens need quotes**
- WRONG: `{borderColor:#ff6b00}` → JS parser sees private field error.
- RIGHT: `{borderColor:"#ff6b00"}` (quoted string).

**Quality gates:**
1. `npx hyperframes lint` → 0 errors.
2. `npx hyperframes validate --no-contrast` → 0 errors.
3. `fonts/` dir exists with actual .ttf files, not symlinks (`ls -la fonts/`).
4. No `var(--` in HTML inline styles.
5. No `Math.random()` in scripts.
6. Hex colors in JS are `"#xxxxxx"` not `#xxxxxx`.

### Session-Learned Pitfalls (updated 26-May-2026)

### Language Rule (CRITICAL)
- **English only in chat** with Ammar. Arabic is exclusively for content output files (scripts, HTML, SVG, Notion pages). Never use Arabic in chat messages — not even when quoting or explaining Arabic content. A single Arabic word in chat is a bug. If you catch yourself typing Arabic, stop and rewrite the sentence in English before sending.
- This applies to ALL interactions, including replies to Notion pages, scripts, or diagrams you generated. Explain them in English, even if the content itself is Arabic.

### Font Rule (CRITICAL — Windows render compatibility)
- **LOCAL FONTS ONLY.** Cairo and Rubik .ttf files at `/mnt/d/Hermes project/output/assets/fonts/`.
- **Use a `fonts/` subdirectory INSIDE the composition folder** with COPIED files. Do NOT symlink — WSL symlinks don't resolve when accessed from Windows (the render command). Copy the actual .ttf files:
  ```bash
  cd COMPOSITION_DIR && mkdir -p fonts && cp /mnt/d/Hermes\ project/output/assets/fonts/*.ttf fonts/
  ```
- `@font-face` in index.html must use relative path: `url('fonts/Cairo-Regular.ttf') format('truetype')`
- **DO NOT use `../../../assets/fonts/` relative paths** — they fail in `hyperframes validate` (the tool resolves URLs relative to its server root, which is the composition directory).
- NEVER use Google Fonts CDN `<link>` tags. They fail in sandboxed renders.
- Every weight needs its own `@font-face`: Cairo 400/700/900 and Rubik 400/500/700.

### Notion Delivery
- **Deliver Notion URLs as bare clickable links on their own line.** The user opens these on mobile and needs to tap directly. Never wrap in descriptive text like `[title](url)`. Put `https://www.notion.so/...` alone on its own line.
- **Never create empty Notion pages.** Always add content after creation using `page_content` or `add_block_to_page`.
- **Use Zapier Notion only.** Direct Notion API token was deleted 26-May-2026.

### Linter: Avoid `var(--color)` in inline `style` attributes
The HyperFrames linter's JS parser scans the entire file and errors on:
- `var(--red)` in HTML inline style attributes → treated as JavaScript `var` keyword
- Unquoted hex colors `#ff6b00` inside JS tweens → treated as private class field

**This is the #1 source of linter errors in new compositions.** Define color classes in CSS upfront to avoid the inline-var trap entirely.

**Fix strategy:** Define CSS utility classes for brand colors and use them instead of inline `style="color:var(--red)"`:
```css
.c-red{color:#ff0040}.c-blue{color:#00d4ff}.bg-red{background:#ff0040}
```
Then use in HTML: `<div class="t1 c-red">text</div>`
For border/shadow effects that can't be classed, use direct hex in inline style: `style="color:#ff0040"` (these are in HTML context, not JS, so they're safe).
In GSAP tweens, quote hex values as strings: `{color:"#ff0040"}` not `{color:#ff0040}`.

### Linter: Every scene div needs `class="clip"`
Without `class="clip"` on timed elements, the linter warns `timed_element_missing_clip_class` and the element stays visible for the entire composition instead of its scheduled range.
Always: `<div class="scene clip" id="s1" data-start="0" data-duration="12">`

### Other Pitfalls

- **Design.md must exist per composition.** Create a `design.md` with brand colors, fonts, and mood before writing the HTML. The `hyperframes` skill reads `design.md` as source of truth. Without it, the composition uses generic defaults that get rejected.
- **Font rendering from Windows requires real files, not symlinks.** Symlinks created in WSL (`ln -sf`) don't resolve when `npx hyperframes render` runs from Windows CMD. Always `cp` the font files into the composition's `fonts/` directory.
- **GSAP overlapping tweens on same element:** When a pulse/beat animation overlaps an entrance animation on the same element, lint warns `overlapping_gsap_tweens`. Fix: (a) shorten entrance duration so it completes before pulse starts, (b) add `overwrite: "auto"` to the pulse tween.
- **Pollinations API no longer works** (returns HTTP 401). Use `gemini-image` MCP instead.
- **Shorts scripts must be deep.** Generic statements get rejected. Must include real stats (Google 12K, Microsoft 10K, Amazon 27K) and concrete examples.
- **GameSinsTech vs GameSins distinction:** GameSinsTech = MSA Arabic, AI tools for retired pros 45-65, Shorts only 60-90s. GameSins = Egyptian Arabic, gaming content, any format.
- **`/home/ammar/scripts/hyperframes-broll-cli.py`** generates JSON — broken. Only use the Python pipeline `/home/ammar/scripts/hyperframes-broll`.


---

## 🔥 Motion Complexity Requirements

Every scene MUST have:
1. **5-6 distinct animation steps** (not 3-4)
2. **3+ different GSAP eases**: mix of `power2.out`, `power3.out`, `back.out(2)`, `expo.out`, `elastic.out(1,0.3)`
3. **Multi-property tweens**: scale + rotation + x/y + opacity combined
4. **Overlapping entrances**: stagger 0.15-0.25s (not 0.5s gaps)
5. **Accent pulse on hero element**: finite repeat pulse after entrance

### Forbidden
- All same ease → vary across the scene
- All at t=0 → offset first to 0.3s+
- Single-property only (just opacity) → combine
- Gaps >1.5s with no animation → fill with secondary motion

---

## 🔄 End-to-End Workflow Summary

```
User: "generate b-roll for [script]"
  ↓
Agent loads this skill automatically
  ↓
Agent shows scene breakdown (types, text, durations)
  ↓
User approves
  ↓
Agent runs: cat script.txt | hyperframes-broll
  ↓ (PARALLEL) Launch NotebookLM Video Overview generation
Agent POST-GENERATION HTML FIX:
  - Remove "أسطورة جديدة" default subtitle from all opener scenes
  - Upgrade comparison scenes to split-screen (comparison-container CSS classes)
  - Verify on-screen text matches the user's script exactly
  ↓
Agent reports generated compositions + render commands
Agent reports NotebookLM Video Overview result (download path or "still generating")
  ↓
User renders from Windows CMD (render_all.bat)
  ↓
✅ Done!
```
