# HyperFrames Composition Template for B-Roll Diagrams

## Directory Structure

```
D:\Hermes project\output\videos\hyperframes\TOPIC-2026\
  index.html            ← Main composition
  storyboard.html       ← Storyboard preview
  diagrams/             ← SVG diagram files
    timeline.svg
    flow.svg
    stats.svg
  fonts/                ← Copied .ttf files (NOT symlinks)
    Cairo-Regular.ttf
    Cairo-Bold.ttf
    Cairo-Black.ttf
    Rubik-Regular.ttf
    Rubik-Medium.ttf
    Rubik-Bold.ttf
  rendered/             ← Output mp4s
    TOPIC-2026.mp4
```

## Font Setup

**CRITICAL:** Use local `fonts/` directory inside the composition folder. Copy files, never symlink:
```
mkdir -p fonts && cp /mnt/d/Hermes\ project/output/assets/fonts/*.ttf fonts/
```

@font-face paths in index.html: `url('fonts/FontName.ttf')` — relative to index.html location.

## HTML Skeleton

```html
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<style>
  @font-face { font-family: 'Cairo'; font-weight: 400; src: url('fonts/Cairo-Regular.ttf') format('truetype'); }
  @font-face { font-family: 'Cairo'; font-weight: 700; src: url('fonts/Cairo-Bold.ttf') format('truetype'); }
  @font-face { font-family: 'Cairo'; font-weight: 900; src: url('fonts/Cairo-Black.ttf') format('truetype'); }
  @font-face { font-family: 'Rubik'; font-weight: 400; src: url('fonts/Rubik-Regular.ttf') format('truetype'); }
  @font-face { font-family: 'Rubik'; font-weight: 500; src: url('fonts/Rubik-Medium.ttf') format('truetype'); }
  @font-face { font-family: 'Rubik'; font-weight: 700; src: url('fonts/Rubik-Bold.ttf') format('truetype'); }
  /* ... rest of CSS ... */
</style>
</head>
<body>

<div data-composition-id="my-comp" data-width="1920" data-height="1080" data-start="0" data-duration="30">
  <!-- Scene 1: Diagram 1 (0-7s) -->
  <div class="scene clip" id="s1" data-start="0" data-duration="7">
    <div class="vignette"></div>
    <div class="glow red" id="s1-g1"></div>
    <div class="scene-header" id="s1-title">🧭 Title</div>
    <div class="accent-line red" id="s1-acc"></div>
    <div class="diagram-frame" id="s1-frame">
      <img src="diagrams/topic-flow.svg">
    </div>
  </div>

  <!-- Scene 2: Diagram 2 (7-14s) -->
  <div class="scene clip" id="s2" data-start="7" data-duration="7">...</div>

  <!-- Scene 3: Diagram 3 (14-21s) -->
  <div class="scene clip" id="s3" data-start="14" data-duration="7">...</div>

  <!-- Scene 4: Outro (21-30s) -->
  <div class="scene clip" id="s4" data-start="21" data-duration="9">...</div>

  <div class="transition-overlay" id="t-overlay"></div>

  <script>
  window.__timelines = window.__timelines || {};
  const tl = gsap.timeline({ paused: true });
  const T = 0.35;

  // Scene 1
  tl.set("#s1", { opacity: 1 });
  tl.fromTo("#s1-g1", { scale:0, opacity:0 }, { scale:2, opacity:0.4, duration:2.5, ease:"expo.out" }, 0.2);
  // ... more entrances ...
  tl.to("#t-overlay", { opacity:1, duration:T, ease:"power2.inOut" }, 7-T);
  tl.to("#s1", { opacity:0, duration:T }, 7-T);

  // Scene 2
  tl.set("#s2", { opacity:1 });
  tl.to("#t-overlay", { opacity:0, duration:T }, 7);
  // ... entrances with 3+ different eases ...
  tl.to("#t-overlay", { opacity:1, duration:T }, 14-T);
  tl.to("#s2", { opacity:0, duration:T }, 14-T);

  // Scene 3 — same pattern
  // Scene 4 — same pattern + final fade to black

  window.__hf = { duration: 30 };
  window.__timelines["my-comp"] = tl;
  </script>
</div>
</body>
</html>
```

## Lint Check

After creating any composition:
```bash
npx hyperframes lint --dir "SCENE_NAME"
# Must show: 0 errors, 0 warnings
```