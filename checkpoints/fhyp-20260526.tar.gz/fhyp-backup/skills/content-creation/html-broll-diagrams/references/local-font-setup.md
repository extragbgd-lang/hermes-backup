# Local Font Setup for B-Roll Compositions

## Font Source Location

```
D:\Hermes project\output\assets\fonts\
├── Cairo-Regular.ttf    (400 weight, 91KB)
├── Cairo-Bold.ttf       (700 weight, 92KB)
├── Cairo-Black.ttf      (900 weight, 92KB)
├── Rubik-Regular.ttf    (400 weight, 175KB)
├── Rubik-Medium.ttf     (500 weight, 176KB)
└── Rubik-Bold.ttf       (700 weight, 176KB)
```

These were sourced from Google Fonts.

## Copy Fonts Into Composition (CRITICAL: NOT symlinks)

```bash
cd /mnt/d/Hermes\ project/output/videos/hyperframes/SCENE_NAME
mkdir -p fonts
cp /mnt/d/Hermes\ project/output/assets/fonts/*.ttf fonts/
```

## @font-face Declaration (Mandatory)

Every composition MUST include this at the top of `<style>`. Path is relative to index.html:

```css
@font-face { font-family: 'Cairo'; font-weight: 400; src: url('fonts/Cairo-Regular.ttf') format('truetype'); }
@font-face { font-family: 'Cairo'; font-weight: 700; src: url('fonts/Cairo-Bold.ttf') format('truetype'); }
@font-face { font-family: 'Cairo'; font-weight: 900; src: url('fonts/Cairo-Black.ttf') format('truetype'); }
@font-face { font-family: 'Rubik'; font-weight: 400; src: url('fonts/Rubik-Regular.ttf') format('truetype'); }
@font-face { font-family: 'Rubik'; font-weight: 500; src: url('fonts/Rubik-Medium.ttf') format('truetype'); }
@font-face { font-family: 'Rubik'; font-weight: 700; src: url('fonts/Rubik-Bold.ttf') format('truetype'); }
```

## Why Local Fonts

The HyperFrames renderer fires two lint warnings when fonts are loaded from Google Fonts CDN:

1. `google_fonts_import` — External font requests fail in sandboxed/offline renders
2. `font_family_without_font_face` — Cairo and Rubik are not in the auto-resolved font list

Local @font-face declarations eliminate both warnings and ensure correct typography in renders.

## Usage in CSS

```css
.scene-header {
  font-family: 'Cairo', sans-serif;
  font-size: 64px; font-weight: 900;
}
.body-text {
  font-family: 'Rubik', sans-serif;
  font-size: 32px; font-weight: 400;
}
```