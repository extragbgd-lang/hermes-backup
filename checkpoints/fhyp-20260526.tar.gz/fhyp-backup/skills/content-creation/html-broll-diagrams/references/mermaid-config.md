# Mermaid Config & Render Reference

## Base Config: `~/.config/mermaid/config.json`

```json
{
  "backgroundColor": "transparent",
  "theme": "base",
  "themeVariables": {
    "fontFamily": "Cairo, Arial, sans-serif",
    "primaryColor": "#6c5ce7",
    "primaryTextColor": "#ffffff",
    "primaryBorderColor": "#5a4bd1",
    "lineColor": "#636e72",
    "secondaryColor": "#2d3436",
    "tertiaryColor": "#dfe6e9"
  }
}
```

## Per-diagram override (use %%{init}%% block at top of .mmd file)

For GameSins branding (red/blue):
```
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#ff0040', 'primaryTextColor': '#ffffff', 'primaryBorderColor': '#cc0033', 'lineColor': '#636e72', 'secondaryColor': '#00d4ff', 'tertiaryColor': '#2d3436', 'fontFamily': 'Cairo, sans-serif' }}}%%
```

## Render command
```bash
mmdc -i /tmp/file.mmd -o /mnt/d/hyperframe/output/diagrams/file.svg -c ~/.config/mermaid/config.json -w 1200 -H 900
```

- `-w 1200` — minimum width for 16:9 video
- `-H 900` — optional height constraint
- Background is transparent by default (for video overlay use)

## Supported diagram types for b-roll
| Type | Mermaid keyword | Best for |
|------|----------------|----------|
| Flowchart | `flowchart TD` or `LR` | Comparisons, processes, decisions |
| Quadrant | `quadrantChart` | Cost/performance, 2D positioning |
| Timeline | `timeline` | Evolution, history, roadmap |
| Mind map | `mindmap` | Topic breakdown, feature list |
| Pie chart | `pie` | Percentage breakdowns |
| Sequence | `sequenceDiagram` | Step-by-step interactions |

## Pitfalls
- Mind map: EXACTLY 2-space indent per level, no tabs
- Node text: max 3-5 words to avoid layout issues
- Arabic RTL text may render incorrectly in some Mermaid versions
- Quadrant chart requires x-axis/y-axis declarations