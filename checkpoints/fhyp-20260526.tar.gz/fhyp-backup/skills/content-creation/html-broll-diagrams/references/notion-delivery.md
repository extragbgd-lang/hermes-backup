# Notion Delivery via Zapier — B-Roll Output Workflow

After generating b-roll compositions and diagrams, push a report to Notion so Ammar can view from mobile.

## Step-by-Step

### 1. Get the Zapier URL
```bash
ZAPIER_URL=$(grep "zapier:" -A 2 ~/.hermes/config.yaml | grep "url:" | awk '{print $2}' | tr -d '"')
```

### 2. Create the Page (standalone)
```bash
curl -s --max-time 25 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"tools/call","id":1,"params":{"name":"execute_zapier_write_action","arguments":{"app":"Notion","action":"create_page","params":{"icon":"🎬","title":"B-Roll Title"},"instructions":"Create b-roll report page","output":"page URL"}}}' \
  "$ZAPIER_URL"
```

- Do NOT include `parent_page` unless Main Brain has been shared with Zapier integration
- Capture the page ID from the response for content addition

### 3. Check the response
The response is SSE format: `data: {"result":{"content":[{"text":"{\"results\":\"https://...\"}"}]}}`
Parse the `results` field for the page URL. The page ID is embedded in the URL.

### 4. Add Content Blocks
Use `page_content` action:
```bash
curl -s --max-time 25 ... \
  -d '{"jsonrpc":"2.0","method":"tools/call","id":2,"params":{"name":"execute_zapier_write_action","arguments":{"app":"Notion","action":"page_content","params":{"page_id":"PAGE_ID","content":"## Heading\n\nBody text..."},"instructions":"Add content","output":"confirmation"}}}'
```

### 5. Deliver to User
- Provide ONLY the bare URL on its own line: `https://www.notion.so/Title-PageID`
- Nothing else on that line — the user taps directly on mobile

## Critical Notes

- **parent_page requires sharing.** The Main Brain page (368d2f44...) is NOT shared with Zapier. Creating pages with it as parent will fail with "Could not find page with ID".
- **Always add content.** Creating an empty page is a user frustration point.
- **Standalone pages work fine.** No parent means the page lives at the top level of the workspace — accessible via direct URL.
- **To nest under Main Brain later:** User must Share Main Brain → invite "Zapier", then recreate the page with parent_page=MainBrainID. Or drag it in Notion manually.
- **Response parsing:** The SSE response has `data: {jsonrpc...}` lines. Extract the `text` field from `content[0].text`, then JSON-parse it to get `results` (page URL).