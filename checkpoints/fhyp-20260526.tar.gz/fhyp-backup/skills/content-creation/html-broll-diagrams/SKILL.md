---
name: html-broll-diagrams
description: Generate professional b-roll footage from HTML web pages + embedded diagrams (Mermaid SVGs). For GameSins/GameSinsTech videos. Proper HyperFrames compositions with @font-face, scene transitions, and GSAP animation.
version: 2.0
trigger: html-broll-diagrams
aliases:
  - html broll
  - html-broll
  - web broll
  - web-broll
  - diagram-broll
  - page-capture
  - html-diyagrams
  - web-page-broll
  - html-pages-broll
toolsets:
  - terminal
  - file
  - web
---

# 🎬 HTML + Diagrams B-Roll Skill v2

## What This Is

Generates proper **HyperFrames b-roll compositions** with Mermaid SVG diagrams embedded as animated scenes. Fully local fonts, clean lint, proper scene transitions.

## Prerequisites

```bash
npm install -g @mermaid-js/mermaid-cli     # already installed
mmdc --version                              # verify
```

## Fonts directory

The font source is `/mnt/d/Hermes project/output/assets/fonts/` — copy these into a local `fonts/` inside your composition folder. Cairo (Regular, Bold, Black) + Rubik (Regular, Medium, Bold) .ttf files.

## Language Rule (NON-NEGOTIABLE)

English ONLY in all chat messages to Ammar. Arabic is exclusively for content output files (scripts, HTML compositions, SVG diagrams, Notion pages). Never use Arabic in chat — not even when quoting or explaining Arabic content. A single Arabic word in chat is a bug. If you catch yourself typing Arabic, stop and rewrite the sentence in English before sending.

## Notion URL Delivery

When delivering a Notion page to Ammar:
- **Bare clickable URL on its own line.** Nothing else on that line.
- Format: `https://www.notion.so/Page-Title-PageID`
- Never wrap in descriptive text like `[title](url)`.
- Never bury in a sentence. The user opens these on mobile and needs to tap directly.

## Output Delivery

All b-roll compositions, diagrams, and reports MUST be pushed to Notion. Never share local file paths as the primary delivery. Create a Notion page with:
1. A meaningful title with icon
2. Content blocks explaining what was generated
3. The render command at the end

Always add content to the page after creation via `page_content` or `add_block_to_page` — never deliver an empty page.

## Fonts: LOCAL ONLY (copied, not symlinked, not CDN)

**Font source:** `/mnt/d/Hermes project/output/assets/fonts/` (Cairo Regular/Bold/Black + Rubik Regular/Medium/Bold).

**CRITICAL — Copy fonts into composition directory, do NOT use `../` relative paths:**
```bash
mkdir -p fonts && cp /mnt/d/Hermes\ project/output/assets/fonts/*.ttf fonts/
```

Every composition MUST use local `@font-face` declarations:
```css
@font-face { font-family: 'Cairo'; font-weight: 400; src: url('fonts/Cairo-Regular.ttf') format('truetype'); }
@font-face { font-family: 'Cairo'; font-weight: 700; src: url('fonts/Cairo-Bold.ttf') format('truetype'); }
@font-face { font-family: 'Cairo'; font-weight: 900; src: url('fonts/Cairo-Black.ttf') format('truetype'); }
@font-face { font-family: 'Rubik'; font-weight: 400; src: url('fonts/Rubik-Regular.ttf') format('truetype'); }
@font-face { font-family: 'Rubik'; font-weight: 500; src: url('fonts/Rubik-Medium.ttf') format('truetype'); }
@font-face { font-family: 'Rubik'; font-weight: 700; src: url('fonts/Rubik-Bold.ttf') format('truetype'); }
```

**Do NOT use `../fonts/FontName.ttf`** — the HyperFrames validate/render server resolves paths from the composition directory root. The path must be `fonts/FontName.ttf` (relative to the HTML file location).

### HyperFrames Structure — Non-Negotiable

```html
<div data-composition-id="my-id" data-width="1920" data-height="1080" data-start="0" data-duration="30">
```

Every scene div MUST have:
- `class="scene clip"`
- `id="unique-id"`
- `data-start` and `data-duration` (in seconds, cumulative across scenes)

Every composition MUST have:
- `<div class="transition-overlay" id="t-overlay">` for crossfade transitions
- `window.__timelines = window.__timelines || {};`
- `const tl = gsap.timeline({ paused: true });`
- `window.__timelines["composition-id"] = tl;`
- `window.__hf = { duration: TOTAL_SECONDS };`

### Scene Structure — 8-10 Elements Per Scene

Each scene needs THREE layers:
1. **Background** — vignette + glow dots (2-3) for texture. NEVER flat black.
2. **Midground** — the actual message: title, accent line, diagram frame, callout.
3. **Foreground** — corner brackets, source tags, decorative accents.

### GSAP Rules

- Use `fromTo()` exclusively (NOT `from()` or `to()` for entrances)
- Every scene: 5-6 animation steps minimum, 3+ different eases
- First element offset 0.2-0.3s (never at t=0)
- Stagger related elements at 0.15-0.25s intervals
- Vary directions per scene (y, x, scale, rotation) — don't repeat patterns
- Transition overlay: `tl.to("#t-overlay", { opacity: 1, duration: T, ease: "power2.inOut" }, SCENE_END - T);`
- NO exit animations (gsap.to) except on the FINAL scene (outro)
- NO repeat: -1 — use finite repeats (yoyo: true, repeat: 2)
- NO Math.random() — use fixed arrays
- **QUOTE hex colors in GSAP:** `{color:"#ff0040"}` not `{color:#ff0040}` (unquoted hex is parsed as private JS field)
- Timeline must be synchronous (no async/await, setTimeout, Promises)

## Workflow

### Step 1 — Get Script + Identify Diagram Types

| Content | Diagram |
|---------|---------|
| Comparison / vs | flowchart TD or quadrantChart |
| Tutorial / How-To | flowchart LR or sequenceDiagram |
| News / Update | timeline |
| Review | mindmap |
| Stats / Data | pie or quadrantChart |
| Evolution | timeline |

### Step 2 — Generate SVG Diagrams

Diagrams go into the composition's `diagrams/` directory:

```bash
mkdir -p "/mnt/d/Hermes project/output/videos/hyperframes/SCENE_NAME/diagrams"
mmdc -i /tmp/diagram.mmd -o "/mnt/d/Hermes project/output/videos/hyperframes/SCENE_NAME/diagrams/diagram-name.svg" -w 1600 -H 900 --backgroundColor transparent
```

### Step 3 — Build HyperFrames Composition

Follow the template in `references/composition-template.md`:

1. Write index.html with @font-face declarations
2. 4 scenes max (3 diagrams + 1 outro)
3. Each scene 7s (diagrams) or 9s (outro)
4. Transitions via transition-overlay crossfade
5. Run `npx hyperframes lint --dir "SCENE_NAME"` — must get 0 errors, 0 warnings

## Output

```
D:\Hermes project\output\videos\hyperframes\SCENE_NAME\          ← index.html composition + fonts/
D:\Hermes project\output\assets\fonts\                           ← Cairo + Rubik .ttf files (source - copy from here)
```

## Pitfalls

- **FORGETTING @font-face = broken render.** The font_lint warning WILL fire. Add @font-face declarations for EVERY weight used.
- **Missing class="clip" = lint warning.** Every scene div with data-start/data-duration needs it.
- **No transition overlay = jump cuts.** Always include #t-overlay with crossfade animation.
- **Linter false positive on `var(--color)` in inline styles:** Define CSS color utility classes (`.c-red`, `.c-blue`) instead of `style="color:var(--red)"` — the JS parser treats CSS `var()` as JS `var` keyword.
- **Linter false positive on hex in GSAP:** Quote hex colors in GSAP: `{color:"#ff0040"}` not `{color:#ff0040}` — unquoted `#` is parsed as JS private field.
- **Symlinks don't work for Windows renders:** Always `cp` font files, never `ln -sf`.
- **Arabic in chat = user frustration.** English ONLY in all chat messages, even when describing Arabic content.
- **Notion URLs must be bare clickable links on their own line.** The user opens these on mobile and needs to tap directly. Never wrap URLs in descriptive text. Put the full `https://www.notion.so/...` URL on its own line with nothing else.