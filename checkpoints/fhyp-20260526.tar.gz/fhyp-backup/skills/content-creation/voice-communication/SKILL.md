---
name: voice-communication
description: Voice communication setup and workflows — TTS for Arabic/English responses, voice note transcription, and provider configuration. Trigger when the user wants to send/receive voice messages, set up voice transcription, configure TTS providers, or troubleshoot audio workflows.
---

# Voice Communication

## TTS (Text-to-Speech)

### Quick Test (Hermes built-in)
```python
text_to_speech(text="your message here")
```
Returns a `MEDIA:` path — include it in your response for the platform to deliver as audio.

### Arabic / Egyptian Dialect
- Default provider (Edge TTS) handles Arabic but tends toward Modern Standard Arabic (MSA), not Egyptian dialect
- For better Egyptian Arabic: consider ElevenLabs or other providers with dialect-specific voices
- Always test first — send a voice message to the user and ask if the accent is acceptable

### Best Practices
- Keep TTS messages concise (under 30 seconds of speech)
- For GameySins content: TTS is useful for quick voiceovers, not full narration
- Use `[[audio_as_voice]]` tag + `MEDIA:path` for Telegram voice bubbles

## edge-tts CLI for Content Pipelines

When building automated content pipelines (e.g., Quick Facts, faceless channels), use edge-tts directly from Python for voiceover generation with word-level subtitle timing. This is separate from Hermes' built-in `text_to_speech` — edge-tts CLI gives you the VTT subtitle file needed for burned captions.

### Installation
```bash
pip install edge-tts --break-system-packages
```

### Available Arabic Voices
| Voice | Gender | Style |
|---|---|---|
| `ar-EG-SalmaNeural` | Female | Egyptian dialect (closest to target) |
| `ar-SA-ZariyahNeural` | Female | Saudi / Gulf MSA |
| `ar-SA-HamedNeural` | Male | Saudi / Gulf MSA |

### Generating Voice + Subtitles
```python
import asyncio
import hashlib
from pathlib import Path

async def generate(text: str, voice: str = "ar-EG-SalmaNeural", speed: str = "+15%"):
    text_hash = hashlib.md5(text.encode()).hexdigest()[:12]
    audio_path = Path(f"voice_{voice}_{text_hash}.mp3")
    sub_path = Path(f"subs_{voice}_{text_hash}.vtt")
    
    # Check cache first
    if audio_path.exists() and sub_path.exists():
        return audio_path, sub_path
    
    cmd = [
        "edge-tts", "--voice", voice, "--text", text,
        "--write-media", str(audio_path),
        "--write-subtitles", str(sub_path),
        "--rate", speed,
    ]
    proc = await asyncio.create_subprocess_exec(*cmd)
    await proc.communicate()
    
    return audio_path, sub_path
```

### VTT Subtitle Parsing — CRITICAL PITFALL

**edge-tts outputs VTT with COMMA-separated milliseconds** (`00:00:00,100`), but most parsers expect dots (`00:00:00.100`). If your regex uses `\.` for the decimal, VTT cues will parse as zero.

**Broken pattern (misses VTT commas):**
```
pattern = r'(\d{2}:\d{2}:\d{2}\.\d{3})\s*-->\s*...'
```

**Fixed pattern (handles both):**
```python
# Accept both dot and comma millisecond separators
pattern = r'(\d{2}:\d{2}:\d{2}[.,]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[.,]\d{3})\s*\n(.*?)(?=\n\n|\n\d|\Z)'

def _vtt_time_to_seconds(time_str: str) -> float:
    # Normalize: replace comma with dot for float parsing
    time_str = time_str.replace(",", ".")
    h, m, s = time_str.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)
```

Symptom if broken: `duration_seconds=0.0` and `subtitles=0 cues` even though the audio file exists and the VTT file has valid content.

### Voice Duration Calibration for Arabic

Arabic TTS at +15% speed produces roughly **2.5-3 words per second**. For the 20-45 second short-form target:
- **30s target:** 60-80 words
- **45s max:** 100-120 words
- If script is 89 words → expect ~35-41 seconds at +15%

Adjust speed (`--rate "+25%"`) or trim script words if duration exceeds 45s.

## Voice Note Transcription (Whisper)

### Preferred: faster-whisper
**Always use `faster-whisper` over `openai-whisper`.**

Reason: `openai-whisper` via pip downloads full PyTorch (~2GB), which frequently times out. `faster-whisper` uses CTranslate2 — much smaller download, faster inference, same quality.

### Installation
```bash
pip install faster-whisper --break-system-packages
```

### Transcribing a Voice Note
```python
# IMPORTANT: Set PYTHONPATH — faster-whisper installs to user site-packages
# but Python 3.12 on this system doesn't pick it up automatically
import os
os.environ["PYTHONPATH"] = "/home/ammar/.local/lib/python3.12/site-packages"

from faster_whisper import WhisperModel
model = WhisperModel("small", device="cpu", compute_type="int8")
segments, info = model.transcribe("path/to/audio.ogg", language="ar")
for segment in segments:
    print(f"[{segment.start:.1f}s - {segment.end:.1f}s] {segment.text}")
```

**PYTHONPATH Fix (required on this system):**
`faster-whisper` installs to `/home/ammar/.local/lib/python3.12/site-packages` but `python3` won't find it without `PYTHONPATH` set. Always include the `os.environ` line above, or run with:
```bash
PYTHONPATH=/home/ammar/.local/lib/python3.12/site-packages python3 script.py
```

### Model Size Guide
| Model | Size | Speed | Quality | Use Case |
|-------|------|-------|---------|----------|
| `tiny` | 75MB | Fastest | Basic | Quick tests |
| `base` | 140MB | Fast | Good | Default choice |
| `small` | 460MB | Medium | Better | Arabic content |
| `medium` | 1.5GB | Slower | Great | Final production |
| `large-v3` | 3GB | Slowest | Best | Maximum accuracy |

For Arabic/Egyptian: `base` is minimum, `small` or `medium` recommended.

### Language Codes
- Arabic (general): `ar`
- Egyptian Arabic: use `ar` (Whisper auto-detects dialect from audio)
- English: `en`

### GPU Acceleration
If CUDA is available (user has NVIDIA GPU):
```python
model = WhisperModel("base", device="cuda", compute_type="float16")
```
Check with: `nvidia-smi`

## Platform Notes

### Telegram
- Voice notes sent by user: can be received and transcribed
- TTS responses: delivered as native voice bubbles (best experience)
- Send voice: include `MEDIA:/path/to/file.ogg` in message

### Discord
- Voice notes: delivered as file attachments (must download first — not auto-saved)
- TTS responses: delivered as file attachments (not voice bubbles)
- Less ideal for voice communication than Telegram

## See Also
- `references/wsl-setup-notes.md` — verified installation details, PYTHONPATH fix, system-specific notes
- `references/session-2026-05-20.md` — Whisper installation session notes, model quality comparison, code-switching pitfall

## Workflow: Voice Note → Response
1. Receive voice note — on this system, Discord voice notes are **auto-saved** to `/home/ammar/.hermes/audio_cache/` as `audio_*.ogg` files. Check `ls -lt /home/ammar/.hermes/audio_cache/*.ogg` for the latest.
2. Transcribe with `faster-whisper` (language="ar" or auto-detect)
3. Process the transcribed text as a normal message
4. Respond via text or TTS (user's preference)

## Pitfalls
- **PYTHONPATH required** — `faster-whisper` installs to `/home/ammar/.local/lib/python3.12/site-packages` but `python3` won't find it without `PYTHONPATH` set. Always use the `os.environ` fix or `PYTHONPATH=` prefix.
- Don't install `openai-whisper` — it's too large and times out. Use `faster-whisper`
- Don't assume TTS accent matches Egyptian dialect — always test with the user
- Don't hardcode `device="cuda"` — check GPU availability first
- Whisper model downloads on first run — the first transcription will be slow, subsequent ones are fast
- **Mixed Arabic-English speech** — when the user code-switches (e.g., says "upgrade" mid-Arabic sentence), Whisper may phonetically transliterate the English word into Arabic script (e.g., "افجريد"). If the transcription looks like a phonetic Arabic rendering of an English word, try reading it as the English word instead.
- **Voice note file location** — auto-saved files go to `/home/ammar/.hermes/audio_cache/audio_*.ogg`. Sort by time (`ls -lt`) to find the latest.
