# WSL Voice Communication Setup Notes

## System Info
- Host: WSL (Windows Subsystem for Linux)
- Python: 3.12
- User: `/home/ammar`
- GPU: CPU only (i5-12450HX) — no CUDA

## faster-whisper Installation (Verified 2026-05-20)

```bash
pip install faster-whisper --break-system-packages
```

**DO NOT** install `openai-whisper` — PyTorch download (~2GB) times out.

### Installed Location
Packages install to: `/home/ammar/.local/lib/python3.12/site-packages`

### PYTHONPATH Fix (REQUIRED)
Python 3.12 on this system does NOT auto-detect user site-packages. Must set:
```python
import os
os.environ["PYTHONPATH"] = "/home/ammar/.local/lib/python3.12/site-packages"
```
Or run scripts with:
```bash
PYTHONPATH=/home/ammar/.local/lib/python3.12/site-packages python3 script.py
```

### Model Auto-Download
First run auto-downloads the model from HuggingFace Hub. The `small` model (~460MB) downloaded successfully during testing. Subsequent loads are fast (cached).

### Verified Working
```python
import os
os.environ["PYTHONPATH"] = "/home/ammar/.local/lib/python3.12/site-packages"
from faster_whisper import WhisperModel
model = WhisperModel("small", device="cpu", compute_type="int8")
segments, info = model.transcribe("audio.ogg", language="ar")
# Arabic transcription confirmed working
```

## TTS (Edge) — Verified 2026-05-20
- Arabic TTS works via Edge provider
- Accent leans Modern Standard Arabic, not Egyptian dialect
- File format: `.ogg` -> also cached as `.mp3`
- Delivery: use `[[audio_as_voice]]` + `MEDIA:/path/to/file.ogg`

## Discord Voice Notes
- Voice notes from Discord arrive as `(attachment)` — NOT auto-saved to filesystem
- Must explicitly download the attachment before transcription
- Telegram voice notes may be handled differently (not yet tested)
