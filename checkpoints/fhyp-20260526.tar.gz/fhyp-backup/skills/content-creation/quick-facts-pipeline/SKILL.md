---
title: quick-facts-pipeline
name: quick-facts-pipeline
description: "Automated faceless Quick Facts short-form channel. English-only. Trend discovery to script (Hermes LLM) to NotebookLM Video Overview via REST API (notebooklm-mcp, preferred) or Chrome CDP (fallback). Output to D drive. Separate from GameSins."
trigger_conditions:
  - "User says quick facts or run quick facts pipeline or generate quick facts video"
  - "User wants faceless short-form content about weird facts gaming AI science psychology etc"
  - "User asks about the automated quick facts channel system"
---

# Quick Facts Pipeline — "Quickshot facts"

English-only faceless short-form videos. "Things you probably didn't know" style. Fast-paced, 20-45 second videos, curiosity-driven hooks, 10 content categories. COMPLETELY SEPARATE from GameSins and GameSinsTech.

**Channel:** Quickshot facts — `https://youtube.com/channel/UCmqSFJ-otrZv9fNJCI-EJTw`

**Core insight:** NotebookLM Video Overviews handle BOTH visuals AND narration — free. No local TTS, no image gen APIs, no paid services.

**PREFERRED:** `roomi-fields/notebooklm-mcp` REST API (Playwright-based, handles new UI) — see `references/notebooklm-mcp-setup.md`.
**FALLBACK:** Chrome CDP (raw WebSocket — fragile against NotebookLM UI changes, see pitfalls).

## System Location

- **Code:** `/home/ammar/quick-facts-channel/` (Linux home)
- **All output:** `/mnt/d/quick-facts-channel/` (D: drive)
- Config exists at both locations, must be kept in sync
- Config path in memory: `/mnt/d/quick-facts-channel/config.yaml`

## Simplified Pipeline (5 steps)

1. TREND DISCOVERY → Reddit JSON API, 10 categories, virality scoring
2. SCRIPT GENERATION → Hermes LLM (DeepSeek v4 Pro) writes English script
3. NOTEBOOKLM VIDEO → Chrome CDP: navigate → add source → generate Video Overview (Brief)
4. DOWNLOAD → Click Download via CDP → copy to D: drive
5. SEO + PUBLISH → Hermes LLM writes titles/tags → YouTube upload (private)

## Script Generation

**Primary:** Hermes LLM (DeepSeek v4 Pro) — polished scripts immediately. Zero setup.

**Fallback (requires LM Studio fix):** LM Studio at `http://192.168.100.17:1234` with Qwen 3.5 9B. Currently BOTH Gemma and Qwen run as reasoning models — they output empty `content` and burn all tokens on `reasoning_content`. User must disable "Reasoning" in LM Studio model settings before either model works for scripts.

Script structure: 5 parts, ~80 words, ~30s. Prompt via `script_generator.generate_script_prompt(topic, category)`.

## NotebookLM via REST API (PREFERRED)

Use `roomi-fields/notebooklm-mcp` — a production-grade Node.js project (81⭐, updated May 2026) that wraps NotebookLM behind a 33-endpoint REST API. Uses Playwright (not raw CDP), handles the new NotebookLM UI, generates video/audio/infographic/report/presentation, and downloads directly. Batch-tested on 1000+ overnight runs. MIT license.

See `references/notebooklm-mcp-setup.md` for full setup.

**Quick workflow (once server is running on Windows port 3000):**

From WSL2, use the Windows gateway IP (`172.23.240.1` or `$(ip route | grep default | awk '{print $3}')` — NOT `localhost`):

```bash
WIP=$(ip route | grep default | awk '{print $3}')

# 1. Add script as source
curl -s -X POST "http://$WIP:3000/content/sources" \
  -H "Content-Type: application/json" \
  -d '{"source_type":"text","text":"<SCRIPT_TEXT>","title":"Quick Fact: AI Jobs"}'

# 2. Generate video (Brief format, English)
curl -s -X POST http://localhost:3000/content/generate \
  -H "Content-Type: application/json" \
  -d '{"content_type":"video","video_format":"brief","language":"English"}'

# 3. Download MP4
curl -s "http://localhost:3000/content/download?content_type=video&output_path=D:/quick-facts-channel/output/videos/ai_jobs.mp4"
```

**Why this over raw CDP:**
- Handles NotebookLM UI changes (onboarding, dialog states, Angular re-renders) via Playwright selectors
- Single API call replaces 8-step CDP dance
- Downloads files directly — no guessing download paths
- Multi-account rotation, auto-reauth on session expiry
- REST API means calls work from WSL2, Python, cron, anywhere

**One-time setup:**
1. Clone to `D:\notebooklm-mcp\`
2. Open **CMD** (not PowerShell — PowerShell blocks npm), run: `npm install` then `npm run build`
3. `set BROWSER_CHANNEL=chrome && npm run setup-auth` (Google login via visible Chrome)
4. `set BROWSER_CHANNEL=chrome && npm run start:http` — keeps server running on `0.0.0.0:3000`
5. From WSL2: call `http://$(ip route | grep default | awk '{print $3}'):3000` (gateway IP, not localhost)
6. One-time firewall rule in Admin PowerShell: `New-NetFirewallRule -DisplayName "NotebookLM API WSL" -Direction Inbound -Port 3000 -Protocol TCP -Action Allow`

## NotebookLM via Chrome CDP (FALLBACK)

User's Chrome must be running with remote debugging. Credentials: `hermossybatooty@gmail.com` / `IamDangerous`.

**WARNING — CDP approach is fragile.** NotebookLM's Angular UI (v2, May 2026) frequently ignores `Input.dispatchMouseEvent` clicks on nested stateful components. The onboarding dialog on new notebooks resists dismissal via CDP. The "Add source" → "Copied text" dialog may not appear even after clicking the correct button. **Prefer the REST API above.** Use CDP only when the API server is unavailable and you need a one-off.

**CDP workflow (last tested May 2026 — may break on UI updates):**
1. `Page.navigate` to notebook URL (reuse existing notebook to skip onboarding)
2. If onboarding appears: click "Start a project" or "How do I upload my own documents?" to try to advance
3. Click "Sources" tab → "Add source" button → "Copied text" → paste script → Insert
4. Wait 5s, verify "1 source" appears
5. Studio → Video Overview → Brief → English → Generate
6. Poll page for "Download" button, click, retrieve from Downloads

## Chrome Remote Debugging Setup

Full skill: `chrome-cdp-automation`. Quick reference: `references/chrome-remote-debugging.md`.

**User starts Chrome (Win+R, after `taskkill /F /IM chrome.exe`):**
```
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --remote-allow-origins=* --user-data-dir="C:\temp\chrome-debug"
```
`--remote-allow-origins=*` is CRITICAL — without it, CDP WebSocket gets HTTP 403.

**One-time Windows Admin CMD:**
```cmd
netsh interface portproxy add v4tov4 listenport=9223 listenaddress=0.0.0.0 connectport=9222 connectaddress=127.0.0.1
netsh advfirewall firewall add rule name="Chrome Debug WSL" dir=in action=allow protocol=TCP localport=9222
```

**Connect from WSL2:**
```python
import json, urllib.request, websocket
resp = urllib.request.urlopen("http://192.168.100.17:9223/json/version", timeout=5)
ws_url = json.loads(resp.read())["webSocketDebuggerUrl"]
ws = websocket.create_connection(ws_url, timeout=15)
```

No timeouts. No headless detection. User's own Chrome session.

## YouTube Publishing — Zapier-Focused (May 2026)

**Google YouTube API v3 OAuth is REMOVED.** No `uploader.py`, no Google OAuth tokens, no `googleapiclient`.

**Upload flow:**
1. Pipeline produces video → saves metadata to **Notion** under the GST Hub page
2. User's Zapier Zap watches Notion → triggers YouTube upload
3. Pipeline also delivers a Discord notification with the Notion link

**Notion token for automated page creation:**
```
NOTION_TOKEN=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
```
Create pages under the GST Hub: `36cd2f44-bc2c-8185-a180-fa34878ed951`
Title format: `"QF: [title] - [date]"`

**Cron jobs:**
- `42ed80d3d808` — Quick Facts Daily Auto-Publish (9 AM daily, workdir: ~/quick-facts-channel)
- `647b578807fd` — Quick Facts Daily Trend Discovery (12 PM daily, workdir: ~/quick-facts-channel)

## Content Categories

weird_facts, gaming_facts, ai_tech, science_mysteries, psychology_tricks, internet_history, useful_hacks, dark_facts, productivity_secrets, historical_oddities

## English Script Structure

5 parts, ~80 words, ~30 seconds:
1. HOOK (3s, 8-12 words) — curiosity or shock
2. MAIN FACT (10s, 25-35 words) — core surprising fact
3. TWIST (6s, 15-20 words) — deeper layer
4. PAYOFF (5s, 12-18 words) — conclusion
5. CTA (4s, 6-10 words) — engagement ask

## Channel Separation (CRITICAL)

- Different YouTube channel, different OAuth credentials
- No Ammar/Mosmar/gaming personality
- No GameSins social links in descriptions
- English only — user rejected Arabic TTS as bad quality
- Hermes communicates with user in English per global rule

## Pipeline Maintenance — Known Issues

### `pipeline.py` broken imports (as of May 2026)

The main `pipeline.py` orchestrator has stale imports that crash on any mode:

```
ImportError: cannot import name 'parse_script_response' from 'modules.script_generator'
```

**Fixes applied in session (patches verified working):**
- `parse_script_response` → module exports `parse_script`, not `parse_script_response`
- `validate_script` → not exported by `script_generator.py` — remove from import line
- `voice_generator.py` crashes at module-load time with `KeyError: 'paths.voices'` — config.yaml has no `paths.voices` key

**Until pipeline.py is fully repaired, call modules directly:**

```python
# Trend discovery (works perfectly)
from modules.trend_discovery import discover_trends, save_trends
trends = discover_trends(categories=[...], max_per_category=5)
path = save_trends(trends)

# Script generation (works)
from modules.script_generator import generate_script_prompt
prompt = generate_script_prompt(topic, category)
```

See session May 26, 2026 for the full working one-liner.

### `ai_tools` vs `ai_tech` naming mismatch

Config.yaml lists category `ai_tech` but `trend_discovery.REDDIT_SOURCES` uses `ai_tools` as the dict key. When user passes `--categories ai_tools`, trend discovery works (correct source key). When pipeline.py reads from config (`ai_tech`), the AI category is silently skipped (no subreddits match). Fix: rename config to `ai_tools` or add an alias.

## Pitfalls

- **CMD not PowerShell for Windows commands.** The user's PowerShell has script execution disabled. Always give Windows commands formatted for CMD, not PowerShell. Use `set VAR=value` not `$env:VAR="value"`. Use `cd /d D:\path` not `cd D:\path`. One command at a time — the user is not a developer.
- **.env is NOT auto-loaded** by the notebooklm-mcp project. It reads from `process.env` directly (shell env), not from a .env file. All required env vars must be set via `set VAR=value` on the command line BEFORE running npm. Setting them in .env has NO effect.
- **HEADLESS=false required with BROWSER_CHANNEL=chrome.** patchright headless mode looks for a bundled headless shell that doesn't exist. Use HEADLESS=false for visible Chrome. Without this, content generation fails.
- **SEARCH FOR EXISTING TOOLS FIRST.** Before building raw CDP/Playwright/selenium automation for any web service, search GitHub for existing projects. Many popular services (NotebookLM, YouTube, Google Flow) already have battle-tested automation libraries. User frustration signal: "is there an existing project on github or something that accomplish this efficiently?" — means you should have searched before writing custom automation. Save hours by finding what already works.
- **NotebookLM CDP is unreliable against new UI.** As of May 2026, NotebookLM deployed a new Angular UI where onboarding dialogs, source panels, and buttons resist CDP clicks. The REST API (notebooklm-mcp) is tested on this UI. Use CDP only as last resort. See `references/notebooklm-mcp-setup.md`.
- **JUST DO IT. Don't ask, don't explain, don't check — execute.** When CDP is connected, read the page via `Runtime.evaluate`, then click/paste/navigate. Only ask the user if CDP has been definitively tried and failed. The user's time is more valuable than being asked to click through things the agent can already control. User signals: "why are you not automating this", "cant you see it yourself", "why can you not do this yourself", "u stopped?".
- **Browser automation FIRST.** Default to Chrome CDP for ANY web UI task (OAuth consent screen, Google Cloud Console, NotebookLM, Google Flow). Do NOT ask user to manually click through unless CDP has been tried and failed.
- **NotebookLM source vs Chat.** Add content via "Add source" → "Copied text" → paste → Insert. Do NOT paste into the Chat textbox. User will correct this: "it was added in chat not in sources."
- **NotebookLM onboarding blocks everything.** New notebooks have an onboarding dialog. Click "Create a podcast, video, slide deck, etc." first. See `references/notebooklm-cdp-elements.md` for full element patterns.
- **LM Studio models in reasoning mode.** Both Gemma and Qwen return empty content. Disable "Reasoning" in LM Studio. Use Hermes LLM until fixed.
- **Angular SPAs ignore element.click().** Use `Input.dispatchMouseEvent` with coordinates from `getBoundingClientRect()`.
- **Chrome must be FULLY closed.** `taskkill /F /IM chrome.exe` before debug flags. Windows firewall blocks WSL2 — need portproxy + rules.
- **Output always to D: drive.** `/mnt/d/quick-facts-channel/`. Config synced between both locations.
- **YouTube OAuth redirect_uri must be explicit.** Build URL manually when library omits it.
- **Reuse notebook, don't recreate.** Add new sources to existing Quick Facts notebook.
- **Separate YouTube credentials.** Never reuse GameSins token.
