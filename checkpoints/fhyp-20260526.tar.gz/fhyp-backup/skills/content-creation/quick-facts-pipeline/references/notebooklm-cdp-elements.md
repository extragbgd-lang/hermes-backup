# NotebookLM CDP Element Patterns (May 2026 — New UI)

The NotebookLM UI changed significantly around May 2026. These are the CURRENT element patterns for Chrome CDP automation.

## Onboarding Dismissal (REQUIRED for new notebooks)

New notebooks show an onboarding screen:
- "What would you like this notebook to help you do?"
- Four buttons: "Start a project", "Learn or understand something", "Create a podcast, video, slide deck, etc.", "Something else..."

**Fix:** Click "Create a podcast, video, slide deck, etc." to dismiss onboarding. Without this, the source panel and Studio won't work.

CDP JS to find and click:
```javascript
var btns = document.querySelectorAll('button');
for (var i=0; i<btns.length; i++) {
    if (btns[i].textContent.includes('video') || btns[i].textContent.includes('podcast')) {
        btns[i].click(); break;
    }
}
```

## Tab Structure

Three tabs visible as `role="button"` divs:
- **Sources** — Left panel for managing sources. Contains "Add source" button when expanded.
- **Chat** — Center/main area. DO NOT paste scripts here — adds to chat, not sources.
- **Studio** — Right panel. Contains Video Overview, Audio Overview, Slide Deck, etc.

The tabs are NOT `<button>` elements — they're `<div role="button">`. Use `Input.dispatchMouseEvent` to click.

To find Sources coordinates:
```javascript
var all = document.querySelectorAll('[role="button"]');
for (var i=0; i<all.length; i++) {
    if (all[i].textContent.trim() === 'Sources') {
        var rect = all[i].getBoundingClientRect();
        JSON.stringify({x: rect.x + rect.width/2, y: rect.y + rect.height/2});
        break;
    }
}
```

## Adding a Source (Copied Text)

1. Click "Sources" tab to expand source panel
2. Click "Add source" button → dialog opens with options
3. Click "Copied text" button IN THE DIALOG (not the main page)
4. Wait 1-2s for textarea to appear
5. Find `<textarea>` — it's inside the dialog, NOT the chat textbox
6. Set `textarea.value` + dispatch `input` event + `change` event
7. Click "Insert" button

**Pitfall:** After clicking "Copied text", a dialog opens with a textarea. If `document.querySelector('textarea')` returns null, the dialog hasn't loaded yet. Wait and retry.

**Pitfall:** The Chat also has a textbox. Make sure you're in the Source dialog, not the Chat. The Source dialog has a "Pasted text" label above the textarea.

## Finding Video Overview in Studio

After source is processed (check for "1 source" in body text):
1. Look for button containing "Video Overview" text
2. Click it with `Input.dispatchMouseEvent`

If "Video Overview" text not found in page, the Studio panel may be collapsed. Click "Studio" tab first.

## Video Overview Generation Dialog

After clicking Video Overview:
- Format: "Explainer" (default) or "Brief" (shorter, better for shorts)
- Language dropdown: "English" 
- Visual style radio group: "Auto-select" (default)
- "Generate" button

Select "Brief" format for short-form content.

## Checking Generation Status

Poll with `Runtime.evaluate`:
```javascript
JSON.stringify({
    generating: document.body.innerText.includes('Generating'),
    download: document.body.innerText.includes('Download'),
    play: document.body.innerText.includes('play_arrow'),
    error: document.body.innerText.includes('failed')
});
```

Generation takes 30-180 seconds. When "Download" or "play_arrow" appears, it's done.

## Downloading Completed Video

The completed Video Overview appears as a list item in the Studio panel:
- Title (e.g., "AI and Jobs: A Quick Reality Check")
- "play_arrow" button
- "more_vert" (⋮) menu button → contains: Rename, Download, Share, Delete

Click "more_vert" to open menu, then find "Download" menuitem and click it.

Downloads go to `C:\Users\ammar\Downloads\`.

## Alternative: Reuse Existing Notebook

Instead of creating new notebooks and fighting onboarding, reuse an existing working notebook (e.g., "Sputnik and the Hidden World of Virus Eaters" ID: `5ccb2287-1917-4a32-a846-0c310ba6b06e`). Add new sources via "Add source", generate new Video Overviews. Each source gets its own Video Overview entry in the Studio panel.

## Known Notebook IDs

- Sputnik/Virophages: `5ccb2287-1917-4a32-a846-0c310ba6b06e`
- AI/Jobs (Untitled): `55fd481b-55c6-4edd-98f0-5bf205e27cfb`
- GameSins Hub: `3b421487-9ac0-4d06-bea4-957604998c70`
