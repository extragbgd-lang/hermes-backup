# NotebookLM Browser Automation — Working Flow (May 2026)

## Key Discovery: Direct Email Login Works

NotebookLM presents a direct email+password form (NOT Google OAuth popup). This is why browser automation works here but fails on Google Flow. The login form uses standard HTML inputs accessible via `browser_type` and `browser_click`.

## Credentials

- Email: `hermossybatooty@gmail.com`
- Password: `IamDangerous`
- Stored in: `~/.hermes/.env`

## Browserbase Constraint

Free plan: 5-minute session limit. Must complete login → add source → click Generate within ~4 minutes. If session expires during Video Overview generation, the generation continues on Google servers. Reconnect and find the finished video in the notebook.

## Verified Refs (from working session May 23, 2026)

These WILL differ per session — always run `browser_snapshot` first.

### Login Page
- Email field: `e11` (`textbox "Email or phone"`)
- Next button: `e7`

### Password Page
- Password field: `e12` (`textbox "Enter your password"`)
- Next button: `e7`

### NotebookLM Home
- Create new notebook: `e5` or `e16`
- GameSins notebook: `e30` (link element)

### New Notebook — Add Source Dialog
- Copied text button: `e6`
- Upload files: `e3`
- Websites: `e4`
- Drive: `e5`
- Close: `e2`

### Paste Text Dialog
- Textbox: `e4` (`textbox "Pasted text"`)
- Insert button: `e3` (disabled until text filled)
- Back button: `e1`
- Close: `e2`

### Notebook Page (after source added)
- Video Overview button (Studio panel): `e11`
- Audio Overview: `e9`
- Slide Deck: `e10`
- Mind Map: `e12`

### Customize Video Overview Dialog
- Format: Explainer `e3`, Brief `e4`
- Language: `e24` (combobox, English default)
- Visual style: Auto-select `e9`, Custom `e10`, Classic `e11`, Whiteboard `e12`, Kawaii `e13`, Anime `e14`, Watercolor `e15`, Retro print `e16`, Heritage `e17`, Paper-craft `e18`
- Generate button: `e8`

### Generating State
- Shows disabled button: `"Generating Video Overview... This may take a while"` (ref varies)
- Poll every 15-20s with `browser_snapshot`

## Session Timeout Recovery

If the session dies during generation:
1. `browser_navigate` to `https://notebooklm.google.com`
2. Login again (email/password)
3. Find the notebook in "Recent notebooks"
4. The Video Overview will be in the Studio panel if generation completed
