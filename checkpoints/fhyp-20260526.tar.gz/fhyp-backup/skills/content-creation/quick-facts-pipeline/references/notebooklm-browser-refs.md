# NotebookLM Browser Refs — Working Session (May 2026)

These refs are from a successful Hermes browser automation session. Refs change every session — always `browser_snapshot` first. These are reference patterns, not guaranteed refs.

## Login Flow

### Page 1: Email
- URL: `https://accounts.google.com/v3/signin/identifier?continue=...notebooklm.google.com...`
- Email textbox: ref pattern `e10` or `e11` — labeled "Email or phone"
- Next button: ref pattern `e7` or `e3` — button "Next"

### Page 2: Password
- URL: same domain, password entry
- Google shows "Welcome" with user email
- Password textbox: ref `e12` — labeled "Enter your password"
- Next button: ref `e7`

### Successful login redirects to: `https://notebooklm.google.com/`

## NotebookLM Home Page

After login, the home page shows:
- "Create new notebook" button: ref `e5` (top) or `e16` (bottom)
- Existing notebooks listed with names and links
- GameSins notebook appears as "GameSins - Content Creation Hub 🎮"

## New Notebook — Add Source Dialog

After clicking "Create new notebook", a dialog appears:
- Heading: "Create Audio and Video Overviews from your documents"
- "Copied text" button: ref `e6`
- "Upload files" button: ref `e3`
- "Websites" button: ref `e4`
- Close button: ref `e2`

## Paste Copied Text Dialog

After clicking "Copied text":
- Heading: "Paste copied text"
- Textbox: ref `e4` — labeled "Pasted text"
- Insert button: ref `e3` — disabled until text is entered, then enabled

## Notebook View (After Source Added)

- Notebook auto-named from content (e.g., "Sputnik and the Hidden World of Virus Eaters")
- Source appears in left panel as a clickable item
- "Studio" panel on the right with all generation options
- Key elements:

### Studio Panel
- "Video Overview": ref `e11`
- "Audio Overview": ref `e9`
- "Slide Deck": ref `e10`
- "Mind Map": ref `e12`
- "Infographic": ref `e16`

### Video Overview — Customize Dialog
- Format: "Explainer" (ref `e3`) or "Brief" (ref `e4`) — use Brief for shorts
- Language: combobox ref `e24` — select "English"
- Visual style: radio group, "Auto-select" is default (ref `e9`)
- Generate button: ref `e8`

### Generating State
- Button shows: "Generating Video Overview... This may take a while" — disabled, ref `e38`
- Poll every 15-20s
- When complete, Download button appears

## Session Notes

- Google's headless browser detection may trigger "This browser or app may not be secure" after repeated sessions from same headless instance
- First session in a fresh browser instance usually works
- Using the user's own Chrome (see chrome-remote-debugging.md) avoids this entirely
- NotebookLM auto-saves — notebook persists even if session dies mid-generation
- The generated video remains available in the notebook's Studio panel
