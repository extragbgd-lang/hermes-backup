# Chrome Remote Debugging — The Standard Way (May 2026)

## Overview

Browser automation is done via Chrome DevTools Protocol (CDP) to the user's own Chrome on Windows. This REPLACES Browserbase/Browse CLI entirely — no 5-minute timeouts, no headless detection, no API keys.

## One-Time Setup (Windows, as Admin)

```cmd
netsh interface portproxy add v4tov4 listenport=9223 listenaddress=0.0.0.0 connectport=9222 connectaddress=127.0.0.1
netsh advfirewall firewall add rule name="Chrome Debug WSL" dir=in action=allow protocol=TCP localport=9222
```

## Starting Chrome (User — every session)

Close ALL Chrome windows first. Then Win+R:

```
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --remote-allow-origins=* --user-data-dir="C:\temp\chrome-debug"
```

Verify: visit `http://localhost:9222/json/version` — should show JSON.

## Connecting from WSL2

```python
import json, urllib.request, websocket

# Get WebSocket URL
resp = urllib.request.urlopen("http://192.168.100.17:9223/json/version", timeout=5)
ws_url = json.loads(resp.read())["webSocketDebuggerUrl"]

# Connect
ws = websocket.create_connection(ws_url, timeout=15)

# Send CDP commands
def cmd(ws, method, params=None, session_id=None):
    msg = {"id": 1, "method": method, "params": params or {}}
    if session_id:
        msg["sessionId"] = session_id
    ws.send(json.dumps(msg))
    # Read response (simplified — increment id and match in production)
    return json.loads(ws.recv())
```

## Key CDP Methods

| Method | What It Does |
|---|---|
| `Page.enable` | Enable page domain |
| `Page.navigate` | Navigate to URL |
| `Runtime.enable` | Enable JS execution |
| `Runtime.evaluate` | Run JavaScript in page |
| `Input.enable` | Enable mouse/keyboard input |
| `Input.dispatchMouseEvent` | Click at coordinates |
| `Target.getTargets` | List open tabs |
| `Target.attachToTarget` | Attach to a tab |
| `Browser.setDownloadBehavior` | Set download path |

## Finding Element Coordinates

Use `Runtime.evaluate` to run JS that finds element positions:

```javascript
var el = document.querySelector('button');
var rect = el.getBoundingClientRect();
JSON.stringify({x: rect.x + rect.width/2, y: rect.y + rect.height/2});
```

Then click with:
```python
cmd(ws, "Input.dispatchMouseEvent", {"type": "mousePressed", "x": x, "y": y, "button": "left", "clickCount": 1}, sid)
cmd(ws, "Input.dispatchMouseEvent", {"type": "mouseReleased", "x": x, "y": y, "button": "left", "clickCount": 1}, sid)
```

## Downloads

Files download to `C:\Users\ammar\Downloads\` — accessible from WSL2 at `/mnt/c/Users/ammar/Downloads/`.

## Pitfalls

- **Angular apps ignore programmatic clicks.** Use `Input.dispatchMouseEvent` for SPA frameworks.
- **Chrome must be fully closed before starting.** Use `taskkill /F /IM chrome.exe` if needed.
- **WSL2 IP may change.** Always fetch with `ip route show default | awk '{print $3}'`.
- **Don't use Browserbase/Browse CLI.** It has 5-min timeouts and Google detects headless mode.
