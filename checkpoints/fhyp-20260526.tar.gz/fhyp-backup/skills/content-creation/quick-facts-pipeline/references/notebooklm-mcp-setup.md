# notebooklm-mcp — REST API for NotebookLM Automation

Project: `roomi-fields/notebooklm-mcp` (81⭐, MIT, updated May 2026)
GitHub: https://github.com/roomi-fields/notebooklm-mcp
npm: `@roomi-fields/notebooklm-mcp` v2.0.0

33-endpoint REST API wrapping NotebookLM via Playwright. Citation-backed Q&A, full Studio generation (video, audio, infographic, report, presentation, data table), multi-account rotation with auto-reauth. Batch-tested on 1000+ overnight runs.

## Why Use This Instead of Raw CDP

- **Handles NotebookLM UI changes.** Playwright selectors are more robust than raw CDP clicks on Angular SPAs. The project was updated for the v2 NotebookLM UI (May 2026).
- **Single API calls.** Adding a source + generating video is 2 HTTP calls, not 8+ CDP steps with fragile timing.
- **Downloads files directly.** No guessing download paths or polling the browser.
- **Runs on Windows.** Playwright needs Windows Chrome. Server runs on Windows, WSL2 calls `localhost:3000`.

## Key Endpoints (for Quick Facts pipeline)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `POST` | `/content/sources` | Add text as source (`source_type: "text"`) |
| `POST` | `/content/generate` | Generate video (`content_type: "video"`, `video_format: "brief"`) |
| `GET` | `/content/download?content_type=video&output_path=...` | Download generated MP4 |
| `GET` | `/health` | Check server and auth status |
| `POST` | `/notebooks/create` | Create new notebook |
| `GET` | `/notebooks/scrape` | List all notebooks |

## One-Time Setup (Windows) — USE CMD, NOT POWERSHELL

**ALWAYS use Command Prompt (cmd.exe), not PowerShell.** PowerShell blocks npm scripts by default due to execution policy (`File …\npm.ps1 cannot be loaded because running scripts is disabled on this system`). CMD has no such restriction. Open `cmd.exe` and proceed below.

### 1. Clone to D: drive (Windows-accessible)

```cmd
D:
cd \
git clone https://github.com/roomi-fields/notebooklm-mcp.git
cd notebooklm-mcp
```

**Drive-switching gotcha:** `cd D:\notebooklm-mcp` from `C:\Users\ammar` does NOT switch drives in CMD. You must type `D:` first, then `cd notebooklm-mcp`. Or use `cd /d D:\notebooklm-mcp` (single command that switches drive + directory).

### 2. Install + Build

```cmd
npm install
npm run build
```

### 3. Configure .env

Create `D:\notebooklm-mcp\.env`:
```env
NOTEBOOK_URL=https://notebooklm.google.com/notebook/YOUR-NOTEBOOK-ID
HTTP_HOST=0.0.0.0
HTTP_PORT=3000
NODE_ENV=production
HEADLESS=false
STEALTH_ENABLED=true
NOTEBOOKLM_UI_LOCALE=en
MAX_SESSIONS=10
SESSION_TIMEOUT=900
DATA_DIR=./Data
CHROME_PROFILE_DIR=./Data/chrome_profile
BROWSER_STATE_DIR=./Data/browser_state
```

**⚠️ The `.env` file is NOT auto-loaded by this project.** Unlike most Node.js projects that use `dotenv`, this one reads from `process.env` directly (the shell environment, not the file). `BROWSER_CHANNEL` and other vars must be set as ACTUAL environment variables before running commands. The `.env` file exists for documentation/self-documentation only — the project doesn't load it.

**CRITICAL — `BROWSER_CHANNEL=chrome` must be set in the shell:**
```cmd
set BROWSER_CHANNEL=chrome
```
The project uses `patchright` (Playwright fork) which defaults to `chromium` channel — looking for its own downloaded Chromium at `ms-playwright/chromium-1194/chrome-win/chrome.exe`. Setting `BROWSER_CHANNEL=chrome` as an environment variable tells it to use the user's existing Google Chrome installation instead. Without this, `setup-auth` fails with: `Executable doesn't exist at …\\ms-playwright\\chromium-1194\\chrome-win\\chrome.exe`.

If you prefer the bundled Chromium, run `npx playwright install chromium` instead — but the `chrome` channel is simpler and avoids a ~300MB download.

**⚠️ `HEADLESS=false` required when using `BROWSER_CHANNEL=chrome`.** When `HEADLESS=true` (default), patchright tries to use `chromium_headless_shell-1194` which is a separate bundled binary that only exists if `npx playwright install chromium` was run. With `BROWSER_CHANNEL=chrome`, headless mode still looks for this bundled headless shell — not the system Chrome. Set `HEADLESS=false` to use the system Chrome in visible mode (same as auth setup). Chrome windows will pop up during content generation — don't touch them, the automation handles everything.

```cmd
# Required for every server start:
set BROWSER_CHANNEL=chrome
# .env must also have HEADLESS=false
npm run start:http
```

### 4. Authenticate (opens Chrome)

```cmd
set BROWSER_CHANNEL=chrome
npm run setup-auth
```

- Chrome opens in visible window
- Sign in with your Google account
- Navigate to notebooklm.google.com, wait for load
- Close Chrome — session saved to `%LOCALAPPDATA%\notebooklm-mcp\Data\`

### 5. Start server + Allow WSL2 access

```cmd
npm run start:http
```

Keep this terminal open. Server listens on `localhost:3000`.

**Windows Firewall — allow WSL2 to reach port 3000 (one-time, run as Administrator in PowerShell):**

```powershell
New-NetFirewallRule -DisplayName "NotebookLM API WSL" -Direction Inbound -Port 3000 -Protocol TCP -Action Allow
```

Without this rule, `curl` from WSL2 fails with `exit code 7` (connection refused) or `exit code 28` (timeout).

**From WSL2, use the Windows host IP (not `localhost`):**
```bash
# WSL2's default gateway IS the Windows host
WINDOWS_IP=$(ip route | grep default | awk '{print $3}')
curl -s "http://$WINDOWS_IP:3000/health"
```
Typical gateway IPs: `172.23.240.1` (WSL2 NAT), `192.168.100.17` (LAN). If mirrored networking is enabled in `.wslconfig`, `localhost` may also work.

## Quick Facts Video Generation (from WSL2)

```bash
# Add AI script as source
curl -s -X POST http://localhost:3000/content/sources \
  -H "Content-Type: application/json" \
  -d '{
    "source_type": "text",
    "text": "AI isn'\''t coming for your job — it already took it...",
    "title": "Quick Fact: AI Will Replace People",
    "notebook_url": "https://notebooklm.google.com/notebook/YOUR-ID"
  }'

# Generate video (Brief format, English)
curl -s -X POST http://localhost:3000/content/generate \
  -H "Content-Type: application/json" \
  -d '{
    "content_type": "video",
    "video_format": "brief",
    "language": "English",
    "notebook_url": "https://notebooklm.google.com/notebook/YOUR-ID"
  }'

# Download MP4 to D: drive
curl -s "http://localhost:3000/content/download?content_type=video&output_path=D:/quick-facts-channel/output/videos/video.mp4"
```

## Video Visual Styles

`classroom`, `documentary`, `animated`, `corporate`, `cinematic`, `minimalist`

Add `"video_style": "documentary"` to the generate body. Default is auto-selected.

## New NotebookLM UI (May 2026) — Required Patches

As of May 2026, NotebookLM deployed a new UI that breaks two things in `roomi-fields/notebooklm-mcp`. These patches are REQUIRED before content generation works. Apply them in `/tmp/notebooklm-mcp/src/content/content-generator.ts` then rebuild and copy `dist/` to `D:\\notebooklm-mcp\\`.

### Patch 1: "Discussion" tab renamed to "Chat"

The old UI had tabs: Sources | **Discussion** | Studio. The new UI has: Sources | **Chat** | Studio. The `navigateToDiscussion()` method only looks for "Discussion". Fix at line ~232:

```typescript
private async navigateToDiscussion(): Promise<void> {
    const discussionSelectors = [
      'div.mdc-tab:has-text("Chat")',          // ← ADDED
      'div.mdc-tab:has-text("Discussion")',
      '.mat-mdc-tab:has-text("Chat")',         // ← ADDED
      '.mat-mdc-tab:has-text("Discussion")',
      '[role="tab"]:has-text("Chat")',         // ← ADDED
      '[role="tab"]:has-text("Discussion")',
      'div.mdc-tab >> text=Chat',              // ← ADDED
      'div.mdc-tab >> text=Discussion',
    ];
```

Without this, the chat fallback fails silently because it can't find the Discussion tab to switch to before looking for the chat input.

### Patch 2: Chat input selectors need more fallbacks

The old UI had `textarea.query-box-input`. The new UI sometimes uses different aria-labels. Fix at line ~617:

```typescript
const chatInputSelectors = [
      'textarea.query-box-input',
      'textarea[aria-label*="query"]',
      'textarea[aria-label="Feld für Anfragen"]',     // ← ADDED (German — confirmed working)
      'textarea[aria-label*="Zone de requete"]',
      'textarea[placeholder*="Ask"]',                  // ← ADDED (new UI placeholder)
      'textarea:not([aria-hidden="true"])',            // ← ADDED (generic fallback)
    ];
```

### Applying patches

```bash
# Edit the source file in /tmp (copied from initial clone)
# Then rebuild:
cd /tmp/notebooklm-mcp && npm run build

# Copy updated dist to Windows:
cp /tmp/notebooklm-mcp/dist/content/content-generator.js /mnt/d/notebooklm-mcp/dist/content/

# Restart server on Windows (Ctrl+C, then):
set BROWSER_CHANNEL=chrome && npm run start:http
```

## Troubleshooting

### "Chat input not found" or "Chat fallback failed"
→ Apply Patch 1 AND Patch 2 above, rebuild, restart server.

### "Chrome not found" — Server running in WSL, not Windows
Kill node processes, start from PowerShell on Windows: `npm run start:http`

### Port 3000 in use
```powershell
taskkill /F /IM node.exe
npm run start:http
```

### Auth expired
```powershell
npm run setup-auth
```

### Server health check
```bash
curl http://localhost:3000/health
# → {"success":true,"data":{"authenticated":true,...}}
```

## Saved Notebook IDs

- **Sputnik (virophages)** — `5ccb2287-1917-4a32-a846-0c310ba6b06e` (2 sources: virophages + AI jobs script. Video generation attempted — used for Quick Facts pipeline testing.)
- **GameSins Hub** — `3b421487-9ac0-4d06-bea4-957604998c70`
- **Untitled (AI jobs, onboarding blocked)** — `55fd481b-55c6-4edd-98f0-5bf205e27cfb` (0 sources, unusable due to onboarding)
- **Empty untitled** — `7f1c6008-7d9f-4cc6-8ef3-f5c3ed13379c` (unused)

**Recommendation:** Reuse the Sputnik notebook for Quick Facts testing. Add new scripts as additional text sources. Each source generates its own Video Overview based on all sources — or prompt NotebookLM to focus on a specific source.
