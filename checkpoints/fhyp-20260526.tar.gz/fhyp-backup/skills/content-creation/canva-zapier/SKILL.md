---
name: canva-zapier
description: Create, export, and search Canva designs through Hermes' built-in Zapier MCP integration. Uses execute_zapier_write_action and execute_zapier_read_action tools.
---

# Canva via Zapier MCP

Hermes has Canva connected through the built-in Zapier MCP integration (top-level `zapier:` in config.yaml, NOT an mcp_servers entry). Canva's app ID in Zapier is `App205891CLIAPI` with 12 actions (7 write, 5 search).

## Available Canva Actions

### Write Actions (for creating/exporting)
- `create_design` — Create a new design
- `create_design_export_job` — Export a design as PNG/JPG/PDF/MP4/GIF/PPTX
- `create_design_autofill_job` — Autofill a brand template
- `create_asset_upload_job` — Upload an asset
- `move_folder_item` — Move items between folders

### Read Actions (for searching/checking)
- `find_design` — Search for designs
- `get_design_export_job` — Check export job status
- `get_design_autofill_job` — Check autofill job status
- `get_asset_upload_job` — Check asset upload status
- `get_design_import_job` — Check import job status

## How to Use

### Create a Design
```
execute_zapier_write_action(
  app: "Canva",
  action: "create_design",
  instructions: "Create a design titled X with custom dimensions",
  params: {
    title: "Design Name",
    design_type__type: "custom",  // or "preset" for templates
    design_type__width: 1920,     // for custom type
    design_type__height: 1080     // for custom type
  },
  output: "design_id, url"
)
```

### Export a Design
```
execute_zapier_write_action(
  app: "Canva",
  action: "create_design_export_job",
  instructions: "Export design DESIGN_ID as PNG",
  params: {
    design_id: "DESIGN_ID_HERE",
    format__type: "png"   // or jpg, pdf, pptx, gif, mp4
  },
  output: "url"
)
```

### Check Export Status
```
execute_zapier_read_action(
  app: "Canva",
  action: "get_design_export_job",
  instructions: "Check export job JOB_ID",
  params: {
    job_id: "JOB_ID_HERE"
  },
  output: "url"
)
```

### Search Designs
```
execute_zapier_read_action(
  app: "Canva",
  action: "find_design",
  instructions: "Find designs matching QUERY",
  params: {
    query: "GameSins"  // search term
  },
  output: "url, design_id"
)
```

## Flow for Content Creation
1. `create_design` → get `design_id` and edit URL
2. User edits design in Canva web editor
3. `create_design_export_job` → get `job_id`
4. `get_design_export_job` → get download URL
5. Download PNG and use in content

## Important Notes
- Designs are editable via the returned Canva URL
- Export formats supported: pdf, jpg, png, pptx, gif, mp4
- The tool may ask follow-up questions about assets — respond to create without assets by including `instructions` clearly: `"No assets needed, just create the design."`
- Canva Zapier token stored in config.yaml under `zapier:` (top-level key, NOT mcp_servers)

## CRITICAL LIMITATION: Canva creates BLANK canvases only

**This is the single most important fact about this tool.** Canva via Zapier's `create_design` action produces an **empty frame with zero visual content** -- no text, no graphics, no images, no design elements. The user sees a white page and will ask "where is the design?"

**Use Canva only for:**
- Creating a blank template/canvas that the USER will manually edit in the Canva web editor
- Exporting an existing user-designed Canva template as PNG/JPG/PDF
- Asset uploads to Canva's library

**Do NOT use Canva when you need automated visual content creation** (text on screen, title cards, thumbnails, graphics, overlays). These are what you want:

| Need | Tool |
|------|------|
| Animated title cards, b-roll, overlays | **HyperFrames** |
| Static graphics with text (thumbnails) | **HyperFrames** |
| Charts, diagrams, infographics | HyperFrames (via Mermaid) or html-broll-diagrams |
| Branded video compositions | HyperFrames |
| Blank canvas for manual editing | Canva |
| Export an existing Canva template | Canva |

**HyperFrames is the correct tool for GameSins content production.** It handles Arabic text with Cairo/Rubik fonts, GSAP animations, title cards, and overlays. Canva is only useful when the user specifically asks for a Canva template to edit manually.

## Pitfalls

### API Edit URLs don't work in browser
The `url` returned from `create_design` has path `/api/design/TOKEN/edit` -- these produce **400 Client Error** when opened directly. The user cannot view the design from this link. Instead:
- Use the design ID directly at `https://www.canva.com/design/DAHKxxxxx/edit` (try the standard format)
- Or export the design as PNG and send the downloaded image via `MEDIA:` path
- **Best approach: ask the user if they want to open the design too** -- they may prefer to edit it manually

### Export download URL has masked signature
The `results` field from `get_design_export_job` contains an S3 pre-signed URL where the `X-Amz-Signature=` value is masked as `***` by Zapier. **However, downloading via Python `urllib.request.urlopen()` still works** because the SDK gets the unmasked URL internally. Do NOT try to parse or modify the URL -- just pass it directly to `urllib.request.Request()`.

### Follow-up questions from Zapier
The `create_design` action often returns `{"followUpQuestion": "Would you like to add..."}` instead of a design result. To skip this, re-call with explicit `instructions` like `"No asset needed, just create a blank design."` and include `output: "design_id, url"`.

### Preset designs vs Custom
- `preset` type uses `design_type__preset_design_type` (e.g. `"presentation"`, `"doc"`, `"whiteboard"`)
- `custom` type uses `design_type__width` and `design_type__height` (e.g. 1920x1080)
- **Both types produce blank canvases** -- preset templates have a pre-sized frame but still NO text/graphics/design content added by the API

## Verification Script
See `scripts/verify-canva.py` for a self-contained Python script that creates, exports, and downloads a Canva design end-to-end.