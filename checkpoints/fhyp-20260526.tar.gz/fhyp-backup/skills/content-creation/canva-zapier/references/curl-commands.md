# Canva via Zapier — Verified curl Commands

All examples use `$ZAPIER_URL` which expands to the full MCP endpoint URL.

## 1. Search for Canva in Zapier catalog
```bash
curl -s $ZAPIER_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"discover_zapier_actions","arguments":{"app":"Canva"}}}'
```
Returns: app ID `App205891CLIAPI`, 12 actions (7 write, 5 search)

## 2. Create a design
```bash
curl -s $ZAPIER_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc":"2.0","id":2,
    "method":"tools/call",
    "params":{"name":"execute_zapier_write_action","arguments":{
      "app":"Canva","action":"create_design",
      "instructions":"Create a custom design. No asset needed.",
      "params":{"title":"My Design","design_type__type":"custom","design_type__width":1920,"design_type__height":1080},
      "output":"design_id, url"
    }}
  }'
```

## 3. Export as PNG
```bash
curl -s $ZAPIER_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc":"2.0","id":3,
    "method":"tools/call",
    "params":{"name":"execute_zapier_write_action","arguments":{
      "app":"Canva","action":"create_design_export_job",
      "instructions":"Export design DESIGN_ID as PNG",
      "params":{"design_id":"DESIGN_ID","format__type":"png"},
      "output":"job_id"
    }}
  }'
```

## 4. Check export status + get download URL
```bash
curl -s $ZAPIER_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc":"2.0","id":4,
    "method":"tools/call",
    "params":{"name":"execute_zapier_read_action","arguments":{
      "app":"Canva","action":"get_design_export_job",
      "instructions":"Check job JOB_ID",
      "params":{"job_id":"JOB_ID"},
      "output":"url"
    }}
  }'
```

## 5. Search designs
```bash
curl -s $ZAPIER_URL \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc":"2.0","id":5,
    "method":"tools/call",
    "params":{"name":"execute_zapier_read_action","arguments":{
      "app":"Canva","action":"find_design",
      "instructions":"Find designs matching GameSins",
      "params":{"query":"GameSins"},
      "output":"url, design_id, title"
    }}
  }'
```

## 6. Download exported image via Python
The download URL has a masked `X-Amz-Signature=***` but urllib still works:
```python
import urllib.request
req = urllib.request.Request(DOWNLOAD_URL)
with urllib.request.urlopen(req) as resp:
    img = resp.read()
    with open("/tmp/canva.png", "wb") as f:
        f.write(img)
```

## Tokens / Auth
Format: `https://mcp.zapier.com/api/v1/connect?token=BASE64_TOKEN`
Stored in config.yaml under top-level `zapier:` key (NOT mcp_servers).