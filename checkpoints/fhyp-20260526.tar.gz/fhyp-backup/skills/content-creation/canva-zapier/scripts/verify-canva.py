#!/usr/bin/env python3
"""End-to-end Canva design test: create, export, download.

Run: python3 verify-canva.py
Requires: Zapier MCP token in config.yaml (zapier: url: ...)
"""
import json, urllib.request, time, sys, os

TOKEN = None
# Try to extract token from config
config_path = os.path.expanduser("~/.hermes/config.yaml")
if os.path.exists(config_path):
    with open(config_path) as f:
        for line in f:
            if "token=" in line:
                TOKEN = line.split("token=")[-1].strip().strip('"\'')
                break

if not TOKEN:
    print("ERROR: Could not find Zapier token in ~/.hermes/config.yaml")
    print("Set ZAPIER_TOKEN env var or add token to config.yaml")
    sys.exit(1)

BASE_URL = f"https://mcp.zapier.com/api/v1/connect?token={TOKEN}"

def call_mcp(method, params):
    data = json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params}).encode()
    req = urllib.request.Request(BASE_URL, data=data,
        headers={"Content-Type":"application/json","Accept":"application/json, text/event-stream"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        body = resp.read().decode()
        for line in body.splitlines():
            if line.startswith("data: "):
                d = json.loads(line[6:])
                txt = json.loads(d["result"]["content"][0]["text"])
                return txt
    return None

# Step 1: Create design
print("1. Creating Canva design...")
r1 = call_mcp("tools/call", {
    "name":"execute_zapier_write_action",
    "arguments":{
        "app":"Canva",
        "action":"create_design",
        "instructions":"Create a blank custom design. No assets needed.",
        "params":{"title":"Canva Test via Script","design_type__type":"custom","design_type__width":1920,"design_type__height":1080},
        "output":"design_id"
    }
})
did = r1.get("results",{}).get("design_id","")
if not did:
    print(f"  Follow-up needed: {r1.get('followUpQuestion','?')}")
    print("  Re-calling with explicit instructions...")
    r1 = call_mcp("tools/call", {
        "name":"execute_zapier_write_action",
        "arguments":{
            "app":"Canva","action":"create_design",
            "instructions":"Create a blank custom design titled 'Canva Test'. No asset needed, just a blank canvas.",
            "params":{"title":"Canva Test via Script","design_type__type":"custom","design_type__width":1920,"design_type__height":1080},
            "output":"design_id"
        }
    })
    did = r1.get("results",{}).get("design_id","")
print(f"  Design ID: {did}")

# Step 2: Export
print("2. Exporting as PNG...")
r2 = call_mcp("tools/call", {
    "name":"execute_zapier_write_action",
    "arguments":{
        "app":"Canva","action":"create_design_export_job",
        "instructions":f"Export {did} as PNG",
        "params":{"design_id":did,"format__type":"png"},
        "output":"job_id"
    }
})
job_id = r2.get("results",{}).get("job_id","")
print(f"  Job ID: {job_id}")

# Step 3: Wait and check
time.sleep(8)
print("3. Checking export status...")
r3 = call_mcp("tools/call", {
    "name":"execute_zapier_read_action",
    "arguments":{
        "app":"Canva","action":"get_design_export_job",
        "instructions":f"Check job {job_id}",
        "params":{"job_id":job_id},
        "output":"url"
    }
})
dl_url = r3.get("results","")
print(f"  Download URL: {dl_url[:80]}...")

# Step 4: Download
print("4. Downloading image...")
req = urllib.request.Request(dl_url)
with urllib.request.urlopen(req, timeout=30) as resp:
    img = resp.read()
    out = "/tmp/canva_verify.png"
    with open(out, "wb") as f:
        f.write(img)
    print(f"  {len(img)} bytes saved to {out}")
    print(f"  Type: {resp.headers.get('Content-Type','?')}")
    print("\n✅ Canva workflow verified!")