---
name: mermaid-diagrams
title: Mermaid Diagrams
description: Generate professional diagrams from video scripts using Mermaid CLI — flowcharts, mind maps, timelines, and more.
category: content-creation
triggers:
  - "generate diagrams from script"
  - "create diagram for video"
  - "visualize script content"
  - "diagram generation pipeline"
---

# Mermaid Diagrams Skill

Convert video scripts into professional SVG/PNG diagrams for use in HyperFrames compositions or video overlays. Built on [Mermaid](https://mermaid.js.org/) CLI (`mmdc`).

## Prerequisites

- Node.js >= 18 (v20.20.2 installed)
- `mmdc` installed globally: `npm install -g @mermaid-js/mermaid-cli`
- Output directory: `/mnt/d/hyperframe output/diagrams/`

## Supported Diagram Types

| Type | Best For | Mermaid Syntax |
|------|----------|---------------|
| **Flowchart** | Game mechanics, decision trees, processes, pipeline flows | `flowchart TD` or `LR` |
| **Mind Map** | Review breakdown, feature analysis, topic structure | `mindmap` |
| **Timeline** | Game series evolution, update history, development roadmap | `timeline` |
| **Sequence** | Game quest flow, dialogue trees, interaction order | `sequenceDiagram` |
| **Class/Graph** | Game systems, entity relationships, progression trees | `classDiagram` |
| **Pie/XY Chart** | Stats distributions, score breakdowns, rating splits | `pie` / `xyChart` |
| **Block Diagram** | System architecture, toolchain, workflow infrastructure | `block` |
| **Quadrant** | Feature comparison matrix, genre classification | `quadrantChart` |

## GameSins Brand Styling

Use this config file for all diagrams:

```json
{
  "backgroundColor": "transparent",
  "theme": "base",
  "themeVariables": {
    "fontFamily": "Cairo, Arial, sans-serif",
    "primaryColor": "#6c5ce7",
    "primaryTextColor": "#ffffff",
    "primaryBorderColor": "#5a4bd1",
    "lineColor": "#636e72",
    "secondaryColor": "#2d3436",
    "tertiaryColor": "#dfe6e9"
  }
}
```

Save as `~/.config/mermaid/config.json` or pass with `-c <path>`.

## Workflow

### 1. Analyze Script
Parse the video script to extract:
- **Sections** (Introduction, Topic 1, Topic 2, Conclusion)
- **Key entities** (games, features, comparisons)
- **Flow/sequence** (cause and effect, progression)
- **Data points** (scores, ratings, stats)

### 2. Decide Diagram Types
- **Mind map** → For scripts with 3+ topic categories
- **Flowchart** → For process/gameplay/decision explanations
- **Timeline** → For version history or series evolution
- **Comparison** → For vs-content (game A vs game B)
- **Pie/XY** → For stats-heavy scripts

### 3. Write Mermaid Definition
Use the `%%{init: ...}%%` header for styling, then the diagram body.

**Flowchart template:**
```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#6c5ce7', 'primaryTextColor': '#ffffff',
  'lineColor': '#636e72'
}}}%%
flowchart TD
    A[Topic] --> B[Subtopic 1]
    A --> C[Subtopic 2]
    B --> D[Conclusion]
    style A fill:#6c5ce7,color:#fff
```

**Mind map template:**
```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#0984e3', 'primaryTextColor': '#ffffff'
}}}%%
mindmap
  root((Script Topic))
    Section 1
      Point A
      Point B
    Section 2
      Point C
      Point D
```

### 4. Render to SVG/PNG

```bash
# SVG (best for video - transparent, scalable)
mmdc -i input.mmd -o output.svg -c ~/.config/mermaid/config.json -w 1200

# PNG (for thumbnails/thumbnails)
mmdc -i input.mmd -o output.png -c ~/.config/mermaid/config.json -w 1920 -H 1080

# Custom width
mmdc -i input.mmd -o output.svg -w 1600
```

### 5. Use in HyperFrames
SVG files can be embedded directly in HyperFrames HTML compositions:
```html
<img src="../diagrams/output.svg" style="width:100%; height:auto;">
```

## Output Location
All diagram outputs go to: `/mnt/d/hyperframe output/diagrams/`

## Pitfalls
- Mind map text has strict indent rules (spaces, not tabs)
- Flowchart node IDs must be unique and use capital letters (A, B, C...)
- Emoji in node labels preferred for visual pop (🎮 ⭐ 🎬 🔥 📊 🆚)
- Long text in nodes → use `<br>` for line breaks or keep to 3-5 words max
- Always check rendered SVG visually before adding to video
- `mmdc` requires Puppeteer (auto-installed with npm package)
- **Transparent background quirk:** Mermaid v11 ignores `backgroundColor: "transparent"` in the config file for the SVG wrapper. The SVG has `style="background-color: white"` hardcoded. Fix with a post-render sed: `sed -i 's/background-color: white/background-color: transparent/g' output.svg`
- **Arabic text renders correctly** in Mermaid — RTL labels work. Use Cairo font in themeVariables for Arabic scripts.
- **block-beta syntax is picky:** special characters break parsing. Use simple block labels with plain text.
- **Mind map indent:** EXACTLY 2 spaces per level. Tabs break parsing silently.
- **Do NOT generate more than 3 diagrams per script** — 2 is the sweet spot.
