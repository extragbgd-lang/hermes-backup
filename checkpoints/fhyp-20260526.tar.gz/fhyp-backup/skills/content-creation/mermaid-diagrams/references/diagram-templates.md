# Mermaid Diagram Templates for GameSins

## Template 1: Game Review Mind Map

```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#6c5ce7', 'primaryTextColor': '#ffffff'
}}}%%
mindmap
  root((🎮 [GAME NAME]))
    📖 Story
      Characters
      Plot
      Setting
    ⚔️ Gameplay
      Combat
      Exploration
      Progression
    🎨 Graphics
      Art Style
      Performance
    🔊 Sound
      Music
      Voice Acting
    ⭐ Verdict  [SCORE/10]
```

## Template 2: Comparison Flowchart

```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#e17055', 'primaryTextColor': '#ffffff'
}}}%%
flowchart LR
    subgraph GameA["🎮 Game A"]
        A1[Feature 1]
        A2[Feature 2]
        A3[Rating: X/10]
    end
    subgraph GameB["🎮 Game B"]
        B1[Feature 1]
        B2[Feature 2]
        B3[Rating: Y/10]
    end
    GameA --> Winner["🏆 Best Choice"]
    GameB --> Winner
```

## Template 3: Game Evolution Timeline

```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#0984e3', 'primaryTextColor': '#ffffff'
}}}%%
timeline
    title [GAME] Evolution
    [Year 1] : Launch : Initial reviews
    [Year 2] : Major Update : New features
    [Year 3] : Expansion : DLC release
    [Year 4] : Current State : Community & support
```

## Template 4: Combat/Mechanics Flowchart

```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#00b894', 'primaryTextColor': '#ffffff'
}}}%%
flowchart TD
    A[⚔️ Combat Start] --> B{Choose Weapon}
    B --> C[🗡️ Sword]
    B --> D[🏹 Bow]
    B --> E[🛡️ Shield]
    C --> F[8 Special Abilities]
    D --> F
    E --> F
    F --> G[🔥 Combo Chain]
    G --> H[✨ Ultimate Move]
    H --> I[🏆 Victory]
```

## Template 5: Pros/Cons Block

```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'fontFamily': 'Cairo, Arial, sans-serif',
  'primaryColor': '#00b894', 'primaryTextColor': '#ffffff',
  'lineColor': '#636e72'
}}}%%
block
    block("✅ Pros")
        P1["Amazing Graphics"]
        P2["Deep Combat"]
        P3["Great Story"]
    end
    block("❌ Cons")
        C1["Repetitive Quests"]
        C2["Steep Learning Curve"]
    end
    block("⭐ Verdict")
        V["9/10 Must Play!"]
    end
end
```
