# LM Studio Reasoning Models — Structured Output Pitfall

## The Problem

Models like `qwen/qwen3.5-9b` and `google/gemma-4-e2b` (the "reasoning" or "thinking" variants loaded in LM Studio) **cannot** be made to emit clean structured JSON via system prompts.

Even with explicit instructions like:

```
Return ONLY a JSON array. No explanation, no thinking steps.
```

The model will:
1. Output everything into `message.reasoning_content` (a text field with internal thinking steps)
2. Leave `message.content` completely empty (`""`)
3. Consume all allocated `max_tokens` on reasoning, leaving zero room for the actual structured output

This makes them **unsuitable** for any task requiring reliable structured output (JSON, YAML, regex-parseable formats).

## Reproduction

Using the LM Studio OpenAI-compatible API at `http://<ip>:1234/v1/chat/completions`:

```python
import requests

r = requests.post(
    "http://192.168.100.17:1234/v1/chat/completions",
    json={
        "model": "google/gemma-4-e2b",
        "messages": [
            {"role": "system", "content": "Return ONLY a JSON array. No explanation."},
            {"role": "user", "content": 'Transcript: "0:05 - That was insane!" Find the viral moment. JSON only.'}
        ],
        "temperature": 0.2,
        "max_tokens": 400
    },
    timeout=30
)

msg = r.json()["choices"][0]["message"]
print(repr(msg.get("content", "")))        # '' — always empty
print(repr(msg.get("reasoning_content")))  # 'Thinking Process:\n1. Analyze the Request...' — 1000+ chars
```

## The Response Structure

```json
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "",
      "reasoning_content": "Thinking Process:\n\n1. Analyze the Request...\n\n2. ...",
      "tool_calls": []
    },
    "finish_reason": "length"
  }],
  "usage": {
    "completion_tokens": 200,
    "completion_tokens_details": {
      "reasoning_tokens": 197  // almost all tokens are reasoning
    }
  }
}
```

## Solutions

### Option A: Use a Non-Reasoning Model (Best)

Load a regular (non-thinking) model in LM Studio:
- `Qwen2.5-7B-Instruct` (not the reasoning/thinking variant)
- `Llama-3.1-8B-Instruct`
- `Mistral-7B-Instruct-v0.3`

These models follow "JSON only" instructions correctly and populate `content` with actual JSON.

### Option B: Increase max_tokens Dramatically

Set `max_tokens` to 800 or more so the model has room to finish reasoning AND output JSON:

```python
"max_tokens": 800  # 400 for reasoning + 400 for actual output
```

This is unreliable — the model may still use all tokens on reasoning.

### Option C: Disable Reasoning in LM Studio

Some LM Studio versions have a "Reasoning" toggle per loaded model. Check the model settings panel for an option to disable the thinking chain.

### Option D: Parse Reasoning Text (Last Resort)

If you must use a reasoning model, parse the reasoning text with regex extractors. Reasoning models typically describe their final decisions in structured prose near the end of the reasoning block:

```python
import re

def parse_reasoning(text: str):
    # Pattern 1: "Selection A: [0:05] - description"
    selection_pattern = re.compile(
        r'(?:Selection|Clip|Moment)\s*[A-Z0-9]*[:)\]]?\s*'
        r'(?:\[?\s*)([0-9.:]+)(?:\s*\])?'
        r'[\s\-–—]+(.+?)(?=\n(?:Selection|Clip|Moment)|\Z)',
        re.IGNORECASE | re.DOTALL
    )
    for m in selection_pattern.finditer(text):
        timestamp = m.group(1)
        reason = m.group(2).strip()
        # ... extract clip data ...

    # Pattern 2: "Start X, End ~Y"
    start_end = re.findall(
        r'(?:start|from)[:\s]*([0-9.]+)[\s\w,]*(?:end|to)[:\s~]*([0-9.]+)',
        text, re.IGNORECASE
    )
    for start, end in start_end:
        # ... extract clip data ...
```

This is fragile and model-specific. Always prefer Option A.

## Key Takeaway

When a user asks for structured output from LM Studio, **immediately check if the loaded model is a reasoning variant**. If so, recommend switching to a non-reasoning model rather than fighting with prompt engineering.
