# Multi-Segment Compilation Pattern for Shorts

When a single isolated clip doesn't make sense without context, compile shorts from multiple segments.

## Narrative Arc

```
[Setup] → [Moment] → [Reaction]
   3-10s     5-60s      3-15s
```

- **Setup**: Context, explanation, tension-building
- **Moment**: The viral peak — punchline, reveal, shock
- **Reaction**: Aftermath, commentary, follow-up

## Data Structure

```python
short = {
    "hook": "I NEARLY DIED",
    "reason": "Extreme reaction built on earlier tension",
    "score": 9,
    "segments": [
        {"start": 40, "end": 52, "content_type": "talking_head", "purpose": "setup"},
        {"start": 120, "end": 135, "content_type": "talking_head", "purpose": "moment"},
        {"start": 200, "end": 210, "content_type": "mixed", "purpose": "reaction"},
    ]
}
```

## Pipeline Changes

### 1. Engagement AI returns segments, not single timestamps

Old format (single clip):
```json
{"start": 45, "end": 58, "hook": "...", "reason": "...", "score": 9}
```

New format (compiled short):
```json
{
    "hook": "...",
    "reason": "...",
    "score": 9,
    "segments": [
        {"start": 40, "end": 52, "content_type": "talking_head", "purpose": "setup"},
        {"start": 120, "end": 135, "content_type": "talking_head", "purpose": "moment"}
    ]
}
```

### 2. Reframe each segment individually

Each segment may have a different content type requiring a different reframe strategy:
- `talking_head` → face-tracking crop
- `text_screen` → blur-background letterbox
- `gameplay` / `mixed` → center-crop

### 3. Concatenate with ffmpeg

```python
def concat_segments(segment_paths: List[str], output_path: str) -> str:
    if len(segment_paths) == 1:
        os.rename(segment_paths[0], output_path)
        return output_path

    list_path = os.path.join(os.path.dirname(output_path), "concat_list.txt")
    with open(list_path, "w", encoding="utf-8") as f:
        for p in segment_paths:
            f.write(f"file '{p.replace(chr(39), chr(39)+chr(92)+chr(39)+chr(39))}'\n")

    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", list_path,
        "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8M",
        "-c:a", "aac", "-pix_fmt", "yuv420p",
        output_path,
    ]
    subprocess.run(cmd, capture_output=True)
    return output_path
```

### 4. Subtitle timestamps offset by cumulative duration

When generating ASS subtitles for a compiled short, shift word timestamps by the sum of all previous segment durations:

```python
cumulative_offset = 0.0
all_words = []

for meta in short_segments_meta:
    seg_start = meta["start"]
    seg_end = meta["end"]
    seg_duration = seg_end - seg_start

    for seg in transcription_segments:
        if seg["end"] < seg_start or seg["start"] > seg_end:
            continue
        for w in seg.get("words", []):
            ws = max(w["start"], seg_start)
            we = min(w["end"], seg_end)
            if ws < we:
                all_words.append({
                    "word": w["word"].strip(),
                    "start": ws - seg_start + cumulative_offset,
                    "end": we - seg_start + cumulative_offset,
                })

    cumulative_offset += seg_duration
```

## Smart Fallback When LLM Fails

When the LLM returns no parseable output (common with reasoning models), automatically build narrative shorts by pairing high-engagement scenes with their preceding context scenes:

```python
def smart_fallback_clips(scenes: list, duration: float) -> List[Dict]:
    sorted_scenes = sorted(scenes, key=lambda s: s["duration"], reverse=True)
    clips = []
    used_starts = set()

    for s in sorted_scenes[:MAX_SHORTS_PER_VIDEO * 2]:
        start = s["start"]
        if start in used_starts:
            continue

        segments = [{
            "start": start,
            "end": min(s["end"], start + MAX_SHORT_DURATION),
            "content_type": "mixed",
            "purpose": "moment",
        }]

        # Try to include previous scene as setup
        prev_scene = None
        for ps in scenes:
            if ps["end"] <= start and (start - ps["end"]) < 60 and ps["duration"] < 45:
                prev_scene = ps
                break

        if prev_scene and prev_scene["start"] not in used_starts:
            segments.insert(0, {
                "start": prev_scene["start"],
                "end": prev_scene["end"],
                "content_type": "mixed",
                "purpose": "setup",
            })
            used_starts.add(prev_scene["start"])

        used_starts.add(start)
        total = sum(seg["end"] - seg["start"] for seg in segments)
        if total < MIN_SHORT_DURATION:
            segments[-1]["end"] = min(duration, segments[-1]["start"] + MIN_SHORT_DURATION)
        if total > MAX_SHORT_DURATION:
            segments[-1]["end"] = segments[-1]["start"] + MAX_SHORT_DURATION

        clips.append({
            "hook": "VIRAL CLIP",
            "reason": "High-engagement scene with context",
            "score": 5,
            "segments": segments,
        })

    return clips[:MAX_SHORTS_PER_VIDEO]
```

## Validation

- [ ] Each short's total duration is between MIN_SHORT_DURATION (5s) and MAX_SHORT_DURATION (90s)
- [ ] Segments are in chronological order
- [ ] No overlapping segments within a short
- [ ] Subtitle word timestamps correctly offset for multi-segment compilation
- [ ] Each segment's content_type triggers the correct reframe strategy
