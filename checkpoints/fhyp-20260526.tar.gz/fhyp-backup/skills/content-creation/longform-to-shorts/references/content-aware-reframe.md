# Content-Aware Reframe Strategies

Not all scenes should use the same 9:16 crop strategy. Auto-detect the dominant content type and pick the right approach.

## Content Type Detection

Sample a frame from the middle of the segment and classify:

```python
def detect_content_type(video_path: str, start: float, end: float) -> str:
    cap = cv2.VideoCapture(video_path)
    t = (start + end) / 2
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
    ret, frame = cap.read()
    cap.release()
    if not ret:
        return "mixed"

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 1. Face check
    cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)
    faces = cascade.detectMultiScale(gray, scaleFactor=1.05, minNeighbors=4, minSize=(30, 30))
    if len(faces) > 0:
        largest = max(faces, key=lambda f: f[2] * f[3])
        face_area = largest[2] * largest[3]
        frame_area = frame.shape[0] * frame.shape[1]
        if face_area / frame_area > 0.015:  # face is at least 1.5% of frame
            return "talking_head"

    # 2. Text screen detection: high edge density in upper half
    edges = cv2.Canny(gray, 50, 150)
    h, w = edges.shape
    upper_half = edges[:h // 2, :]
    edge_density = cv2.countNonZero(upper_half) / (upper_half.size + 1)
    if edge_density > 0.08:  # lots of edges = likely text/UI
        return "text_screen"

    return "mixed"
```

## Strategy 1: Face-Tracking Crop (talking_head)

For videos where a person is speaking. Track their face across 20-30 sampled frames and compute a stable crop center.

```python
def sample_face_positions(video_path, start, end, num_samples=30):
    cap = cv2.VideoCapture(video_path)
    positions = []
    for i in range(num_samples):
        t = start + (end - start) * (i / max(num_samples - 1, 1))
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ret, frame = cap.read()
        if ret:
            face = detect_face_center(frame)
            if face:
                positions.append(face)
    cap.release()
    return positions

def compute_stable_crop_center(positions, src_w, crop_w):
    if not positions:
        return 0.5
    xs = [p[0] for p in positions]
    mean_x = sum(xs) / len(xs)
    variance = sum((x - mean_x) ** 2 for x in xs) / len(xs)
    std_dev = math.sqrt(variance)

    # Too much movement → center-crop is safer
    if std_dev > 0.12:
        return 0.5

    xs_sorted = sorted(xs)
    median_x = xs_sorted[len(xs_sorted) // 2]

    # Edge safety: nudge inward if face near edge
    SAFE_MARGIN = 0.18
    if median_x < SAFE_MARGIN:
        return min(SAFE_MARGIN + (median_x * 0.3), 1.0 - SAFE_MARGIN)
    if median_x > 1.0 - SAFE_MARGIN:
        return max((1.0 - SAFE_MARGIN) - ((1.0 - median_x) * 0.3), SAFE_MARGIN)
    return median_x
```

**ffmpeg crop:**
```python
crop_w = int(src_h * (9 / 16))  # 0.5625 ratio
crop_w = min(crop_w, src_w)
face_x = compute_stable_crop_center(positions, src_w, crop_w)
center_x_px = int(face_x * src_w)
crop_x = max(0, min(center_x_px - crop_w // 2, src_w - crop_w))

filter_str = f"crop={crop_w}:{src_h}:{crop_x}:0,scale=1080:1920:flags=lanczos,setsar=1:1"
```

## Strategy 2: Blur-Background Letterbox (text_screen)

For screens with text, charts, or UI elements that must remain perfectly readable. The original content stays centered at its original aspect ratio, while blurred background fills the vertical space.

**Why this matters:** Face-tracking crop or center-crop will cut off edge text. Letterbox preserves everything.

**ffmpeg filter_complex:**
```
[0:v]scale=1080:1920:force_original_aspect_ratio=decrease,boxblur=20:20,scale=1080:1920[bg];
[0:v]scale=1080:-2:force_original_aspect_ratio=decrease[fg];
[bg][fg]overlay=(W-w)/2:(H-h)/2:shortest=1[outv]
```

**Python command builder:**
```python
filter_str = (
    "[0:v]scale={w}:{h}:force_original_aspect_ratio=decrease,"
    "boxblur=20:20,scale={w}:{h}[bg];"
    "[0:v]scale={w}:-2:force_original_aspect_ratio=decrease[fg];"
    "[bg][fg]overlay=(W-w)/2:(H-h)/2:shortest=1[outv]"
).format(w=SHORT_WIDTH, h=SHORT_HEIGHT)

cmd = [
    "ffmpeg", "-y", "-ss", str(start), "-t", str(duration), "-i", video_path,
    "-filter_complex", filter_str,
    "-map", "[outv]", "-map", "0:a",
    "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8M",
    "-c:a", "aac", "-pix_fmt", "yuv420p", output_path,
]
```

## Strategy 3: Center-Crop (gameplay / mixed)

For gameplay footage or mixed content where no single subject dominates.

```python
crop_w = int(src_h * (9 / 16))
crop_w = min(crop_w, src_w)
crop_x = max(0, (src_w - crop_w) // 2)

filter_str = f"crop={crop_w}:{src_h}:{crop_x}:0,scale=1080:1920:flags=lanczos,setsar=1:1"
```

## Strategy Selection Table

| Content Type | Detection Signal | Crop Strategy | Edge Behavior |
|-------------|------------------|---------------|---------------|
| talking_head | Face > 1.5% frame area | Track median face x | Nudge inward if near edge |
| text_screen | Canny edge density > 0.08 in upper half | Blur-bg letterbox | Preserves all content |
| gameplay | Neither face nor text dominant | Center-crop | Symmetric, balanced |
| mixed | Ambiguous / low confidence | Center-crop with 0.18 safe margin | Conservative |

## Verification

Always verify the output is exactly 1080×1920:

```python
def get_video_info(video_path: str) -> dict:
    cmd = ["ffprobe", "-v", "error", "-select_streams", "v:0",
           "-show_entries", "stream=width,height", "-of", "json", video_path]
    result = subprocess.run(cmd, capture_output=True, text=True)
    data = json.loads(result.stdout)
    stream = data["streams"][0]
    return {"width": int(stream["width"]), "height": int(stream["height"])}

out_info = get_video_info(output_path)
assert out_info["width"] == 1080 and out_info["height"] == 1920
```

## WSL ffmpeg D: Drive Quirk

ffmpeg often fails writing directly to `/mnt/d/...`. Write to local temp first, then move:

```python
import tempfile, shutil

temp_out = tempfile.mktemp(suffix=".mp4", dir=os.path.expanduser("~/cliply/temp"))
# ... run ffmpeg writing to temp_out ...
shutil.move(temp_out, "/mnt/d/cliply_output/shorts/final.mp4")
```
