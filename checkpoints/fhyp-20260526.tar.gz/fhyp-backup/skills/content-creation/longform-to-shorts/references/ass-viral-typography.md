# ASS Viral Typography for Shorts

Generating hundreds of PNG subtitle frames with Pillow and compositing via ffmpeg overlay is extremely slow (10+ minutes for a 30-second clip). The solution is to generate an `.ass` (Advanced SubStation Alpha) subtitle file and let ffmpeg burn it in real-time during the single-pass NVENC encode.

## Why ASS Wins

| Method | Time for 30s clip | File overhead |
|--------|-------------------|---------------|
| Pillow PNG frames | ~10-15 minutes | 600+ PNG files (~30 MB) |
| ASS subtitles | <1 second | 1 text file (~5 KB) |
| ffmpeg burn-in | Same pass as encode | Zero extra time |

## ASS Generation Pattern

```python
from PIL import ImageFont
import os

def format_ass_time(seconds: float) -> str:
    """H:MM:SS.cc"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h}:{m:02d}:{s:05.2f}"

def get_font_path() -> str:
    """Return escaped font path for ASS."""
    candidates = [
        "/mnt/c/Windows/Fonts/tahomabd.ttf",
        "/mnt/c/Windows/Fonts/tahoma.ttf",
        "/mnt/c/Windows/Fonts/arialbd.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            return p.replace("/", "\\\\")  # ASS needs double backslash
    return "Tahoma"

def build_ass_header(width: int, height: int, font_size: int, font_path: str) -> str:
    margin_v = int(height * 0.78)  # lower third
    return f"""[Script Info]
Title: Viral Captions
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Tahoma,{font_size},&H00FFFFFF,&H00FFFF00,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,3,0,2,20,20,{margin_v},1
Style: Gray,Tahoma,{font_size},&H00AAAAAA,&H00FFFF00,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,3,0,2,20,20,{margin_v},1
Style: Highlight,Tahoma,{font_size+6},&H0000FFFF,&H00FFFF00,&H00000000,&H80000000,1,0,0,0,110,110,0,0,1,4,0,2,20,20,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
```

## Word-by-Word Highlighting

For each line of text, generate:
1. A base `Gray` dialogue showing all words dimmed
2. Per-word `Highlight` dialogues during each word's timestamp, using ASS `\r` (return to style) tags to color the current word yellow and spoken words white:

```
Dialogue: 0,0:04:44.12,0:04:45.62,Gray,,0,0,0,,الناس اللي برعا علم اللي
Dialogue: 0,0:04:44.12,0:04:44.56,Highlight,,0,0,0,,{\rHighlight}الناس{\rGray} اللي برعا علم اللي
Dialogue: 0,0:04:44.56,0:04:44.82,Highlight,,0,0,0,,{\rDefault}الناس{\rGray} {\rHighlight}اللي{\rGray} برعا علم اللي
Dialogue: 0,0:04:44.82,0:04:45.20,Highlight,,0,0,0,,{\rDefault}الناس{\rGray} {\rDefault}اللي{\rGray} {\rHighlight}برعا{\rGray} علم اللي
```

Key ASS override tags used:
- `\rStyleName` — switch to named style (resets all attributes)
- `\c&HBBGGRR&` — primary color override
- Default style = white spoken words, Gray = dimmed future words, Highlight = yellow + 110% scale for current word

## Arabic Handling in ASS

ASS renders Arabic left-to-right by default. For proper RTL Arabic:
1. Reshape with `arabic_reshaper`
2. BIDI with `python-bidi` (`get_display`)
3. Use `Encoding: 1` (Unicode) in the style
4. The font must support Arabic glyphs — Tahoma from `/mnt/c/Windows/Fonts/` is the safest choice on WSL

## ffmpeg Burn-In

```python
import subprocess

# Safe path for ffmpeg (escape colons)
safe_sub = subtitle_path.replace("\\", "/").replace(":", "\\:")
filter_str = f"subtitles={safe_sub}"

cmd = [
    "ffmpeg", "-y",
    "-i", video_path,
    "-vf", filter_str,
    "-c:v", "h264_nvenc",
    "-preset", "p1",
    "-b:v", "8M",
    "-c:a", "aac",
    "-pix_fmt", "yuv420p",
    "-movflags", "+faststart",
    output_path,
]
```

This burns the styled ASS directly into the video during the NVENC encode pass — no extra rendering step needed.
