---
name: longform-to-shorts
description: Build and run a fully local AI pipeline that cuts long videos into viral 9:16 shorts with auto-reframe, word-sync subtitles, and engagement-based moment selection.
trigger: "User wants to clip long videos to shorts, build a local video short clipper, auto-reframe to vertical, burn viral captions, or process videos into TikTok/YouTube Shorts format locally"
---

# Longform-to-Shorts Pipeline

Fully local pipeline: download → transcribe → scene-detect → engagement AI → smart reframe → viral typography → compose & export.

No cloud APIs. Uses local LLM (LM Studio), local GPU (faster-whisper), and ffmpeg NVENC.

## Architecture

```
Video URL
  │
  ▼
┌─────────────┐  yt-dlp → .mp4 + audio.wav
│ 1. DOWNLOAD │
└──────┬──────┘
       │
       ▼
┌───────────────┐  faster-whisper (GPU/CPU) → word-level timestamps
│ 2. TRANSCRIBE │
└──────┬────────┘
       │
       ▼
┌──────────────────┐  PySceneDetect → scene list with durations
│ 3. SCENE DETECT  │
└──────┬───────────┘
       │
       ▼
┌──────────────────┐  Local LLM (LM Studio) → top viral moments
│ 4. ENGAGEMENT AI │
└──────┬───────────┘
       │
       ▼
┌──────────────────┐  OpenCV face tracking → 9:16 crop following subject
│ 5. SMART REFRAME │
└──────┬───────────┘
       │
       ▼
┌──────────────────┐  ASS subtitle file → word-by-word viral highlighting
│ 6. VIRAL TYPO    │
└──────┬───────────┘
       │
       ▼
┌──────────────────┐  ffmpeg NVENC → burn subtitles + hardware encode
│ 7. COMPOSITION   │
└──────────────────┘
```

## Prerequisites

| Tool | Purpose |
|------|---------|
| `yt-dlp` | Download from YouTube/X/Facebook |
| `ffmpeg` with NVENC | Hardware encode H.264 |
| `faster-whisper` | Transcription (GPU via CTranslate2) |
| `PySceneDetect` (`scenedetect`) | Scene boundary detection |
| `opencv-python` | Face detection for reframe |
| `requests` | LM Studio API calls |
| `arabic-reshaper`, `python-bidi` | Arabic text shaping |

## Directory Layout

```
~/cliply/
├── cliply.py              # CLI orchestrator
├── requirements.txt
├── stages/
│   ├── config.py          # LM URL, output dirs, video settings
│   ├── downloader.py      # Stage 1
│   ├── transcriber.py     # Stage 2 (GPU with CPU fallback)
│   ├── scene_detector.py  # Stage 3
│   ├── engagement_ai.py   # Stage 4 (see LM Studio pitfall below)
│   ├── reframer.py        # Stage 5
│   ├── typography.py      # Stage 6 (ASS subtitles, not PNG frames)
│   └── composer.py        # Stage 7 (temp-write then move)
```

## Critical Pitfalls

### 1. LM Studio Reasoning Models Never Follow "JSON Only"

**Problem:** Models like `qwen/qwen3.5-9b` and `google/gemma-4-e2b` (reasoning variants) output everything in `reasoning_content` and leave `content` empty. Even with explicit "Return ONLY JSON" system prompts, they consume all tokens on internal thinking and never emit structured output.

**Solution:**
- Prefer **non-reasoning models** (regular Qwen 2.5, Llama 3.1, Mistral) for structured output tasks
- If only reasoning models available, parse the reasoning text with regex extractors for patterns like `Selection A: [0:05] - description`
- Set `max_tokens` very high (800+) so reasoning can finish and still have room for actual output
- In LM Studio, check if there's a "Reasoning" toggle to disable for loaded models

### 2. ASS Subtitles Are Faster Than PNG Frame Pre-rendering

**Problem:** Generating hundreds of PNG frames with Pillow and compositing with ffmpeg overlay is extremely slow (10+ minutes for a 30s clip).

**Solution:** Generate an `.ass` (Advanced SubStation Alpha) subtitle file with word-by-word style overrides. ffmpeg's `subtitles` filter burns it in real-time during encode. Instant. Same visual effect.

See `references/ass-viral-typography.md` for the full ASS generation pattern.

### 3. WSL Cannot Write Directly to `/mnt/d/` from ffmpeg

**Problem:** ffmpeg fails with "Permission denied" when writing output directly to `/mnt/d/...` (Windows D: drive mount).

**Solution:** Write to a temp file on the WSL filesystem first, then `shutil.move()` to the D: drive destination.

```python
import tempfile, shutil

temp_out = tempfile.mktemp(suffix=".mp4", dir=os.path.expanduser("~/cliply/temp"))
# ... run ffmpeg with temp_out as destination ...
shutil.move(temp_out, final_path_on_d_drive)
```

### 4. Whisper GPU Fallback When CUDA Libraries Are Missing

**Problem:** faster-whisper throws `RuntimeError: Library libcublas.so.12 is not found or cannot be loaded` on WSL even though `nvidia-smi` shows the GPU.

**Solution:** Catch the error and transparently reload the model on CPU with `int8` compute type. CPU whisper on a modern laptop is fast enough for short videos.

```python
try:
    segments, info = model.transcribe(audio_path, word_timestamps=True, ...)
except RuntimeError as e:
    if "libcublas" in str(e) or "CUDA" in str(e):
        model_cpu = WhisperModel("base", device="cpu", compute_type="int8", cpu_threads=4)
        segments, info = model_cpu.transcribe(audio_path, ...)
```

### 5. Arabic Text Requires Reshaping and BIDI

Arabic text in Pillow or ASS must be:
1. Detected (check for `\u0600-\u06FF` range)
2. Reshaped with `arabic_reshaper`
3. BIDI-processed with `python-bidi` (`get_display`)

Use Windows fonts mounted at `/mnt/c/Windows/Fonts/` — Tahoma Bold (`tahomabd.ttf`) is the best fallback for clean Arabic rendering.

## Configuration

```python
# LM Studio API
LM_STUDIO_URL = "http://192.168.100.17:1234"  # your local IP
LM_MODEL = "google/gemma-4-e2b"  # or non-reasoning model
LM_TIMEOUT = 45
LM_MAX_TOKENS = 400

# Directories — temp on C: (fast I/O), output on D: (save space)
TEMP_DIR = os.path.expanduser("~/cliply/temp")
OUTPUT_DIR = "/mnt/d/cliply_output/shorts"

# Video
SHORT_WIDTH = 1080
SHORT_HEIGHT = 1920
SHORT_CODEC = "h264_nvenc"
SHORT_PRESET = "p1"  # fastest NVENC preset
SHORT_BITRATE = "8M"
Plus system tools: `yt-dlp`, `ffmpeg` (with NVENC), `nvidia-cuda-toolkit` (WSL).

## Multi-Segment Compiled Shorts (Setup → Moment → Reaction)

**Problem:** A single isolated clip often makes no sense to viewers who haven't watched the full video. A punchline without setup is confusing.

**Solution:** Compile each short from multiple segments that build a complete narrative arc:

| Segment | Purpose | Typical Length |
|---------|---------|---------------|
| **Setup** | Context — what the video is about, why this moment matters | 3–10s |
| **Moment** | The viral peak — emotion, punchline, reveal | 5–60s |
| **Reaction** (optional) | Aftermath, commentary, or follow-up | 3–15s |

**How it works in code:**
1. The LLM returns `segments` array instead of a single `start`/`end` pair
2. Each segment has `purpose`, `content_type`, and `start`/`end`
3. The pipeline reframes each segment individually (different strategies per content type)
4. ffmpeg `concat` demuxer stitches them together
5. Subtitle timestamps are offset by cumulative duration of previous segments

**LLM prompt addition:**
```
Each short can combine MULTIPLE segments to build a complete narrative arc.
Segments array: [{"start": X, "end": Y, "content_type": "talking_head|text_screen|gameplay|mixed", "purpose": "setup|moment|reaction"}]
```

**Fallback when LLM fails:** Automatically pair the moment scene with the preceding scene as setup if it's within 60s and under 45s long.

## Content-Aware Reframe Strategies

Not all scenes should use the same reframe strategy. Auto-detect the dominant content type from a sample frame:

| Content Type | Detection | Reframe Strategy |
|-------------|-----------|------------------|
| **talking_head** | OpenCV face detected, face area > 1.5% of frame | Face-tracking crop — follow the speaker horizontally |
| **text_screen** | High edge density in upper half (Canny) | **Blur-background letterbox** — preserve all text in center, blur + scale the background to fill 9:16 |
| **gameplay / mixed** | Neither face nor text dominant | Center-crop with safe margins |

**Blur-background letterbox filter (ffmpeg):**
```
[0:v]scale=1080:1920:force_original_aspect_ratio=decrease,boxblur=20:20,scale=1080:1920[bg];
[0:v]scale=1080:-2:force_original_aspect_ratio=decrease[fg];
[bg][fg]overlay=(W-w)/2:(H-h)/2:shortest=1[outv]
```
This keeps the original text/UI perfectly readable while filling the vertical frame.

## Preview / Approval Workflow

**User requirement:** Before generating shorts, show a production plan with transcript previews so the user can approve, reject, or pick specific shorts.

**Implementation:**
```bash
python cliply.py "URL" --preview   # shows plan, no generation
python cliply.py "URL" --count 3  # generates approved shorts
```

The preview prints for each short:
- Hook title, score, total duration
- Each segment with timestamps, purpose, content type
- **Transcript preview** (first 120 chars) for each segment

The user reviews and says "generate 1 and 3" or "all of them".

## Variable Clip Lengths

**Don't force every short to the same length.** Let the LLM choose based on the natural arc:

- Quick punchlines / reactions: **5–15s**
- Standard viral moments: **15–30s**
- Story arcs / reveals: **30–60s**
- Deep dives / tutorials: **60–90s**

Prompt the LLM explicitly:
```
Let each clip's length match its natural emotional arc — some moments need only 5-10 seconds, others need 30-60 seconds to land.
```

Only clamp if truly out of bounds (< 5s or > 90s).

## Usage

```bash
python ~/cliply/cliply.py "https://youtube.com/watch?v=..." --count 3
python ~/cliply/cliply.py "URL" --count 5 --keep-temp  # debug mode
```

## References

- `references/ass-viral-typography.md` — Full ASS generation code for word-by-word viral captions
- `references/lm-studio-reasoning-pitfall.md` — Detailed analysis of the reasoning model JSON problem with reproduction examples
- `references/multi-segment-compilation.md` — Multi-segment shorts: setup + moment + reaction pattern with concat and subtitle offset
- `references/content-aware-reframe.md` — Auto-detect content type (face / text / gameplay) and pick the right reframe strategy
