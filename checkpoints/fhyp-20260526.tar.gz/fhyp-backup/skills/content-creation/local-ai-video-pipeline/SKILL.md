---
name: local-ai-video-pipeline
description: >
  Build fully local, GPU-accelerated video processing pipelines that download,
  transcribe, analyze with local LLMs, smart-reframe to vertical, add viral
  typography, and export ready-to-upload shorts. Covers faster-whisper,
  ffmpeg NVENC, LM Studio / Ollama integration, OpenCV tracking, and
  word-level subtitle rendering.
category: content-creation
---

# Local AI Video Pipeline

Trigger: When the user wants to build, extend, or debug a **local-only** video processing tool — shorts clipper, viral caption generator, auto-reframer, or any pipeline that runs on their GPU without cloud APIs.

Also trigger when: integrating a local LLM (LM Studio, Ollama) into a video workflow, or debugging why a local model's response is empty.

## Canonical 7-Stage Architecture

Every local video shorts pipeline should follow this order:

1. **Download** — `yt-dlp` extracts video + WAV audio. Supports YouTube, X/Twitter, Facebook, TikTok, and 1000+ sites.
2. **Transcribe** — `faster-whisper` on GPU with **word-level timestamps** (`word_timestamps=True`). This is non-negotiable for viral typography.
3. **Scene Detect** — `PySceneDetect` (`ContentDetector`) finds natural cut boundaries.
4. **Engagement AI** — Local LLM (Qwen, Llama, etc.) analyzes transcript + scene boundaries and returns the top viral moments with timestamps, hooks, and scores.
5. **Smart Reframe** — OpenCV face/person detection tracks the speaker; ffmpeg `crop` + `scale` to 9:16 vertical. Falls back to center-crop.
6. **Viral Typography** — Pillow renders **word-by-word** captions synced to whisper timestamps. Current word pops (color + scale), spoken words highlight, future words dim.
7. **Compose** — ffmpeg overlays subtitle PNG sequence onto reframe video. Encode with `h264_nvenc` or `hevc_nvenc` hardware encoder.

## Stage Details & Commands

### Stage 1: Download
```python
subprocess.run([
    "yt-dlp",
    "-f", "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
    "--merge-output-format", "mp4",
    "-o", video_path,
    "--no-playlist",
    url,
])
```
Extract audio separately for whisper:
```bash
ffmpeg -y -i video.mp4 -vn -acodec pcm_s16le -ar 16000 -ac 1 audio.wav
```

### Stage 2: Transcribe (GPU)

```python
from faster_whisper import WhisperModel
model = WhisperModel(
    "small",  # or "medium" (see model selection guide below)
    device="cuda",
    compute_type="int8_float16",  # RTX 3050 / 6GB VRAM
)
segments, info = model.transcribe(
    audio_path,
    word_timestamps=True,
    vad_filter=True,
    vad_parameters=dict(min_silence_duration_ms=500),
)
```

**CRITICAL — Model size vs language quality:**

| Model | VRAM | Arabic Quality | English Quality | Speed |
|-------|------|----------------|-----------------|-------|
| `base` | ~0.5 GB | ❌ Garbage for dialect | ⚠️ Okay | Fastest |
| `small` | ~1.0 GB | ✅ Good for dialect | ✅ Good | Medium |
| `medium` | ~3.0 GB | ✅✅ Excellent | ✅✅ Excellent | Slow |

For **Arabic gaming content (Egyptian dialect + slang)**:
- `base` hallucinates completely — produces gibberish words that don't exist
- `small` is the **minimum viable** — understands "سكواد", "كلتش", "جيم", "وين"
- `medium` is ideal if VRAM allows (fits on RTX 3050 6GB with `int8`)

**Pitfall — CUDA library missing in WSL:**
If you get `Library libcublas.so.12 is not found or cannot be loaded`, CUDA math libraries are missing. Install:
```bash
sudo apt update && sudo apt install nvidia-cuda-toolkit
```
The pipeline should auto-fallback to CPU (`device="cpu", compute_type="int8"`) but CPU is ~2× slower.

**Pitfall — import in sandboxed environments:**
If `from faster_whisper import WhisperModel` fails inside `execute_code`, the environment may not have the right PYTHONPATH. Fix:
```python
import sys
sys.path.insert(0, '/home/ammar/.local/lib/python3.12/site-packages')
```

### Stage 3: Scene Detect
```python
from scenedetect import open_video, SceneManager
from scenedetect.detectors import ContentDetector

video = open_video(video_path)
scene_manager = SceneManager()
scene_manager.add_detector(ContentDetector(threshold=27.0))
scene_manager.detect_scenes(video)
scenes = scene_manager.get_scene_list()
```

### Stage 4: Engagement AI (Critical Pitfall Zone)

**CRITICAL — Reasoning Model Behavior (Qwen 3.5, Gemma 4 E2B, etc.):**
When using reasoning-first models through LM Studio's OpenAI-compatible API, the response structure is:
- `message.content` → **EMPTY STRING** (the model "thinks" instead of speaks)
- `message.reasoning_content` → **CONTAINS THE ACTUAL ANALYSIS**

**This applies to BOTH Qwen 3.5 AND Gemma 4 E2B.**

Always parse from `reasoning_content` first:

```python
choice = data["choices"][0]
msg = choice["message"]
content = msg.get("content", "")
reasoning = msg.get("reasoning_content", "")
combined = reasoning + "\n" + content  # reasoning has the JSON
```

Also check `usage.completion_tokens_details.reasoning_tokens` to confirm the model actually reasoned.

**Multi-segment compiled shorts (setup → moment → reaction):**
The best shorts are NOT single random clips. They are **narrative arcs** compiled from multiple segments:

| Part | Time | Purpose |
|------|------|---------|
| Setup | [0:00-0:13] | Context — what is this about? |
| Moment | [0:33-1:05] | The viral emotional peak |
| Reaction | [2:14-2:33] | The aftermath that lands the punchline |

This creates shorts that **make sense to viewers who haven't seen the full video.**

Prompt the LLM for multi-segment output:
```
Each short can combine MULTIPLE segments to build a complete narrative arc.
Each object must have: hook, reason, score, segments.
segments is an array of {start, end, content_type, purpose}.
purpose: "setup" | "moment" | "reaction"
```

**Preview / approval workflow:**
This user explicitly requires seeing the production plan BEFORE generating. Always run with `--preview` first, show:
- Segment timestamps
- Content types
- Transcript previews
- Why each short was chosen

Wait for user approval (e.g., "generate 1,2,3" or "reject, try different chapters") before rendering.

**LM Studio API settings for consumer GPUs:**
- `max_tokens`: 200–500 (9B models at ~13 tok/s on RTX 3050)
- `timeout`: 35–60 seconds
- `temperature`: 0.3–0.4 (structured output)
- Do NOT stream for JSON responses

**Smart fallback when LLM fails:**
When reasoning models don't output parseable JSON (common), build narrative shorts from adjacent scenes:
- Pick a high-engagement scene as the "moment"
- Include the previous scene within 60s as "setup" if it's under 45s
- This guarantees context + punchline structure even without LLM cooperation

### Stage 5: Smart Reframe — Context-Aware

The reframe strategy MUST match the content type. Auto-detect by sampling a middle frame:

| Content Type | Detection | Reframe Strategy |
|-------------|-----------|------------------|
| `talking_head` | Face detected, face area > 1.5% of frame | **Face-tracking crop** — OpenCV tracks subject, crop follows |
| `text_screen` | High edge density in upper half (> 8%) | **Blur-background letterbox** — preserve all text, blur vertical bands |
| `gameplay` / `mixed` | Neither above dominates | **Center-crop** — stable, no tracking artifacts |

```python
import cv2

# Detection
def detect_content_type(video_path, start, end):
    # Sample middle frame
    cap = cv2.VideoCapture(video_path)
    t = (start + end) / 2
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
    ret, frame = cap.read()
    cap.release()
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Face check
    faces = cv2.CascadeClassifier(FACE_CASCADE).detectMultiScale(gray, 1.05, 4, minSize=(30,30))
    if len(faces) > 0:
        largest = max(faces, key=lambda f: f[2]*f[3])
        if (largest[2]*largest[3]) / (gray.shape[0]*gray.shape[1]) > 0.015:
            return "talking_head"
    
    # Text screen check
    edges = cv2.Canny(gray, 50, 150)
    edge_density = cv2.countNonZero(edges[:edges.shape[0]//2, :]) / (edges[:edges.shape[0]//2, :].size + 1)
    if edge_density > 0.08:
        return "text_screen"
    
    return "mixed"
```

**Face-tracking crop:**
- Sample 20–30 frames across the clip for face positions
- Use **median** center (not mean — robust against outliers)
- If face moves too much (std dev > 0.12), fall back to **center-crop** to avoid cutting off the subject
- If face is near frame edge (< 18% margin), **nudge crop inward** so subject isn't at extreme edge

**Blur-background letterbox for text screens:**
```bash
ffmpeg -i input.mp4 -filter_complex \
  "[0:v]scale=1080:1920:force_original_aspect_ratio=decrease,boxblur=20:20,scale=1080:1920[bg]; \
   [0:v]scale=1080:-2:force_original_aspect_ratio=decrease[fg]; \
   [bg][fg]overlay=(W-w)/2:(H-h)/2:shortest=1[outv]" \
  -map "[outv]" -map 0:a -c:v h264_nvenc output.mp4
```
This preserves all text while filling the 9:16 frame with blurred background.

**Center-crop (fallback):**
```python
crop_w = int(src_h * (9/16))  # 0.5625 ratio for 9:16
crop_x = (src_w - crop_w) // 2  # dead center
```

### Stage 6: Viral Typography — ASS Subtitles (Recommended)

**Do NOT pre-render PNG frames.** Pillow rendering 600+ PNGs per short is insanely slow (10+ minutes) and doesn't scale. Instead, generate **ASS subtitle files** and burn them directly with ffmpeg:

```python
import os, re

# Build ASS header with styles
ass_header = """[Script Info]
Title: Viral Captions
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Tahoma,80,&H00FFFFFF,&H00FFFF00,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,3,0,2,20,20,1497,1
Style: Gray,Tahoma,80,&H00AAAAAA,&H00FFFF00,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,3,0,2,20,20,1497,1
Style: Highlight,Tahoma,86,&H0000FFFF,&H00FFFF00,&H00000000,&H80000000,1,0,0,0,110,110,0,0,1,4,0,2,20,20,1497,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
```

**Word-by-word pop effect:**
For each spoken word, create a dialogue line where:
- **Current word**: `Highlight` style (yellow, bigger, 110% scale)
- **Already spoken words**: `Default` style (white)
- **Future words**: `Gray` style (dimmed)

This renders in **real-time by ffmpeg** — zero frame pre-rendering.

**Arabic text support:**
```python
import arabic_reshaper
from bidi.algorithm import get_display

reshaped = arabic_reshaper.reshape(text)
display_text = get_display(reshaped)
```

**Font paths on WSL:**
- Arabic: `/mnt/c/Windows/Fonts/tahoma.ttf` or `tahomabd.ttf`
- Latin fallback: `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf`

**Multi-segment offset handling:**
When a short is compiled from multiple source segments, word timestamps must be **offset by cumulative duration** of previous segments so the ASS syncs with the concatenated video.

### Stage 7: Compose & Concat (NVENC)

**Multi-segment concatenation:**
When a short is compiled from multiple segments, concatenate before burning subtitles:

```python
# Create concat list for ffmpeg
with open("concat_list.txt", "w") as f:
    for p in segment_paths:
        f.write(f"file '{p}'\n")

subprocess.run([
    "ffmpeg", "-y", "-f", "concat", "-safe", "0",
    "-i", "concat_list.txt",
    "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8M",
    "-c:a", "aac", "-pix_fmt", "yuv420p",
    "-movflags", "+faststart",
    "concat.mp4",
])
```

**Burn ASS subtitles with ffmpeg:**
```bash
ffmpeg -y -i concat.mp4 -vf "subtitles=subtitles.ass" \
  -c:v h264_nvenc -preset p1 -b:v 8M \
  -c:a aac -pix_fmt yuv420p -movflags +faststart output.mp4
```

**WSL + D: drive output workaround:**
ffmpeg often fails to write directly to `/mnt/d/` (Permission denied). The fix: write to local temp first, then move:

```python
import tempfile, shutil

temp_out = tempfile.mktemp(suffix=".mp4", dir="/home/ammar/cliply/temp")

# ffmpeg writes to temp_out
subprocess.run(["ffmpeg", ..., temp_out])

# Then move to D: drive
shutil.move(temp_out, "/mnt/d/cliply_output/shorts/final.mp4")
```

NVENC preset speed vs quality:
- `p1` = fastest, lowest quality (good for drafts)
- `p2`–`p4` = balanced
- `p5`–`p7` = best quality, slower

**Verify exact output dimensions:**
```bash
ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=p=0 output.mp4
# Expected: 1080:1920
```

## Verification Checklist

Before declaring a pipeline working:
- [ ] faster-whisper returns word-level timestamps (not just segment-level)
- [ ] LLM response parses from `reasoning_content` if using Qwen 3.5 or Gemma
- [ ] Reframe output is actually 1080×1920 (check with ffprobe)
- [ ] Subtitle timestamps offset correctly for multi-segment compiled shorts
- [ ] Final export has audio and uses NVENC (check `ffmpeg -i output.mp4` for `h264_nvenc`)
- [ ] `--preview` mode shows transcript previews per segment
- [ ] Each short is 30–90 seconds with a clear narrative arc

## User Workflow: Preview → Approve → Generate

This user explicitly requires a **human-in-the-loop approval step** before rendering. The pipeline must support:

1. `--preview` mode: analyze, transcribe, detect scenes, run engagement AI, then **STOP** and display a production plan
2. Show per-segment transcript previews (first ~120 chars) so the user can judge context
3. Wait for explicit approval: "generate 1,2,3" or "reject, try different chapters"
4. Only after approval: reframe, concat, subtitle, compose, export

**Preview output format:**
```
🎬 SHORT 1/3: "HOOK TITLE"
   Score: 8/10 | Total: 45.2s
   Why: Emotional peak with universal gamer relatability
   Segment 1: [2:14-2:33] setup | talking_head
      📝 "first squad, first win, friends we never met..."
   Segment 2: [3:54-4:10] moment | mixed
      📝 "game scenes hit harder than real life..."
```

## References

- `references/lmstudio-qwen-quirks.md` — Qwen 3.5 / Gemma 4 reasoning model API behavior
- `references/cliply-architecture.md` — Full Cliply v2 architecture: multi-segment shorts, content-type reframe, ASS subtitles
