# LM Studio + Qwen 3.5 Reasoning Model API Quirks

## The Problem

Qwen 3.5 (and other reasoning-first models) loaded in LM Studio do NOT follow the standard OpenAI chat completion format where the assistant's reply lives in `choices[0].message.content`.

Instead:
- `message.content` → empty string `""`
- `message.reasoning_content` → contains the actual structured analysis / JSON / thinking

This is because reasoning models are trained to "think" (reasoning) rather than "speak" (content). LM Studio surfaces both fields.

## Reproduction

```python
import requests

r = requests.post(
    "http://192.168.100.17:1234/v1/chat/completions",
    json={
        "model": "qwen/qwen3.5-9b",
        "messages": [
            {"role": "system", "content": "Return only JSON."},
            {"role": "user", "content": "Analyze: 0:05 - That was insane! Find viral moment."}
        ],
        "temperature": 0.3,
        "max_tokens": 300,
    },
    timeout=35,
)
data = r.json()
choice = data["choices"][0]
msg = choice["message"]

print("content:", repr(msg.get("content", "")))
# → ''  (EMPTY!)

print("reasoning_content:", repr(msg.get("reasoning_content", "")[:200]))
# → 'Thinking Process:\n\n1. Analyze the Request...\n[{"start": 5, "end": 12, ...}]'
```

## Usage Pattern

Always combine both fields, preferring reasoning_content:

```python
combined = msg.get("reasoning_content", "") + "\n" + msg.get("content", "")
# Then parse JSON, regex, etc. from combined
```

## Diagnostics

Check if the model actually reasoned:
```python
reasoning_tokens = data.get("usage", {}).get("completion_tokens_details", {}).get("reasoning_tokens")
if reasoning_tokens and reasoning_tokens > 10:
    print("Model reasoned — parse reasoning_content")
```

## Performance on Consumer GPU

Tested on RTX 3050 (6GB VRAM) with Qwen 3.5 9B Q4_K_M quantized via LM Studio llama.cpp CUDA backend:
- Throughput: ~13 tok/s
- Time to first token: ~0.7s
- Recommended timeout: 35s for 300 tokens
- Recommended max_tokens: 200–500

## Other LM Studio Notes

- `/v1/models` endpoint lists loaded models including embeddings
- `/api/v0/chat/completions` also works but `v1` is preferred
- The `model` field in the request can be any string (LM Studio ignores it and uses the currently loaded model), but best practice is to pass the actual model ID
