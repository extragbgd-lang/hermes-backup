# Cliply v2 Architecture — Session Reference

Full working pipeline built for Ammar (GameySins) to convert long-form Arabic gaming videos into viral 9:16 shorts. Runs entirely local on RTX 3050 6GB.

## Architecture Overview

```
URL → Download → Transcribe (faster-whisper GPU)
                              ↓
                    Scene Detect (PySceneDetect)
                              ↓
                    Engagement AI (LM Studio local LLM)
                              ↓
                    Multi-segment viral moment planning
                              ↓
                    Preview / Approval (human-in-the-loop)
                              ↓
                    Reframe each segment (context-aware)
                              ↓
                    Concatenate segments → single short
                              ↓
                    ASS subtitles (word-level, offset-aware)
                              ↓
                    ffmpeg NVENC compose → 1080×1920 MP4
                              ↓
                    Move to D: drive output
```

## Key Files

```
~/cliply/
├── cliply.py                   # Main CLI orchestrator
├── stages/
│   ├── config.py              # Settings, model names, paths
│   ├── downloader.py          # yt-dlp wrapper
│   ├── transcriber.py         # faster-whisper GPU
│   ├── scene_detector.py      # PySceneDetect
│   ├── engagement_ai.py       # LLM viral analysis + multi-segment
│   ├── reframer.py            # Content-aware 9:16 reframe
│   ├── typography.py          # ASS subtitle generation
│   └── composer.py            # ffmpeg NVENC + D: drive workaround
└── requirements.txt
```

## Critical Discoveries from This Session

### 1. Whisper Model Size Matters Massively for Arabic

- `base` model: produces complete gibberish for Egyptian gaming dialect
  - Example hallucination: "الوطديج مش هتفى مزاي" (not real words)
- `small` model: correctly transcribes "سكواد", "كلتش", "جيم", "وين"
  - Example correct: "فاكرة صاحبي اول سكواد واول جيم اللعبنا مع بعض"
- `medium` model: best quality, fits on 6GB VRAM with `int8`

**Config:**
```python
WHISPER_MODEL = "small"  # minimum for Arabic dialect
WHISPER_DEVICE = "cuda"
WHISPER_COMPUTE_TYPE = "int8_float16"
```

### 2. Reasoning Models (Qwen 3.5, Gemma 4) Never Output Clean JSON

Both models spend ALL tokens on `reasoning_content` and leave `content` empty. Even with "NO THINKING, JSON ONLY" prompts, they still output 300+ reasoning tokens and zero structured JSON.

**Parsing strategy (5 layers of fallback):**
1. Code blocks ` ```json... ``` ` (check LAST occurrence first)
2. Direct JSON parse of entire text
3. Find `[...]` array blocks (check LAST first)
4. Extract individual `{...}` objects with `"start"` keys
5. Parse reasoning prose: "Selection A: [0:05] - Strong reaction hook" → structured clip
6. Regex extract `start...end` pairs
7. Smart fallback: build narrative shorts from adjacent scenes (setup + moment)

### 3. Content-Type Detection Changes Reframe Strategy

Auto-detect by sampling middle frame:

```python
def detect_content_type(video_path, start, end):
    # talking_head: face > 1.5% of frame area
    # text_screen: edge density > 8% in upper half
    # mixed: fallback
```

| Type | Strategy | ffmpeg filter |
|------|----------|---------------|
| talking_head | Face-tracking crop | `crop=X:H:x:0,scale=1080:1920` |
| text_screen | Blur-background letterbox | `boxblur` + `overlay` |
| mixed/gameplay | Center-crop | `crop` + `scale` |

### 4. ASS Subtitles vs PNG Frame Overlay

**PNG approach (abandoned):**
- Generates 600+ PNG frames per short with Pillow
- 10+ minutes per short just for subtitle rendering
- RAM-heavy, doesn't scale

**ASS approach (adopted):**
- Generate one `.ass` file per short (~100 lines)
- ffmpeg burns it in real-time: `-vf "subtitles=subtitles.ass"`
- Instant — zero pre-rendering
- Word-level sync via `\rHighlight` style overrides

### 5. WSL + D: Drive ffmpeg Write Failure

ffmpeg fails with `Permission denied` when writing directly to `/mnt/d/`. Fix:

```python
import tempfile, shutil

temp_out = tempfile.mktemp(suffix=".mp4", dir="~/cliply/temp")
subprocess.run(["ffmpeg", ..., temp_out])
shutil.move(temp_out, "/mnt/d/cliply_output/shorts/final.mp4")
```

### 6. Multi-Segment Compiled Shorts

Instead of cutting single random clips, each short is compiled from multiple segments:

```json
{
  "hook": "I NEARLY DIED",
  "score": 9,
  "segments": [
    {"start": 40, "end": 52, "content_type": "talking_head", "purpose": "setup"},
    {"start": 120, "end": 135, "content_type": "mixed", "purpose": "moment"},
    {"start": 200, "end": 210, "content_type": "mixed", "purpose": "reaction"}
  ]
}
```

This guarantees each short:
- Starts with context (setup)
- Builds to a viral moment
- Ends with a punchline (reaction/aftermath)
- Is 30–90 seconds total

### 7. Smart Fallback When LLM Fails

When the LLM doesn't output parseable JSON (reasoning model behavior), automatically build narrative shorts:

1. Sort scenes by duration (proxy for engagement)
2. Pick top scene as "moment"
3. Look backward for a scene within 60s and under 45s → use as "setup"
4. This creates setup + moment structure even without LLM

## CLI Usage

```bash
# Preview mode — shows production plan for approval
python cliply.py "https://youtu.be/..." --count 3 --preview --keep-temp

# Generate approved shorts
python cliply.py "https://youtu.be/..." --count 3

# Keep temp files for debugging
python cliply.py "https://youtu.be/..." --keep-temp
```

## Hardware Verified

- **GPU:** NVIDIA RTX 3050 Laptop, 6GB VRAM
- **Driver:** 595.71.01, CUDA 13.2
- **WSL:** Ubuntu 22.04
- **LM Studio:** Qwen 3.5 9B Q4_K_M + Gemma 4 E2B
- **Throughput:** ~13 tok/s on RTX 3050
- **Transcription:** faster-whisper small on CUDA, int8_float16
- **Encoding:** ffmpeg NVENC h264_nvenc, preset p1
