# Creating Channel-Specific Pipelines from the GameSins Template

Ammar runs multiple content channels. Each has its own pipeline, but they all derive from the same architectural pattern established in `video-pipeline-agent`. This document explains what varies per channel and what stays the same.

## Common Pipeline Architecture

All channels share this pipeline structure:
```
Topic → Research → Script Writing → SEO → Notion/Storage → Present
```

Executed via `delegate_task` with sequential steps feeding output to the next.

## What Varies Per Channel

| Aspect | GameSins (gaming) | GameSinsTech (AI/freelancing) | When creating a new channel |
|--------|------------------|------------------------------|-----------------------------|
| **Host persona** | GameSins character + Mosmar mascot | Ammar as himself | Define host voice, mascots, and tone |
| **Language** | Egyptian Arabic (عامية مصرية) | Egyptian Arabic (عامية مصرية), MSA for formal | Pick the Arabic dialect for the audience |
| **Tone** | Funny, energetic, sarcastic | Educational, practical, direct | Match the content niche |
| **Research focus** | Gaming trends, Steam, IGN | AI tools, freelancing platforms | Point researcher at domain-specific sources |
| **Script structure** | Fast cuts, Mosmar interjections, gaming slang | Listicle format, visual tool demos | Adapt format to content type |
| **Delivery target** | Google Docs (no local files) | Notion + local file | Choose the storage backend |
| **Thumbnail style** | Bold Arabic text, Ammar reaction face, game art | Clean 50/50 split: Ammar + tool logos | Match the content vertical |
| **B-roll** | Game footage, memes, animated overlays | Tool UI recordings, screen captures, icon animations | Source from the actual tools/domain |

## Creating a New Channel Pipeline

1. **Copy `video-pipeline-agent`** as your base template — it has the proven research→script→SEO→delivery flow.
2. **Reset persona rules:** Host voice, mascots, tone, language dialect.
3. **Customize research sources:** Point the researcher agent at websites relevant to the new niche.
4. **Customize script format:** Adjust duration, structure (listicle vs narrative vs tutorial), visual cue style.
5. **Choose a delivery target:** Google Docs (GameSins), Notion (GameSinsTech), or both.
6. **Add domain-specific pitfalls:** What can go wrong in THIS niche that the base template doesn't cover?

## Pitfalls When Forking

- **Don't carry forward mascot rules.** Mosmar is GameSins-only. A new channel must define its own character rules or explicitly state "no mascot."
- **Research scope changes entirely.** Gaming researcher visits Steam/IGN. AI researcher visits tool websites. Don't reuse outdated source lists.
- **File storage preference is per-channel.** The base template says "no local files" (GameSins rule), but a new channel may prefer local files for editing convenience. Check with the user.
- **Thumbnail and brand assets are channel-specific.** Don't reuse GameSins orange/blue scheme or logo elements on a new channel without user approval.
- **Arabic dialect preference stays with the host.** GameSins uses Egyptian dialect. A new channel with a different host might use Gulf, Levantine, or MSA.
