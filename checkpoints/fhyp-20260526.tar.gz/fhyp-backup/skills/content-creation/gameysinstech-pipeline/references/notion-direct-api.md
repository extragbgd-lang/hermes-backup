# Notion Direct API Usage

## Discovery (May 26, 2026)

The Direct Notion API is **not dead** — the token lives in the `better-notion` MCP config at `~/.hermes/config.yaml` under `mcp_servers.better-notion.env.NOTION_TOKEN`.

**Token:** `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`
**Bot name:** "gameysins hub"
**Workspace:** "hermossy batooty's Space"

## API Endpoints

### Create a Page (under a parent)
```bash
NOTION_TOKEN="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"

curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{
    "parent": {"page_id": "PARENT_PAGE_ID"},
    "properties": {
      "title": {"title": [{"type": "text", "text": {"content": "📺 My Page Title"}}]}
    }
  }'
```

### Add Children Blocks to a Page
```bash
curl -s -X PATCH "https://api.notion.com/v1/blocks/PAGE_ID/children" \
  -H "Authorization: Bearer $NOTION_TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{
    "children": [
      {"heading_2": {"rich_text": [{"type": "text", "text": {"content": "Section Title"}}]}},
      {"paragraph": {"rich_text": [{"type": "text", "text": {"content": "Paragraph content here."}}]}}
    ]
  }'
```

## Key Facts

- **Token is NOT expired.** It was configured with the `better-notion` MCP which has a `command: better-notion-mcp` entry in config.yaml.
- **Workspace-level pages cannot be created.** Error: "Internal integrations aren't owned by a single user, so creating workspace-level private pages is not supported." Always use `parent.page_id` or `parent.database_id`.
- **Nesting works under accessible parents.** Pages created under a hub page (that the integration can access) ARE correctly nested as children. The earlier claim that "Zapier can't nest" was about the Main Brain page specifically, which is in a different workspace scope.
- **Block types supported:** `heading_2`, `heading_3`, `paragraph`, `bulleted_list_item`, `numbered_list_item`, `to_do`, `toggle`, `callout`, `quote`, `divider`, `code`, `image`, `video`, `embed`, `bookmark`, `table_of_contents`.

## Limits & Quirks

- Notion-Version header required: `2022-06-28`
- `icon.emoji` must be a real Unicode emoji character, not a name
- `callout` blocks do NOT support `bold: true` in rich_text
- Max block children per call: ~100 blocks
- Create page first (returns ID), then add children in a second call
- Response gives a `url` field: `https://notion.so/{id_without_hyphens}`
- URL construction: remove dashes from page ID → `https://notion.so/` + cleaned ID

## When to Use vs Zapier

| Approach | Use Case |
|----------|----------|
| **Direct Notion API** | Creating pages under a known parent; adding structured block content; batch operations |
| **Zapier MCP** | When you don't have the parent page ID; standalone pages user will move manually; YouTube uploads |

The direct API is preferred when you know the parent page ID and need structured content. Zapier is better for one-off standalone pages where nesting isn't critical.