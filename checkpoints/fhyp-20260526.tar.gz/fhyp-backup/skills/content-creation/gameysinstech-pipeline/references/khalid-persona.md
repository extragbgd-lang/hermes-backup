# Khalid — GameSinsTech Audience Persona

## Identity Card
- **Name archetype:** خالد (Khalid)
- **Age:** 45-65
- **Background:** Retired/semi-retired Arab professional — government, oil & gas, banking, education, or military
- **Location:** Any Arab country (Gulf, Levant, Egypt, North Africa)
- **Tech level:** WhatsApp + YouTube. Has NEVER used terminal/coding/Docker. "Cloud" = iCloud photos.
- **Language:** MSA Arabic (فصحى) — NO dialects tolerated
- **Device:** Mid-range iPhone or Samsung + tablet for reading. Types one finger.

## Why He Watches
- "AI is the future, I don't want to be left behind" (FOMO — his kids/grandkids talk about it)
- Wants to feel capable and current, not intimidated
- Needs simplified explanations without feeling stupid for asking
- Prefers practical: "show me what to click, where, what happens next"

## Content Format
- **Shorts ONLY** — 60-90 seconds. Will NOT commit to long-form (8+ min)
- **MSA Arabic** — formal, clear, respectful. NO Egyptian or any dialect
- **Slow pace** — clear pronunciation, short sentences, simple vocabulary
- **Step-by-step** — every click described. Red circles on screen recordings
- **3-4 tools/concepts per short** maximum
- **Always pinned comment** with direct tool URLs

## Examples That Resonate
- Translating government documents / official papers
- Restoring old family photos
- Summarizing long news articles
- Organizing travel bookings
- Reading/enhancing Quranic texts
- Writing polite formal emails
- Avoiding WhatsApp scams and phishing

## Absolute Turnoffs (Triggers Click-Away)
- ❌ Egyptian or any dialect
- ❌ Gaming references or slang
- ❌ Fast cuts, memes, flashing effects
- ❌ Coding, terminal, Docker, any "technical" jargon
- ❌ "Freelancing" or "earn money online" hooks (he's retired, not job-hunting)
- ❌ Long-form content (8+ minutes)

## Emotional State
- Wants to feel **capable**, not stupid
- Embarrassed asking "dumb questions" in tech communities
- Trusts family recommendations (kids told him to watch the channel)
- Skeptical of "too good to be true" claims (scam-aware)
- Values clear, respectful explanations over hype

## Brand Touchpoints
- Colors: Navy #0b276c (trust) + Orange #ff753a (warmth/energy)
- Font: Cairo (clear, modern Arabic typeface)
- Host: Ammar — on camera, warm, respectful, speaks formal MSA
- Visual style: Clean, professional, plain background, slow zooms, red circles