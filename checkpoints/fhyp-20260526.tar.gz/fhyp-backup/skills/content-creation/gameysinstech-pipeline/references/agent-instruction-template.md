# Agent Instructions Template — Local Model Executable Format

## Problem

Paperclip agent instructions were written as Arabic job descriptions — they describe roles but don't tell agents HOW to execute. Local models (Qwen 2.5 7B, Gemma 4, etc.) can't infer tool usage from prose descriptions. They need EXACT copy-pasteable commands.

## Template

Every agent AGENTS.md must end with this EXECUTION PROTOCOL footer. The instructions BEFORE can be in Arabic (role description), but the footer MUST be in English with concrete commands.

### Footer Template

```
---

## EXECUTION PROTOCOL — DO THIS EXACTLY

You received an issue. Follow these steps. Do NOT skip any step.

### STEP 1: Read the issue
Run this EXACT command (replace ISSUE_ID):
```
curl -s "http://127.0.0.1:3100/api/issues/ISSUE_ID" -o /tmp/issue.json && python3 -c "import json; d=json.load(open('/tmp/issue.json')); print('TITLE:', d['title']); print('DESC:', d.get('description',''))"
```

### STEP 2: Do the work using your tools
Available tools: terminal (curl/bash), mcp_promptpilot_generate_image, mcp_gemini_image_gemini_generate_image, mcp_better_notion_pages, mcp_notebooklm_*

### STEP 3: Post a completion comment
```
curl -s -X POST "http://127.0.0.1:3100/api/issues/ISSUE_ID/comments" -H "Content-Type: application/json" -d '{"body":"DONE: <summary of what was done>"}'
```

### STEP 4: Mark done
```
curl -s -X PATCH "http://127.0.0.1:3100/api/issues/ISSUE_ID" -H "Content-Type: application/json" -d '{"status":"done"}'
```

### API Info
- Base: http://127.0.0.1:3100/api
- Company: ba4e7d36-e75a-44eb-97c9-5432d71f0c50
- Notion parent: 368d2f44-bc2c-80f6-a8ae-e8f1f66212b5
- NEVER write files to disk, save to Notion instead
- Always post a comment before marking done
```

## Why This Works

Local models need:
1. **Exact curl commands** — they can copy-paste, they can't infer API format
2. **Single-step tasks** — one issue = one task. Multi-step delegation causes timeouts
3. **English instructions** — local models are trained primarily on English; Arabic prose causes them to ignore technical details
4. **No abstract instructions** — "create sub-issues" is too vague. Give them the exact POST body.

## Applying to New Agents

When creating a new Paperclip agent:
1. Write the role/persona in Arabic (the agent's identity and domain knowledge)
2. Append the EXECUTION PROTOCOL footer in English
3. Include any agent-specific IDs (their agent ID, the issue ID) as environment variables
4. Keep the task description in the issue short: one paragraph max, focused on EXACTLY what to do
