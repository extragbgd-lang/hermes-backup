# Batch Production — 4 Shorts / One Session

## When to Use This Pattern

The user wants to record multiple Shorts in a single session (same setup, same lighting, same outfit). This saves setup time and creates consistent visual quality across videos.

## Workflow Steps

### Phase 1: Planning (before the shoot)
1. **Confirm 4 topics** — all must use the same recording setup (face cam + screen recording). Avoid topics needing different gear.
2. **Research all 4** in one pass — check free tiers, Arabic support, verify tool URLs still work.
3. **Write all 4 scripts** — MSA Arabic, 60-90s each. Keep structure consistent for seamless session flow.
4. **Create Notion hub** — standalone page titled `📺 GameSinsTech — Video Outputs`. User drags under Main Brain.
5. **Create 4 sub-pages** — one per Short. Each gets title, icon, metadata.
6. **Deliver checklist** — give Ammar the shoot order, time estimates, and what tools to have open.

### Phase 2: Script Structure (consistent across batch)

Each Short follows the same 4-section formula so the pacing feels natural in one session:

```
Section 1 (0:00-0:15) — Hook: attention grabber
Section 2 (0:15-0:35) — What it is: simple explanation
Section 3 (0:35-0:55) — How to use: step-by-step with red circles
Section 4 (0:55-1:10) — CTA: subscribe, pinned comment link
```

### Phase 3: Repackaging Old Content

When repurposing an old script for the new retiree audience:

| Old (Freelancer/Egyptian) | New (Retiree/MSA) |
|---|---|
| Egyptian dialect "ازاي تشتغل فريلانس" | MSA "كيف تستخدم الذكاء الاصطناعي في حياتك" |
| "اكسب فلوس من النت" | "وفر وقتك وجهدك" |
| "العميل عاوز كذا" | "استخدمه في المستندات الرسمية" |
| Fast cuts, energetic | Slow pace, clear instructions |
| ChatGPT for work | ChatGPT for daily life |
| Freelancer examples | Family/retiree examples (government docs, Quran, travel, photos) |

**Always verify free tiers still exist** when repackaging — old scripts reference tools whose free plans may have changed.

### Phase 4: Packaging Per Short

Each Short's Notion page must be self-contained:

1. **Script** — full MSA Arabic with timestamps
2. **SEO** — title, description (2-3 lines), tags (#shorts #ذكاء_اصطناعي)
3. **Pinned comment** — always includes direct tool URLs
4. **B-roll instructions** — what screen recordings to capture, where red circles go
5. **Thumbnail prompt** — ready for Google Flow (Nano Banana Pro model)

### Phase 5: Shooting Order (Example)

| Order | Short | Complexity | Notes |
|-------|-------|-----------|-------|
| 1st | Tool with most screen recording | High | Do first while fresh |
| 2nd | Document/site recording | Medium | Similar setup |
| 3rd | Before/after comparison | Medium | Prep demo files beforehand |
| 4th | Easiest (face cam heavy) | Low | Good closer, relaxed |

## Concrete Example (from May 26, 2026)

Batch: 4 Shorts, one session
- Short 1: ChatGPT في حياتك اليومية (70s) — repackaged from old "5 Free AI Tools"
- Short 2: ترجمة المستندات الرسمية (75s) — Google Translate Documents
- Short 3: إحياء الصور القديمة (65s) — Pippit.ai photo restoration
- Short 4: تلخيص المقالات الطويلة (70s) — Perplexity.ai

Notion hub: `https://notion.so/36cd2f44bc2c8185a180fa34878ed951`
Total recording time: ~30 min
Total screen recordings: 4 (one per short, ~1 min each)
Face cam segments: 4 (one per short, ~30s each)

## Pitfalls

- **Don't write all 4 scripts identically.** Vary section order, hook style, or tool type per short — template fatigue is real for the viewer.
- **All 4 must use the same recording setup.** If one short needs a different tool/lighting setup, it ruins the session efficiency.
- **Pinned comments per short must be distinct.** Don't reuse the same link list across all 4 — each needs its own tool URLs.
- **Repackaging trap: old hooks don't work for Khalid.** "استخدم ChatGPT لكسب المال" repackages to "استخدم ChatGPT لترجمة المستندات." Always reframe the hook for retiree daily life.
- **Notion pages CAN be nested via API when the parent is accessible.** The pitfall about "can't nest" was specific to the Main Brain page (different workspace scope from the integration). If you have a hub page under the integration's scope, create child pages with `parent: {"page_id": "HUB_ID"}` and they nest correctly. See `references/notion-direct-api.md`.