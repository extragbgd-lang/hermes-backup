# GameSinsTech — Channel Essentials

## Account
- **Google account:** gamerdaddyreveiw@gmail.com
- **YouTube channel:** GameSinsTech (UCWD4CHsU2tekfWt5--CVlxA) — brand channel under same Google account as GameSins
- **Language:** MSA Arabic (فصحى) — NO dialects
- **Category:** Science & Technology (28)
- **Sister channel to:** GameSins (gaming)

## Local Asset Files (stored under ~/)
- `gamesinstech_logo.png` — 800×800 profile picture
- `gamesinstech_banner.png` — 2560×1440 YouTube banner

## Channel Description

### English (for reference)
GameSinsTech — Your guide to AI tools simplified for Arab professionals. I'm Ammar, and I show you practical ways to use artificial intelligence in your daily life. No jargon. No coding. Just tools you can use today for free.

### Arabic (channel description)
GameSinsTech — دليلك لأدوات الذكاء الاصطناعي المبسطة للمتخصصين العرب. أنا عمّار، وأشرح لك بطريقة عملية كيف تستخدم الذكاء الاصطناعي في حياتك اليومية. بدون تعقيد، بدون برمجة.

## Content Pillars (Retiree-Friendly)
1. **AI tools for daily life** — translate documents, organize photos, write emails, summarize articles
2. **Simplified tech explanations** — what is ChatGPT? what is the cloud? explained like you're 50
3. **AI for family & hobbies** — genealogy research, Quran study aids, travel planning, photo editing
4. **Digital security & privacy** — safe browsing, avoiding scams, managing passwords (Khalid is vulnerable to scams)
5. **Government services** — AI for official paperwork, document translation, administrative tasks

## What This Channel Is NOT
- ❌ NOT about freelancing or earning money online
- ❌ NOT about coding, programming, or any technical skill
- ❌ NOT about gaming
- ❌ NOT using Egyptian or any local dialect

## Social Handles
- Instagram/Twitter/TikTok: @GameSinsTech
- Notion workspace: https://notion.so/368d2f44bc2c81c6b83af9a1ee9fc849

## First Video (DEPRECATED — don't reference)
- Old topic: "5 Free AI Tools Every Arab Freelancer Needs" (11:30)
- **This does NOT match current audience.** Start fresh with retiree-friendly topics.

## Brand
- **Primary:** #0b276c (navy blue)
- **Accent:** #ff753a (orange)
- **Dark:** #000000
- **White:** #ffffff
- **Font:** Cairo (local @font-face only, NO Google Fonts CDN)