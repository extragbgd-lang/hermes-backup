---
title: gameysinstech-pipeline
name: gameysinstech-pipeline
description: Full GameSinsTech video production pipeline — Shorts only (60-90s), MSA Arabic, for retired Arab professionals 45-65. Research → Script → SEO → Notion → Telegram.
trigger_conditions:
  - User says "run gameysinstech pipeline" or "gst pipeline" or "new video gst"
  - Creating content for GameSinsTech YouTube channel
  - Topic relates to AI tools simplified for non-technical older Arab audience
---
# GameSinsTech Pipeline (REBUILT May 2026)

Orchestrates full GameSinsTech Short production:
**Topic → Research → Script (MSA Arabic) → SEO + Pinned Comment → Notion → Telegram**

## ⚠️ CRITICAL — Audience Persona: "خالد"

> See `references/khalid-persona.md` for the full condensed persona card. Load it with `skill_view(name="gameysinstech-pipeline", file_path="references/khalid-persona.md")`

Before ANY production step, internalize this. Every decision flows from it.

**Who is Khalid?**
- Retired Arab professional, 45-65, from ANY Arab country
- Financially comfortable (gov/oil/banking/education/military background)
- WhatsApp + YouTube level tech — has NEVER used terminal/coding/Docker
- "Cloud" = iCloud photos. Doesn't know AWS.
- Learns from kids/grandkids or YouTube
- Watches because: "AI is the future, I don't want to be left behind"

**What Khalid NEEDS:**
- MSA Arabic ONLY (formal, clear, respectful — NO dialects)
- Shorts ONLY (60-90 seconds) — will not commit to long videos
- Slow-paced, step-by-step: "show me what to click, where, what happens next"
- Red circles, slow zooms, clear on-screen labels
- Real Arab daily life examples: government paperwork, Quran, family photos, travel booking
- Pinned comment with tool URLs
- 3-4 tools/concepts per short maximum

**What Khalid ABSOLUTELY HATES:**
- Egyptian or any dialect
- Gaming references/slang
- Fast cuts, memes, flashing effects
- Coding/terminal/Docker
- "Freelancing" as primary hook (he's retired, not job-hunting)
- Long-form content (will click away immediately)

## ⚠️ Critical Content Rules

1. **MSA Arabic ONLY** — NO Egyptian dialect, NO local dialect. Formal respectful Arabic.
2. **Shorts ONLY** — 60-90 seconds. Never suggest or produce long-form for GameSinsTech.
3. **NO coding/terminal/Docker** — triggers immediate click-away for this audience.
4. **NO freelancing hooks** — audience is retired, not looking for income.
5. **NO gaming references** — separate channel from GameSins gaming.
6. **Slow pace** — clear pronunciation, step-by-step explanations.
7. **Practical examples** — Arab daily life (government docs, Quran, travel, family).

## What's Working

| Tool | Status | How to Use |
|------|--------|------------|
| **Zapier MCP** | ✅ Works | Notion: create standalone pages. YouTube: upload_video. |
| **HyperFrames** | ✅ Works | `npx hyperframes render --dir "D:\\hyperframe output\\SCENE" --output "D:\\hyperframe output\\rendered\\SCENE.mp4"` via Windows CMD |
| **Mermaid CLI** | ✅ Works | `mmdc -i /tmp/NAME.mmd -o "/mnt/d/hyperframe output/diagrams/NAME.svg"` |
| **Local fonts (Cairo/Rubik)** | ✅ Works | `D:\\hyperframe output\\fonts\\` — `@font-face` with `../fonts/` |
| **SearXNG** | ✅ Works | `mcp_searxng_web_search` for local search |
| **TTS** | ✅ Works | `text_to_speech` tool |
| **Chrome CDP** | ✅ Works | Browser via user's Chrome |
| **Image Generation** | ✅ Works | `image_generate` tool |
| **CapCut MCP** | ✅ Works | Video editing drafts |
| **Obsidian Vault** | ✅ Works | `/mnt/d/Hermes-Vault/` — primary memory |

## What's NOT Working / Banned

| Tool | Status | Alternative |
|------|--------|-------------|
| **NotebookLM** | ❌ BANNED | No replacement. Don't attempt. |
| **Google Gemini** | ❌ BANNED | Use `image_generate` tool. |
| **Firecrawl MCP** | ❌ 401 broken | Use SearXNG or `web_search`. |
| **Google Fonts CDN** | ❌ No internet | Local `@font-face` + `../fonts/`. |
| **Pollinations** | ❌ Auth required | Use `image_generate` tool. |

## 📌 Kanban Integration for Batch Production

GameSinsTech content is best produced in **batches** (multiple shorts for one recording session). Use Kanban to track the batch:

```bash
# Switch to default board (GameSinsTech is not gaming)
hermes kanban boards switch default

# Create hub page setup task
hermes kanban create \
  --title "GST Hub: [topic theme] - [date]" \
  --assignee default \
  --body "Create Notion hub page for batch. Then produce N shorts."

# Create one task per short
hermes kanban create \
  --title "Short 1: [topic] - Research + Script + SEO + Notion" \
  --assignee default \
  --body "Full production package for one 60-90s Short."

# Repeat for Shorts 2, 3, 4...
# Link as sequential if needed:
hermes kanban link <task_2> --parent <hub_task>
```

**Kanban rules for GST batch production:**
- Use `default` board (NOT `gameysins` — that's for gaming)
- Tenant tag: `gst-batch` for easy filtering
- One hub task + N short tasks (sequential: hub → shorts)
- Keep chains short: max 5 tasks per pipeline
- If a short is blocked, scrap just that one — don't scrap the whole batch
- All tasks on `default` profile, Hermes-only (no Paperclip)

## Pipeline Steps

### ⚡ Batch Production Flow (for 4 Shorts / One-Session Shoot)

> See `references/batch-production.md` for the full concrete playbook with timing, repackaging table, and shooting order.

When the user says "let's do 4 shorts in one session," follow this pattern:

1. **Create Notion hub page** — "📺 GameSinsTech — Video Outputs" (standalone page via Zapier)
2. **Decide topics** — 4 retiree-friendly topics, same recording setup (face cam + screen recording). Each 60-90s.
3. **Research all 4** — in one pass. Visit tool websites, check free tier + Arabic support.
4. **Write all 4 scripts** — MSA Arabic. Keep them short. Each ~80 words of dialogue.
5. **Package each** — standalone SEO + pinned comment + b-roll instructions + thumbnail prompt per short
6. **When repackaging old content**: strip freelancing/dialect references, replace with retiree-friendly MSA, reframe hooks from "earn money" to "simplify your daily life"
7. **Save as 4 standalone Notion pages** under the hub page (user drags them). Each page is self-contained: script + SEO + pinned comment + b-roll notes.
8. **Deliver** — summary table for Ammar's shoot day

### Step 1: Research (Batch — all topics in one pass)

Research all topics together. Do NOT use delegate_task.

**Visit (live browsing) for each topic:**
- Actual tool websites (free tier, Arabic support)
- Check if the tool has an Arabic interface

**Research focus per topic (audience-aware):**
- What does it do in PLAIN LANGUAGE? (no jargon)
- Is it FREE? (Khalid won't pay)
- Does it support Arabic interface / output?
- Real use case for a retired Arab person (NOT for freelancers)
- Simple enough for WhatsApp-level users?

**Repackaging signal:** If a tool was covered in old content (e.g., the old "5 Free AI Tools" script), re-verify the free tier still exists — it may have changed.

### Step 2: Write MSA Arabic Script (60-90s Short)

**CRITICAL:** MSA Arabic ONLY. NO dialects. Clear, slow, step-by-step.

**Script Structure (4 sections, ~15-20s each):**
```
### 0:00-0:15 | SECTION NAME

[Visual: Ammar on camera, warm lighting, plain background]

Ammar (MSA):
العربية الفصحى هنا... جمل قصيرة... واضحة... بطيئة

[Visual: Screen recording with RED CIRCLE highlighting each click]
```

**4 Sections Formula:**
1. **0:00-0:15 — Hook** — Grab attention. "هل تعلم أن الذكاء الاصطناعي يمكنه..."
2. **0:15-0:35 — What it is** — Simple explanation. Arab daily life example.
3. **0:35-0:55 — How to use** — Step-by-step screen recording. RED CIRCLES. "اضغط هنا... ثم اختر..."
4. **0:55-0:70 — Why it matters + CTA** — "هذه الأداة ستوفر عليك..." اشترك في القناة

**Visual Style:**
- Ammar on camera (warm, professional, plain background)
- Screen recordings with RED CIRCLE highlights (MUST)
- Slow zooms, smooth transitions, NO fast cuts
- Text overlays: Cairo font, navy #0b276c bg, white text
- Accent orange #ff753a for highlights

### Step 3: SEO + Pinned Comment

**SEO:**
1. **Title (Arabic, 40-60 chars)** — Simple, numbers. "أداة ذكاء اصطناعي مجانية لترجمة المستندات"
2. **Description** — 2-3 lines. Include #shorts, pull relevant tags.
3. **Pinned Comment** — ALWAYS include direct tool URLs:
```
📌 روابط الأدوات المذكورة في الفيديو:
1. [Name] — [URL]
2. [Name] — [URL]

🔔 اشترك في القناة
```

### Step 4: Save to Notion

**Hub page first:** Create "📺 GameSinsTech — Video Outputs" via Notion API or Zapier (standalone page).
**Then per Short:** Create standalone page titled `GST: [Short Topic] - YYYY-MM-DD` under the hub via Notion API (`parent: {"page_id": "HUB_ID"}`). Content: full script + SEO + pinned comment + b-roll instructions + thumbnail prompt.

> **Notion API nesting works.** Unlike the Main Brain page (which is in a different workspace scope), child pages can be created under a hub page that the integration can access. Use `curl -X POST "https://api.notion.com/v1/pages" -H "Authorization: Bearer $NOTION_TOKEN" -H "Notion-Version: 2022-06-28"` with `parent.page_id` set to the hub. Add block children via `PATCH /v1/blocks/{page_id}/children`.

### Step 5: Deliver Telegram + Summary Table

Send a compact summary. Include a shoot-ready table Ammar can reference during recording:

```
━━━ GST BATCH READY — 4 SHORTS ━━━
📺 Notion Hub: [URL]

| # | Topic | Length | Tools | Visual |
|---|-------|--------|-------|--------|
| 1 | [topic] | ~Xs | [tools] | face cam + screen |
| 2 | [topic] | ~Xs | [tools] | face cam + screen |
...

📋 Shoot checklist (all 4):
1. Same face cam setup (plain bg, warm lighting)
2. Screen recording with RED CIRCLES for each short
3. [X] minutes total recording
4. Send raw footage → I handle post
```

## Delivery Format

```
━━━ GAMEYSINSTECH PIPELINE COMPLETE ━━━
🎬 Short: [title]
📄 Notion: [Notion URL]
📱 Telegram: sent ✓

✍️ Script: [X]s, MSA Arabic
🔍 SEO + Pinned comment: ready

📋 Ammar needs:
1. Record face cam
2. Screen record with red circles
3. Send raw footage for post-production ✨
```

## Pitfalls

- **Audience confusion is #1 risk.** Khalid is 55+ and non-technical. Every instruction: "click here → see this happen." Assume ZERO prior knowledge.
- **MSA not dialect.** GameSinsTech = MSA only. GameSins (gaming) = Egyptian dialect. NEVER confuse them.
- **NO long-form.** 60-90s Shorts only.
- **NO freelancing.** Retirees don't want "how to earn money online."
- **NO gaming.** Tech channel = zero gaming content.
- **NO NotebookLM.** Banned permanently.
- **NO Gemini.** Banned. Use `image_generate`.
- **English communication with Ammar only.** Arabic is ONLY in content files.
- **Notion = standalone pages.** User drags to parent manually.
- **Verify every tool claim** — visit actual websites. Free tiers change.
- **Arabic support is key.** Game changer for Khalid.
- **Firecrawl broken (401).** Use SearXNG or web_search.
- **Batch production trap: don't write all 4 scripts identically.** Each short needs a distinct hook, different tool focus, different example. If all 4 follow the same structure readers detect template fatigue. Vary section order occasionally.
- **Repackaging old content: verify free tiers still exist.** Old scripts reference tools whose free tiers may have changed. Always re-verify before repackaging.
- **Notion hub page must exist before child pages.** Create hub first, then create standalone pages and tell user to drag them under hub. Zapier cannot nest pages automatically.