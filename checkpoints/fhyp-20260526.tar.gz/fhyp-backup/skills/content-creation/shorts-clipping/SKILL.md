---
name: shorts-clipping
description: AI-assisted Shorts extraction agent for GameySins with human-in-the-loop. User provides original video file, agent analyzes transcript, suggests candidate Short-worthy moments with timestamps, waits for user approval, then cuts perfect-quality segments. User adds text/branding in their own editor. Trigger when the user wants to extract Shorts from a video, or asks to clip/cut a video into Short-form content.
---

# Shorts Clipping Agent — GameySins

## When to Use

Trigger this skill when the user:
- Puts a video file in `D:\GameySins_Shorts\input\` and asks to extract Shorts
- Asks to find the best clips from a long video
- Wants to cut/clip a video into Short-form content
- Says anything like "extract shorts from this", "clip this video", "find the best moments", "make shorts of my latest video"

## What This Agent Does

This is a **hybrid human-in-the-loop workflow**. The agent handles analysis and cutting. The user makes final judgment calls and adds creative overlays.

### Agent Responsibilities:
1. **Analyzes** the video (transcript, chapters, metadata)
2. **Suggests** candidate Short-worthy moments with timestamps
3. **Waits for user approval** before proceeding to cut
4. **Cuts** approved clips using FFmpeg stream copy (NO re-encode, NO quality loss)
5. **Outputs** full-quality raw clips + upload metadata (titles, descriptions, tags)

### User Responsibilities:
- **Provides** the original high-quality video file in `D:\GameySins_Shorts\input\`
- **Reviews** suggested timestamps and picks which clips to extract
- **Adjusts** timestamps if needed
- **Adds** text overlays, branding, and effects in their own editor (CapCut, Premiere, etc.)

### Why This Workflow?
- **Stream copy cutting** = zero quality loss, original audio preserved
- **No re-encoding** = no blur, no artifacts, no audio degradation
- **User controls creative** = full control over text styling, fonts, animations
- **Agent handles analysis** = fast timestamp suggestions based on transcript

---

## Directory Structure

```
D:\GameySins_Shorts\
├── input\          # User drops original video files here
└── (agent outputs numbered clips here)
```

```
~/gameysins/shorts/
├── raw/            # Local copy of input video
└── clips_hq/       # HQ stream-copy cuts
```

---

## Full Workflow

### Phase 1: Get the Video

**User drops video in `D:\GameySins_Shorts\input\`**

Copy to local WSL directory for processing:
```bash
cp "/mnt/d/GameySins_Shorts/input/[filename]" ~/gameysins/shorts/raw/
```

Get video info:
```bash
ffprobe -v error -show_entries format=duration,size -show_entries stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 ~/gameysins/shorts/raw/[filename]
```

### Phase 2: Analyze & Get Transcript

Extract audio and transcribe with Whisper:
```bash
# Extract audio
ffmpeg -i ~/gameysins/shorts/raw/[filename] -vn -ar 16000 -ac 1 -c:a pcm_s16le ~/gameysins/shorts/raw/audio.wav

# Transcribe (Arabic)
whisper ~/gameysins/shorts/raw/audio.wav --language ar --model medium --output_dir ~/gameysins/shorts/raw/
```

### Phase 3: Generate Candidate Timestamps (For User Review)

Analyze the transcript for Short-worthy moments. Look for:
- Emotional peaks (funny, shocking, relatable)
- Strong hooks and punchlines
- Self-contained moments (make sense without context)
- Clear beginning and end

For each candidate, output:
```
🎬 CANDIDATE #[number]
⏱️  Timestamp: [START] — [END] ([DURATION]s)
🎯 Hook: [What makes this engaging]
📝 Transcript excerpt: [Key lines]
💡 Title Idea: [Suggested title]
⚠️  Note: [Any caveats]
```

**Minimum 5 candidates, maximum 10.** More options = better for user to pick from.

### Phase 3.5: User Review ⏸️

**STOP and wait for user input.** Present the candidate list and ask which ones to cut.

**Do NOT proceed until the user approves.**

### Phase 4: Cut Approved Clips (Stream Copy — No Quality Loss)

**Only proceed after user approval.**

Use FFmpeg stream copy (`-c:v copy -c:a copy`) for perfect quality:
```bash
# Single clip
ffmpeg -ss [START_SECONDS] -i ~/gameysins/shorts/raw/[filename] -t [DURATION] -c:v copy -c:a copy ~/gameysins/shorts/clips_hq/short_[number]_[name]_hq.mp4
```

Key rules:
- **ALWAYS use `-c:v copy -c:a copy`** — never re-encode the cuts
- **Never crop or change aspect ratio** — output is same as source
- **Never convert to vertical** — user does this in their editor
- Output files go directly to `D:\GameySins_Shorts\` for easy access

### Phase 5: Generate Upload Package

For each cut, provide:
```
📦 UPLOAD PACKAGE — Short #[number]

📹 File: D:\GameySins_Shorts\[filename].mp4
⏱️  Duration: [XX]s
📐 Format: [original resolution]

📌 TITLE:
[Arabic title — punchy, under 60 chars]

📝 Description:
[First 2 lines keyword-rich]
#Shorts #GameySins #العاب #جيمايسنز

🏷️ Tags:
Arabic: #Shorts #جيمايسنز #العاب
English: #Shorts #GameySins #Gaming
SEO: shorts, gaming, arabic gaming, gameysins, العاب, جيمايسنز
```

---

## Quick Reference

```bash
# Copy video from D drive to WSL
cp "/mnt/d/GameySins_Shorts/input/[file]" ~/gameysins/shorts/raw/

# Get video info
ffprobe -v error -show_entries format=duration,size -show_entries stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 ~/gameysins/shorts/raw/[file]

# Extract audio for Whisper
ffmpeg -i ~/gameysins/shorts/raw/[file] -vn -ar 16000 -ac 1 -c:a pcm_s16le ~/gameysins/shorts/raw/audio.wav

# Transcribe
whisper ~/gameysins/shorts/raw/audio.wav --language ar --model medium

# Cut clip (stream copy — perfect quality)
ffmpeg -ss [START] -i ~/gameysins/shorts/raw/[file] -t [DURATION] -c:v copy -c:a copy ~/gameysins/shorts/clips_hq/output.mp4

# Copy output to D drive
cp ~/gameysins/shorts/clips_hq/output.mp4 "/mnt/d/GameySins_Shorts/output.mp4"
```

---

## Tips

- **Stream copy is key** — `-c:v copy -c:a copy` preserves 100% quality
- **Don't crop or convert** — user handles aspect ratio in their editor
- **Don't add text** — user has full creative control in CapCut/Premium
- **More candidates = better** — generate 8-10 options for user to choose from
- **Transcript quality matters** — Whisper Arabic isn't perfect, be aware of errors
- **File naming** — use descriptive names: `01_صحاب_الألعاب_Friends_HQ.mp4`
- **Output to D drive** — always copy final files to `D:\GameySins_Shorts\` for easy Windows access
