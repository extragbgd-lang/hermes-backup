# GameySins — Thumbnail Generation Workflow

## Tool: Google Flow (Nano Banana Pro)
- URL: https://labs.google/fx/tools/flow
- Model: Nano Banana Pro
- **CRITICAL: Do NOT describe Ammar's appearance in text prompts** — upload reference images to Flow instead
- Upload Ammar's photo + Mosmar's photo as reference images once, reuse for all thumbnails
- Prompt should say "Using the reference image of Ammar" not describe facial features

## What NOT to Do
- Do NOT use the built-in `image_generate` tool — FAL key is corrupted
- Do NOT use Google AI Studio API directly — free tier has 0 image gen quota
- Do NOT try browser automation for Google Flow — Google blocks Playwright sign-in
- Do NOT describe character appearance in prompts — always use reference images

## Prompt System
- Full prompt template + variables + game scenes + emotion guide at:
  `~/.hermes/gameysins/thumbnail-prompt-system.md`
- When user gives video topic/game, generate complete prompt from template
- Only swap: emotion, game name, scene description, Arabic text (2-5 words max)

## Master Prompt Structure
```
YouTube thumbnail, 16:9 aspect ratio, ultra high quality. Using the reference
image of Ammar, place him on the left third of the frame. His face shows
[EMOTION] — [EMOTION_DESC]. He is seamlessly integrated into the [GAME_NAME]
game world as if he is the protagonist — [SCENE_DESC]. Cinematic lighting with
dramatic rim lighting, volumetric light rays, high contrast warm orange/yellow
highlights + cool blue/teal shadows, vibrant saturated, deep blacks. Bold Arabic
text "[ARABIC_TEXT]" in heavy sans-serif font on right side, bright yellow with
thick black outline and drop shadow. Red accent element (arrow/circle/burst).
Style: cinematic, hyper-detailed, YouTube CTR optimized, mobile-friendly. No
watermarks, no text other than specified Arabic text.
```

## Emotion Guide
- shock: mouth open, eyes wide, eyebrows raised, one hand near face
- excitement: huge grin, eyes wide, both hands raised
- fear: wide eyes, gritted teeth, looking over shoulder
- focus: determined eyes, slight smirk, gripping weapon
- laughter: eyes shut, mouth wide, tears forming
- rage: clenched jaw, intense eyes, veins visible
- disbelief: both hands on head, mouth wide, eyes popped
- mystery: one eyebrow raised, slight smile, direct gaze

## Content Type Variations
- **News/Reaction**: Split-screen collage, glitch border, electric blue/orange
- **Funny**: Bright oversaturated, warm yellow/orange, comic impact lines
- **Tutorial**: Clean, character pointing at element, blue/orange scheme
- **Challenge**: Dark intense, character in danger, red accent lighting
- **Comparison**: Split composition, energy sparks between sides
- **Mosmar videos**: Include Mosmar ref image alongside Ammar

## Vision Analysis Workaround
- `vision_analyze` tool may fail on this provider
- Fallback: Google Gemini API via curl with inline_data (base64 image)
- Endpoint: POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent

## Ammar's Appearance (from Gemini vision analysis)
- Age: Early to mid-30s | Face: Round to oval, full cheeks, wider jawline
- Head: Mostly bald on top, short dark buzz cut on sides
- Beard: Full dark brown/black, medium length, thick connected mustache
- Eyebrows: Thick, dark, slight arch, almost meeting in middle
- Eyes: Dark brown, almond-shaped, hooded, dark circles
- Skin: Fair to light-medium olive | Neck: Relatively thick, slight double chin
- Typical outfit: Black long-sleeved button-up, top buttons undone

## Mosmar Character
- Childhood gaming companion, minimal dialogue, one catchy phrase
- Upload reference image to Flow alongside Ammar's
- Place Mosmar alongside Ammar when video features him
