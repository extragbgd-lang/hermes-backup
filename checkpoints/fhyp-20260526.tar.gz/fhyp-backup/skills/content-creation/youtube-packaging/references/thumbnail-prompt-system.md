# GameySins Thumbnail Prompt System
# ==================================
# Use with Google Flow (labs.google/fx/tools/flow) → Nano Banana Pro model
# Upload reference images (Ammar + Mosmar) to Flow before generating.

## MASTER PROMPT (copy-paste into Google Flow):

YouTube thumbnail, 16:9 aspect ratio, ultra high quality. Using reference image of Ammar [position/composition as main character]. Using reference image of Mosmar [position/composition as mascot sidekick]. Ammar shows [EMOTION] — [EMOTION_DESC]. Mosmar is positioned [mascot placement] reacting with [mascot reaction]. Both are seamlessly integrated into the [GAME_NAME] game world — [SCENE_DESC]. Cinematic lighting with dramatic rim lighting on the characters, volumetric light rays, high contrast between warm orange/yellow highlights and cool blue/teal shadows. The overall color grade is vibrant and saturated with deep blacks. Bold Arabic text "[ARABIC_TEXT]" in a heavy sans-serif font positioned on the right side of the frame, bright yellow with thick black outline and drop shadow. A subtle red accent element (arrow, circle, or burst) draws attention to a key area. Style: cinematic, hyper-detailed, YouTube CTR optimized, mobile-friendly composition with clear focal point. No watermarks, no text other than the specified Arabic text.

## VARIABLES (fill per video):

[CHARACTER_REF]: Use reference image of Ammar (upload to Flow). Also use reference image of Mosmar (the mascot plush character) positioned in the scene. Do NOT describe either appearance in the prompt.
[EMOTION]: shock | excitement | fear | focus | laughter | rage | disbelief | mystery
[EMOTION_DESC]: (see emotion guide below)
[GAME_NAME]: Once Human | Myth of Empires | Dying Light 2 | Fortnite | GTA | etc.
[SCENE_DESC]: (see game scenes guide below)
[ARABIC_TEXT]: 2-5 words max, punchy, matches video title hook

## EMOTION GUIDE:
- shock: "extreme shock — mouth open, eyes wide, eyebrows raised, one hand near his face"
- excitement: "wild excitement — huge grin, eyes wide, both hands raised in celebration"
- fear: "genuine fear — wide eyes, gritted teeth, looking over his shoulder"
- focus: "intense competitive focus — determined eyes, slight smirk, gripping a weapon"
- laughter: "uncontrollable laughter — eyes squeezed shut, mouth wide open laughing, tears forming"
- rage: "competitive rage — clenched jaw, intense eyes, veins visible on forehead"
- disbelief: "shock and disbelief — both hands on head, mouth wide open, eyes popped"
- mystery: "intrigued mystery — one eyebrow raised, slight smile, looking directly at viewer"

## GAME SCENES GUIDE:
- Once Human: "zombie horde charging through a ruined city, dark apocalyptic sky with lightning, destroyed buildings and fire"
- Myth of Empires: "massive medieval castle siege with fire and smoke, armies clashing on a battlefield, dramatic sunset sky"
- Dying Light 2: "nighttime rooftop parkour chase with volatile zombies pursuing, city lights below, full moon behind, volumetric fog"
- Fortnite: "victory royale moment with storm circle closing, colorful battle bus in sky, loot scattered around"
- GTA: "dramatic car chase through Los Angeles streets, police helicopters overhead, explosions and neon lights"
- Minecraft: "epic cave exploration with diamond ore glowing, lava waterfall, dramatic torch lighting"
- PUBG: "intense final circle battle, pan weapon in hand, smoke grenades and gunfire"
- Valorant: "clutch moment with agent abilities firing, dramatic spike plant site, neon-lit futuristic map"
- Elden Ring: "epic boss fight moment, massive boss creature with glowing weak point, dark fantasy arena"
- Cyberpunk: "neon-lit Night City street, flying cars, holographic advertisements, rain-soaked reflections"
- Where Winds Meet: "dramatic martial arts combat in ancient Chinese landscape, cherry blossoms falling, dramatic sunset"

## CONTENT TYPE COMPOSITION MAPPING:

### Comparison/Controversy (PC vs Console, etc.):
Split composition showing both options clashing, energy sparks between sides, character in the middle pointing or choosing. Red lightning bolt between sides.
Arabic text examples: "اختار صح!", "مين الأقوى؟", "PC vs Console"

### News/Reaction:
Split-screen collage of gaming news moments behind character, glitch/energy effect border, electric blue and orange color grade. Multiple red arrows pointing to news elements.
Arabic text examples: "الخبر الصادم!", "أخيراً!", "ما توقعت!"

### Funny Moments:
Bright oversaturated colors, warm yellow/orange grade, comic-style impact lines and star bursts around funny moment.
Arabic text examples: "ما قدرت أتمالك 😂", "لحظة مجنونة!"

### Tutorial/Guide:
Clean composition, character pointing at game element, blue/orange color scheme, info-graphic style.
Arabic text examples: "السر اللي ما حد يعرفه!", "تعلم هذا!", "نصيحة ذهبية"

### Challenge/Hardcore:
Dark intense atmosphere, character in danger, red accent lighting, dramatic shadows.
Arabic text examples: "أصعب تحدي في حياتي!", "مستحيل!", "تحدي الموت"

### Review/First Impression:
Game elements arranged around character, yellow star rating visible, game logo prominent.
Arabic text examples: "يستاهل؟", "أول انطباع!", "تقييمي النهائي"

### Mosmar Character (mascot only):
Include Mosmar mascot character using his reference image. Mosmar is the imaginary friend / plush sidekick, not the main presenter. Appears for comedic punchlines. Same cinematic quality. Place Mosmar alongside Ammar or in the scene. Use [MOSMAR_REF] placeholder for his reference image. Mosmar is NOT the main speaker — GameSins (Ammar) is.

## REFERENCE IMAGES:

- **Ammar's photo**: Saved at `~/.hermes/image_cache/img_361c36d7f826.jpeg` (3888x5184 JPEG). User uploads to Google Flow. Do NOT describe his appearance in prompts.
- **Mosmar's image**: User has a photo of the Mosmar mascot character. User uploads to Google Flow. Both reference images are used together in every thumbnail.
- When generating prompts for Google Flow, always mention BOTH reference images: "Using reference image of Ammar" + "Using reference image of Mosmar". Do NOT describe either character's physical appearance.

## CONSISTENCY RULES:
- Use Ammar reference image for main character (upload once, reuse every time)
- Use Mosmar reference image for mascot character (upload once, reuse every time)
- Always include BOTH reference images in every thumbnail prompt
- Do NOT describe character appearance in prompts — reference images handle this

## TITLE HOOK → ARABIC TEXT MAPPING:
The Arabic text on the thumbnail should match or complement the video title:
- If title is a question → text should be the answer or "شوف الإجابة!"
- If title is a claim → text should be the claim in Arabic (2-5 words)
- If title is a list → text should be "أفضل X!" or "أخطر X!"
- If title is a comparison → text should be "اختار صح!" or "مين أفضل?"
- Keep it SHORT: 2-5 words maximum
- Use power words: صادم، مجنون، مستحيل، أخيراً، السر، ما كانش متوقع
