# Hyperframes Composition Template — GameySins B-Roll

## Fonts — Arabic-First, SIZE MATTERS

**⚠️ User explicitly complained text was too small and fonts didn't match taste. Use Arabic-first fonts with LARGE sizes.**

### Font Pairing: Cairo (Arabic) + Rubik (English)

```css
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&family=Rubik:wght@400;500;700;900&display=swap');
.font-cairo { font-family: 'Cairo', sans-serif; }
.font-rubik { font-family: 'Rubik', sans-serif; }
```

### Font Size Reference

| Use Case | Font | Size | Weight |
|----------|------|------|--------|
| **Main title (English)** | Rubik | **100-110px** | 900 |
| **Main title (Arabic)** | Cairo | **44-48px** | 700 |
| **Section title** | Rubik | **72px** | 900 |
| **Subtitle (Arabic)** | Cairo | **36-44px** | 700 |
| **Body/spec text** | Cairo | **24-36px** | 600-700 |
| **Small labels** | Cairo | **22-24px** | 600 |
| **Watermark** | Rubik | **24px** | 700 |

### ⚠️ Banned Fonts (user rejected these)
- **Orbitron**: Too "sci-fi", not sleek enough
- **Rajdhani**: Too thin, not readable enough
- **Chakra Petch**: User didn't like it
- **Inter, Roboto, Poppins, Montserrat**: Generic AI defaults

## Video Composition Rules

### Layout: 3 Layers Minimum
Every scene needs:
1. **Background**: Grid pattern, corner accents, accent lines
2. **Midground**: The actual content (titles, cards, visuals)
3. **Foreground**: Watermark, data bars, decorative elements

### Text Readability (Video Sizes, NOT Web Sizes)
- **Headlines: 60-120px** (web sizes are invisible on video)
- **Body: 28-42px**
- **Labels: 18-24px**
- **Minimum: 24px** for anything that needs to be readable

### Motion Principles
- **Vary eases**: Use at least 3 different eases per scene
- **Vary directions**: Mix from left, right, scale, opacity
- **Offset first animation 0.1-0.3s** — never start at t=0
- **Use `fromTo` not `from`** — deterministic rendering
- **Ambient motion ON the timeline** — never standalone `gsap.to()`

### GSAP Rules (Non-Negotiable)
1. `gsap.timeline({ paused: true })` — always
2. `window.__timelines["id"] = tl` — always
3. `window.__hf = { duration, seek }` — always
4. **Use `fromTo` not `from`** — deterministic rendering
5. **Position parameter** (3rd arg) for absolute timing — NOT delay
6. **NO `repeat: -1`** — use finite counts
7. **NO `Math.random()`** — breaks deterministic rendering
8. **NO standalone `gsap.to()`/`gsap.from()`** — all animation on the timeline

## Color Scheme

**⚠️ STRICT: Only neon red + neon blue + black/white. NO green, purple, orange, amber.**

| Element | Color | Hex |
|---------|-------|-----|
| Primary accent | Neon Red | `#ff0040` |
| Secondary accent | Neon Blue | `#00d4ff` |
| Background | Near-black | `#050508` |
| Text | White | `#ffffff` |

## Render Command

```bash
export NVM_DIR="$HOME/.nvm" && . "$NVM_DIR/nvm.sh"
cd ~/gameysins/broll/PROJECT-NAME
LD_LIBRARY_PATH=~/local-libs/lib npx hyperframes render --dir compositions/COMP-NAME --output output/COMP-NAME.mp4
```

## WSL Chrome Dependency Fix

If Chrome headless shell fails with `libnss3.so: cannot open shared object file`:

```bash
mkdir -p ~/local-libs && cd ~/local-libs
# Download .deb packages from Ubuntu 24.04 archive (libnss3, libnspr4, libasound2t64)
# Extract: dpkg-deb -x package.deb extracted/
cp extracted/usr/lib/x86_64-linux-gnu/*.so* ~/local-libs/lib/
# Then: LD_LIBRARY_PATH=~/local-libs/lib npx hyperframes render ...
```
