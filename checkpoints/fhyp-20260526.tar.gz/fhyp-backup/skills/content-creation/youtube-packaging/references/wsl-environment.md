# WSL-Windows Hybrid Environment Reference

## Setup Pattern

The user runs WSL2 (Ubuntu) on Windows. Key Windows tools are accessible from WSL via `/mnt/c/` mount.

## Symlink Pattern for Windows Tools in WSL

When a tool exists on Windows but not in WSL, create symlinks:

```bash
mkdir -p ~/.local/bin
ln -sf "/mnt/c/ffmpeg/bin/ffmpeg.exe" ~/.local/bin/ffmpeg
ln -sf "/mnt/c/ffmpeg/bin/ffprobe.exe" ~/.local/bin/ffprobe
```

Ensure `~/.local/bin` is in PATH:
```bash
grep -q '.local/bin' ~/.bashrc || echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
```

## Known Tool Locations

| Tool | Windows Path | WSL Symlink |
|---|---|---|
| FFmpeg | `C:\ffmpeg\bin\ffmpeg.exe` | `~/.local/bin/ffmpeg` |
| FFprobe | `C:\ffmpeg\bin\ffprobe.exe` | `~/.local/bin/ffprobe` |
| OBS | `C:\Program Files\obs-studio\bin\64bit\obs64.exe` | N/A (GUI app) |
| Node.js | `C:\Program Files\nodejs\node.exe` | Use nvm in WSL instead |
| Python 3.13 | `C:\Program Files\Python313\python.exe` | N/A (use `/usr/bin/python3` in WSL) |

## Python Environments — CRITICAL

There are **three** Python environments. Using the wrong one causes `ModuleNotFoundError`:

| Environment | Executable | Key Packages |
|---|---|---|
| **WSL system Python** | `/usr/bin/python3` | google-api-python-client, google-auth-oauthlib, yt-dlp, Pillow, requests, dotenv, torch, numpy |
| **WSL hermes-agent venv** | `/home/ammar/.local/share/pipx/venvs/hermes-agent/bin/python` | openai-whisper, moviepy, ImageIO, numba, tiktoken, torch, numpy |
| **Windows Python 3.13** | `C:\Program Files\Python313\python.exe` | openai-whisper, torch, yt-dlp, Pillow, requests, numba, numpy, tiktoken |

**Rules:**
- For YouTube API (google-api-python-client): use `/usr/bin/python3` (WSL system)
- For Whisper (openai-whisper): use the hermes-agent venv Python
- For Windows-side whisper: `"/mnt/c/Program Files/Python313/python.exe" -m whisper`
- When running scripts from WSL that need google packages, always use `/usr/bin/python3` not the default `python3` (which may point to the venv)
- Add `sys.path.insert(0, str(Path.home() / ".local/lib/python3.12/site-packages"))` at the top of scripts that need user-installed packages
- For hermes-agent venv installs: use `/home/ammar/.local/share/pipx/venvs/hermes-agent/bin/python -m pip install <pkg>`

## Package Installation Notes

- **sudo requires password** — user must enter it manually
- **snap also requires sudo** — same limitation
- **pip install** works with `--user --break-system-packages` flags for system Python
- **nvm** is the preferred Node.js installer (no sudo needed)
- **Static binaries** can be downloaded to `~/.local/bin` without sudo
- **Large downloads** may timeout on slow connections — install heavy deps (torch, numba) first, then lighter packages
- **ImageMagick CLI** is NOT installed and NOT needed — Pillow covers all image processing needs
- **faster-whisper** is installed on WSL system Python (alternative to openai-whisper, faster inference)

## GPU Note

No NVIDIA GPU detected in WSL. CUDA-dependent tools (like GPU-accelerated Whisper) will fall back to CPU. This is expected for the Lenovo LOQ in WSL2.

## API Credentials & Scripts

- YouTube OAuth credentials: `~/.hermes/youtube_credentials.json`
- YouTube OAuth token: `~/.hermes/youtube_token.json`
- YouTube API helper script: `~/.hermes/youtube_api.py`
- Run YouTube API scripts with: `/usr/bin/python3 ~/.hermes/youtube_api.py`
- OAuth flow: **DO NOT use `run_local_server`** — WSL2 localhost redirect from Windows browser causes `MismatchingStateError` (CSRF state mismatch). Instead use the OOB (out-of-band) flow:
  1. Set `client_config["redirect_uris"] = ["urn:ietf:wg:oauth:2.0:oob"]`
  2. Generate URL: `flow.authorization_url(prompt="consent", access_type="offline")`
  3. Save the flow state (pickle) or use a two-script approach
  4. User opens URL in Windows browser, authorizes, gets a code
  5. User pastes code back, script runs `flow.fetch_token(code=code)`
  6. Save token to `~/.hermes/youtube_token.json`
- **OAuth consent screen must be in "Testing" mode with user added as tester**, or published. Otherwise: `Error 403: access_denied`
- **Scope typos cause `Error 400: invalid_scope`** — correct scopes are `https://www.googleapis.com/auth/youtube`, `https://www.googleapis.com/auth/youtube.upload`, `https://www.googleapis.com/auth/youtube.readonly` (no double `auth/auth`)
- **Port 8080 may be in use** from previous failed attempts — run `lsof -ti:8080 | xargs kill -9` to free it
- Helper scripts: `~/.hermes/youtube_api.py` (main API helper), `~/.hermes/youtube_auth_step2.py` (code-to-token exchange)
