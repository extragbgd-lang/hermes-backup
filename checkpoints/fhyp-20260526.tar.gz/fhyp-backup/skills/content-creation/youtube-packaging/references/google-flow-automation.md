# Google Flow — Status & Notes (Updated May 2026)

## Current Status: WORKS via Chrome CDP

Previous attempts failed because Google blocks headless/Playwright browsers. With the user's own Chrome via CDP remote debugging, this may work — the browser appears as a normal Chrome instance.

Use the same CDP approach as NotebookLM: see `quick-facts-pipeline` → `references/chrome-remote-debugging.md`.

## Flow URL

`https://labs.google/fx/tools/flow`

## Alternative: OpenRouter Image Gen (Fallback)

If Google Flow still blocks, use OpenRouter API: model `google/gemini-2.5-flash-image`, cost ~$0.0000003/image. See `modules/image_generator.py` in quick-facts-channel.

## Manual Workflow (Always Available)

1. User opens `https://labs.google/fx/tools/flow`
2. Select Nano Banana Pro model
3. Upload reference images once
4. Paste the generated prompt
5. Generate 4 variations, pick best

## Agent's Role

Generate COMPLETE thumbnail prompts with ALL variables filled in. No templates with blanks.
