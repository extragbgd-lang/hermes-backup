# GameySins — Channel Reference

## Social Links (Copy-Paste Ready)

```
YouTube: https://www.youtube.com/@Gameysins
Twitch: https://www.twitch.tv/gameysins
TikTok: https://www.tiktok.com/@gameysins7
Facebook: https://www.facebook.com/profile.php?id=61587385348813
Instagram: https://www.instagram.com/gameysins/
Discord: https://discord.gg/ty8qXXpcMT
Email: gameysins@gmail.com / gamerdaddyreveiw@gmail.com
```

## Platform-Specific Notes

### YouTube
- Primary platform for long-form + Shorts
- Audience: Arabic-speaking gamers, Egyptian dialect
- Upload consistency matters more than frequency
- First 48 hours critical for algorithm push

### Twitch
- Stream schedule: evening shift (Ammar), morning shift (Beir)
- Clip highlights for Shorts/TikTok after stream
- Community interaction priority

### TikTok
- Short-form vertical content
- Trending sounds boost reach
- Arabic captions essential

### Facebook
- Longer captions, storytelling
- Gaming groups for cross-promotion

### Instagram
- Reels = priority format
- Stories for daily engagement

### Discord
- Community hub for announcements

## SEO Quick Reference

### Arabic Keywords
العاب, جيمايسنز, شرح, تقييم, أفضل, جديد, ترند

### English Keywords
GameySins, Gaming, Gameplay, Walkthrough, Review, Tips and tricks

### Hashtag Groups

Arabic:
#جيمايسنز #العاب #جيمينق #العاب_اونلاين #ترند #جديد

English:
#GameySins #Gaming #Gamer #Gameplay #GamingCommunity #PS5Gaming #PCGaming

### SEO Tags Format (comma-separated)
gaming, arabic gaming, gameplay, [game name] gameplay, [game name] arabic, gaming arabic, mena gaming

## Mosmar Character Reference

- Childhood gaming companion/gamemate
- Minimal dialogue, one catchy phrase
- Used in branding, thumbnails, scripts, jokes
- Do NOT let Mosmar dominate content

## PC Specs (for content reference)

Lenovo LOQ 83GS0095AX, i5-12450HX, 24GB RAM, ~475GB storage

## Automation Pipeline Goals

1. Stream → Clips: Auto-extract highlights from Twitch VODs
2. Clips → Shorts: Auto-format vertical with captions
3. Arabic Transcription: Whisper API
4. Thumbnail Generation: AI prompts → batch generate
5. Cross-posting: One-click publish to all platforms
