#!/usr/bin/env python3
"""
Google Flow - Thumbnail Generator Automation
==============================================
Generates YouTube thumbnails using Google Flow (Nano Banana Pro model).
Uses saved session from flow_setup.py — no login required.

Usage:
  /usr/bin/python3 flow_generate.py --prompt "your prompt here"
  /usr/bin/python3 flow_generate.py --game "Once Human" --emotion "shock" --text "الكابوس بدأ!"
  /usr/bin/python3 flow_generate.py --list prompts.txt  (batch mode, one prompt per line)

Requirements:
  - Run flow_setup.py first to save your Google session
  - pip install playwright --break-system-packages (system Python)
  - /usr/bin/python3 (system python, not venv)
"""

import asyncio
import argparse
import json
import os
import sys
import time
from pathlib import Path
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

SESSION_FILE = Path.home() / ".hermes" / "google_flow_session.json"
UI_CACHE_FILE = Path.home() / ".hermes" / "flow_editor_ui.json"
OUTPUT_DIR = Path.home() / "gameysins" / "thumbnails" / "generated"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

GOOGLE_FLOW_URL = "https://labs.google/fx/tools/flow"

# ═══════════════════════════════════════════════════════════════
# THUMBNAIL PROMPT TEMPLATES
# ═══════════════════════════════════════════════════════════════

# Base character description — KEEP CONSISTENT for brand recognition
CHARACTER_DESC = (
    "A young Arab man in his mid-20s with short dark hair and a short beard, "
    "wearing a dark gaming hoodie, positioned on the left third of the frame"
)

# Base style — KEEP CONSISTENT
BASE_STYLE = (
    "Cinematic lighting with dramatic rim lighting on the character, "
    "volumetric light rays, high contrast between warm orange/yellow highlights "
    "and cool blue/teal shadows. The overall color grade is vibrant and saturated "
    "with deep blacks. "
    "Style: cinematic, hyper-detailed, YouTube CTR optimized, mobile-friendly "
    "composition with clear focal point. Shot as if captured by a professional "
    "gaming photographer. No watermarks, no text other than specified Arabic text and logo."
)

# Text style — KEEP CONSISTENT
TEXT_STYLE = (
    "Bold Arabic text in a heavy sans-serif font positioned on the right side "
    "of the frame, with a thick black outline and drop shadow for maximum "
    "readability at small sizes. The text is bright yellow or white."
)

# Watermark — KEEP CONSISTENT
WATERMARK = "The GameySins logo watermark is subtly placed in the bottom right corner."

EMOTIONS = {
    "shock": "extreme shock — mouth open, eyes wide, eyebrows raised, one hand near his face",
    "excitement": "wild excitement — huge grin, eyes wide, both hands raised in celebration",
    "fear": "genuine fear — wide eyes, gritted teeth, looking over his shoulder",
    "focus": "intense competitive focus — determined eyes, slight smirk, gripping a weapon",
    "laughter": "uncontrollable laughter — eyes squeezed shut, mouth wide open laughing, tears forming",
    "rage": "competitive rage — clenched jaw, intense eyes, veins visible on forehead",
    "disbelief": "shock and disbelief — both hands on head, mouth wide open, eyes popped",
    "mystery": "intrigued mystery — one eyebrow raised, slight smile, looking directly at viewer",
}

GAME_SCENES = {
    "once human": "zombie horde charging through a ruined city, dark apocalyptic sky with lightning, destroyed buildings and fire",
    "myth of empires": "massive medieval castle siege with fire and smoke, armies clashing on a battlefield, dramatic sunset sky",
    "dying light 2": "nighttime rooftop parkour chase with volatile zombies pursuing, city lights below, full moon behind, volumetric fog",
    "fortnite": "victory royale moment with storm circle closing, colorful battle bus in sky, loot scattered around",
    "gta": "dramatic car chase through Los Angeles streets, police helicopters overhead, explosions and neon lights",
    "minecraft": "epic cave exploration with diamond ore glowing, lava waterfall, dramatic torch lighting",
    "pubg": "intense final circle battle, pan weapon in hand, smoke grenades and gunfire, chicken dinner celebration",
    "valorant": "clutch moment with agent abilities firing, dramatic spike plant site, neon-lit futuristic map",
    "elden ring": "epic boss fight moment, massive boss creature with glowing weak point, dark fantasy arena",
    "cyberpunk": "neon-lit Night City street, flying cars, holographic advertisements, rain-soaked reflections",
}


def build_thumbnail_prompt(
    game: str,
    emotion: str,
    arabic_text: str,
    custom_scene: str = None,
    custom_emotion: str = None,
) -> str:
    """Build a complete thumbnail prompt from template variables."""
    game_lower = game.lower()
    emotion_lower = emotion.lower()

    scene = custom_scene or GAME_SCENES.get(game_lower, f"dramatic high-action scene from {game}")
    emotion_desc = custom_emotion or EMOTIONS.get(emotion_lower, f"extreme {emotion}")

    prompt = (
        f"YouTube thumbnail, 16:9 aspect ratio, ultra high quality. "
        f"{CHARACTER_DESC}. His face shows {emotion_desc}. "
        f"He is seamlessly integrated into the {game} game world as if he is the protagonist — "
        f"{scene}. "
        f"{BASE_STYLE} "
        f"Bold Arabic text \"{arabic_text}\" {TEXT_STYLE} "
        f"A subtle red accent element (arrow, circle, or burst) draws attention to a key area. "
        f"{WATERMARK}"
    )
    return prompt


# ═══════════════════════════════════════════════════════════════
# BROWSER AUTOMATION
# ═══════════════════════════════════════════════════════════════

class GoogleFlowAutomation:
    """Automates Google Flow for thumbnail generation."""

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.browser = None
        self.context = None
        self.page = None
        self.ui_map = {}

    async def start(self):
        """Start browser and load saved session."""
        if not SESSION_FILE.exists():
            print("❌ Session file not found!")
            print(f"   Run flow_setup.py first to save your Google login session.")
            print(f"   Expected: {SESSION_FILE}")
            sys.exit(1)

        print("🚀 Starting browser...")

        launch_args = ['--no-sandbox', '--disable-gpu']
        if not self.headless:
            launch_args.extend([
                '--enable-features=UseOzonePlatform',
                '--ozone-platform=wayland',
                '--start-maximized',
            ])

        async with async_playwright() as p:
            self.browser = await p.chromium.launch(headless=self.headless, args=launch_args)

            with open(SESSION_FILE) as f:
                storage_state = json.load(f)

            self.context = await self.browser.new_context(
                storage_state=storage_state,
                viewport={'width': 1920, 'height': 1080},
                locale='en-US',
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
            )

            self.page = await self.context.new_page()

            print(f"📱 Opening Google Flow...")
            await self.page.goto(GOOGLE_FLOW_URL, wait_until='domcontentloaded', timeout=60000)
            await asyncio.sleep(3)

            if 'accounts.google' in self.page.url:
                print("❌ Session expired! Please run flow_setup.py again to re-login.")
                sys.exit(1)

            print(f"✅ Logged in! URL: {self.page.url}")
            await self._navigate_to_editor()
            await self._build_ui_map()

    async def _navigate_to_editor(self):
        """Navigate from landing page to the actual editor."""
        current_url = self.page.url
        if 'labs.google/fx/tools/flow' in current_url and 'accounts.google' not in current_url:
            page_text = await self.page.inner_text('body')
            if 'Create with Google Flow' in page_text:
                print("📝 On landing page, clicking 'Create with Google Flow'...")
                create_btn = await self.page.query_selector('text=Create with Google Flow')
                if create_btn:
                    await create_btn.click()
                    await asyncio.sleep(5)
                    print(f"   Navigated to: {self.page.url}")

    async def _build_ui_map(self):
        """Explore the editor UI and build a map of interactive elements."""
        if UI_CACHE_FILE.exists():
            with open(UI_CACHE_FILE) as f:
                self.ui_map = json.load(f)
            print("📋 Loaded cached UI map.")
            return

        print("🔍 Exploring editor UI...")
        page = self.page
        self.ui_map = {'model_selector': None, 'prompt_input': None, 'generate_button': None, 'image_output': None, 'download_button': None}

        textareas = await page.query_selector_all('textarea, [contenteditable="true"]')
        for ta in textareas:
            placeholder = await ta.get_attribute('placeholder') or ''
            aria = await ta.get_attribute('aria-label') or ''
            if any(kw in (placeholder + aria).lower() for kw in ['prompt', 'describe', 'create', 'generate', 'image']):
                self.ui_map['prompt_input'] = f'textarea[placeholder*="{placeholder[:20]}"]' if placeholder else '[contenteditable="true"]'
                print(f"   Found prompt input: placeholder='{placeholder[:40]}'")
                break

        if not self.ui_map['prompt_input'] and textareas:
            self.ui_map['prompt_input'] = 'textarea'
            print(f"   Using first textarea as prompt input")

        buttons = await page.query_selector_all('button, [role="button"]')
        for btn in buttons:
            txt = (await btn.inner_text()).strip().lower()
            aria = (await btn.get_attribute('aria-label') or '').lower()
            if any(kw in txt or kw in aria for kw in ['generate', 'create', 'submit', 'run', 'send', '▶', 'play']):
                self.ui_map['generate_button'] = txt or aria
                print(f"   Found generate button: '{txt or aria}'")
                break

        model_elements = await page.query_selector_all('[role="combobox"], select, text=Nano Banana, text=Model')
        for elem in model_elements:
            txt = await elem.inner_text()
            if 'nano' in txt.lower() or 'banana' in txt.lower() or 'model' in txt.lower():
                self.ui_map['model_selector'] = txt.strip()[:60]
                print(f"   Found model selector: '{txt.strip()[:40]}'")
                break

        with open(UI_CACHE_FILE, 'w') as f:
            json.dump(self.ui_map, f, indent=2)
        print(f"   UI map saved to: {UI_CACHE_FILE}")

    async def select_model(self, model_name: str = "Nano Banana"):
        """Select the specified model in Google Flow."""
        print(f"🎯 Selecting model: {model_name}")
        page = self.page

        model_selectors = await page.query_selector_all('[role="combobox"], select, button:has-text("Model"), text=Nano Banana, text=Gemini, text=Veo')
        for selector in model_selectors:
            txt = await selector.inner_text()
            if 'nano' in txt.lower() or 'banana' in txt.lower() or 'model' in txt.lower():
                print(f"   Clicking model selector: '{txt.strip()[:40]}'")
                await selector.click()
                await asyncio.sleep(1)
                option = await page.query_selector(f'text={model_name}')
                if option:
                    await option.click()
                    print(f"   ✅ Selected: {model_name}")
                    await asyncio.sleep(1)
                    return True

        all_clickables = await page.query_selector_all('button, [role="option"], [role="tab"], .model-selector, [class*="model"]')
        for elem in all_clickables:
            txt = (await elem.inner_text()).strip()
            if model_name.lower() in txt.lower():
                print(f"   Found model option: '{txt}'")
                await elem.click()
                await asyncio.sleep(1)
                return True

        print(f"   ⚠️ Could not find model selector for '{model_name}'")
        return False

    async def enter_prompt(self, prompt: str):
        """Enter the prompt text into the editor."""
        print(f"📝 Entering prompt ({len(prompt)} chars)...")
        page = self.page

        textareas = await page.query_selector_all('textarea')
        for ta in textareas:
            placeholder = await ta.get_attribute('placeholder') or ''
            if any(kw in placeholder.lower() for kw in ['prompt', 'describe', 'create', 'generate', '']):
                await ta.click()
                await ta.fill(prompt)
                print(f"   ✅ Prompt entered via textarea")
                await asyncio.sleep(0.5)
                return True

        editables = await page.query_selector_all('[contenteditable="true"]')
        for editable in editables:
            await editable.click()
            await page.keyboard.type(prompt, delay=5)
            print(f"   ✅ Prompt entered via contenteditable")
            await asyncio.sleep(0.5)
            return True

        inputs = await page.query_selector_all('input[type="text"], input:not([type])')
        for inp in inputs:
            await inp.click()
            await inp.fill(prompt)
            print(f"   ✅ Prompt entered via input")
            return True

        print("   ❌ Could not find prompt input field!")
        return False

    async def click_generate(self):
        """Click the generate/create button."""
        print("🎬 Clicking generate...")
        page = self.page
        generate_keywords = ['generate', 'create', 'submit', 'run', 'send', '▶', 'play', 'go']

        buttons = await page.query_selector_all('button, [role="button"]')
        for btn in buttons:
            txt = (await btn.inner_text()).strip().lower()
            aria = (await btn.get_attribute('aria-label') or '').lower()
            if any(kw in txt or kw in aria for kw in generate_keywords):
                print(f"   Found: '{txt or aria}'")
                await btn.click()
                print("   ✅ Generate clicked!")
                return True

        print("   No generate button found, trying Enter key...")
        textareas = await page.query_selector_all('textarea, [contenteditable="true"]')
        if textareas:
            await textareas[0].press('Enter')
            print("   ✅ Sent Enter key")
            return True

        print("   ❌ Could not find generate button!")
        return False

    async def wait_for_generation(self, timeout: int = 120):
        """Wait for image generation to complete."""
        print(f"⏳ Waiting for generation (timeout: {timeout}s)...")
        page = self.page
        start_time = time.time()

        while time.time() - start_time < timeout:
            await asyncio.sleep(3)

            images = await page.query_selector_all(
                'img[src*="googleusercontent"], img[src*="lh3."], img[src*="generative"], '
                '.generated-image img, [class*="output"] img, [class*="result"] img'
            )
            if images:
                print(f"   ✅ Found {len(images)} generated image(s)!")
                return images

            page_text = await page.inner_text('body')
            if 'generating' in page_text.lower() or 'creating' in page_text.lower():
                elapsed = int(time.time() - start_time)
                if elapsed % 15 == 0:
                    print(f"   Still generating... ({elapsed}s)")
                continue

            elapsed = int(time.time() - start_time)
            if elapsed % 30 == 0:
                print(f"   Waiting... ({elapsed}s elapsed)")

        print(f"   ❌ Generation timed out after {timeout}s")
        return []

    async def download_images(self, images, output_prefix: str = "thumbnail"):
        """Download generated images."""
        print(f"📥 Downloading images...")
        downloaded = []

        for i, img in enumerate(images):
            try:
                src = await img.get_attribute('src')
                if not src:
                    continue

                timestamp = int(time.time())
                filename = OUTPUT_DIR / f"{output_prefix}_{timestamp}_{i+1}.png"

                response = await page.evaluate("""
                    async (url) => {
                        const response = await fetch(url);
                        const blob = await response.blob();
                        const arrayBuffer = await blob.arrayBuffer();
                        return Array.from(new Uint8Array(arrayBuffer));
                    }
                """, src)

                if response:
                    img_bytes = bytes(response)
                    with open(filename, 'wb') as f:
                        f.write(img_bytes)
                    print(f"   ✅ Saved: {filename}")
                    downloaded.append(str(filename))
                else:
                    bbox = await img.bounding_box()
                    if bbox:
                        await self.page.screenshot(path=str(filename), clip=bbox)
                        print(f"   ✅ Screenshot saved: {filename}")
                        downloaded.append(str(filename))
            except Exception as e:
                print(f"   ⚠️ Error downloading image {i+1}: {e}")

        return downloaded

    async def generate_thumbnail(self, prompt: str, output_prefix: str = "thumbnail") -> list:
        """Full pipeline: enter prompt → generate → download."""
        await self.select_model("Nano Banana")
        success = await self.enter_prompt(prompt)
        if not success:
            return []
        success = await self.click_generate()
        if not success:
            return []
        images = await self.wait_for_generation(timeout=120)
        if not images:
            return []
        downloaded = await self.download_images(images, output_prefix)
        return downloaded

    async def close(self):
        """Close browser."""
        if self.browser:
            await self.browser.close()
            print("🔒 Browser closed.")


# ═══════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════

async def main():
    parser = argparse.ArgumentParser(
        description="Google Flow Thumbnail Generator for GameySins",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  /usr/bin/python3 flow_generate.py --prompt "your full prompt here"
  /usr/bin/python3 flow_generate.py --game "Once Human" --emotion "shock" --text "الكابوس بدأ!"
  /usr/bin/python3 flow_generate.py --list prompts.txt
  /usr/bin/python3 flow_generate.py --headless --game "Dying Light 2" --emotion "fear" --text "الليل ما ينتهي!"
        """
    )

    parser.add_argument('--prompt', type=str, help='Full prompt text (overrides template)')
    parser.add_argument('--game', type=str, help='Game name (e.g., "Once Human", "Dying Light 2")')
    parser.add_argument('--emotion', type=str, help='Emotion (shock, excitement, fear, focus, laughter, rage, disbelief, mystery)')
    parser.add_argument('--text', type=str, help='Arabic text for thumbnail')
    parser.add_argument('--scene', type=str, help='Custom scene description (overrides game default)')
    parser.add_argument('--list', type=str, help='File with prompts (one per line)')
    parser.add_argument('--headless', action='store_true', help='Run in headless mode (no visible browser)')
    parser.add_argument('--output', type=str, default='thumbnail', help='Output filename prefix')

    args = parser.parse_args()

    prompts = []

    if args.prompt:
        prompts.append(args.prompt)
    elif args.game and args.emotion and args.text:
        prompt = build_thumbnail_prompt(game=args.game, emotion=args.emotion, arabic_text=args.text, custom_scene=args.scene)
        prompts.append(prompt)
        print(f"📝 Generated prompt:\n{prompt}\n")
    elif args.list:
        with open(args.list) as f:
            prompts = [line.strip() for line in f if line.strip()]
    else:
        parser.print_help()
        print("\n❌ Error: Provide --prompt, or --game + --emotion + --text, or --list")
        sys.exit(1)

    flow = GoogleFlowAutomation(headless=args.headless)

    try:
        await flow.start()

        for i, prompt in enumerate(prompts):
            print(f"\n{'='*60}")
            print(f"  Generating thumbnail {i+1}/{len(prompts)}")
            print(f"{'='*60}")

            prefix = f"{args.output}_{i+1}" if len(prompts) > 1 else args.output
            downloaded = await flow.generate_thumbnail(prompt, output_prefix=prefix)

            if downloaded:
                print(f"\n✅ Generated {len(downloaded)} image(s):")
                for path in downloaded:
                    print(f"   📁 {path}")
            else:
                print(f"\n❌ Failed to generate thumbnail {i+1}")

            if i < len(prompts) - 1:
                print("\n⏳ Waiting 5 seconds before next generation...")
                await asyncio.sleep(5)

    except KeyboardInterrupt:
        print("\n\n⚠️ Interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        await flow.close()


if __name__ == "__main__":
    asyncio.run(main())
