#!/usr/bin/env python3
"""
Google Flow - Session Setup Script (One-Time)
==============================================
This script opens Google Flow in a visible browser so you can log in.
After login, it saves the session state for future automated runs.

Usage: /usr/bin/python3 flow_setup.py
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from playwright.async_api import async_playwright

# Configuration
SESSION_FILE = Path.home() / ".hermes" / "google_flow_session.json"
SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)

GOOGLE_FLOW_URL = "https://labs.google/fx/tools/flow"

async def main():
    print("=" * 60)
    print("  Google Flow - Session Setup")
    print("=" * 60)
    print()
    print("This will open Google Flow in a visible browser.")
    print("Please log in with your Google account.")
    print("The script will automatically detect when you're logged in")
    print("and save the session for future automation.")
    print()
    input("Press Enter to continue...")
    
    async with async_playwright() as p:
        # Launch visible browser with WSLg
        browser = await p.chromium.launch(
            headless=False,
            args=[
                '--enable-features=UseOzonePlatform',
                '--ozone-platform=wayland',
                '--no-sandbox',
                '--disable-gpu',
                '--start-maximized',
            ]
        )
        
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            locale='en-US',
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
        )
        
        page = await context.new_page()
        
        print(f"\nOpening Google Flow: {GOOGLE_FLOW_URL}")
        await page.goto(GOOGLE_FLOW_URL, wait_until='domcontentloaded', timeout=60000)
        await asyncio.sleep(2)
        
        # Click "Create with Google Flow" to trigger sign-in
        create_btn = await page.query_selector('text=Create with Google Flow')
        if create_btn:
            print("Clicking 'Create with Google Flow'...")
            await create_btn.click()
        
        print("\n" + "=" * 60)
        print("  🔐 PLEASE LOG IN TO GOOGLE IN THE BROWSER WINDOW")
        print("=" * 60)
        print()
        print("Waiting for login to complete...")
        print("(This may take a minute or two)")
        print()
        
        # Wait for successful login - detect when we're back at flow editor
        max_wait = 300  # 5 minutes
        check_interval = 3
        elapsed = 0
        logged_in = False
        
        while elapsed < max_wait:
            await asyncio.sleep(check_interval)
            elapsed += check_interval
            
            current_url = page.url
            current_title = await page.title()
            
            # Check if we've been redirected back to Google Flow editor
            if 'labs.google/fx/tools/flow' in current_url and 'accounts.google' not in current_url:
                page_text = await page.inner_text('body')
                if 'signin' not in current_url.lower() and 'Sign in' not in current_title:
                    print(f"\n✅ Login detected! URL: {current_url}")
                    logged_in = True
                    break
            
            if elapsed % 15 == 0:
                print(f"  Still waiting... ({elapsed}s elapsed, URL: {current_url[:80]})")
        
        if not logged_in:
            print("\n❌ Login not detected within 5 minutes.")
            print("Please run this script again and complete the login.")
            await browser.close()
            sys.exit(1)
        
        # Wait a bit more for the page to fully load
        print("\nWaiting for editor to fully load...")
        await asyncio.sleep(5)
        
        # Take a screenshot of the logged-in state
        await page.screenshot(path='/tmp/flow_logged_in.png')
        print("Screenshot saved: /tmp/flow_logged_in.png")
        
        # Save the session state
        print("\nSaving session state...")
        storage_state = await context.storage_state()
        
        with open(SESSION_FILE, 'w') as f:
            json.dump(storage_state, f, indent=2)
        
        print(f"✅ Session saved to: {SESSION_FILE}")
        print(f"   Cookies: {len(storage_state.get('cookies', []))}")
        print(f"   Origins: {len(storage_state.get('origins', []))}")
        
        # Now explore the editor UI for the automation script
        print("\n" + "=" * 60)
        print("  🔍 Exploring Editor UI...")
        print("=" * 60)
        
        await explore_editor(page)
        
        await browser.close()
        
        print("\n" + "=" * 60)
        print("  ✅ SETUP COMPLETE!")
        print("=" * 60)
        print(f"\nSession saved to: {SESSION_FILE}")
        print("You can now run the automation script: /usr/bin/python3 flow_generate.py")

async def explore_editor(page):
    """Explore the Google Flow editor UI to map out elements for automation."""
    
    # Get page text
    text = await page.inner_text('body')
    print(f"\nPage content preview (first 1500 chars):")
    print("-" * 40)
    print(text[:1500])
    print("-" * 40)
    
    # Find all interactive elements
    buttons = await page.query_selector_all('button, a, [role="button"]')
    print(f"\nFound {len(buttons)} buttons/links:")
    for i, btn in enumerate(buttons[:40]):
        try:
            txt = await btn.inner_text()
            aria = await btn.get_attribute('aria-label') or ''
            cls = await btn.get_attribute('class') or ''
            if txt.strip() or aria:
                display = txt.strip()[:60] or aria[:60]
                print(f"  [{i}] '{display}' class='{cls[:50]}'")
        except:
            pass
    
    # Find all inputs
    inputs = await page.query_selector_all('input, textarea, [contenteditable="true"]')
    print(f"\nFound {len(inputs)} input fields:")
    for i, inp in enumerate(inputs[:20]):
        try:
            tag = await inp.evaluate('el => el.tagName')
            placeholder = await inp.get_attribute('placeholder') or ''
            aria = await inp.get_attribute('aria-label') or ''
            name = await inp.get_attribute('name') or ''
            cls = await inp.get_attribute('class') or ''
            print(f"  [{i}] <{tag}> placeholder='{placeholder[:60]}' aria='{aria[:40]}' name='{name[:30]}' class='{cls[:50]}'")
        except:
            pass
    
    # Find all select/dropdown elements
    selects = await page.query_selector_all('select, [role="combobox"], [role="listbox"], [aria-haspopup="listbox"]')
    print(f"\nFound {len(selects)} dropdowns/selects:")
    for i, sel in enumerate(selects[:10]):
        try:
            tag = await sel.evaluate('el => el.tagName')
            aria = await sel.get_attribute('aria-label') or ''
            txt = await sel.inner_text()
            cls = await sel.get_attribute('class') or ''
            print(f"  [{i}] <{tag}> aria='{aria[:60]}' text='{txt[:60]}' class='{cls[:50]}'")
        except:
            pass
    
    # Save exploration results
    exploration = {
        'url': page.url,
        'title': await page.title(),
        'buttons': [],
        'inputs': [],
        'selects': [],
    }
    
    for btn in buttons[:40]:
        try:
            txt = (await btn.inner_text()).strip()[:80]
            aria = (await btn.get_attribute('aria-label') or '')[:80]
            if txt or aria:
                exploration['buttons'].append({'text': txt, 'aria': aria})
        except:
            pass
    
    for inp in inputs[:20]:
        try:
            exploration['inputs'].append({
                'tag': await inp.evaluate('el => el.tagName'),
                'placeholder': (await inp.get_attribute('placeholder') or '')[:80],
                'aria': (await inp.get_attribute('aria-label') or '')[:80],
            })
        except:
            pass
    
    explore_file = Path.home() / ".hermes" / "flow_editor_ui.json"
    with open(explore_file, 'w') as f:
        json.dump(exploration, f, indent=2)
    print(f"\nUI exploration saved to: {explore_file}")

if __name__ == "__main__":
    asyncio.run(main())
