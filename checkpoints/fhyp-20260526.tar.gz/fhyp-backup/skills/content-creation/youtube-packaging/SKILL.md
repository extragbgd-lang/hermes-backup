---
name: youtube-packaging
description: End-to-end YouTube video packaging workflow for GameySins channel. Generates video ideas, titles, descriptions, tags, thumbnail concepts, and upload-ready metadata. Trigger when the user wants to package, publish, or prepare a YouTube video/Short.
---

# YouTube Packaging Agent — GameySins

## When to Use

Trigger this skill when the user wants to:
- Generate YouTube video ideas for the GameySins channel
- Package a YouTube video or Short with metadata
- Generate titles, descriptions, tags, or thumbnail ideas
- Generate B-Roll footage using Hyperframes
- Prepare upload-ready content for the GameySins channel
- Optimize content for Arabic-speaking gaming audience
- Package a Twitch stream (title, description, thumbnail, pinned message)
- Create social media posts (TikTok, Facebook, Discord, Instagram)
- Generate AI image prompts for thumbnails or branding

## Kanban Pipeline Connection

GameySins content follows a **kanban pipeline** on the `gameysins` board:
`planning → scripting → recording → editing → publishing (+ shorts)`

After completing any video-packaging step, update the board:
```
hermes kanban --board gameysins complete t_abc --summary "thumbnails ready"
hermes kanban --board gameysins create "next: record gameplay" --assignee default
```

The pipeline is linked with parent dependencies — downstream tasks auto-promote to `ready` when all parents complete. See `~/.hermes/skills/kanban/SKILL.md` for full kanban usage.

## Channel Profile

- **Channel:** @GameySins (Ammar — main host/presenter)
- **Mosmar:** Mascot character — imaginary friend / plush sidekick. Appears for comedic punchlines, **5-6 short lines per video** (not 2-3 — user wants him more present). Vary entrance position each time.
- **Audience:** Arabic-speaking gamers, Egyptian dialect
- **Content types:** Tutorials, news, reactions, funny moments, reviews, discussions, stream highlights, Shorts, compilations, AI/gaming tech
- **Business email:** gameysins@gmail.com

---

## Non-Negotiables (ALWAYS apply)

### 📌 Social links must be in EVERY description
The full social links block MUST appear in every generated YouTube and Twitch description — never leave `[Social links]` as a placeholder:

```
📌 تابعني على:
YouTube: https://www.youtube.com/@Gameysins
Twitch: https://www.twitch.tv/gameysins
TikTok: https://www.tiktok.com/@gameysins7
Instagram: https://www.instagram.com/gameysins/
Discord: https://discord.gg/ty8qXXpcMT
Facebook: https://www.facebook.com/profile.php?id=61587385348813
```

Also applies to stream descriptions, pinned chat messages, and social cross-posts. When space is tight (TikTok, Discord), use 2-3 key links + "رابط كل السوشيال ميديا في البايو".

---

## Workflow A — Video Ideation

### When the user asks for video ideas (no specific topic)

Generate **10 video ideas** across different content categories. For each idea, provide:

```
💡 IDEA #[number]
📌 Type: [tutorial / review / reaction / funny moment / discussion / Short / compilation]
🎮 Game/Topic: [specific game or subject]
🎯 Hook: [the angle that makes it clickable]
📝 Brief: [2-3 sentence description of the video]
⚡ Difficulty: [easy / medium / hard] — based on editing effort
🔥 Virality: [low / medium / high] — estimated shareability
```

### Idea Generation Rules

- Mix content types: at least 2 Shorts, 2 long-form, 1 compilation
- Include at least 1 trending topic (current gaming news/events)
- Include at least 1 Mosmar character idea
- Prioritize games Ammar plays: Once Human, Myth of Empires, Dying Light 2, Where Winds Meet
- Consider seasonal events, game updates, and community drama
- Include at least 1 "list" video (top 5, top 10, etc.)
- Include at least 1 comparison or challenge video

### Idea Categories to Rotate

1. **Reaction/Review** — new game announcements, trailers, updates
2. **Tutorial/Guide** — tips, tricks, hidden mechanics
3. **Funny Moments** — compilations, fails, glitches
4. **Discussion/Opinion** — hot takes, industry news, community topics
5. **Challenge** — self-imposed rules, speedruns, hardcore modes
6. **Comparison** — game vs game, before/after, old vs new
7. **Story/Narrative** — lore breakdowns, Easter eggs
8. **Shorts** — quick tips, one-liners, meme-worthy clips
9. **Behind the Scenes** — setup tours, workflow reveals
10. **Collaboration** — featuring Mosmar or other creators

---

## Workflow B — Video Packaging

### 1. Gather Context

Ask (or infer from context):
- Video topic / game / subject
- Content type (tutorial, review, funny moment, Short, etc.)
- Target game/community
- Any specific angle or hook

### 2. Generate Titles (3-5 options)

Create click-worthy titles in **Arabic** (Egyptian dialect feel):
- Use power words: صادم، مجنون، مستحيل، أخيراً، السر، ما كانش متوقع
- Include the game name
- Keep under 60 characters when possible
- Mix curiosity + value proposition

### 3. Write Description

Structure:
```\n[Hook — first 2 sentences, keyword-rich]\n[What the video covers — 2-3 lines]\n[Timestamps — plain format for YouTube auto-chapters:]\n0:00 first section\nX:XX second section\n[Call to action: subscribe, like, comment]\n📌 تابعني على:\nYouTube: https://www.youtube.com/@Gameysins\nTwitch: https://www.twitch.tv/gameysins\nTikTok: https://www.tiktok.com/@gameysins7\nInstagram: https://www.instagram.com/gameysins/\nDiscord: https://discord.gg/ty8qXXpcMT\nFacebook: https://www.facebook.com/profile.php?id=61587385348813\n[Hashtags]\n```\n\n- Front-load keywords in the first 200 words\n- Arabic primary, English secondary\n- Include relevant game names, platform names\n- **YT timestamps must be plain `NUMBER:NN Section Name` with no brackets or extra formatting — YouTube auto-detects this for chapter markers**

### 4. Generate Tags

Provide three sets:
- **Arabic hashtags:** #جيمايسنز #العاب #[اسم_اللعبة]
- **English hashtags:** #GameySins #Gaming #[GameName]
- **SEO tags (comma-separated):** gaming, arabic gaming, [game name] gameplay, [game name] arabic, etc.

### 5. Thumbnail Prompt Generation

**⚠️ Google Flow automation is BLOCKED** — Google blocks Playwright browsers. The user generates thumbnails manually in Google Flow.

**Agent's role**: When the user provides a video topic/game/title, generate the COMPLETE thumbnail prompt with ALL variables filled in — ready to paste into Google Flow (Nano Banana Pro model). **Do NOT output a template with blank variables.**

**CRITICAL: Do NOT describe Ammar's or Mosmar's appearance in prompts.** User uploads their own reference images to Flow. Use "Using reference image of Ammar" and "Using reference image of Mosmar" instead — both every time.

Use the master prompt template from `references/thumbnail-workflow.md` (or `~/.hermes/gameysins/thumbnail-prompt-system.md`) and fill in:
- **EMOTION**: Match video tone (shock for reveals, fear for horror, excitement for wins, focus for competitive, laughter for funny, rage for fails, disbelief for twists, mystery for secrets)
- **EMOTION_DESC**: Specific facial expression from emotion guide
- **GAME_NAME**: The game featured in the video
- **SCENE_DESC**: Dramatic game scene matching video content (from game scenes guide)
- **ARABIC_TEXT**: 2-5 word Arabic title hook

Also see `references/thumbnail-workflow.md` for the full workflow document including:
- What NOT to do (broken tools, blocked automation)
- Vision analysis workaround
- Ammar's appearance reference
- Mosmar character handling
- **GAME_NAME**: The game featured in the video
- **SCENE_DESC**: Dramatic game scene matching the video content
- **ARABIC_TEXT**: 2-5 words max, punchy, matches video title hook

Adapt composition based on content type (see `references/thumbnail-prompt-system.md`):
- Comparison → split screen, pointing at viewer, energy clash, red lightning bolt
- News/Reaction → collage, glitch border, multiple arrows
- Funny → bright oversaturated, comic lines, star bursts
- Tutorial → clean, pointing at element, blue circle
- Challenge → dark intense, character in danger, red glow
- Review → game elements around character, yellow star

**Consistency rules** (NEVER CHANGE across thumbnails):
- Reference images: Ammar (main character) + Mosmar (mascot) — both uploaded to Flow every time
- Dimensions: 1280×720 (standard YouTube thumbnail), JPEG quality 95%
- Colors: warm orange/yellow highlights + cool blue/teal shadows
- Text: bold Arabic (Cairo font), bold yellow/orange, thick black outline, drop shadow
- Do NOT describe character appearance in prompts — reference images handle this
- Only change per video: emotion, game scene, Arabic text

See `references/thumbnail-prompt-system.md` for the full prompt template, emotion guide, game scenes, and content type mappings.

### 6. Shorts-Specific Packaging

If the content is a Short:
- Hook in first 2 seconds
- Script outline (not full script) with talking points
- Editing notes (cuts, zooms, sound effects, text overlays)
- On-screen text suggestions
- Vertical format (9:16) considerations

---

## Workflow C — B-Roll Generation with Hyperframes

### What is Hyperframes?

Hyperframes is an open-source (Apache 2.0) video rendering framework by HeyGen. You write HTML + CSS + GSAP animations and it renders to MP4. It's designed for AI-agent-driven workflows — perfect for automated B-Roll generation.

**Requirements:** Node.js >= 22, FFmpeg

### Setup (one-time)

```bash
# Install Hyperframes CLI globally
npm install -g hyperframes

# Verify installation
hyperframes --version

# Initialize a new B-Roll project
npx hyperframes init b-roll-project
cd b-roll-project
```

### B-Roll Generation Workflow

#### Step 1: Define B-Roll Needs

For each video, identify B-Roll requirements:
- **Game footage overlays** — gameplay clips with text/effects
- **Text animations** — animated captions, lower thirds, titles
- **Transitions** — wipes, fades, shader effects between clips
- **Social overlays** — subscribe buttons, like animations, social handles
- **Data visualizations** — stats, charts, comparisons
- **Background loops** — animated backgrounds for voiceovers
- **Intro/Outro stings** — branded short animations

#### Step 2: Generate Hyperframes Composition

Create an `index.html` composition file. Basic structure:

```html
<!DOCTYPE html>
<html>
<head>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
  <style>
    /* Custom styles here */
  </style>
</head>
<body>
  <div id="stage"
       data-composition-id="broll-001"
       data-start="0"
       data-width="1920"
       data-height="1080">

    <!-- Background video layer -->
    <video id="bg-clip"
           data-start="0"
           data-duration="10"
           data-track-index="0"
           src="./assets/gameplay.mp4"
           muted playsinline></video>

    <!-- Animated text overlay -->
    <div id="title-text"
         data-start="0.5"
         data-duration="4"
         data-track-index="1"
         class="absolute inset-0 flex items-center justify-center">
      <h1 class="text-6xl font-bold text-white drop-shadow-lg">
        YOUR TEXT HERE
      </h1>
    </div>

    <!-- Lower third -->
    <div id="lower-third"
         data-start="1"
         data-duration="5"
         data-track-index="2"
         class="absolute bottom-16 left-16">
      <div class="bg-red-600 px-6 py-3 rounded-lg">
        <span class="text-white text-2xl font-bold">@GameySins</span>
      </div>
    </div>

    <!-- Background music -->
    <audio id="bg-music"
           data-start="0"
           data-duration="10"
           data-track-index="3"
           data-volume="0.3"
           src="./assets/music.mp3"></audio>
  </div>

  <script>
    // ⚠️ CRITICAL Hyperframes GSAP API — read hyperframes docs gsap for full reference
    // 1. Always use gsap.timeline({ paused: true }) — NOT standalone gsap.to/gsap.from
    // 2. Register timeline on window.__timelines[compositionId] — REQUIRED
    // 3. Expose window.__hf = { duration, seek } — REQUIRED for frame capture
    // 4. Use position parameter (3rd arg) for absolute timing — NOT delay
    // 5. NEVER use repeat: -1 (infinite) — breaks deterministic capture
    // 6. NEVER use Math.random() — non-deterministic output breaks rendering
    // 7. Set initial states with gsap.set() BEFORE timeline animations

    const tl = gsap.timeline({ paused: true });

    // Set initial states (before animation)
    gsap.set("#title-text h1", { scale: 0.5, opacity: 0 });
    gsap.set("#lower-third", { x: -200, opacity: 0 });

    // Animate using position parameter (3rd argument = absolute time in seconds)
    tl.to("#title-text h1", { duration: 1, scale: 1, opacity: 1, ease: "back.out(1.7)" }, 0.5);
    tl.to("#lower-third", { duration: 0.8, x: 0, opacity: 1, ease: "power2.out" }, 1.0);

    // Register timeline — REQUIRED for Hyperframes to control playback
    window.__timelines = window.__timelines || {};
    window.__timelines["broll-001"] = tl;

    // Expose HF runtime API — REQUIRED for frame capture
    window.__hf = { duration: 10, seek: (t) => tl.seek(t) };
  </script>
</body>
</html>
```

#### Step 3: Preview

```bash
# Live preview in browser with hot reload
npx hyperframes preview
```

#### Step 4: Render to MP4

```bash
# Render a specific composition directory
npx hyperframes render --dir compositions/composition-name --output output/composition-name.mp4

# Batch render all compositions (run from project root)
for dir in ./compositions/*/; do
  name=$(basename "$dir")
  echo "Rendering: $name"
  npx hyperframes render --dir "$dir" --output "output/${name}.mp4"
done
```

**WSL Chrome dependency fix:** If Chrome headless shell fails with `libnss3.so: cannot open shared object file`, extract the required `.so` files from Ubuntu `.deb` packages into `~/local-libs/lib/` and set `LD_LIBRARY_PATH`:
```bash
# One-time fix — download and extract Chrome dependencies
mkdir -p ~/local-libs && cd ~/local-libs
# Download .deb packages for libnss3, libnspr4, libasound2 from Ubuntu archive
# Extract: dpkg-deb -x package.deb extracted/
cp extracted/usr/lib/x86_64-linux-gnu/*.so* ~/local-libs/lib/
# Then render with: export LD_LIBRARY_PATH=~/local-libs/lib:$LD_LIBRARY_PATH
```

#### Step 5: Use Catalog Blocks (pre-built components)

```bash
# Browse available blocks
npx hyperframes add flash-through-white    # transition
npx hyperframes add instagram-follow       # social overlay
npx hyperframes add subscribe-button       # YouTube subscribe
npx hyperframes add data-chart             # animated chart
npx hyperframes add lower-third            # lower third template
npx hyperframes add captions               # animated captions
```

### B-Roll Templates for GameySins

Keep these templates ready in `~/.hermes/gameysins/templates/broll/`:

#### Template 1: Game Clip with Lower Third
- Gameplay footage background
- Animated lower third with game name
- @GameySins watermark
- Duration: 5-15 seconds

#### Template 2: Text Hook (for Shorts)
- Bold animated text on game background
- Bouncy caption animation synced to TTS
- 9:16 vertical format
- Duration: 3-5 seconds

#### Template 3: Transition/Wipe
- Shader transition between two clips
- Flash-through-white or glitch effect
- Duration: 0.5-1 second

#### Template 4: Outro/Subscribe CTA
- Animated subscribe button
- Social media handles
- "Next video" preview
- Duration: 5-10 seconds

#### Template 5: Stats/Comparison Overlay
- Animated bar chart or number counter
- Game stats comparison
- Voiceover-friendly timing
- Duration: 5-10 seconds

### Hyperframes + AI Agent Workflow

When the user asks for B-Roll generation:

1. **Analyze the video script/outline** — identify where B-Roll is needed
2. **List B-Roll shots needed** — with timing and description
3. **Generate Hyperframes compositions** — one HTML file per B-Roll shot
4. **Preview and iterate** — adjust timing, text, effects
5. **Batch render** — render all B-Roll clips to MP4
6. **Output file list** — provide paths to all rendered clips for the editor

### HyperFrames Prompt Format (used in script-writer-agent)

The script-writer-agent produces [VISUAL:] blocks that serve as intermediate prompts to a B-Roll agent. The B-Roll agent takes these text prompts and generates HyperFrames HTML compositions from them.

Each [VISUAL:] block has this structure:

```
[VISUAL:
SCENE: Camera shot type + subject + action + setting + lighting
DURATION: X seconds
STYLE: Intended vibe (cinematic/fast-paced/comic/sad/etc.)
TEXT OVERLAY: Arabic text content, font, colors, animation
COLORS: Color palette for the scene
OUTPUT: 1920x1080, 30fps
]
```

The B-Roll agent reads these blocks and generates the corresponding HyperFrames HTML+GSAP compositions. Each SCENE description is specific enough that the agent can select the right template, footage, text overlays, and animation timing.

See `references/hyperframes-prompt-format.md` under the script-writer-agent skill for full format details with examples.

### Batch Render Script

```bash
#!/bin/bash
# batch-render.sh — render all B-Roll compositions in a directory
for dir in ./compositions/*/; do
  echo "Rendering: $dir"
  cd "$dir"
  npx hyperframes render --output "../output/$(basename $dir).mp4"
  cd -
done
echo "All B-Roll clips rendered!"
```

---

## Workflow D — Stream Packaging

### When the user wants to prepare a Twitch stream

Generate a complete stream package:

#### 1. Stream Title Options (3-5)
- Include game name + goal/challenge
- Use urgency/excitement language
- Keep under 150 characters
- Mix Arabic and English options
- Examples structure: "[Game] — [Goal/Challenge] | [Hook]"

#### 2. Stream Description
- First line: what's happening + goal
- Include schedule info
- Social links
- Discord invite
- Relevant hashtags

#### 3. Thumbnail Concept
- Same cinematic style as video thumbnails
- Include stream goal text
- High energy, urgency
- AI image prompt ready-to-use

#### 4. Live Chat Pinned Message
- Welcome message in Arabic (Egyptian dialect)
- Stream goal/rules
- Social links
- Discord link
- Keep it concise (under 500 chars)

#### 5. Stream Energy/Style Recommendations
- Suggested pacing (when to hype, when to focus)
- Community interaction moments
- Challenge milestones to celebrate
- Clip-worthy moments to create

#### 6. Tags & SEO
- Arabic hashtags
- English hashtags
- SEO tags (comma-separated)
- Game-specific tags

---

## Workflow E — Social Media Cross-Posting

### When the user wants to promote content across platforms

For each platform, adapt the content:

#### TikTok
- Caption: Short, punchy, Arabic (Egyptian dialect)
- Hook in first line
- Hashtags: 3-5 gaming hashtags
- CTA: follow, share, comment
- Trending sound suggestion if relevant

#### Facebook
- Longer caption, storytelling style
- Arabic primary
- Question to drive engagement
- Link to full video
- Tag relevant gaming groups/pages

#### Instagram
- Caption: Medium length, personality-driven
- Mix Arabic + English
- Hashtags: 10-15 (gaming + Arabic + English)
- Story version: shorter, with poll/question sticker suggestion

#### Discord Announcement
- Ping role suggestion (@everyone or @gaming)
- Brief, exciting summary
- Link to content
- Emoji for visual pop
- Keep under 300 words

#### Community Post (YouTube)
- Poll or question to drive engagement
- Behind-the-scenes or teaser
- Arabic primary
- Keep it short and visual

---

## Workflow F — AI Image Prompt Generation

### When the user needs thumbnail or branding image prompts

#### Standard Thumbnail Prompt Structure
```
[Cinematic description], [camera angle], [lighting type], [atmosphere/color mood], 
[emotional tone], [composition details], [facial expression], [game world integration],
[protagonist: Ammar as main character integrated into game world], 
[style: cinematic, high contrast, dramatic, YouTube CTR optimized]
```

#### Nano Banana Pro Format
- Output ONLY clean prompt text
- No scene labels unless requested
- Visually descriptive and cinematic
- No markdown formatting in the prompt itself

#### Mosmar Character Prompts (mascot only)
- Include: "Mosmar mascot character, imaginary friend, small plush sidekick"
- Minimal dialogue context, punchlines only
- Same cinematic quality as main thumbnails

#### Branding/Image Prompts
- GameySins logo integration
- Gaming setup background
- Arabic text elements if needed
- Consistent color scheme: bold, high contrast

---

## Content Strategy Guidelines

### Hook Types (prioritize these)
1. **Controversial** — hot takes, unpopular opinions
2. **Emotional** — nostalgia, excitement, frustration
3. **Surprising** — unexpected facts, plot twists
4. **Curiosity-driven** — questions, cliffhangers, "what if"
5. **Urgency** — limited time, last chance, breaking news

### Retention Tactics
- Pattern interrupts every 15-30 seconds
- Curiosity gaps before cuts
- "Wait for it" moments
- Visual variety (zooms, cuts, overlays)
- Sound design (whooshes, bass drops, silence)

### Content Pillars (rotate through these)
1. Console vs PC discussions
2. Laptop vs desktop comparisons
3. Top games lists (top 5, top 10)
4. Weekly gaming news roundups
5. Funny gaming glitches and bugs
6. AI and gaming tool workflows
7. Game reviews and first impressions
8. Challenge runs and hardcore modes
9. Community highlights and fan content
10. Behind-the-scenes / setup tours

---

## Workflow Preferences

### Code & Technical Outputs
- Always provide FULL code files, never partial snippets
- Copy-paste-ready format
- Beginner-friendly explanations
- Step-by-step instructions
- Include installation commands when needed
- Avoid unnecessary jargon
- One-click solutions preferred

### Communication with Ammar
- **All conversation with Ammar is in English.** Arabic is only used in content deliverables (scripts, titles, descriptions, tags, thumbnail text) for the GameySins audience. Never greet, explain, chat, or plan in Arabic.
- This preference applies globally across all skills — not just content creation. Arabic = output content only.

### Response Format
- Organized with clear sections
- Direct and action-oriented
- No unnecessary filler
- Ranked options with brief tradeoffs when multiple approaches exist
- Date format: date-only, NO weekdays (avoids date/day mismatch)
- Optimized for execution speed

### What NOT to Do
- No overly complicated technical explanations
- No slow workflows
- No generic advice
- No unnecessary filler
- No partial code replacements
- No robotic phrasing in Arabic content
- No long boring intros
- No slow pacing
- No over-explaining obvious gaming topics

Present everything in a clean, copy-paste-ready block:

```
📹 TITLE OPTIONS:
1. [Title A]
2. [Title B]
3. [Title C]

📝 DESCRIPTION:
[Full description]

🏷️ TAGS:
Arabic: [hashtags]
English: [hashtags]
SEO: [comma-separated tags]

🖼️ THUMBNAIL:
Concept: [description]
AI Prompt: [ready-to-use prompt — COMPLETE with all variables filled in]

🎬 B-ROLL SHOTS:
1. [Shot description] — [timing] — [template to use]
2. [Shot description] — [timing] — [template to use]

✂️ SHORTS NOTES: (if applicable)
Hook: [first 2 seconds]
Outline: [talking points]
Editing: [notes]
On-screen text: [suggestions]
```

## Tips

- Always prioritize Arabic content with Egyptian dialect flavor
- Keep titles punchy and curiosity-driven
- Thumbnails should work at mobile size (small = bold)
- For Shorts, the hook is everything — spend most effort there
- Use Mosmar character references when it fits naturally
- B-Roll should enhance, not distract — keep overlays clean
- **Google Flow automation is blocked** — Google blocks Playwright browsers. Generate complete prompts manually for the user to paste into Google Flow.
- **Hyperframes compositions are deterministic** — same input = same output every time
- **Hyperframes GSAP rules** — always use `gsap.timeline({ paused: true })`, register on `window.__timelines[id]`, expose `window.__hf = { duration, seek }`, never use `repeat: -1` or `Math.random()`, use position parameters not delays
- **GameySins B-Roll color theme** — STRICT: only neon red `#ff0040` + neon blue `#00d4ff` + black `#050508` + white. NEVER use green, purple, orange, amber, or soft red. See `references/hyperframes-template.md` for full color spec.
- **Font: Cairo (Arabic) + Rubik (English)** — Arabic-first content. User rejected Orbitron, Rajdhani, Chakra Petch. See `references/hyperframes-template.md` for full font spec and banned fonts list.
- **Font sizes must be LARGE** — main titles 100-110px, Arabic titles 44-48px, subtitles 36-44px, body 28-36px. User explicitly complained text was too small multiple times. See `references/hyperframes-template.md`.
- **Video composition: 3 layers minimum** — background (grid, corners), midground (content), foreground (watermark, accents). 8-10 visual elements per scene. See `references/hyperframes-template.md` for full composition rules.
- **Use `fromTo` not `from`** — `gsap.from()` uses `immediateRender: true` which causes elements to flash/skip in deterministic capture. Always use `tl.fromTo()`.
- **Use `hyperframes preview`** before rendering to save time
- **Keep a library of reusable B-Roll templates** for consistency

## Workflow G — YouTube API OAuth Setup (One-Time)

### When the user needs to set up or refresh YouTube API access

#### Prerequisites
- Google Cloud project with YouTube Data API v3 enabled
- OAuth consent screen configured (Testing mode with user as tester, or Published)
- Desktop OAuth client ID created

#### Step-by-Step OAuth Flow (WSL2 + Windows Browser)

**⚠️ CRITICAL: Do NOT use `run_local_server()`** — WSL2 causes `MismatchingStateError` due to localhost redirect issues between Windows browser and WSL server.

**Correct approach — OOB (out-of-band) or Localhost Redirect:**

1. **Save credentials** to `~/.hermes/youtube_credentials.json`:
   ```json
   {
     "installed": {
       "client_id": "<CLIENT_ID>.apps.googleusercontent.com",
       "client_secret": "<CLIENT_SECRET>",
       "auth_uri": "https://accounts.google.com/o/oauth2/auth",
       "token_uri": "https://oauth2.googleapis.com/token",
       "redirect_uris": ["http://localhost"]
     }
   }
   ```

2. **Generate auth URL** (run in WSL):
   Try OOB (`urn:ietf:wg:oauth2.0:oob`) first. If Google blocks this flow (common in newer apps), use `http://localhost` as the `redirect_uri`.

   ```python
   import sys; sys.path.insert(0, str(Path.home() / ".local/lib/python3.12/site-packages"))
   from google_auth_oauthlib.flow import InstalledAppFlow
   cfg = json.load(open(Path.home() / ".hermes/youtube_credentials.json"))["installed"]
   # Toggle between "urn:ietf:wg:oauth2.0:oob" and "http://localhost"
   cfg["redirect_uris"] = ["http://localhost"]
   flow = InstalledAppFlow.from_client_config({"installed": cfg}, [
       "https://www.googleapis.com/auth/youtube",
       "https://www.googleapis.com/auth/youtube.upload",
       "https://www.googleapis.com/auth/youtube.readonly",
   ])
   url, state = flow.authorization_url(prompt="consent", access_type="offline")
   # Save state for step 2
   import base64, pickle
   data = {"state": state, "client_config": cfg}
   with open(Path.home() / ".hermes/oauth_data.b64", "w") as f:
       f.write(base64.b64encode(pickle.dumps(data)).decode())
   print(url)
   ```

3. **Send URL to user** — they open it in Windows browser

4. **User authorizes**:
   - If OOB: Google shows an authorization code → user copies it.
   - If Localhost: Browser redirects to a "failed" page (localhost) → user copies the `code` parameter from the address bar.

5. **Exchange code for token** (run in WSL):
   ```python
   import sys, base64, pickle, json
   sys.path.insert(0, str(Path.home() / ".local/lib/python3.12/site-packages"))
   from google_auth_oauthlib.flow import InstalledAppFlow
   data = pickle.loads(base64.b64decode(open(Path.home() / ".hermes/oauth_data.b64").read()))
   flow = InstalledAppFlow.from_client_config({"installed": data["client_config"]}, [
       "https://www.googleapis.com/auth/youtube",
       "https://www.googleapis.com/auth/youtube.upload",
       "https://www.googleapis.com/auth/youtube.readonly",
   ])
   flow.fetch_token(code="<USER_PASTED_CODE>")
   with open(Path.home() / ".hermes/youtube_token.json", "w") as f:
       f.write(flow.credentials.to_json())
   ```

6. **Verify** by running `/usr/bin/python3 ~/.hermes/youtube_api.py`

#### Common OAuth Errors

| Error | Cause | Fix |
|---|---|---|
| `Error 403: access_denied` | App in Testing mode, user not added as tester | Add user as tester in Google Cloud Console → OAuth consent screen → Test users |
| `Error 400: invalid_scope` | Typo in scope URLs (e.g. `auth/auth/youtube`) | Use exact scopes listed above |
| `MismatchingStateError` | Using `run_local_server()` with WSL2 | Switch to OOB flow |
| `Address already in use` | Port 8080 occupied by previous failed attempt | `lsof -ti:8080 \| xargs kill -9` |
| `could not locate runnable browser` | WSL has no browser | Use OOB flow or `open_browser=False` with manual URL |
| `Error 400: invalid_request / Missing required parameter: redirect_uri` | `google_auth_oauthlib` omits `redirect_uri` from auth URL | **Build URL manually.** Construct the auth URL with explicit `redirect_uri=http://localhost` using `urllib.parse.urlencode`, passing `client_id`, `scope`, `state`, `code_challenge`, `response_type=code`, `prompt=consent`, `access_type=offline`. Save `code_verifier` for later. Exchange code via POST to `https://oauth2.googleapis.com/token` with `grant_type=authorization_code`, `code`, `client_id`, `client_secret`, `redirect_uri`, `code_verifier`. Then add `client_id` and `client_secret` to the saved token JSON before using it with `Credentials.from_authorized_user_file()`. |
| App shows "test" name | Default OAuth consent screen not updated | Update app name in OAuth consent screen settings |

---

## Reference Files

- **`references/channel-reference.md`** — Social links, SEO quick ref, Mosmar character, PC specs, automation pipeline
- **`references/wsl-environment.md`** — WSL-Windows hybrid setup, symlink patterns, package install notes
- **`references/hyperframes-template.md`** — Complete working HTML template, color scheme, animation patterns, render commands, lint error reference
- **`references/thumbnail-prompt-system.md`** — Master thumbnail prompt template, emotion guide, game scenes, content type composition mapping
- **`references/google-flow-automation.md`** — Google Flow status (blocked), alternative methods, archived automation docs
