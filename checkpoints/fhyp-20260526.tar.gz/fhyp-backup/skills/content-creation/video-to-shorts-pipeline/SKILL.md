---
name: video-to-shorts-pipeline
description: Build local AI-powered pipelines that convert long-form videos into viral short-form clips (9:16) with smart reframe, word-level captions, and hardware-accelerated export.
trigger: When the user wants to clip long videos into shorts, build a video-to-shorts pipeline, add captions/reframe to existing videos, or process video with local AI (Whisper, LLM, OpenCV, ffmpeg).
---

# Video-to-Shorts Pipeline

A fully local pipeline: download → transcribe (Whisper GPU) → scene detect → engagement AI (local LLM) → smart reframe (face tracking) → viral typography → export (NVENC).

## Architecture

```
Video URL (YouTube/X/FB)
      │
      ▼
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│ 1. DOWNLOAD │────→│ 2. TRANSCRIBE │────→│ 3. SCENE DETECT  │
│   yt-dlp    │     │ faster-whisper │     │  PySceneDetect  │
└─────────────┘     └──────────────┘     └─────────────────┘
                                                │
┌────────────────┐     ┌──────────────┐     ┌──┴──────────────┐
│ 7. COMPOSITION │←────│ 6. TYPOGRAPHY │←────│ 4. ENGAGEMENT AI │
│  ffmpeg NVENC  │     │  ASS subtitles│     │   Local LLM     │
└────────────────┘     └──────────────┘     └─────────────────┘
         ▲                                        │
         └────────────────────────────────────────┘
                    ┌──────────────────┐
                    │ 5. SMART REFRAME │
                    │ OpenCV tracking  │
                    └──────────────────┘
```

## Stage-by-Stage Guide

### 1. Download
- Use `yt-dlp` for all platforms (YouTube, X/Twitter, Facebook, TikTok, etc.)
- Download best quality ≤1080p, merge to MP4
- Extract audio as 16kHz mono WAV for Whisper

### 2. Transcribe (faster-whisper)
- Load model on GPU with `int8_float16` compute type
- Enable `word_timestamps=True` — critical for caption sync
- Enable `vad_filter=True` to skip silence
- **GPU requirement**: Install `nvidia-cuda-toolkit` in WSL for `libcublas.so.12` or Whisper falls back to CPU
- **WSL CUDA check**: `python -c "import ctranslate2; print(ctranslate2.get_cuda_device_count())"` should return 1

### 3. Scene Detection
- Use `scenedetect` with `ContentDetector`
- Sensitivity ~27.0; min scene length 2s
- Scene boundaries help the LLM pick natural cut points

### 4. Engagement AI
- Send transcript + scene list to local LLM via LM Studio / Ollama
- **CRITICAL**: Reasoning models (Qwen 3.5, Gemma 4 E2B) output thinking in `reasoning_content` with empty `content`
- Parser must extract JSON from `reasoning_content`, not just `content`
- Use multiple extraction strategies: code blocks, `[...]` arrays, regex on reasoning prose
- Let clip lengths vary naturally (5s punchlines to 90s stories)

### 5. Smart Reframe (9:16)
- Landscape-to-portrait crop: `crop_w = src_h * (9/16)`, keep full height
- Sample 30 frames across clip, detect faces with OpenCV Haar cascade
- Compute stable crop center from face positions:
  - If subject moves a lot (std dev > 0.12), fall back to center-crop
  - If face near edge, nudge crop inward with safe margin (0.18)
  - Otherwise track median face position
- Scale exact to 1080×1920 with `lanczos`, set `setsar=1:1`

### 6. Viral Typography
- **NEVER pre-render PNG frames with Pillow** — generates hundreds of frames per short, impossibly slow
- **Use ASS subtitle files** rendered by ffmpeg's `subtitles` filter:
  - Define styles: Default (white), Gray (dimmed future words), Highlight (yellow + bigger current word)
  - Each word gets timed Dialogue lines with `\r` style overrides
  - ffmpeg burns ASS in real-time during final encode — zero pre-rendering
- Arabic support: Use Windows fonts (`/mnt/c/Windows/Fonts/tahoma.ttf`), apply `arabic-reshaper` + `python-bidi`

### 7. Composition & Export
- ffmpeg overlay subtitles onto reframe video
- **NVENC encoding**: `-c:v h264_nvenc -preset p1 -b:v 8M`
- Output: exact 1080×1920, 30fps, yuv420p, faststart for streaming

## Critical Pitfalls

### WSL D: Drive Write Issues
**Problem**: ffmpeg and other tools get "Permission denied" writing directly to `/mnt/d/`.
**Fix**: Write to local temp (`~/cliply/temp/`), then `shutil.move()` to D: drive.

### Reasoning Model JSON Parsing
**Problem**: Models like Qwen 3.5 and Gemma 4 E2B return empty `content`, all output in `reasoning_content`.
**Fix**: Combine `reasoning + content`, then parse with layered strategies:
1. JSON code blocks (reversed, last first)
2. Direct JSON parse
3. `[...]` array extraction (last match first)
4. Regex on reasoning prose for "Selection/Moment/Clip" patterns
5. Start/end timestamp regex fallback

### ASS Path Escaping for ffmpeg
**Problem**: ffmpeg subtitles filter fails with Windows-style paths.
**Fix**: Use forward slashes, escape colons: `path.replace("\\", "/").replace(":", "\\:")`

## Project Structure

```
~/cliply/
├── cliply.py              # CLI orchestrator
├── requirements.txt
└── stages/
    ├── config.py          # Settings, paths, API config
    ├── downloader.py      # yt-dlp wrapper
    ├── transcriber.py     # faster-whisper GPU/CPU
    ├── scene_detector.py  # PySceneDetect
    ├── engagement_ai.py   # Local LLM viral analysis
    ├── reframer.py        # OpenCV face tracking → 9:16
    ├── typography.py      # ASS subtitle generation
    └── composer.py        # ffmpeg NVENC export
```

## Dependencies

```
faster-whisper>=1.0.0
opencv-python>=4.8.0
scenedetect>=0.6.0
requests>=2.31.0
moviepy>=2.0.0
Pillow>=10.0.0
numpy>=1.24.0
arabic-reshaper>=3.0.0
python-bidi>=0.4.0
```

Plus system tools: `yt-dlp`, `ffmpeg` (with NVENC), `nvidia-cuda-toolkit` (WSL).

## Usage

```bash
python cliply.py "https://youtube.com/watch?v=..." --count 3
python cliply.py "URL" --count 5 --keep-temp
```

## References

- See `references/wsl-gpu-setup.md` for WSL CUDA / D: drive specifics.
- See `references/reasoning-model-parsing.md` for LLM output extraction patterns.
