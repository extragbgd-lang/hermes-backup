# WSL GPU Setup for Local Video Processing

## Environment
- WSL2 on Windows
- NVIDIA GPU (RTX 3050 6GB in this case)
- CUDA drivers mounted at `/usr/lib/wsl/lib/`

## CUDA Toolkit for faster-whisper GPU

faster-whisper uses CTranslate2 which needs `libcublas.so.12`. The WSL GPU driver mount provides `libcuda.so` but NOT the full CUDA toolkit libraries.

### Install
```bash
sudo apt update
sudo apt install nvidia-cuda-toolkit
```

### Verify
```bash
python3 -c "import ctranslate2; print('CUDA devices:', ctranslate2.get_cuda_device_count())"
# Should print: CUDA devices: 1
```

### Verify faster-whisper GPU
```bash
python3 -c "
from faster_whisper import WhisperModel
model = WhisperModel('base', device='cuda', compute_type='int8_float16')
print('GPU Whisper loaded')
"
```

## WSL D: Drive Write Pattern

### Problem
ffmpeg and other tools fail with "Permission denied" writing directly to `/mnt/d/...` through WSL's 9P filesystem.

### Solution: Temp-then-Move
```python
import tempfile
import shutil

# Write to local temp first
temp_out = tempfile.mktemp(suffix=".mp4", dir=os.path.expanduser("~/cliply/temp"))
cmd = ["ffmpeg", "-i", input_path, "...", temp_out]
subprocess.run(cmd)

# Then move to D: drive
shutil.move(temp_out, "/mnt/d/output/final.mp4")
```

This avoids the 9P permission issue entirely.

## ffmpeg NVENC Availability Check

```bash
ffmpeg -hide_banner -encoders | grep nvenc
# Should show: h264_nvenc, hevc_nvenc, av1_nvenc
```

If missing, install from https://www.gyan.dev/ffmpeg/builds/ (Windows) or use apt ffmpeg (usually has NVENC on Ubuntu).
