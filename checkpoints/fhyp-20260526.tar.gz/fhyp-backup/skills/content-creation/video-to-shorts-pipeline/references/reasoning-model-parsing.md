# Parsing JSON from Reasoning Models (LM Studio)

## The Problem

Models like **Qwen 3.5** and **Gemma 4 E2B** (reasoning variants) output their thinking process in `reasoning_content` and leave `content` empty. The actual structured answer is buried inside the reasoning text.

Example LM Studio response:
```json
{
  "choices": [{
    "message": {
      "content": "",
      "reasoning_content": "Thinking Process:\n1. Analyze the request...\n5. Format output: [{\"start\": 45, ...}]"
    }
  }],
  "usage": {
    "completion_tokens_details": {"reasoning_tokens": 397}
  }
}
```

## The Fix: Layered Extraction

Combine `reasoning + content`, then try strategies in order (most specific first):

```python
def parse_response(text: str) -> List[Dict]:
    if not text or not text.strip():
        return []

    # 1. JSON code blocks (last occurrence first)
    code_blocks = re.findall(r'```(?:json)?\n([\s\S]*?)\n```', text)
    for block in reversed(code_blocks):
        try:
            data = json.loads(block.strip())
            if isinstance(data, list):
                return data
        except Exception:
            pass

    # 2. Direct JSON parse
    for prefix, suffix in [("", ""), ("```json\n", ""), ("", "\n```")]:
        try:
            data = json.loads(prefix + text.strip() + suffix)
            if isinstance(data, list):
                return data
        except Exception:
            pass

    # 3. Find [...] arrays — try LAST match first
    matches = re.findall(r'\[[\s\S]*?\]', text)
    for match in reversed(matches):
        try:
            data = json.loads(match)
            if isinstance(data, list) and len(data) > 0:
                return data
        except json.JSONDecodeError:
            pass

    # 4. Extract individual JSON objects with "start" key
    blocks = re.findall(r'\{[\s\S]*?"start"[\s\S]*?\}', text)
    if blocks:
        try:
            json_text = "[" + ",".join(blocks) + "]"
            data = json.loads(json_text)
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass

    # 5. Parse reasoning prose for structured selections
    # "Selection A: [0:05] - Strong reaction hook."
    # "Clip 1: Start 5, End ~15"
    clips = []
    for m in re.finditer(
        r'(?:Selection|Moment|Clip|Option)\s*[A-Za-z0-9]*[:)\]]?\s*'
        r'(?:\[?\s*)([0-9]+[.:][0-9]+)(?:\s*\])?'
        r'[\s\-–—]+(.+?)(?=\n(?:Selection|Moment|Clip|Option)|\Z)',
        text, re.IGNORECASE | re.DOTALL
    ):
        ts_str = m.group(1)
        reason = m.group(2).strip()
        # Parse timestamp, build clip dict...

    # 6. Final: regex extract start/end timestamps
    for m in re.finditer(r'\{\s*"start"\s*:\s*([0-9.]+)\s*,\s*"end"\s*:\s*([0-9.]+)', text):
        clips.append({"start": float(m.group(1)), "end": float(m.group(2)), "hook": "Viral Clip", "score": 5})

    return clips
```

## Best Practice

If possible, load a **non-reasoning model** in LM Studio (e.g., regular Qwen 2.5, Llama 3.1, Mistral). These models output clean JSON in `content` directly, eliminating the parsing problem entirely.

Reasoning models are great for chat but terrible for structured API responses.
