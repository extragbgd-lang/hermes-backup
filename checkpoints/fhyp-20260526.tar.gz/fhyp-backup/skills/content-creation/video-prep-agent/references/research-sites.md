# Trend Research Sites for GameySins Video Ideation

## Order of Operations

Start with IGN for broad headlines, then PC Gamer for PC-specific news,
then Google Trends for search volume (often empty — skip if so),
then Steam pages for game-specific data (sales, DLC, review scores).

## 1. IGN News

**URL:** https://www.ign.com/news
**What to look for:**
- "Trending News" section — top story of the moment
- "Popular Stories" (#1 through #5) — note comment counts (100+ = viral topic)
- Scroll down for "Latest News" with timestamps
- Check tabs: PlayStation, PC, Tech for game-specific news

## 2. PC Gamer News

**URL:** https://www.pcgamer.com/news/
**What to look for:**
- "Editor's Picks" section
- "LATEST NEWS" section
- Popular sidebar topics (Clips, Subnautica 2, Memorial Day deals, etc.)

## 3. Google Trends (often empty — skip if so)

**URL (gaming category):** https://trends.google.com/trending?geo=US&category=8
**How to use:**
1. Click "Got it" to dismiss cookie banner
2. Check "Trending Now" tab for any gaming-related trends
3. Switch to "Explore" tab
4. Search for each of Ammar's games:
   - Once Human
   - Myth of Empires
   - Dying Light 2
   - Where Winds Meet
5. Note interest-over-time chart and related queries

**⚠️ Known limitation:** The "Hobbies and Leisure" (gaming) category
frequently returns no trending data. Do not waste time refreshing.
If empty, move on to Steam pages immediately.

**⚠️ Google News search blocks automation:** Direct Google News
searches (tbm=nws) trigger a CAPTCHA/sorry page. Do not use.

## 4. Steam Pages

- **Once Human:** https://store.steampowered.com/app/2139460/Once_Human/
- **Myth of Empires:** https://store.steampowered.com/app/1371580/Myth_of_Empires/
- **Dying Light 2:** https://store.steampowered.com/app/534380/Dying_Light_2_Stay_Human_Reloaded_Edition/

**Check these data points on each store page:**

| Signal | What to Look For | Why It Matters |
|--------|-----------------|----------------|
| Review score + count | "Very Positive (3,476)" or "Mostly Positive (900)" | High count = active community = search demand |
| Sale event badge | "70% OFF", "Part of a sale event" banner near top | Strong "why now" hook — limited time urgency |
| New DLC/expansion | Banner or text like "Xizhou Civilization Pack now released!" | Fresh content = fresh video angle |
| Recent reviews trend | Recent vs overall score comparison | Improving/worsening sentiment = discussion hook |

## 5. Ammar's Games (for reference when mapping ideas)

- **Once Human** — multiplayer open-world survival, free-to-play, on Steam
- **Myth of Empires** — sandbox survival PvP/PvE, on Steam
- **Dying Light 2** — zombie parkour action RPG
- **Where Winds Meet** — open-world wuxia action RPG (PS5 + PC, August 2026)

## Output Format Notes

After research, synthesize findings into ideas.
Keep idea titles in English for CLI readability.
