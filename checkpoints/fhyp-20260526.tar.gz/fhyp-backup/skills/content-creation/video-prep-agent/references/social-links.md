# GameSins Social Links — MUST be in EVERY video description

Always include this block in every YouTube/Short description. Never leave it as a placeholder or omit it.

```
📌 تابعني على:
YouTube: https://www.youtube.com/@Gameysins
Twitch: https://www.twitch.tv/gameysins
TikTok: https://www.tiktok.com/@gameysins7
Instagram: https://www.instagram.com/gameysins/
Discord: https://discord.gg/ty8qXXpcMT
Facebook: https://www.facebook.com/profile.php?id=61587385348813
```

## Emails
- Business contact: gameysins@gmail.com
- Google account for YouTube: gamerdaddyreveiw@gmail.com

## Rule
This block MUST be the last thing before hashtags in every description. If space is tight (TikTok, Shorts), use top 3 links + "📌 باقي اللينكات في البايو".
