# GameySins Channel Profile (May 2026)

## Basic Info
- **Handle:** @GameySins
- **Videos:** 37 total
- **Language:** Arabic, Egyptian dialect (مصري عامية)
- **Style:** Discussion / opinion with gameplay B-roll
- **Format:** 5-10 minutes per video
- **Channel description:** "مرحبًا بكم في GameySins — وجهتك الأولى لعالم الألعاب في 2026 🎮"
- **Links:** discord.gg/uN6rjpCJ
- **Character:** Mosmar (childhood gaming companion)

## Recent Video Performance (sorted newest first)

| # | Title | Views | Age | Duration |
|---|-------|-------|-----|----------|
| 1 | الألعاب مش مجرد لعب… ودي الحقيقة | 16 | 6 days | 5:36 |
| 2 | من كابتن ماجد لـ Uncharted.. رحلتي مع أفضل الألعاب ❤️ (originally: الألعاب دي صنعت طفولتي وإدماني للجيمنج 🔥) | 56 | 13 days | 8:06 |
| 3 | ألعاب موبايل تسحبك بالساعات بدل ما تتمرمط في السوشيال | 44 | 2 weeks | 6:22 |
| 4 | ألعاب موبايل تنافس الكونسول فعلاً؟ شوف بنفسك! | **136** ⭐ | 1 month | 8:18 |
| 5 | ألعاب PC مجانية خطيرة الجودة تنافس الألعاب المدفوعة | 24 | 1 month | 10:19 |
| 6 | GTA 5 \| هل فعلاً تستحق تلعبها في 2026؟ | 21 | 3 months | 8:12 |
| 7 | GTA 5 \| عصابه الضحك | (older) | — | 6:39 |

## Key Insights

### What Works (based on data)
- **Comparisons** — "Mobile vs Console" got the most views (136). Contrast/direct comparison videos outperform.
- **Nostalgia/Personal Stories** — Gaming childhood memories (56 views). Personal angle connects.
- **Arabic-Egyptian hook titles** — All top videos use Egyptian street-language titles, not formal Arabic.
- **5-8 min range** — Shortest videos (5:36, 6:22) match attention span better than 10+ min.

### What Doesn't
- **Overly broad topics** — "الألعاب مش مجرد لعب" (16 views) is philosophical, too vague.
- **PC free games list** (24 views) — generic lists underperform.
- **GTA 5 content** (21 views) — dated game, low interest unless tied to GTA 6 news.

### Audience Profile
- Small but engaged (comment sections exist based on channel activity)
- Arabic-speaking MENA gamers who understand Egyptian dialect
- Likely mobile-first or console-first gamers
- Interested in: what to play, what's worth it, comparisons, free options
- Not interested in: formal reviews, heavily edited content, English-language content

## Recommended Content Strategy
1. **Comparison videos** — X vs Y format (mobile vs console, free vs paid, PC vs PS5)
2. **"Is it worth it?"** videos — review with strong opinion angle
3. **Nostalgia/personal journey** — "my journey with X game" or "how I got into gaming"
4. **Free-to-play recommendations** — aligns with budget-conscious MENA audience
5. **News + Opinion** — gaming news explained in Egyptian dialect with personal take

## Games Ammar Actually Plays
- Once Human (PC)
- Myth of Empires (PC)
- Dying Light 2 (PC)
- Where Winds Meet (PS5)

Always prioritise content about these games — footage is already available and interest is genuine.
