---
name: video-prep-agent
description: Fully autonomous video preparation agent for GameySins. Researches gaming trends, knows the channel, generates video ideas, then produces the full package — script, titles, description, tags, thumbnail prompt, b-roll specs, and kanban pipeline tasks.
trigger_conditions:
  - User says "prepare my next video"
  - User says "prep the next video"
  - User says "come up with video ideas"
  - User says "I want to make a video about..."
  - User says "run the video prep agent"
  - User says "build a daily research agent" or "morning notification" or "research agent"
  - User wants a complete video package from idea to publish-ready
  - User wants video ideas or content suggestions
  - User wants a recurring daily opportunity alert
---

# Video Prep Agent — GameySins

## How to Call

Just say:
> "prepare my next video"
> "come up with video ideas"
> "run the prep agent"
> "set up the daily research agent"

## GameySins Channel Profile (May 2026)

Before any research, internalise this channel context:

| Data | Value |
|------|-------|
| @handle | GameySins |
| Videos | 37 total |
| Language | Arabic, Egyptian dialect |
| Format | 5-10 min discussion/opinion with gameplay B-roll |
| Recent avg views | 16-136 per video |
| Best performer | Mobile vs console comparison (136 views) |
| Content topics | Mobile gaming, PC free games, GTA 5, gaming nostalgia, Once Human, Myth of Empires, Dying Light 2, Where Winds Meet |
| Channel description | "مرحبًا بكم في GameySins — وجهتك الأولى لعالم الألعاب في 2026 🎮" |
| Character | Mosmar (childhood gaming companion, minimal dialogue) |
| Stage | Small channel building from scratch |

Top content types that work: comparisons (mobile vs console), list/review videos, opinion/discussion pieces. The channel does NOT yet do tutorials, guides, or heavily edited content — keep recommendations achievable with basic editing.

## Workflow

## Workflow A — One-Shot Video Ideation (user asks for ideas now)

### Step 0: Trend Research (MANDATORY — always run)

ALWAYS do this step. Even if the user specified a topic, the trend research validates and refines the idea.

#### Research METHOD (do NOT delegate — use browser_navigate visibly)

The user must SEE the research happening. Do NOT use delegate_task or subagents for this. Use the browser tool directly with browser_navigate. This is non-negotiable — the user explicitly called this out.

**Sites to visit (in order):**

1. **IGN News** → `https://www.ign.com/news`
   - Check "Trending News" and "Popular Stories" sections
   - Note: headlines, comment counts (high comments = high engagement)

2. **PC Gamer News** → `https://www.pcgamer.com/news/`
   - Check "Editor's Picks" and "LATEST NEWS"
   - Note: game-specific news, industry trends

3. **Steam Pages** — check the games Ammar plays:
   - Once Human: `https://store.steampowered.com/app/2139460/Once_Human/`
   - Myth of Empires: `https://store.steampowered.com/app/1371580/Myth_of_Empires/` — also check if Xizhou Civilization Pack is still featured
   - Dying Light 2: `https://store.steampowered.com/app/534380/Dying_Light_2_Stay_Human_Reloaded_Edition/`
   - **Check these data points on each store page:**
     - Recent review score + count (e.g. "Very Positive (3,476)") — high count = active community
     - Sale events / discount badges ("70% OFF", "Part of a sale event" banners) — **sales are the strongest "why now" hook**
     - New DLC or expansion announcements (e.g. "Xizhou Civilization Pack is now officially released!")
     - Community Hub for recent discussion/update announcements

4. **Synthesize** — pick 3-5 real trends that fit:
   - GameySins channel: Arabic gamers, Egyptian dialect
   - Games Ammar plays: Once Human, Myth of Empires, Dying Light 2, Where Winds Meet
   - Content types: tutorials, reviews, funny moments, discussions, reactions, Shorts, compilations
   - Character: Mosmar

**Output:** 5-10 video ideas, each with:
- Game/topic, format, why-now hook, effort level, potential rating
- Every idea must tie to a REAL trend/news item found — no filler

#### CLI Output Rules (critical — no broken RTL rendering)

Terminals reverse bi-directional text when Arabic and English share a line. Follow these rules:
- **Video idea titles: English only** — use descriptive English titles (e.g. "Once Human 2026 Review: Still Worth Playing?")
- **Arabic content** goes in the script body (Step 3), delivered as a separate block
- **Do NOT write:** "💡 شرح لعبة Where Winds Meet بالعامية" — this breaks in the terminal
- **Do write:** "💡 Where Winds Meet PS5 Review — Full Guide in Egyptian Arabic"
- Hashtags and tags: safe to mix since they're single tokens per line

### Step 1: Quick Intake (if user provides own topic)

Only if the user already specified a topic. Ask minimal questions:
1. What format? (review, tutorial, funny moments, etc.)
2. Any specific angle or hook?
3. Length preference?

### Step 2: Research (Quick)

If it's a game I don't know well, do brief research:
- Game genre, recent updates, what's trending about it
- Keep it 2-3 bullet points max

### Step 3: Write Script (Arabic, Egyptian Dialect)

Full script with:
- **Hook** — first 5-10 seconds, Egyptian Arabic, attention-grabbing
- **Body** — main content, conversational flow
- **Outro** — CTA (subscribe, like, comment, next video tease)

Script rules:
- Egyptian dialect (مصري عامية), NOT MSA (فصحى)
- Mosmar character reference if it fits naturally
- Mark [B-ROLL] where visual overlays go
- Mark [TTS] where Arabic TTS is needed
- Short sentences, conversational
- Time markers every 30 seconds

### Step 4: YouTube Package

Using youtube-packaging conventions:
- **Titles** — 3-5 options (Arabic, click-worthy, under 60 chars)
- **Description** — hook-first, keyword-rich, timestamps, CTA, **then the full social links block (MANDATORY — never skip):**
  ```
  📌 تابعني على:
  YouTube: https://www.youtube.com/@Gameysins
  Twitch: https://www.twitch.tv/gameysins
  TikTok: https://www.tiktok.com/@gameysins7
  Instagram: https://www.instagram.com/gameysins/
  Discord: https://discord.gg/ty8qXXpcMT
  Facebook: https://www.facebook.com/profile.php?id=61587385348813
  ```
- **Tags** — Arabic hashtags, English hashtags, SEO comma-separated

### Step 5: Thumbnail Prompt

Complete prompt for Google Flow (Nano Banana Pro):
- ALL variables filled — ready to paste
- Character left third, text right, game background, high contrast
- Use "Using reference image of Ammar" — never describe his appearance
- Emotion, game scene, Arabic text all filled in

### Step 6: B-Roll Specs

Refer to the `hyperframes-broll` skill for full pipeline details. Per script section, list visual overlays:

**Section Intros** (auto-classified):
- Comparison, opener, gameplay, stats, or outro
- Colors: #ff0040 + #00d4ff + #050508 only
- Fonts: Cairo (Arabic) 90-100px, Rubik (Latin) 36-40px
- Landscape 1920×1080 (16:9) for long-form videos

**Presentation Scenes** (kinetic typography):
- Use when script sections have multiple talking points to reinforce visually
- Each bullet point animates in sequentially (every 2.8s)
- Gaming terms auto-highlight in neon red/blue
- Duration: 12s+ depending on bullet count
- Write as `## Title` + `- bullet` per point
- Always in Egyptian Arabic

### Step 7: Kanban Pipeline

Create tasks on gameysins board with linked dependencies:
```
planning → scripting → recording → editing → publishing → shorts
```

---

## Workflow B — Daily MENA Research Agent (Cron Job Pattern)

### When to use this

The user wants a **daily morning notification** with the single best video opportunity for GameySins. Set this up as a cron job that runs every morning, delivers to origin.

### Cron Job Setup

```bash
hermes cron create \
  --name "gameysins-daily-mena-research" \
  --schedule "0 8 * * *" \               # 8AM Oman time (UTC+4)
  --toolsets "web,terminal,file" \
  --deliver "origin" \
  --prompt "See Daily Research Agent prompt below"
```

**Key flags:**
- `--deliver` — see "Delivery Target" section below for platform-specific values
- `--toolsets web,terminal,file` — needs web browsing for research, terminal/file for Steam checks
- `--schedule "0 8 * * *"` — every day at 8AM. Oman is UTC+4.

**⚠️ CRITICAL: Do NOT use `--skills` in cron jobs.**
Loading video-prep-agent or youtube-packaging in a cron job causes the interactive workflow to fire — the agent wastes API calls on script writing, kanban tasks, and terminal commands that get blocked by security guardrails. Instead, embed ALL channel context and research instructions directly in the `--prompt` field (see Sample Prompt below). Keep the cron prompt self-contained.

### MENA-Specific Research Filters

When researching for the Arabic/MENA gaming audience, apply these filters:

**Prioritise (MENA audience):**
- **PlayStation news** — PS is dominant in MENA. Check IGN PlayStation tab.
- **Free-to-play games** — huge traction with Arabic audiences (Once Human, Fortnite, etc.)
- **Mobile gaming** — massive in MENA region. Mobile vs console comparisons do well.
- **Survival/crafting games** — Once Human, Myth of Empires have good MENA followings
- **Steam sales & discounts** — "free" and "sale" content always performs
- **Call of Duty / eFootball / Fortnite** — always strong in the region
- **PC building / budget gaming** — budget-friendly content resonates

**De-prioritise:**
- Nintendo-specific news (low MENA penetration for non-mobile Nintendo)
- Esports-specific deep dives (niche audience)
- Western-centric cultural references

**Source sites (in order):**
1. **IGN News** → `https://www.ign.com/news` (click PlayStation tab for PS content)
2. **PC Gamer** → `https://www.pcgamer.com/news/` (Editor's Picks)
3. **Steam pages** for Once Human, Myth of Empires, Dying Light 2 (sales = hooks)
4. **DO NOT use** Google News search — automated browsers hit CAPTCHA. Stick to IGN/PC Gamer.
5. **DO NOT use** Google Trends gaming category — frequently returns empty results.

### Channel Context (embed in agent prompt)

Every daily run must know:
- Channel is small (37 videos, 16-136 views each)
- Best content: opinion/discussion/comparison in Egyptian Arabic
- Games Ammar plays: Once Human, Myth of Empires, Dying Light 2, Where Winds Meet
- Keep it achievable — one person editing, limited time
- Prioritise FREE games and topics so there's no cost barrier
- Think "what can Ammar film and edit TODAY"

### Notification Format (concise, notification-ready)

Every daily run must output this exact format:

```
━━━ 🎮 GAMEYSINS DAILY OPPORTUNITY ━━━

🏆 TOP PICK: [Arabic video title idea]

🔥 WHY NOW: [Real trend/news found today — one sentence]

🎯 WHY FITS GAMEYSINS: [Connection to channel's content, audience, style]

💡 VIDEO IDEA: [One-sentence pitch in English for clarity, with key Arabic hook]

⏱ EFFORT: [Easy / Medium / Hard] — [brief reasoning]

📈 POTENTIAL: [Why this could outperform recent 16-136 view range]

🔗 SOURCE: [Link to the trend source]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Rules:
- CONCISE — this is a mobile notification, not a report
- Recommend ONE opportunity only — the single best
- Every recommendation must be tied to a REAL trend found that day
- If nothing strong found, say "No strong opportunity today" with brief reason
- No filler, no generic advice
- Must be actionable today — no multi-day projects
- Think as a small creator, not a big channel

### Delivery Target for Cron Jobs

The `--deliver` flag determines where the notification arrives:

| Platform | Value | Notes |
|----------|-------|-------|
| **CLI** | `origin` | Works — delivers to the terminal where the job was created |
| **Discord** | `discord:<channel_id>:<thread_id>` | "origin" does NOT work for Discord threads. Use the channel/thread IDs from the conversation where the cron job is being set up. Falls back to file save in `~/.hermes/cron/output/<job_id>/` if delivery fails. |
| **Telegram** | `telegram:<chat_id>` | Use explicit chat ID, not "origin" |
| **All platforms** | `all` | Fan-out to every connected home channel |

**When in doubt:** run `hermes cron run --job-id <JOB_ID>` and check `~/.hermes/cron/output/` for the saved output — the markdown file there always captures the agent's response even if delivery fails.

### Sample Cron Prompt (self-contained)

```text
You are the GameySins Daily Research Agent. Your job: find the #1 best video opportunity for an Arabic gaming YouTube channel and deliver a notification.

CONTEXT: @GameySins — 37 videos, 16-136 views, Arabic/Egyptian dialect discussion format. Games: Once Human, Myth of Empires, Dying Light 2, Where Winds Meet.

RESEARCH: Use browser_navigate to visit:
1. https://www.ign.com/news — trending + comment counts
2. Click "PlayStation" tab on IGN
3. https://www.pcgamer.com/news/ — Editor's Picks
4. Steam pages for Once Human, Myth of Empires, Dying Light 2 — check sales/DLC

MENA FILTER: PlayStation > F2P > mobile gaming > survival games. Skip Nintendo.

OUTPUT exactly:
━━━ 🎮 GAMEYSINS DAILY OPPORTUNITY ━━━
🏆 TOP PICK: [Arabic title]
🔥 WHY NOW: [real trend found today]
🎯 WHY FITS GAMEYSINS: [connection]
💡 IDEA: [one-sentence pitch]
⏱ EFFORT: Easy / Medium / Hard
📈 POTENTIAL: [why beats ~50 avg views]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Rules: ONE pick only, real trend, concise, actionable today, prioritize free topics.
```

### Testing the Cron Job

After creating, always run a test:

```bash
hermes cron run --job-id <JOB_ID>
# Check output if delivery fails:
ls ~/.hermes/cron/output/<JOB_ID>/
hermes cron list  # verify next_run_at is correct
```

## Response Format

```
━━━ VIDEO PACKAGE — [GAME/TOPIC] ━━━

📜 SCRIPT:
...

📹 TITLES:
1. ...
2. ...
3. ...

📝 DESCRIPTION:
...

🏷️ TAGS:
Arabic: ...
English: ...
SEO: ...

🖼️ THUMBNAIL PROMPT:
...

🎬 B-ROLL SHOTS:
1. ...
2. ...

📋 KANBAN TASKS:
...
```

## Style Rules (Non-Negotiable)

- Colors: ONLY #ff0040 + #00d4ff + #050508 + white
- Fonts: Cairo (Arabic), Rubik (English)
- Titles 100-110px, subtitles 44-48px, body 28-32px
- 3 layers minimum in compositions
- Use fromTo not from in GSAP
- Arabic-first, Egyptian dialect

## Communication with Ammar

- **All conversation with Ammar is in English.** Never use Arabic during normal chat, explanations, planning, or any non-content interaction.
- **Arabic is reserved exclusively for content creation** — scripts, titles, descriptions, tags, thumbnail text, and anything that goes into a video for the GameySins Arabic-speaking audience.
- Do not switch to Arabic for emphasis, friendly rapport, or as a greeting. English only, always.
- This preference applies globally across ALL tasks and skills — not just content-creation workflows.

## Pitfalls

- Google Flow automation is BLOCKED — paste-ready prompts only
- YouTube OAuth needs OOB flow (not run_local_server)
- Don't describe Ammar in prompts — use "Using reference image of Ammar"
- No green, purple, orange, amber, or soft red
- **CLI RTL reversal:** Terminal-facing output (idea titles, sections) must use English-only. Mixed Arabic/English on the same line flips randomly in the terminal. Keep Arabic confined to the script block.
- **Research must be visible:** Use browser_navigate directly. The user called this out — do NOT use delegate_task for trend research. Let them see the sites being checked.
- **Google Trends gaming category often returns empty** — the "Hobbies and Leisure" category frequently shows no trending data. When this happens, skip to Steam pages and game-specific research. Do not waste time refreshing or changing filters.
- **Google News search blocks automated browsers** — direct Google News searches hit a CAPTCHA/sorry page. Use IGN and PC Gamer for news instead of Google News search.
- **Steam sale events are high-value hooks** — discount badges and "part of a sale" banners on Steam store pages are strong "why now" angles for video ideation. Always check for active sales.
- **Bot detection is aggressive** — IGN and PC Gamer work but Google products (Search, Trends) and Reddit reliably block headless browsers. Stick to the source list above.
- **Daily agent must think small** — the channel averages 16-136 views. Do NOT recommend viral-strategy content or multi-day productions. Think "what can Ammar film in one evening."
- **Security blocks pipe-to-interpreter:** Security guardrails block commands like `curl | python3` or `wget -O- | bash` with a HIGH alert. In cron job context, these blocked commands waste runtime and API budget. Use `browser_navigate` exclusively for web research — never terminal-based `curl`/`wget` to fetch and process HTML.
- **Cron job skill loading:** Do NOT pass `--skills video-prep-agent` or `--skills youtube-packaging` when creating cron jobs. Interactive skills' trigger conditions fire in cron context and their multi-step workflows (script writing, kanban tasks, full YouTube packages) take over the agent's turn budget. All context must be inlined in the prompt.
- **Cron delivery fallback:** If a cron job's deliver target fails to route (e.g. "origin" from a Discord thread), the output is still saved to `~/.hermes/cron/output/<job_id>/<timestamp>.md`. Always check this directory after a test run before declaring the job broken.

## Reference Files

- **`references/research-sites.md`** — Research source links and notes for global gaming trends
- **`references/gameysins-channel-profile.md`** — Full GameySins channel analytics, video performance data, audience profile, and content strategy insights (genuine data from May 2026 YouTube page scan)
- **`references/social-links.md`** — The exact social links block to paste into every description. NEVER omit or replace with a placeholder.
