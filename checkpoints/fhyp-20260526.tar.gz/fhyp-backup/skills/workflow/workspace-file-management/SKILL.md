---
name: workspace-file-management
description: "Governs where and how files are created, organized, and archived in the user's D: drive workspace. Prevents root-level mess and enforces the input/output protocol."
category: workflow
trigger_phrases:
  - organize files
  - create folder
  - where should I put this
  - clean up the workspace
  - input/output protocol
  - move folder
  - don't make a mess
  - file management
  - restructure
  - arrange my folders
  - hyperframe
  - b-roll
  - broll
  - composition
  - generate video
  - render
  - file path
  - output directory
  - where to save
  - new project
---

# Workspace File Management Protocol

## THE GOLDEN RULE

**`D:\Hermes project\` is the ONLY workspace on the user's D: drive.**

I NEVER write files or create folders anywhere else on the drive. Zero exceptions.

## The Two-Zone System

```
D:\Hermes project\
├── Git/          (system tool — untouched, leave as-is)
├── input/        (READ ONLY for me)
│   └── MANIFEST.md
└── output/       (my ONLY write zone)
    └── README.md
```

### `input/` — READ ONLY
- **Purpose:** User drops new work here for me to process. Also holds the raw archive of everything already done.
- **My permissions:** Read only. I NEVER create, modify, or delete files in input/.
- **Contains:** MANIFEST.md (catalog of what's inside) + raw source folders from past work.
- **User puts:** Folders, files, screenshots, voice notes, any source material they want me to work on.

### `output/` — Write Zone
- **Purpose:** My organized, categorized, structured output. The only place I create files and folders.
- **My permissions:** Full write authorization.
- **Contains:** Clean categorized structure with README.md at root explaining the hierarchy.

## Root-Level Cleanliness Rule

The root of `D:\Hermes project\` stays clean. Only these belong:
- `Git/` — system Git bundle (untouched)
- `input/` — the read-only archive/drop zone
- `output/` — the write zone

Every other folder belongs inside `input/` (as raw archive) or `output/` (as organized content).

## Output Structure Convention

```
output/
├── videos/                    # Finished rendered content
│   ├── shorts/{category}/     # Short-form videos by type
│   └── projects/              # Full-length video projects
├── projects/{name}/           # Complete channel-scale projects
├── scripts/                   # Active scripts (ready to use)
│   ├── {name}.py              # Individual scripts
│   └── archive/               # Historical scripts collection
├── archive/                   # Reference/historical data
│   ├── config-backups/
│   ├── knowledge-exports/
│   ├── vault/
│   └── processing-metadata/
├── temp/                      # Active staging/processing area
└── assets/                    # Clean reusable assets (fonts, templates, etc.)
```

## When the User Says "Organize / Restructure"

1. **Survey everything** at root level and inside input/
2. **Classify each folder** — is it finished work? project shell? temp? system?
3. **Move originals into `input/`** — raw archive, untouched
4. **Build clean categories in `output/`** — structured, deduplicated, labeled
5. **Write MANIFEST.md inside `input/`** — what's archived and where it went
6. **Write README.md inside `output/`** — explain the structure
7. **Log the decision** in Hermes-Vault/decisions/ — date, what moved, protocol rules

## When Creating New Files/Folders

1. **Everything goes in `output/`** — input/ is off-limits for writes
2. **Use the category structure** — don't dump at root. Match the existing hierarchy (videos/, projects/, scripts/, archive/, temp/, assets/)
3. **If unsure where something belongs** — create a subfolder under the closest category. Explain in README if needed.
4. **Temp/staging work** goes in `output/temp/` — not scattered at root, not in input/

## Anti-Patterns (DON'T)

- Write ANYTHING to `D:\\` itself or `D:\\Hermes-Vault\\` or any other D: path outside `D:\\Hermes project\\`
- Create folders or files in `input/` — it's read-only for me
- Dump files at the root of `D:\\Hermes project\\` — keeps it clean
- Create competing output structures — the conventions above are the canon
- Duplicate large files between input/ and output/ unless the user asked for a working copy in output/
- Trust hardcoded file paths in other skills — many skill files (especially content-creation/video-generation ones) reference old conventions like `D:\\hyperframe output\\`. Those paths are DEPRECATED. This protocol is the source of truth.

## Cross-Reference: Skills That Reference File Paths

**Before creating any files, check if the skill you loaded has hardcoded paths.** If it references `D:\\hyperframe output\\`, `D:\\output\\`, or any path outside `D:\\Hermes project\\`, the skill is outdated — follow THIS protocol instead and note the mismatch.

Known skills with deprecated hardcoded paths (patched 26-May-2026):
- `video-generation/hyperframes-broll` — had `D:\\hyperframe output\\` references, now updated to `output/videos/hyperframes/`

When loading any content-creation or video-generation skill, always audit its file path references against this protocol. If you find mismatches, patch the skill immediately.