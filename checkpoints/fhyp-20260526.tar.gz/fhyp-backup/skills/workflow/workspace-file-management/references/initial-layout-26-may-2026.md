# Workspace Layout — 26 May 2026

Established during the `workspace-file-management` skill creation session.

## Root of D:\Hermes project\
```
Git/          (system git bundle — left untouched)
input/        (all raw originals moved here)
output/       (organized structure built here)
```

## What Was Moved into input/
| Original Folder | Size | Why |
|----------------|------|-----|
| GameySins_Shorts/ | 0B | GameSins short-form project shell |
| cliply_output/ | 73MB | 3 rendered viral clips |
| cliply_temp/ | 65MB | Raw YouTube processing temp files |
| quick-facts-channel/ | 15MB | Full QFC project |
| hermes-backup/ | 220KB | Hermes configs + 31 scripts |
| agent-export/ | 36KB | Knowledge export docs |
| blobs/ | 0B | Empty placeholder |
| Hermes-Vault/ | 4KB | Small vault copy |

## Output Structure Built
```
output/
├── videos/shorts/viral-clips/    — 3 mp4 clips
├── projects/quick-facts-channel/ — full QFC project tree
├── projects/gameysins-shorts/    — GameSins project shell
├── scripts/archive/              — 31 renamed scripts from hermes-backup
├── scripts/pipeline.py           — QFC pipeline (active)
├── scripts/alerter.py            — QFC alerter (active)
├── scripts/uploader.py           — QFC uploader (active)
├── scripts/status_check.py       — QFC status check (active)
├── scripts/daily.sh              — QFC daily runner (active)
├── archive/config-backups/       — Hermes .yaml/.json/.txt backups
├── archive/knowledge-exports/    — 3 files (AGENTS.md, knowledge.md, README.md)
├── archive/vault/                — Hermes-Vault copy
├── archive/cliply-processing/    — info.json metadata
├── temp/                         — empty (staging area)
└── assets/                       — empty (reusable assets)
```

## Protocols Established
- **input/ is READ ONLY** for the agent — never writes there
- **output/ is write zone** — all file/folder creation happens here
- **Root stays clean** — only Git/, input/, output/ at top level
- **Manifest + README** at each zone root for discoverability