---
name: pre-task-environment-check
description: Before starting any task, audit what already exists — MCPs, cron jobs, scripts, skills — to avoid rebuilding from scratch.
category: workflow
trigger_phrases:
  - any task that involves automation, pipeline, cron, MCP, scripts, or tools the user already has
---

# Pre-Task Environment Check

**WHEN:** Before starting ANY task. Every. Single. Time.
**WHY:** The user has called this out explicitly: "you don't look for the actual available MCPs and available tools, you always create things from scratch, and you are not aware of the setup and the environment you are in." Building from scratch when infrastructure exists is the #1 frustration. Do the audit BEFORE proposing any solution.

## ⚠️ MANDATORY: STOP. AUDIT FIRST.

Do NOT start building, coding, or suggesting solutions until you have completed ALL steps below. The user's top complaint is that you skip this and go straight to creating things.

## Quick Audit (do ALL in order — do not skip any section)

### 1. Cron Jobs — ALWAYS check before user mentions them
```bash
cronjob action='list'
```
**MUST CHECK:**
- `last_status` — was the job ok or error?
- `last_run_at` — did it actually fire when expected?
- `last_delivery_error` — was the notification delivered to the user?
- `last_delivery_error` = silent failures the user never saw

**Cron delivery pitfalls (the user complained about this):**
- `deliver: "local"` = saved to server, user never sees it in Discord/Telegram
- `deliver: "discord"` without channel ID = goes to home channel, not a specific thread
- `no_agent: true` jobs with scripts that produce no stdout = silent (user sees nothing)
- `[SILENT]` in last_status = delivery suppressed, not a failure

Fix: change `deliver` to `"origin,all"` to fan out to ALL connected channels, or target a specific Discord DM (`discord:CHANNEL_ID:THREAD_ID`).

Don't create duplicate cron jobs. Check existing ones first.
- Script-based jobs: `script` path must be relative to `~/.hermes/scripts/`
- For deep debugging: read session files at `~/.hermes/sessions/session_cron_<jobid>_*`

### 2. MCP Servers
```bash
hermes mcp list
curl -s http://172.23.240.1:3000/health   # NotebookLM MCP
```

**Prerequisite:** `pipx inject hermes-agent mcp` (missing SDK causes all MCPs to silently fail).
**Config:** Edit `~/.hermes/config.yaml` directly under `mcp_servers:` (CLI `hermes mcp add` is buggy in v0.14.0).

**⚠️ MCP conflict check:** Before adding a new MCP that overlaps with an existing integration (e.g., a Notion MCP when Zapier already handles Notion, or a YouTube MCP when another tool manages uploads), ask the user. Redundant MCPs bloat context, create tool-name collisions, and confuse the agent. Never add an MCP that duplicates functionality the user said is already working.

**🪚 Web research fallback when web/firecrawl/browser are all down:**
When `web_search` returns "no web search provider configured", Firecrawl MCP is unreachable, and the browser CDP isn't connected — all three can fail simultaneously. In that case, use `curl` directly on GitHub raw content:
- **awesome-mcp-servers repo:** `curl -sL "https://raw.githubusercontent.com/punkpeye/awesome-mcp-servers/main/README.md"`
- Then grep with category keywords: `| grep -B1 -A3 -E "youtube|notion|social.*media"`
- The README is ~700KB, so pipe through `head` or grep to avoid flooding output.
- For a specific MCP's setup instructions: `curl -sL "https://raw.githubusercontent.com/<owner>/<repo>/main/README.md" | head -150`
- For release assets (binary downloads): `curl -sL "https://api.github.com/repos/<owner>/<repo>/releases/latest" | grep browser_download_url`
- Works with any public GitHub repo. No API key, no rate limit for raw content.
**Full ref:** `references/curl-github-fallback.md` (category anchor list, branch fallback, release asset download).
**Full ref:** `hermes-agent` skill → `references/mcp-config-format.md`

**⚠️ `hermes gateway restart` may time out** (30s foreground timeout). After timeout the command seems to hang — the gateway does restart eventually. For a reliable restart, use systemctl directly:
```bash
systemctl --user restart hermes-gateway.service
sleep 2
systemctl --user status hermes-gateway.service
```
After any gateway restart, always check that dependent services survived:
  - **NotebookLM HTTP server** — `curl -s http://172.23.240.1:3000/health`
  - **Paperclip** — `curl -s http://127.0.0.1:3100/api/health`
  - **SearXNG** — `curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8888/` (expect 200)
Both are in the same cgroup and may be killed when the gateway process tree is replaced. SearXNG has a keepalive cron that auto-restarts within 5 min.

**Per-server verification (call at least one tool from each MCP to confirm it's alive):**

| Server | Test Tool | Notes |
|--------|-----------|-------|
| better-notion | `mcp_better_notion_workspace(action='info')` | Should return workspace details |
| notebooklm | `mcp_notebooklm_server_health()` | Must see `"status": "ok"`. If unreachable, start server from Windows CMD: `cd /d D:\\notebooklm-mcp && set BROWSER_CHANNEL=chrome && npm run start:http` |
| promptpilot | `mcp_promptpilot_list_models()` | Should list 15+ image models |
| unclick | `mcp_unclick_keychain_status()` or similar | Should connect (may warn about missing SUPABASE_URL — that's fine) |
| piapi | No exposed MCP tools (v1.0.0 confirmed) | Compiled JS registers zero tools. Server process starts but offers nothing to call. Gateway may retry handshake every ~5 min and log warnings. |
| gemini-image | 6 tools: gemini_start_chat, gemini_chat, gemini_generate_image, gemini_upload_file, gemini_analyze_url, gemini_reset | ✅ FIXED and working (23-May-2026). GEMINI_PSID + GEMINI_PSIDTS set in config.yaml. Chrome v20 encryption makes automated extraction from WSL impossible — get both from DevTools (Application → Cookies → gemini.google.com) and paste manually. Use for image generation — pollinations now requires auth. |
| searxng-pipx | `mcp_searxng_web_search(query='test')` | Thin MCP wrapper (`pipx install searxng`). Connects to SearXNG instance URL specified in args. Public instances rate-limit (429). Point to self-hosted at `http://127.0.0.1:8888`. |

**Known MCP issues (checked 23-May-2026):**
- **notebooklm HTTP server** often stops after Windows restart — check first, start if down
- **piapi** has zero registered tools in v1.0.0 — confirmed compiled JS doesn't register any MCP tools
- **gemini-image** ✅ FIXED — both GEMINI_PSID and GEMINI_PSIDTS set, working. Use for image generation.
- **Duplicate MCP processes** accumulate when gateway respawns children without killing old ones. After hours of uptime, 2-3 copies of each MCP can persist. Check with `ps aux | grep -E "(better-notion|piapi|unclick|promptpilot|notebooklm)" | grep -v grep` and compare start times. Clean up by killing older PIDs or restarting gateway.

### Health Audit Bonus — Full-Gamut System Check

When the user asks to "review everything" or "make sure everything works," do the full audit above PLUS:

1. **Test every MCP that has tools** — call one tool from each (workspace for better-notion, list_models for promptpilot, server_health for notebooklm, keychain_status for unclick)
2. **Force-run failing crons** — if a cron has `last_status: error`, run its script manually to confirm it's healthy
3. **Check gateway process tree** — look for duplicate/orphaned MCP children (`ps aux | sort by time`)
4. **Check system resources** — `df -h /home/ammar`, `free -h`, `uptime`
5. **Check heartbeat log** — `tail -3 ~/.hermes/logs/heartbeat.log`
6. **Verify cron delivery** — check `last_delivery_error` on every cron; silent "local" deliveries that should be "discord" are the most common gap
7. **Report traffic-light style** — GREEN/YELLOW/RED per component with actionable items
8. **Re-test after applying fixes** — after making any config change (env vars, disabling MCPs), restart the gateway then re-run the MCP tool tests from step 1 to confirm the fix actually worked. **Critical: gateway restart kills dependent services from the same cgroup.** After restart, check:
   - **SearXNG** — `curl -s http://127.0.0.1:8888/` (expect 200). If dead, restart: `cd /home/ammar/searxng && source venv/bin/activate && SEARXNG_SETTINGS_PATH=/home/ammar/searxng/settings-user.yml nohup python3 -m searx.webapp > server.log 2>&1 &`
   - **NotebookLM HTTP server** — `curl -s http://172.23.240.1:3000/health` → if down, restart from Windows CMD: `cd /d D:\\notebooklm-mcp && set BROWSER_CHANNEL=chrome && npm run start:http`
   - **Paperclip** — `curl -s http://127.0.0.1:3100/api/health` → if down, restart: `node /home/ammar/.npm/_npx/43414d9b790239bb/node_modules/@paperclipai/server/dist/index.js`

### 3. Existing Scripts & Skills
```bash
ls ~/.hermes/scripts/
ls ~/scripts/
skills_list
```
Don't rewrite what exists. Load matching skills with `skill_view()`.

**SearXNG MCP note:** The pipx `searxng` package is a thin MCP wrapper that connects to a SearXNG instance — NOT the actual search engine. A self-hosted SearXNG engine runs at port 8888 from `/home/ammar/searxng/` with keepalive cron every 5 min. See `hermes-agent` → `references/searxng-mcp-entry.md` for setup details.

### 4. Memory / Fact Store
```bash
fact_store action='probe' entity='<relevant>'
fact_store action='search' query='<topic>'
```

### 5. Discord Delivery
- `DISCORD_HOME_CHANNEL` = home for proactive messages
- For DMs: find DM channel ID, NOT user ID
- @mention `<@525784408930910218>` triggers push notifications
- Full ref: `hermes-agent` skill → `references/notification-routing.md`

### 6. Paperclip Agent Profiles — 🔴 CRITICAL — prevents burning paid API credits

ALWAYS check this before any Paperclip-related work. The user explicitly caught agents running on paid opencode-go instead of free local/OpenRouter models.

**⚠️ Paperclip dies on gateway restart.** The heartbeat script (`~/.hermes/scripts/heartbeat_check.sh`) checks Paperclip health every 5 minutes and auto-restarts it if down — so Paperclip comes back within 5 minutes even if you forget. But if you need it immediately after a gateway restart, restart it manually:
```bash
node /home/ammar/.npm/_npx/43414d9b790239bb/node_modules/@paperclipai/server/dist/index.js
```
Then verify: `curl -s http://127.0.0.1:3100/api/health`

**⚠️ Paperclip comment API:** Use `body` field (not `content`) when posting comments. POST `{"body": "text"}` to `/api/issues/{id}/comments`.

**🔴 GATEWAY RESTART KILLS PAPERCLIP.** If Paperclip was started from the same npx/shell session as the gateway, a `hermes gateway restart` or `systemctl --user restart hermes-gateway.service` WILL kill it (systemd terminates the entire control group). Always check Paperclip health after any gateway restart.

**To restart Paperclip:**
```bash
node /home/ammar/.npm/_npx/43414d9b790239bb/node_modules/@paperclipai/server/dist/index.js
```

**Paperclip agent stuck-state fix:** Agents frequently get stuck in "running" status with no active Hermes process. Fix:
```bash
curl -s -X PATCH http://127.0.0.1:3100/api/agents/AGENT_ID -H "Content-Type: application/json" -d '{"status": "idle"}'
curl -s -X POST http://127.0.0.1:3100/api/agents/AGENT_ID/wakeup -H "Content-Type: application/json" -d '{}'
```

**CEO delegation limitation:** CEO agents on local models (qwen2.5-coder-7b-instruct, gemma-4-e2b) and even free OpenRouter models consistently fail at multi-step delegation (creating sub-issues, waking workers, monitoring). Symptoms: CEO marks issues as "done" or "blocked" with comments claiming delegation happened but zero sub-issues actually created. **Direct worker assignment works better** — create issues directly assigned to specialist agents rather than routing through the CEO.

**Paperclip API gotcha:** Comment field is `body` not `content`.
```bash
# CORRECT:
curl -X POST /api/issues/{id}/comments -H "Content-Type: application/json" -d '{"body": "text"}'
# WRONG (returns 400):
curl -X POST /api/issues/{id}/comments -H "Content-Type: application/json" -d '{"content": "text"}'
```
```
POST /api/issues/{id}/comments  →  {"body": "text here"}
POST /api/issues/{id}/comments  →  {"content": "text"}  # WRONG — returns 400
```

**Paperclip agents are unreliable for production use.** The Hermes adapter integration has consistent timeout/execution issues. For now, it's better to execute complex production tasks directly using MCP tools (Gemini images, HyperFrames b-roll, NotebookLM, Notion) rather than fighting Paperclip automation. Paperclip is archived until a more capable orchestration setup is available.

**Agent Profiles (23-May-2026):**
- `default` → opencode-go deepseek-v4-flash → **PAID** — NEVER for agents
- `paperclip-agent` → LM Studio qwen2.5-coder-7b-instruct → **FREE** — workers
- `ceo-free` → OpenRouter gemma-4-31b-it:free → **FREE** — CEO orchestration
- `assistant-local` → LM Studio qwen2.5-coder-7b-instruct → **FREE** — assistant use

**RED FLAG:** Any agent showing `profile: default` → falls back to main Hermes config → uses **opencode-go (paid)**.

**To fix an agent on wrong profile:**
```bash
curl -s -X PATCH http://127.0.0.1:3100/api/agents/AGENT_ID -H "Content-Type: application/json" -d '{"adapterConfig": {"profile": "paperclip-agent", "provider": "auto"}}'
```

API endpoint: `/api/agents/:id` (singular).

**Heartbeat auto-restart safety net:** The heartbeat script (`~/.hermes/scripts/heartbeat_check.sh`) now checks Paperclip health every 5 minutes and auto-restarts it from the cached npx path if down. Confirmed working — log entry: `[OK] Paperclip: running and responding`. This catches Paperclip outages within 5 minutes even if you forget to restart it manually after a gateway restart.

### 7. Brand Assets

Brand assets for GameySins (logos, banners, intro/outro) are at:
```
/home/ammar/hermes-brand-assets/
```
Update agent instructions at `~/.paperclip/.../instructions/AGENTS.md` to reference these paths so agents use consistent branding.

## Key Infrastructure

| Resource | Location | Notes |
|----------|----------|-------|
| NotebookLM MCP | `172.23.240.1:3000` | Use stdio-http-proxy, not raw CDP. Auto-start from WSL: `powershell.exe -Command "Start-Process ... npm run start:http"` |
| SearXNG | `http://127.0.0.1:8888` | Self-hosted meta-search engine. Cloned from github.com/searxng/searxng at `/home/ammar/searxng/`. Python venv. Runs Google + DuckDuckGo searches. Keepalive cron every 5 min. Dies on gateway restart — auto-recovers via cron. MCP wrapper: `pipx searxng`. |
| LM Studio | `192.168.100.17:1234` | **Primary: qwen2.5-coder-7b-instruct** (Q4_K_M, ~4.5GB VRAM, fits RTX 3050 6GB entirely—no system-RAM spill = fast). Best function/tool calling for its size class. Also loaded: qwen3.5-9b (7GB min VRAM, spills to RAM, slower), gemma-4-e2b (weaker tool calling), nomic-embed-text. **Recommend: qwen2.5-coder-7b-instruct for all local agent work.** Arabic support is solid. |
| Paperclip | `http://localhost:3100` | AI company builder, GameSins board |
| Discord DM | `1506939046843125811` | Ammar's home channel |
| Free APIs | Groq, OpenRouter free, Perplexity free | Preferred over all others (zero cost) |
| Paid fallback | `deepseek-v4-flash` via opencode-go | 128K context, last resort only |
| Timezone | Asia/Dubai (GMT+4) | |
| OS | WSL, D: drive at `/mnt/d/` | Windows at `/mnt/c/Users/ammar/` |

**MCP and Paperclip details are NOT here.** See `hermes-agent` skill → `references/mcp-config-format.md` and `references/paperclip-setup.md`.
**Paperclip content production workflow →** `hermes-agent` → `references/paperclip-content-workflow.md` (covers delegation, output-to-Notion, channel identity, anti-patterns).

## Delegation

Use `delegate_task` with `tasks` array (up to 3 concurrent) for parallel independent work. The user explicitly called this out — don't run parallel research/checks sequentially.

## Anti-Patterns (DON'T)

- Go straight to building without completing ALL 7 audit steps above first
- Write a new script when one exists in `~/.hermes/scripts/` or `~/scripts/`
- Use raw Chrome CDP when the NotebookLM MCP can handle it
- Create duplicate cron jobs
- Build HyperFrames from scratch (use `hyperframes` + `hyperframes-cli` skills)
- Do parallel research sequentially (use `delegate_task`)
- Assume a cron is broken without checking session files first
- Do Paperclip work directly (write scripts, generate content) — create issues and wake agents instead
- Save content deliverables to local files — they must go to Notion under the Main Brain
- Let CEO agents execute work — CEO must delegate to specialist agents (Researcher, Script Producer, SEO)
- Confuse GameSinsTech (tech channel) with GameySins Gaming — separate channels, separate content scope
- Use the wrong Notion integration — the token in `notion_token.json` may belong to a different account than expected. Always verify which Notion integration the user wants you to use before creating pages. Prefer Zapier Notion over direct API tokens.
- Assume Paperclip survived a gateway restart — it dies with the gateway cgroup. Always check Paperclip health after any gateway restart: `curl -s http://127.0.0.1:3100/api/health`
- Use npx to restart Paperclip — it fails with "could not determine executable to run". Use the cached node path: `node /home/ammar/.npm/_npx/43414d9b790239bb/node_modules/@paperclipai/server/dist/index.js`
- Use `hermes gateway restart` for restarting — it times out at 30s. Use `systemctl --user restart hermes-gateway.service` directly, then check Paperclip + NotebookLM after
- Start NotebookLM HTTP server with `npm run start:http` from PowerShell (PowerShell version doesn't support `&&`). Use instead: run `powershell.exe -Command "Set-Location D:\notebooklm-mcp; $env:BROWSER_CHANNEL='chrome'; node dist/http-wrapper.js"` via terminal(background=true)
- Use `body` not `content` in Paperclip comment API: `POST /api/issues/{id}/comments {"body": "text"}` — `{"content": "text"}` returns 400
- Repeat MCP/Paperclip/NotebookLM details here — those belong in their respective skills' references
