# Curl-Based Web Research Fallback

**When to use:** `web_search` returns "no web search provider configured", Firecrawl MCP is unreachable, and browser CDP isn't connected. All three can fail at once.

## Technique: curl on GitHub raw content

Public GitHub repos serve raw file content without auth or rate limits. This is the fastest fallback for researching MCP servers, open-source tools, and README-based documentation.

### 1. Search the awesome-mcp-servers repo (2500+ MCPs)

```bash
# Fetch the full README (~700KB)
curl -sL "https://raw.githubusercontent.com/punkpeye/awesome-mcp-servers/main/README.md"

# Filter by category keywords
curl -sL "https://raw.githubusercontent.com/punkpeye/awesome-mcp-servers/main/README.md" \
  | grep -B1 -A3 -E "youtube|notion|social.*media|tts|text-to-speech|gaming|video|translat"

# Find the section header + entries for a specific category
curl -sL "https://raw.githubusercontent.com/punkpeye/awesome-mcp-servers/main/README.md" \
  | grep -A200 "### 📂 <a name=\"browser-automation\"></a>Browser Automation" \
  | grep -B1 -A3 "^- \[" | head -60
```

Category anchors in the README are HTML-anchored (e.g., `#browser-automation`). Known anchors:
- `#social-media` → social media MCPs
- `#multimedia-process` → video/image/audio MCPs
- `#text-to-speech` → TTS MCPs  
- `#gaming` → gaming MCPs
- `#knowledge--memory` → Notion/Obsidian/memory MCPs
- `#search` → search & scraping MCPs
- `#marketing` → SEO/analytics MCPs
- `#translation-services` → translation MCPs
- `#aggregators` → MCP aggregator servers
- `#code-execution` → code/terminal MCPs

### 2. Read a specific MCP's README for setup instructions

```bash
# Read first 150 lines of README (enough for install + config)
curl -sL "https://raw.githubusercontent.com/<owner>/<repo>/main/README.md" | head -150

# Try master branch if main doesn't exist
curl -sL "https://raw.githubusercontent.com/<owner>/<repo>/master/README.md" | head -150
```

### 3. Find latest release assets (binary download URLs)

```bash
curl -sL "https://api.github.com/repos/<owner>/<repo>/releases/latest" \
  | grep -E '"tag_name|"browser_download_url"' | head -20
```

Then download:
```bash
# Linux amd64 binary from release
curl -sL "https://github.com/<owner>/<repo>/releases/download/v1.2.3/<binary>_linux_amd64.tar.gz" -o /tmp/pkg.tar.gz
```

### 4. Limitations

- Works only for **public GitHub repos**
- Does **not** search the web — only known repos
- 700KB+ responses get truncated in terminal output (pipe through `head`/`grep`)
- Raw README.md has no formatting, just markdown
- No structured search (no semantic understanding, just regex)
