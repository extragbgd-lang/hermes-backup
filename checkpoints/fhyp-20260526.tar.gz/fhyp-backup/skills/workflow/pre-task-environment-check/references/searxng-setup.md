# SearXNG Setup on WSL

## Key Discovery (25-May-2026)

There are TWO things named "searxng" — they are NOT the same:

| Package | Install | What it is |
|---------|---------|-----------|
| `pipx install searxng` → `~/.local/bin/searxng` | pipx | Thin **MCP wrapper** that connects to an existing SearXNG instance. Version `0.0.0.dev0`. Not the actual search engine. |
| `github.com/searxng/searxng` | git clone + Docker/manual | The actual **SearXNG meta-search engine**. Needs Docker or manual Python setup. |

## Current State
- Docker daemon is NOT accessible from this WSL instance (Docker Desktop not running on Windows)
- Public SearXNG instances all return HTTP 429 (rate-limited)
- The pipx MCP wrapper is installed and configured in Hermes (`mcp_servers.searxng`) pointing to `https://searx.be`
- It's connected but yields empty results due to rate-limiting at public instances

## Config Format (in Hermes config.yaml under `mcp_servers:`)
```yaml
searxng:
  command: /home/ammar/.local/bin/searxng
  args: ["--instance-url", "https://searx.be"]
```

## Practical Free Alternative (no Docker needed)
Google Custom Search API — 100 free queries/day, needs API key + Search Engine ID:
- Signup: https://programmablesearchengine.google.com/
- Then configure web-researcher-mcp with `GOOGLE_CUSTOM_SEARCH_API_KEY` + `GOOGLE_CUSTOM_SEARCH_ID`

## If Docker becomes available
```bash
docker run -d --name searxng -p 8888:8080 searxng/searxng
```
Then point the MCP wrapper to `http://localhost:8888`.