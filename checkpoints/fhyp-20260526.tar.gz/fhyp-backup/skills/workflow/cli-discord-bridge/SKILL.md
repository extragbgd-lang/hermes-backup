---
title: cli-discord-bridge
name: cli-discord-bridge
description: Bridge CLI sessions to Discord for interactive user input. When the agent needs clarification or approval from Ammar while running in CLI mode, notify on Discord and handoff the session so Ammar can respond from Discord.
trigger_conditions:
  - Agent needs to ask Ammar a question (clarify) during a CLI session
  - Agent needs approval/permission for a flagged command during CLI
  - Ammar wants Discord notifications for agent questions and the ability to respond via Discord
---

# CLI ↔ Discord Bridge for User Input

When Ammar is using you via CLI and you need to ask him a question or get approval, use this workflow to bridge to Discord so he gets a push notification AND can respond there.

## Prerequisites

- Discord gateway must be running (`hermes gateway status`)
- `DISCORD_HOME_CHANNEL` must be set in `~/.hermes/.env` (currently: `1506939046843125811`)
- `discord.free_response_channels` must include the home channel (configured)
- `discord.allowed_channels` must include the home channel (configured)

## Workflow: Need User Input from CLI

When you need to ask Ammar a question or need his input:

1. **Save pending context to memory** — store what you're waiting for so any session (CLI or Discord) can pick it up
2. **Send the question to Discord** — use `send_message(target='discord', message='...')` to send the question to his home channel. Make it clear you need his input.
3. **Handoff the session** — tell Ammar: *"I need your input on this — type `/handoff discord` and the conversation will move to Discord so you can respond there with notifications"*
4. If he types `/handoff discord`, the session transfers to Discord with full context
5. Continue in Discord session, using `send_message` back if you need to relay results to CLI

## Workflow: Need Approval from CLI

When a command needs approval:

1. Set `approvals.mode: smart` (already configured) — routine commands auto-approve
2. For genuinely dangerous commands that escalate, the system shows a CLI dialog
3. Before the dialog appears, send a Discord notification: *"⚠️ I need your approval to run [command]. Type /handoff discord to see and respond"*
4. Wait for Ammar to either type in CLI or handoff to Discord

## Automated Pattern: Cron-Based Notification Monitoring

Beyond manual handoff and proactive send_message, set up cron jobs for **automated monitoring** that DMs the user when something needs attention.

### Typical setup:
```yaml
# Cron job that routes to home channel = DM
schedule: "*/5 * * * *"
deliver: "discord"              # Routes to DISCORD_HOME_CHANNEL
skills: ["kanban"]              # Load relevant skill
prompt: "Check kanban boards for blocked tasks and notify <@USER_ID>"
```

### Prerequisites for DMs to work:
1. `DISCORD_HOME_CHANNEL` must be set to the actual **DM channel ID** (not user ID)
2. To find the DM channel ID: call Discord's API `POST /users/@me/channels` with `recipient_id`
3. Verify the channel type: `data['type'] == 1` means DM
4. See `infrastructure/hermes-agent` skill → `references/discord-dm-setup.md` for full technique

### When to use cron monitoring vs manual handoff:
- **Cron monitoring** — check for new blocked tasks, system health, watch for state changes (runs autonomously, notifies only when there's something)
- **Manual handoff** — when you need interactive back-and-forth with the user to resolve a specific issue
- **Proactive send_message** — mid-session when you hit a clarify/approval wall and need user input right now

## Workflow: Ammar Responds on Discord

When Ammar responds on Discord (either after handoff or in a new Discord session):

1. Check memory for pending context from a CLI session
2. If there's pending context, use it to continue where the CLI session left off
3. Process Ammar's input and respond in Discord
4. If needed, handoff back: "Type /handoff cli and I'll resume there" (not yet supported — instead, just tell him to continue in Discord or start fresh in CLI)

## Important Notes

- The `/handoff discord` command is typed by Ammar, NOT called by the agent
- Handoff creates a 1440-min auto-archive thread under the Discord home channel
- The same session ID persists — full transcript, tool calls, and all context are preserved
- After handoff, the conversation lives on Discord. Ammar can resume CLI later with `/resume <session-id>`
